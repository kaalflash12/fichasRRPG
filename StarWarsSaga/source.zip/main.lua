-- Star Wars Saga Edition 7.3.4
-- Garante que uma atualização instalada em uma sessão já aberta do Firecast
-- recarregue os módulos mecânicos do próprio plugin, sem exigir fechar o programa.
local modules={
"swse_form_context.lua","swse_updater.lua","swse_legacy_import.lua",
"swse_nav_layout.lua","swse_nav_layout_spec.lua",
"swse_runtime_geometry.lua","swse_vehicle_layout.lua","swse_vehicle_layout_spec.lua","swse_theme.lua","swse_hangar.lua","swse_hangar_ui.lua","swse_catalog.lua","swse_catalog_pt.lua","swse_i18n.lua","swse_prereq_510.lua",
"swse_talent_rules_510.lua","swse_talent_rules_620.lua","swse_class_prereq_620.lua",
"swse_progression_620.lua","swse_inventory_equip.lua","swse_builders_350.lua",
"swse_advanced_360.lua","swse_gear_detail_410.lua","swse_parity_410.lua",
"swse_cyberbio_400.lua","swse_extra.lua","swse_extras_320.lua","swse_force_cards_390.lua",
"swse_mods_340.lua","swse_supplement.lua","swse_droid_pt.lua","swse_vehicle_630.lua",
"swse_ptbr_characters.lua","swse_ptbr_gear.lua","swse_ptbr_feats.lua",
"swse_ptbr_talents.lua","swse_ptbr_force.lua"
}
for _,m in ipairs(modules) do
    package.loaded[m]=nil
    package.loaded[string.gsub(m,"%.lua$","")]=nil
end
return true
