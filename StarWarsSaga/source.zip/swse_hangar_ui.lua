local GUI=require('gui.lua')
local Dialogs=require('dialogs.lua')
local Core=require('swse_hangar.lua')
local Theme=require('swse_theme.lua')
local M={}
function M.bind(form)
 local state={owner=nil,current=nil,vehicle=nil,enumerating=false,updating=false,sizing=false,fitTimer=nil}
 form._hangarState=state
 local function root() return form.sheet end
 local function count()
  if form.hangarCount then form.hangarCount.text=tostring(#Core.nodes(root()))..' NAVES' end
 end
 local function detach()
  if state.fitTimer then clearTimeout(state.fitTimer); state.fitTimer=nil end
  if state.vehicle then
   Theme.stopFX(state.vehicle)
   state.vehicle.visible=false
   state.vehicle.parent=nil
   state.vehicle:setNodeObject(nil)
  end
  if form.hangarEditorHost then form.hangarEditorHost.node=nil; form.hangarEditorHost.visible=false end
  if form.hangarShipTitle then form.hangarShipTitle.node=nil end
  state.current=nil
 end
 -- Set the embedded form canvas explicitly whenever its host changes size.
 function form:hangarFitEditor()
  local host=self.hangarEditorHost; local editor=state.vehicle
  if state.sizing or not host or not editor or not state.current then return end
  local w=tonumber(host.width) or 0; local h=tonumber(host.height) or 0
  if w<=0 or h<=0 then return end
  state.sizing=true
  local ok,err=pcall(function()
   editor.align='none'; editor.left=0; editor.top=0
   if math.abs(editor.width-w)>0.5 then editor.width=w end
   if math.abs(editor.height-h)>0.5 then editor.height=h end
   assert(require('swse_vehicle_layout.lua').apply(editor,require('swse_vehicle_layout_spec.lua')))
  end)
  state.sizing=false
  if not ok then self._hangarError=tostring(err) end
 end
 function form:hangarResizeList()
  if not self.hangarList then return end
  local w=math.max(1,(tonumber(self.hangarList.width) or 0)-16)
  for _,item in ipairs(self.hangarList:getChildren()) do
   if item.name=='frmSWSEHangarShipItem' then
    if math.abs(item.width-w)>0.5 then item.width=w end
    local card=item.hangarShipCard
    if card then
     card.align='none';card.left=0;card.top=2;card.width=w;card.height=math.max(1,item.height-4)
    end
   end
  end
 end
 function form:hangarResize()
  if not self.hangarShell or not self.hangarIndexPanel then return end
  if self.hangarShell.width<900 then
   self.hangarIndexPanel.align='top'; self.hangarIndexPanel.height=180
   self.hangarIndexPanel.margins={bottom=8}
  else
   self.hangarIndexPanel.align='left'; self.hangarIndexPanel.width=280
   self.hangarIndexPanel.margins={right=8}
  end
  self:hangarResizeList(); self:hangarFitEditor()
 end
 function form:hangarUpdateVisibility()
  if state.vehicle then
   local show=state.current~=nil and self.pageHangar and self.pageHangar.visible~=false
   state.vehicle.visible=show==true
   self:hangarFitEditor()
   if show then Theme.startFX(state.vehicle,state.current.uiTheme) else Theme.stopFX(state.vehicle) end
  end
 end
 function form:hangarSyncVisual()
  if state.owner==root() and state.current then Core.syncVisual(root(),state.current) end
 end
 function form:hangarSelectShip(node,fromList)
  local owner=root()
  if not owner or state.owner~=owner then return false end
  if node and not Core.belongs(owner,node) then return false end
  if state.current==node then
   Core.select(owner,node)
   if self.hangarEmpty then self.hangarEmpty.visible=node==nil end
   if self.hangarDelete then self.hangarDelete.visible=node~=nil end
   if not fromList and self.hangarList then
    state.updating=true; self.hangarList.selectedNode=node; state.updating=false
   end
   count(); self:hangarUpdateVisibility(); return true
  end
  detach()
  Core.select(owner,node)
  if self.hangarEmpty then self.hangarEmpty.visible=node==nil end
  if self.hangarDelete then self.hangarDelete.visible=node~=nil end
  if not node then count(); return true end
  Core.syncVisual(owner,node)
  local ok,err=pcall(function()
   if not state.vehicle then
    require('FichaRPGmeister/VehicleSheet.lfm.lua')
    state.vehicle=GUI.newForm('frmStarWarsSagaEditionVehicle')
    assert(state.vehicle,'Ficha de nave indisponível')
   end
   -- Bind the ship before parenting so the character never receives vehicle defaults.
   state.vehicle.visible=false
   state.vehicle:setNodeObject(node)
   self.hangarEditorHost.node=node
   state.vehicle.parent=self.hangarEditorHost
   self.hangarEditorHost.visible=true
   self.hangarShipTitle.node=node
   state.current=node
   self:hangarFitEditor()
   state.fitTimer=setTimeout(function()
    state.fitTimer=nil
    if state.owner==root() and state.current==node then self:hangarFitEditor() end
   end,100)
   self._hangarError=nil
   if self.hangarStatus then self.hangarStatus.text='Selecione uma nave para acessar sua ficha.' end
  end)
  if not ok then
   self._hangarError=tostring(err); detach()
   if self.hangarStatus then self.hangarStatus.text='Falha ao abrir nave: '..tostring(err) end
   if self.hangarEmpty then self.hangarEmpty.visible=true end
   return false
  end
  if not fromList and self.hangarList then
   state.updating=true; self.hangarList.selectedNode=node; state.updating=false
  end
  count(); self:hangarUpdateVisibility(); return true
 end
 function form:hangarListSelect()
  if state.updating or not self.hangarList or state.owner~=root() then return end
  local node=self.hangarList.selectedNode
  if node==nil and state.enumerating then return end
  self:hangarSelectShip(node,true)
 end
 function form:hangarRestore()
  if state.owner~=root() or not root() then return end
  Core.ensure(root())
  local node=Core.selected(root()) or Core.nodes(root())[1]
  self:hangarSelectShip(node,false); count()
 end
 function form:hangarBeginEnumeration() state.enumerating=true end
 function form:hangarEndEnumeration() state.enumerating=false; self:hangarResizeList(); self:hangarRestore() end
 function form:hangarAddShip()
  if state.owner~=root() or not root() then return nil end
  local node=Core.add(root())
  self:hangarSelectShip(node,false); count()
  return node
 end
 function form:hangarRemoveSelected()
  local owner=root(); local node=state.current
  if not node or not Core.belongs(owner,node) then return end
  Dialogs.confirmYesNo('Excluir a nave "'..tostring(node.vehicleName or 'Nave')..'" e os dados dela?',function(ok)
   if not ok or root()~=owner or not Core.belongs(owner,node) then return end
   if state.current==node then detach() end
   Core.remove(owner,node)
   self:hangarRestore()
  end)
 end
 function form:hangarClear()
  detach(); state.owner=nil; state.enumerating=false
  if self.hangarEmpty then self.hangarEmpty.visible=true end
  if self.hangarDelete then self.hangarDelete.visible=false end
 end
 function form:hangarInit()
  self:hangarClear(); state.owner=root()
  if self.hangarEmpty then self.hangarEmpty.text='CADASTRE SUA NAVE\n\nClique em + NOVA NAVE.\nA ficha completa aparecerá aqui.' end
  if not root() then return end
  Core.ensure(root()); self:hangarRestore(); self:hangarResize()
 end
 function form:hangarDestroy()
  self:hangarClear()
  if state.vehicle then Theme.resetIndex(state.vehicle); state.vehicle:destroy(); state.vehicle=nil end
 end
 return state
end
return M
