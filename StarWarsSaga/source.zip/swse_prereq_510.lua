local M={}
local CAT=require("swse_catalog.lua")

local function norm(s)
    s=string.lower(tostring(s or ""))
    s=string.gsub(s,"%[","("); s=string.gsub(s,"%]",")")
    s=string.gsub(s,"%-"," ")
    s=string.gsub(s,"%s+"," ")
    s=string.gsub(s,"^%s+",""); s=string.gsub(s,"%s+$","")
    return s
end
M.norm=norm

local function childList(sheet,field)
    if sheet==nil or sheet[field]==nil then return {} end
    return NDB.getChildNodes(sheet[field])
end

function M.hasFeat(sheet,name)
    local w=norm(name)
    for _,x in ipairs(childList(sheet,"chosenFeats")) do
        local a=norm(x.name); local b=norm(x.baseName)
        if a==w or b==w or string.sub(a,1,#w+2)==w.." (" then return true end
    end
    return false
end

function M.hasTalent(sheet,name)
    local w=norm(name)
    for _,x in ipairs(childList(sheet,"chosenTalents")) do
        local a=norm(x.name); local b=norm(x.baseName)
        if a==w or b==w then return true end
    end
    return false
end

local function truthy(v)
    if v==true or v==1 then return true end
    local s=string.lower(tostring(v or ""))
    return s=="true" or s=="1" or s=="yes"
end

function M.trained(sheet,name)
    local w=norm(name)
    for _,x in ipairs(childList(sheet,"campoDasPericias")) do
        if norm(x.nomePericia)==w and (truthy(x.isClass) or truthy(x.speciesTrained)) then return true end
    end
    local talentTraining={
        [norm("Initiative")]={"Force Intuition","Watchful Step"},
        [norm("Perception")]={"Force Perception"},
        [norm("Deception")]={"Force Deception"},
        [norm("Persuasion")]={"Force Persuasion"},
        [norm("Pilot")]={"Force Pilot"},
        [norm("Treat Injury")]={"Force Treatment"},
        [norm("Stealth")]={"White Current Adept"},
        [norm("Use Computer")]={"Hotwire"}
    }
    for _,talent in ipairs(talentTraining[w] or {}) do
        if M.hasTalent(sheet,talent) then return true end
    end
    return false
end

local skillNames={
 "Acrobatics","Climb","Deception","Endurance","Gather Information","Initiative","Jump",
 "Knowledge (Bureaucracy)","Knowledge (Galactic Lore)","Knowledge (Life Sciences)",
 "Knowledge (Physical Sciences)","Knowledge (Social Sciences)","Knowledge (Tactics)",
 "Knowledge (Technology)","Mechanics","Perception","Persuasion","Pilot","Ride","Stealth",
 "Survival","Swim","Treat Injury","Use Computer","Use the Force"
}

local featNames={}
for _,x in ipairs(CAT.feats or {}) do if tostring(x.name or "")~="" then featNames[#featNames+1]=tostring(x.name) end end
table.sort(featNames,function(a,b) return #a>#b end)
local talentNames={}
for _,x in ipairs(CAT.talents or {}) do if tostring(x.name or "")~="" then talentNames[#talentNames+1]=tostring(x.name) end end
table.sort(talentNames,function(a,b) return #a>#b end)
local speciesNames={}
for _,x in ipairs(CAT.species or {}) do if tostring(x.name or "")~="" then speciesNames[#speciesNames+1]=tostring(x.name) end end
table.sort(speciesNames,function(a,b) return #a>#b end)

local attrs={
 {aliases={"str","strength"},field="realFor",label="FOR"},
 {aliases={"dex","dexterity"},field="realDes",label="DES"},
 {aliases={"con","constitution"},field="realCon",label="CON"},
 {aliases={"int","intelligence"},field="realInt",label="INT"},
 {aliases={"wis","wisdom"},field="realSab",label="SAB"},
 {aliases={"cha","charisma"},field="realCar",label="CAR"}
}

local function sizeRank(code)
    local m={f=1,d=2,t=3,s=4,m=5,l=6,h=7,g=8,c=9}
    return m[string.lower(string.sub(tostring(code or "m"),1,1))] or 5
end

local function hasTrait(sheet,needle)
    local all=norm(tostring(sheet.speciesTraitIds or "").." "..tostring(sheet.speciesTraits or ""))
    return string.find(all,norm(needle),1,true)~=nil
end

local function anyCyber(sheet)
    if tonumber(sheet.cyberneticCount or 0)>0 then return true end
    return #childList(sheet,"cyberneticItems")>0
end

local function hasDroidSystemText(sheet,needle)
    local w=norm(needle)
    for _,field in ipairs({"droidSystems","droidLocomotion","droidLocomotions","droidAppendages"}) do
        for _,x in ipairs(childList(sheet,field)) do
            local txt=norm(tostring(x.name or "").." "..tostring(x.namePt or "").." "..tostring(x.detailPt or ""))
            if string.find(txt,w,1,true)~=nil then return true end
        end
    end
    return false
end

local function optionProficiency(sheet,option)
    local o=tostring(option or "")
    if o=="" then return false end
    if M.hasFeat(sheet,"Weapon Proficiency ("..o..")") then return true end
    if M.hasFeat(sheet,"Exotic Weapon Proficiency ("..o..")") then return true end
    if M.hasFeat(sheet,"Exotic Weapon Proficiency") then return true end
    return false
end

local function evalAtomic(sheet,token,option)
    local low=norm(token)
    if low=="" or low=="-" or low=="none" then return true,true end
    local recognized=false
    local ok=true

    -- atributos
    for _,a in ipairs(attrs) do
        for _,alias in ipairs(a.aliases) do
            local n=string.match(low,"%f[%a]"..alias.."%s*([0-9]+)")
            if n~=nil then
                recognized=true
                if tonumber(sheet[a.field] or 0)<tonumber(n) then ok=false end
            end
        end
    end

    -- BBA / nível / Lado Sombrio
    local bab=string.match(low,"base attack bonus%s*%+?%s*([0-9]+)") or string.match(low,"%f[%a]bab%s*%+?%s*([0-9]+)")
    if bab~=nil then recognized=true; if tonumber(sheet.bba or 0)<tonumber(bab) then ok=false end end
    local levelReq=string.match(low,"%f[%a]level%s*([0-9]+)") or string.match(low,"minimum level%s*:?%s*([0-9]+)")
    if levelReq~=nil then recognized=true; if tonumber(sheet.nep or sheet.heroicLevel or 0)<tonumber(levelReq) then ok=false end end
    local dsReq=string.match(low,"dark side score%s*([0-9]+)%s*%+")
    if dsReq~=nil then recognized=true; if tonumber(sheet.darkSideScore or 0)<tonumber(dsReq) then ok=false end end

    -- treinado
    if string.find(low,"trained",1,true)~=nil then
        local foundSkill=false
        for _,sk in ipairs(skillNames) do
            local sn=norm(sk)
            if string.find(low,sn,1,true)~=nil then
                foundSkill=true; recognized=true
                if not M.trained(sheet,sk) then ok=false end
            end
        end
        if string.find(low,"a knowledge skill",1,true)~=nil then
            recognized=true; foundSkill=true
            local any=false
            for _,sk in ipairs(skillNames) do
                if string.find(sk,"Knowledge",1,true)==1 and M.trained(sheet,sk) then any=true end
            end
            if not any then ok=false end
        end
        if not foundSkill and string.find(low,"use the force",1,true)~=nil then recognized=true; if not M.trained(sheet,"Use the Force") then ok=false end end
    end

    -- droide/ciborgue/personagem vivo
    if string.find(low,"not a droid",1,true)~=nil or string.find(low,"living character",1,true)~=nil then
        recognized=true; if sheet.isDroid==true then ok=false end
    elseif string.find(low,"droid or cyborg",1,true)~=nil then
        recognized=true; if sheet.isDroid~=true and not anyCyber(sheet) then ok=false end
    elseif string.find(low,"droid with",1,true)~=nil or low=="droid" or string.sub(low,1,6)=="droid," then
        recognized=true; if sheet.isDroid~=true then ok=false end
    end

    -- espécie
    local current=norm(sheet.racaId or sheet.raca or "")
    for _,sp in ipairs(speciesNames) do
        local sn=norm(sp)
        if low==sn or low==sn.." species" or string.sub(low,1,#sn+1)==sn.."," then
            recognized=true; if current~=sn then ok=false end
        end
    end

    -- tamanho mínimo
    local rank=sizeRank(sheet.sizeCode)
    if string.find(low,"medium or larger",1,true)~=nil then recognized=true; if rank<5 then ok=false end end
    if string.find(low,"small or larger",1,true)~=nil then recognized=true; if rank<4 then ok=false end end

    -- Força / tradição / destino
    if string.find(low,"force sensitive",1,true)~=nil or string.find(low,"force sensitivity",1,true)~=nil then
        recognized=true; if not M.hasFeat(sheet,"Force Sensitivity") then ok=false end
    end
    if string.find(low,"member of sith tradition",1,true)~=nil then
        recognized=true; if norm(sheet.forceTradition or "")~="sith" then ok=false end
    end
    if string.find(low,"member of jedi tradition",1,true)~=nil then
        recognized=true; if norm(sheet.forceTradition or "")~="jedi" then ok=false end
    end
    if low=="destiny" or string.find(low,"has a destiny",1,true)~=nil then
        recognized=true
        if tostring(sheet.destinyName or sheet.destino or "")=="" then ok=false end
    end

    -- traços raciais frequentes
    if low=="rage" or string.find(low,"rage species trait",1,true)~=nil or string.find(low,"ability to rage",1,true)~=nil then
        recognized=true; if not hasTrait(sheet,"rage") then ok=false end
    end
    if string.find(low,"member of nikto subspecies",1,true)~=nil then
        recognized=true
        if string.find(current,"nikto",1,true)==nil then ok=false end
    end
    if string.find(low,"shapeshift species trait",1,true)~=nil then
        recognized=true; if not hasTrait(sheet,"shapeshift") then ok=false end
    end

    -- cibernéticos
    if string.find(low,"cybernetic implant",1,true)~=nil then
        recognized=true; if not anyCyber(sheet) then ok=false end
    end

    -- equipamento de droide que a ficha consegue verificar
    if string.find(low,"shield generator",1,true)~=nil then
        recognized=true
        if tonumber(sheet.shieldRatingMax or 0)<=0 and not hasDroidSystemText(sheet,"shield") then ok=false end
    end
    if string.find(low,"basic processor",1,true)~=nil then
        recognized=true; if not hasDroidSystemText(sheet,"basic processor") then ok=false end
    end
    if string.find(low,"claw or hand appendage",1,true)~=nil or string.find(low,"appendages",1,true)~=nil or string.find(low,"equipped with appendage",1,true)~=nil then
        recognized=true
        local hasAppend=#childList(sheet,"droidAppendages")>0 or hasDroidSystemText(sheet,"appendage") or hasDroidSystemText(sheet,"claw") or hasDroidSystemText(sheet,"hand")
        if not hasAppend then ok=false end
    end
    if string.find(low,"valid locomotion",1,true)~=nil or string.find(low,"hovering",1,true)~=nil or string.find(low,"flying locomotion",1,true)~=nil or string.find(low,"wheeled",1,true)~=nil or string.find(low,"tracked locomotion",1,true)~=nil then
        recognized=true
        local locom=norm(tostring(sheet.droidLocomotionName or "").." "..tostring(sheet.droidLocomotionSummary or ""))
        if locom=="" then
            for _,field in ipairs({"droidLocomotion","droidLocomotions"}) do
                for _,x in ipairs(childList(sheet,field)) do locom=locom.." "..norm(x.name or x.namePt or "") end
            end
        end
        local lok=string.find(locom,"hover",1,true) or string.find(locom,"fly",1,true) or string.find(locom,"wheel",1,true) or string.find(locom,"track",1,true)
        if not lok then ok=false end
    end

    -- proficiência contextual / escolhas de arma
    if string.find(low,"choose a weapon",1,true)~=nil then
        recognized=true; if tostring(option or "")=="" then ok=false end
    end
    if string.find(low,"proficient with weapon",1,true)~=nil or string.find(low,"proficient in weapon",1,true)~=nil then
        recognized=true; if not optionProficiency(sheet,option) then ok=false end
    end
    if string.find(low,"proficient with armor worn",1,true)~=nil then
        recognized=true
        local typ=norm(sheet.armorType or "")
        local need=nil
        if string.find(typ,"light",1,true) then need="Armor Proficiency (Light)"
        elseif string.find(typ,"medium",1,true) then need="Armor Proficiency (Medium)"
        elseif string.find(typ,"heavy",1,true) then need="Armor Proficiency (Heavy)" end
        if need==nil or not M.hasFeat(sheet,need) then ok=false end
    end

    -- nomes explícitos de Proezas
    for _,fn in ipairs(featNames) do
        local f=norm(fn)
        if (#f>=4 or f=="pin") and string.find(low,f,1,true)~=nil then
            -- não trate o próprio nome como pré-requisito
            recognized=true
            if not M.hasFeat(sheet,fn) then ok=false end
        end
    end

    -- nomes explícitos de Talentos
    for _,tn in ipairs(talentNames) do
        local q=norm(tn)
        if #q>=5 and string.find(low,q,1,true)~=nil then
            recognized=true
            if not M.hasTalent(sheet,tn) then ok=false end
        end
    end

    return ok,recognized
end

local function splitComma(s)
    local out={}
    for rawPart in string.gmatch(s..",","(.-),") do
        local part=string.gsub(rawPart,"^%s+",""); part=string.gsub(part,"%s+$","")
        if part~="" then out[#out+1]=part end
    end
    return out
end

local function splitOr(s)
    local out={}
    local low=norm(s)
    if string.find(low,"medium or larger",1,true) or string.find(low,"small or larger",1,true) then return {s} end
    local start=1
    while true do
        local a,b=string.find(string.lower(s)," or ",start,true)
        if not a then out[#out+1]=string.sub(s,start); break end
        out[#out+1]=string.sub(s,start,a-1)
        start=b+1
    end
    return out
end

function M.checkFeat(sheet,feat,option)
    if feat==nil then return true,{},{} end
    local req=tostring(feat.prerequisites or "")
    if req=="" or req=="-" or norm(req)=="prerequisites" then return true,{},{} end
    local raw=req
    -- normalize compound equipment alternatives before comma/or normalization
    raw=string.gsub(raw,"equipped with hovering, flying, wheeled, or tracked locomotion","equipped with valid locomotion")
    raw=string.gsub(raw,",%s*[Oo][Rr]%s+", " or ")
    -- listas internas que representam uma única alternativa mecânica não podem virar pré-requisitos separados
    raw=string.gsub(raw,"equipped with claw or hand appendage","equipped with appendage")
    local clauses=splitComma(raw)
    local missing,manual={},{}
    for _,clause in ipairs(clauses) do
        local low=norm(clause)
        -- caso SagaForge: Sneak Attack, Rapid Shot, or Rapid Strike
        if string.find(norm(req),"sneak attack, rapid shot, or rapid strike",1,true)~=nil then
            local ok=M.hasTalent(sheet,"Sneak Attack") or M.hasFeat(sheet,"Rapid Shot") or M.hasFeat(sheet,"Rapid Strike")
            if not ok then missing[#missing+1]="Sneak Attack, Rapid Shot ou Rapid Strike" end
            clauses={}
            break
        end
        local alternatives=splitOr(clause)
        local clauseOK=false
        local anyRecognized=false
        for _,alt in ipairs(alternatives) do
            local ok,rec=evalAtomic(sheet,alt,option)
            if rec then anyRecognized=true end
            if rec and ok then clauseOK=true end
        end
        if anyRecognized then
            if not clauseOK then missing[#missing+1]=clause end
        else
            manual[#manual+1]=clause
        end
    end
    -- Fail closed: a prerequisite the engine cannot evaluate never becomes legal
    -- merely because a checkbox was marked.
    return (#missing==0 and #manual==0),missing,manual
end

return M
