-- Downloads happen only after the user presses Atualizar. No polling or sheet writes.
local Internet=require('internet.lua')
local Plugins=require('plugins.lua')
local M={version='7.3.4',moduleId='MestreRPG.StarWarsSagaEdition',
  repository='kaalflash12/fichasRRPG',
  manifestURL='https://raw.githubusercontent.com/kaalflash12/fichasRRPG/main/update.txt'}
local busy=nil
local function version(v)
  local a,b,c=tostring(v or ''):match('^(%d+)%.(%d+)%.(%d+)$')
  if not a then return nil end
  return {tonumber(a),tonumber(b),tonumber(c)}
end
function M.compare(a,b)
  a=version(a);b=version(b)
  if not a or not b then return nil end
  for i=1,3 do if a[i]~=b[i] then return a[i]>b[i] and 1 or -1 end end
  return 0
end
local function installedVersion()
  local current=M.version
  local ok,list=pcall(Plugins.getInstalledPlugins)
  if ok then for _,p in ipairs(list or {}) do
    if p.moduleId==M.moduleId and M.compare(p.version,current)==1 then current=p.version end
  end end
  return current
end
function M.parseManifest(text)
  if type(text)~='string' or #text>8192 then return nil,'Manifesto inválido.' end
  text=text:gsub('\r\n','\n')
  if text:match('^([^\n]+)')~='SWSE-UPDATE-1' then return nil,'Canal GitHub ainda não publicado ou resposta inválida.' end
  local data={}
  for line in text:gmatch('[^\n]+') do
    local k,v=line:match('^(%a+)=([^%c]+)$')
    if k then if data[k]~=nil then return nil,'Campo duplicado no manifesto.' end;data[k]=v end
  end
  if data.module~=M.moduleId or not version(data.version) then return nil,'Versão ou identificação inválida.' end
  local raw='https://raw.githubusercontent.com/'..M.repository..'/'
  local release='https://github.com/'..M.repository..'/releases/download/'
  local u=data.rpk or ''
  if not (u:sub(1,#raw)==raw or u:sub(1,#release)==release) or not u:match('%.rpk$')
      or u:find('..',1,true) or u:find('[%s?#]') then return nil,'O RPK não pertence ao canal configurado.' end
  return data
end
local function close(stream) if stream then pcall(function() stream:close() end) end end
local function readText(stream)
  stream.position=0
  if tonumber(stream.size or stream.remainingBytes or 0)>8192 then error('Manifesto muito grande.') end
  local parts={};local total=0
  while stream.remainingBytes>0 do
    local buffer={};local got=stream:read(buffer,math.min(1024,stream.remainingBytes))
    if not got or got<=0 then error('Manifesto incompleto.') end
    total=total+got;if total>8192 then error('Manifesto muito grande.') end
    parts[#parts+1]=string.char(table.unpack(buffer,1,got))
  end
  return table.concat(parts)
end
local function status(form,text)
  pcall(function()
    form._swseUpdateMessage=text
    if form.swseUpdateStatus then form.swseUpdateStatus.text=text end
  end)
end
local function live(state) return busy==state and state.form.sheet==state.sheet end
local function stopResources(state)
  if state.timer then pcall(clearTimeout,state.timer);state.timer=nil end
  if state.download then pcall(Internet.stopDownload,state.download);state.download=nil end
end
local function finish(state,text)
  if busy~=state then return end
  busy=nil;stopResources(state);status(state.form,text)
  pcall(function() if state.form.swseUpdateButton then state.form.swseUpdateButton.enabled=true end end)
end
function M.cancel(form)
  if busy and busy.form==form then finish(busy,'Atualização cancelada.') end
end
local function timeout(state)
  if state.timer then clearTimeout(state.timer) end
  state.timer=setTimeout(function() finish(state,'A conexão demorou demais. Tente atualizar novamente.') end,60000)
end
function M.check(form)
  if not form or not form.sheet then return false end
  if busy then status(form,'Já há uma atualização em andamento.');return false end
  local state={form=form,sheet=form.sheet,current=installedVersion()};busy=state
  pcall(function() if form.swseUpdateButton then form.swseUpdateButton.enabled=false end end)
  status(form,'Consultando atualizações no GitHub…');timeout(state)
  local function failed(message)
    finish(state,'Não foi possível atualizar pelo GitHub: '..tostring(message or 'falha de conexão'))
  end
  local function gotManifest(stream)
    state.download=nil
    if not live(state) then close(stream);finish(state,'Atualização cancelada.');return end
    local ok,text=pcall(readText,stream);close(stream)
    if not ok then failed(text);return end
    local data,err=M.parseManifest(text)
    if not data then failed(err);return end
    if M.compare(data.version,state.current)~=1 then finish(state,'Você já tem a versão mais recente ('..state.current..').');return end
    timeout(state);status(form,'Baixando versão '..data.version..'…')
    local function gotPackage(package)
      state.download=nil
      if not live(state) then close(package);finish(state,'Atualização cancelada.');return end
      local infoOk,info=pcall(Plugins.getRPKDetails,package)
      if not infoOk or type(info)~='table' or info.moduleId~=M.moduleId or info.version~=data.version
          or M.compare(info.version,installedVersion())~=1 then
        close(package);failed('RPK inválido, diferente da versão publicada ou mais antigo.');return
      end
      status(form,'Instalando versão '..data.version..'…')
      -- The SDK enforces its own installation permission. Never bypass that check.
      local installOk,success,message=pcall(Plugins.installPlugin,package,true)
      close(package)
      if not installOk or success~=true then
        failed('O Firecast não concluiu a instalação. '..tostring(installOk and message or success));return
      end
      finish(state,'Versão '..data.version..' instalada. Feche e reabra esta ficha para carregar a atualização.')
    end
    local function progress(downloaded,total)
      if not live(state) then finish(state,'Atualização cancelada.');return false end
      if tonumber(total) and total>0 then
        local percent=math.floor((tonumber(downloaded) or 0)*100/total)
        if percent~=state.percent then state.percent=percent;status(form,'Baixando versão '..data.version..': '..percent..'%') end
      end
      return true
    end
    local good,id=pcall(Internet.download,data.rpk,gotPackage,failed,progress,'alwaysDownload')
    if not good then failed(id) elseif live(state) then state.download=id end
  end
  local good,id=pcall(Internet.download,M.manifestURL,gotManifest,failed,nil,'alwaysDownload')
  if not good then failed(id) elseif live(state) and not state.download then state.download=id end
  return true
end
return M
