-- Responsive geometry only. No node writes, rules, rolls, or window actions.
local M={}
local function set(c,k,v) if c and c[k]~=v then c[k]=v end end
local function width(c) return math.max(1,tonumber(c and c.width) or 1) end
function M.pack(sizes,available,gap)
 available=math.max(1,tonumber(available) or 1);gap=gap or 8
 local result={};local x,y,line=0,0,0
 for _,s in ipairs(sizes) do
  local w=math.min(available,s.width);local h=s.height
  if x>0 and x+w>available+0.01 then y=y+line;x=0;line=0 end
  result[#result+1]={left=x,top=y,width=w,height=h}
  x=x+w+gap;line=math.max(line,h)
 end
 return result,y+line
end
local function textHeight(c,w,minimum)
 local text=tostring(c.text or '');local font=tonumber(c.fontSize) or 10
 local letters=utf8.len(text) or #text
 local columns=math.max(1,math.floor(w/math.max(4,font*0.61)))
 return math.max(minimum,math.min(180,math.ceil(letters/columns)*(font+4)+6))
end
local function row(form,spec,fallback)
 local c=form[spec.name];if not c then return end
 local available=width(c)
 if available<120 then set(c,'width',fallback);available=width(c) end
 available=math.min(available,fallback)
 local sizes={}
 for _,s in ipairs(spec.groups) do
  local g=form[s.name];local w=math.min(available,s.width);local h=s.height
  if g then
   for _,p in ipairs(s.parts) do
    local part=form[p.name]
    if part and p.wrap then
     local pw=math.max(1,math.min(p.width,w-p.left))
     h=math.max(h,p.top+textHeight(part,pw,p.height)+3)
    end
   end
  end
  sizes[#sizes+1]={width=s.width,height=h}
 end
 local positions,height=M.pack(sizes,available,8)
 for i,s in ipairs(spec.groups) do
  local g=form[s.name];local p=positions[i]
  if g then
   set(g,'left',p.left);set(g,'top',p.top);set(g,'width',p.width);set(g,'height',p.height)
   for _,a in ipairs(s.parts) do
    local part=form[a.name]
    if part then
     local pw=math.max(1,math.min(a.width,p.width-a.left))
     set(part,'width',pw)
     if a.wrap then set(part,'wordWrap',true);set(part,'height',textHeight(part,pw,a.height)) end
    end
   end
  end
 end
 set(c,'height',math.max(spec.height,height))
end
local function containers(form,spec)
 -- Specs are ordered deepest first so outer boxes include wrapped child rows.
 for _,s in ipairs(spec.containers) do
  local c=form[s.name]
  if c then
   local h=s.padding
   for _,p in ipairs(s.children) do
    local child=form[p.name]
    if child and child.visible~=false then h=h+(tonumber(child.height) or p.height)+p.margin end
   end
   set(c,'height',math.max(s.height,h))
  end
 end
end
function M.apply(form,spec)
 if not form or form._swseVehicleSizing then return end
 form._swseVehicleSizing=true
 local ok,err=pcall(function()
  local frame=form.swseScreenFrame
  if frame then
   set(frame,'align','none');set(frame,'left',0);set(frame,'top',0)
   set(frame,'width',width(form));set(frame,'height',tonumber(form.height) or 50)
  end
  local fallback=math.max(1,width(form)-42)
  -- Establish ancestor widths before measuring aligned rows. Hidden native
  -- containers retain their initial width until explicitly sized.
  for _,s in ipairs(spec.widths or {}) do
   local c=form[s.name];local parent=form[s.parent]
   if c and parent then set(c,'width',math.max(1,width(parent)-s.inset)) end
  end
  for _,s in ipairs(spec.rows) do row(form,s,fallback) end
  containers(form,spec)
  assert(require('swse_nav_layout.lua').apply(form))
  local usable=math.max(1,width(form)-30)
  if form.vehicleHeaderTitle then
   set(form.vehicleHeaderTitle,'width',math.floor(usable*0.64))
   set(form.vehicleHeaderTitle,'fontSize',14)
  end
  if form.vehicleHeaderStatus then set(form.vehicleHeaderStatus,'width',math.floor(usable*0.34)) end
  for _,p in ipairs(spec.pageHeaders) do
   set(form[p.status],'visible',usable>=650)
   set(form[p.title],'width',usable>=650 and math.min(360,usable-226) or usable-16)
  end
 end)
 form._swseVehicleSizing=false
 if not ok then form._swseVehicleLayoutError=tostring(err) end
 return ok,err
end
function M.request(form,spec)
 if not form or form._swseVehicleSizing or form._swseVehicleLayoutTimer then return end
 form._swseVehicleLayoutTimer=setTimeout(function()
  form._swseVehicleLayoutTimer=nil
  if form.sheet then M.apply(form,spec) end
 end,40)
end
function M.stop(form)
 if form and form._swseVehicleLayoutTimer then clearTimeout(form._swseVehicleLayoutTimer);form._swseVehicleLayoutTimer=nil end
end
return M
