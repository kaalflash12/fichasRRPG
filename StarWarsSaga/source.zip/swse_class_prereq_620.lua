local M={}
local NDB=require("ndb.lua")

local function n(v,d)
    local x=tonumber(v)
    if x==nil then return d or 0 end
    return x
end

local function norm(s)
    s=string.lower(tostring(s or ""))
    s=string.gsub(s,"armour","armor")
    s=string.gsub(s,"force sensitive","force sensitivity")
    s=string.gsub(s,"bureacracy","bureaucracy")
    s=string.gsub(s,"%[","("); s=string.gsub(s,"%]",")")
    s=string.gsub(s,"%s+"," ")
    return s
end

local function children(root,field)
    if root==nil or root[field]==nil then return {} end
    return NDB.getChildNodes(root[field])
end

local function hasFeat(root,name)
    local wanted=norm(name)
    for _,x in ipairs(children(root,"chosenFeats")) do
        if norm(x.name)==wanted or norm(x.baseName)==wanted then return true end
    end
    return false
end

local function trained(root,name)
    local wanted=norm(name)
    for _,x in ipairs(children(root,"campoDasPericias")) do
        if norm(x.nomePericia)==wanted and (x.isClass==true or x.speciesTrained==true) then return true end
    end
    local talentTraining={
        [norm("Initiative")]={"Force Intuition","Watchful Step"},
        [norm("Perception")]={"Force Perception"},
        [norm("Deception")]={"Force Deception"},
        [norm("Persuasion")]={"Force Persuasion"},
        [norm("Pilot")]={"Force Pilot"},
        [norm("Treat Injury")]={"Force Treatment"},
        [norm("Stealth")]={"White Current Adept"},
        [norm("Use Computer")]={"Hotwire"}
    }
    for _,talent in ipairs(talentTraining[wanted] or {}) do
        local target=norm(talent)
        for _,x in ipairs(children(root,"chosenTalents")) do
            if norm(x.name)==target or norm(x.baseName)==target then return true end
        end
    end
    return false
end

local function hasTalent(root,name)
    local wanted=norm(name)
    for _,x in ipairs(children(root,"chosenTalents")) do
        if norm(x.name)==wanted or norm(x.baseName)==wanted then return true end
    end
    return false
end

local function hasPower(root,name)
    local wanted=norm(name)
    for _,x in ipairs(children(root,"chosenForcePowers")) do
        if norm(x.name)==wanted or norm(x.baseName)==wanted then return true end
    end
    return false
end

local function countTalentTrees(root,words)
    local count=0
    for _,x in ipairs(children(root,"chosenTalents")) do
        local tree=norm(x.tree)
        for _,w in ipairs(words) do
            if string.find(tree,norm(w),1,true)~=nil then count=count+1; break end
        end
    end
    return count
end

local function parseTreeRequirement(root,req)
    local low=norm(req)
    local need=1
    if string.find(low,"any two",1,true) or string.find(low,"at least two",1,true) then need=2
    elseif string.find(low,"any three",1,true) or string.find(low,"at least three",1,true) then need=3 end

    local after=string.match(req,"[Ff][Rr][Oo][Mm]%s+(.+)")
    if after==nil then return false end
    after=string.gsub(after,"[Tt][Hh][Ee]%s+","")
    after=string.gsub(after,"[Tt][Aa][Ll][Ee][Nn][Tt]%s+[Tt][Rr][Ee][Ee][Ss]","")
    after=string.gsub(after,"[Tt][Aa][Ll][Ee][Nn][Tt]%s+[Tt][Rr][Ee][Ee]","")
    after=string.gsub(after,"[Tt][Aa][Ll][Ee][Nn][Tt][Ss]","")
    after=string.gsub(after,","," or ")
    local words={}
    for rawPart in string.gmatch(after.." or ","(.-)%s+[Oo][Rr]%s+") do
        local part=string.gsub(rawPart,"^%s+",""); part=string.gsub(part,"%s+$","")
        if part~="" then words[#words+1]=part end
    end
    return countTalentTrees(root,words)>=need
end

local function hasOneMartialTraining(root)
    for _,nm in ipairs({"Echani Training","Hijkata Training","K'tara Training","K'thri Training","Stava Training","Tae-Jitsu Training","Teräs Käsi Training","Wrruushi Training"}) do
        if hasFeat(root,nm) then return true end
    end
    return false
end

function M.validate(root,c,catalog)
    if root==nil or c==nil then return false,{"Classe inválida"} end
    local missing={}
    local lvl=#children(root,"classLevels")
    local min=n(c.min_level,1)
    if min>1 and lvl<min then missing[#missing+1]="Nível mínimo "..tostring(min) end

    for _,req in ipairs(c.prereqs or {}) do
        local low=norm(req)
        local handled=false

        local babReq=tonumber(string.match(low,"base attack bonus:?%s*%+?%s*(%d+)")) or tonumber(string.match(low,"minimum base attack bonus:?%s*%+?%s*(%d+)"))
        if babReq~=nil then handled=true; if n(root.bba,0)<babReq then missing[#missing+1]="BBA +"..babReq end end

        local levelReq=tonumber(string.match(low,"minimum level:?%s*(%d+)"))
        if levelReq~=nil then handled=true; if lvl<levelReq then missing[#missing+1]="Nível "..levelReq end end

        if string.find(low,"trained skills:",1,true)==1 then
            handled=true
            local body=string.match(req,":%s*(.+)") or ""
            for rawSkill in string.gmatch(body.." ,","(.-),") do
                local sk=string.gsub(rawSkill,"^%s+",""); sk=string.gsub(sk,"%s+$","")
                if sk~="" and not trained(root,sk) then missing[#missing+1]="Treinar "..sk end
            end
        end

        if string.find(low,"feat:",1,true)==1 then
            handled=true
            local nm=string.match(req,":%s*(.+)") or ""
            if not hasFeat(root,nm) then missing[#missing+1]="Feat: "..nm end
        end

        if string.find(low,"feats:",1,true)==1 then
            handled=true
            if string.find(low,"point blank shot or flurry",1,true) then
                for _,nm in ipairs({"Armor Proficiency (light)","Armor Proficiency (medium)","Martial Arts I"}) do
                    if not hasFeat(root,nm) then missing[#missing+1]="Feat: "..nm end
                end
                if not hasFeat(root,"Point Blank Shot") and not hasFeat(root,"Flurry") then missing[#missing+1]="Point Blank Shot ou Flurry" end
            elseif string.find(low,"armor proficiency (light, medium)",1,true) then
                if not hasFeat(root,"Force Sensitivity") then missing[#missing+1]="Force Sensitivity" end
                if not hasFeat(root,"Armor Proficiency (light)") then missing[#missing+1]="Armor Proficiency (light)" end
                if not hasFeat(root,"Armor Proficiency (medium)") then missing[#missing+1]="Armor Proficiency (medium)" end
                if not hasFeat(root,"Weapon Proficiency (Lightsabers)") then missing[#missing+1]="Weapon Proficiency (Lightsabers)" end
            elseif string.find(low,"weapon focus with any melee weapon",1,true) then
                if not hasFeat(root,"Melee Defense") then missing[#missing+1]="Melee Defense" end
                if not hasFeat(root,"Rapid Strike") then missing[#missing+1]="Rapid Strike" end
                local found=false
                for _,x in ipairs(children(root,"chosenFeats")) do if norm(x.baseName)=="weapon focus" then found=true end end
                if not found then missing[#missing+1]="Weapon Focus com arma corpo a corpo" end
            elseif string.find(low,"one martial arts training feat",1,true) then
                for _,nm in ipairs({"Martial Arts I","Martial Arts II","Melee Defense"}) do
                    if not hasFeat(root,nm) then missing[#missing+1]="Feat: "..nm end
                end
                if not hasOneMartialTraining(root) then missing[#missing+1]="Uma Proeza de treinamento em artes marciais" end
            else
                local body=string.match(req,":%s*(.+)") or ""
                for rawFeat in string.gmatch(body.." ,","(.-),") do
                    local nm=string.gsub(rawFeat,"^%s+",""); nm=string.gsub(nm,"%s+$","")
                    if nm~="" and not hasFeat(root,nm) then missing[#missing+1]="Feat: "..nm end
                end
            end
        end

        if string.find(low,"talents:",1,true)==1 then
            handled=true
            if string.find(low,"dastardly strike",1,true) then
                if not hasTalent(root,"Dastardly Strike") then missing[#missing+1]="Talent: Dastardly Strike" end
            elseif string.find(low,"any three force talents",1,true) then
                local count=0
                for _,x in ipairs(children(root,"chosenTalents")) do
                    local tr=norm(x.tree)
                    if string.find(tr,"force",1,true) or string.find(tr,"dark side",1,true) then count=count+1 end
                end
                if count<3 then missing[#missing+1]="3 Force Talents" end
            elseif not parseTreeRequirement(root,req) then
                missing[#missing+1]=req
            end
        end

        if string.find(low,"force powers:",1,true)==1 then
            handled=true
            local nm=string.match(req,":%s*(.+)") or ""
            if not hasPower(root,nm) then missing[#missing+1]="Force Power: "..nm end
        end

        if string.find(low,"force techniques:",1,true)==1 then
            handled=true
            if #children(root,"chosenForceTechniques")<1 then missing[#missing+1]="1 Force Technique" end
        end

        if string.find(low,"species:",1,true)==1 then
            handled=true
            local nm=string.match(req,":%s*(.+)") or ""
            if norm(root.racaId or root.raca)~=norm(nm) then missing[#missing+1]="Espécie: "..nm end
        end

        if string.find(low,"dark side score must equal wisdom score",1,true) then
            handled=true
            if n(root.darkSideScore,0)~=n(root.realSab,10) then missing[#missing+1]="Dark Side Score igual a Sabedoria" end
        end

        if string.find(low,"droids only",1,true) then
            handled=true
            if root.isDroid~=true then missing[#missing+1]="Apenas Droid" end
        end

        if string.find(low,"heuristic processor",1,true) then
            handled=true
            if root.heuristicProcessor~=true then missing[#missing+1]="Heuristic Processor" end
        end

        if not handled then missing[#missing+1]=req end
    end

    local special=norm(c.special or "")
    if special~="" then
        if string.find(special,"major interstellar corporation",1,true) and root.employedMajorCorporation~=true then missing[#missing+1]="Emprego em grande corporação interestelar" end
        if string.find(special,"law enforcement",1,true) and root.lawEnforcementMember~=true then missing[#missing+1]="Membro de organização policial/segurança" end
        if string.find(special,"sworn defender of emperor roan fel",1,true) and root.swornDefenderRoanFel~=true then missing[#missing+1]="Defensor juramentado do Imperador Roan Fel" end
        if string.find(special,"built own lightsaber",1,true) and root.builtOwnLightsaber~=true then missing[#missing+1]="Ter construído o próprio sabre de luz" end
        if string.find(special,"member of the jedi tradition",1,true) and norm(root.forceTradition or "")~="jedi" then missing[#missing+1]="Tradição da Força: Jedi" end
        if string.find(special,"military or paramilitary",1,true) and root.militaryOrganizationMember~=true then missing[#missing+1]="Membro de organização militar/paramilitar" end
        if string.find(special,"wanted by the authorities",1,true) and root.wantedByAuthorities~=true then missing[#missing+1]="Procurado pelas autoridades em ao menos um sistema" end
        if string.find(special,"member of the sith tradition",1,true) and norm(root.forceTradition or "")~="sith" then missing[#missing+1]="Tradição da Força: Sith" end
    end

    return #missing==0,missing
end

return M
