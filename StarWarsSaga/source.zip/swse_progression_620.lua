local M={}
local NDB=require("ndb.lua")
local CAT=require("swse_catalog_pt.lua")

local function n(v,d)
    local x=tonumber(v)
    if x==nil then return d or 0 end
    return x
end

local function norm(s)
    s=string.lower(tostring(s or ""))
    s=string.gsub(s,"armour","armor")
    s=string.gsub(s,"force sensitive","force sensitivity")
    s=string.gsub(s,"%s+"," ")
    return s
end

local function children(root,field)
    if root==nil or root[field]==nil then return {} end
    return NDB.getChildNodes(root[field])
end

local function findCatalog(list,name)
    local wanted=tostring(name or "")
    for _,x in ipairs(list or {}) do
        if tostring(x.name or "")==wanted then return x end
    end
end

local function baseName(node)
    local b=tostring(node and (node.baseName or node.name) or "")
    local p=string.match(b,"^(.-) %(")
    return p or b
end

local function isIn(root,field,node)
    for _,x in ipairs(children(root,field)) do if x==node then return true end end
    return false
end

local function hasFeat(root,name)
    local wanted=norm(name)
    for _,x in ipairs(children(root,"chosenFeats")) do
        if norm(baseName(x))==wanted or norm(x.name)==wanted then return true end
    end
    return false
end

local function hasTalent(root,name)
    local wanted=norm(name)
    for _,x in ipairs(children(root,"chosenTalents")) do
        if norm(baseName(x))==wanted or norm(x.name)==wanted then return true end
    end
    return false
end

local function textMentions(text,name)
    local a=norm(text)
    local b=norm(name)
    return b~="" and string.find(a,b,1,true)~=nil
end

local function classUses(root,name)
    for _,lv in ipairs(children(root,"classLevels")) do
        local c=findCatalog(CAT.classes,tostring(lv.className or ""))
        if c~=nil then
            for _,req in ipairs(c.prereqs or {}) do
                if textMentions(req,name) then return true,tostring(c.name or lv.className) end
            end
            if textMentions(c.special,name) then return true,tostring(c.name or lv.className) end
        end
    end
    return false,nil
end

local function choiceUses(root,node)
    local name=baseName(node)
    for _,f in ipairs(children(root,"chosenFeats")) do
        if f~=node then
            local src=findCatalog(CAT.feats,baseName(f))
            if src~=nil and textMentions(src.prerequisites,name) then
                return true,"Proeza "..tostring(f.namePt or f.name or "")
            end
        end
    end
    for _,t in ipairs(children(root,"chosenTalents")) do
        if t~=node then
            local src=findCatalog(CAT.talents,baseName(t))
            if src~=nil and (textMentions(src.prerequisites,name) or textMentions(src.tree,name)) then
                return true,"Talento "..tostring(t.namePt or t.name or "")
            end
        end
    end
    local used,by=classUses(root,name)
    if used then return true,"Classe "..tostring(by) end
    return false,nil
end

local function findSkill(root,name)
    for _,sk in ipairs(children(root,"campoDasPericias")) do
        if tostring(sk.nomePericia or "")==tostring(name or "") then return sk end
    end
end

function M.canRemoveChoice(root,node)
    if root==nil or node==nil then return false,"Escolha inválida." end
    if node.automatic==true then
        return false,"Esta característica é automática de classe ou espécie e não pode ser removida manualmente."
    end
    local isFeat=isIn(root,"chosenFeats",node)
    local isTalent=isIn(root,"chosenTalents",node)
    if not isFeat and not isTalent then return true,nil end
    local base=baseName(node)

    if isFeat then
        if norm(base)=="force sensitivity" then
            if hasFeat(root,"Force Training") or #children(root,"chosenForcePowers")>0 or #children(root,"chosenForceTechniques")>0 or #children(root,"chosenForceSecrets")>0 then
                return false,"Sensibilidade à Força ainda é requisito de escolhas da Força existentes."
            end
        elseif norm(base)=="force training" then
            if #children(root,"chosenForcePowers")>0 then
                local copies=0
                for _,f in ipairs(children(root,"chosenFeats")) do if norm(baseName(f))=="force training" then copies=copies+1 end end
                local wis=math.floor((n(root.realSab,10)-10)/2)
                local capacity=math.max(0,(copies-1)*math.max(1,1+wis)+n(root.bonusForcePower,0))
                if #children(root,"chosenForcePowers")>capacity then
                    return false,"Remova Poderes da Força excedentes antes de remover este Treinamento na Força."
                end
            end
        end
    end

    local used,by=choiceUses(root,node)
    if used then return false,"Esta escolha ainda é pré-requisito de "..tostring(by).."." end
    return true,nil
end

function M.removeChoice(root,node)
    local ok,msg=M.canRemoveChoice(root,node)
    if not ok then return false,msg end

    local isFeat=isIn(root,"chosenFeats",node)
    if isFeat then
        local base=baseName(node)
        local option=tostring(node.option or "")
        if base=="Skill Training" and option~="" then
            local sk=findSkill(root,option)
            if sk~=nil and sk.speciesTrained~=true then sk.isClass=false end
        elseif base=="Skill Focus" and option~="" then
            local sk=findSkill(root,option)
            if sk~=nil and sk.speciesFocus~=true then sk.skillFocus=false end
        end
    end

    NDB.deleteNode(node)
    root.choiceRevision=n(root.choiceRevision,0)+1
    return true,nil
end

local basicHeroic={Jedi=true,Noble=true,Scoundrel=true,Scout=true,Soldier=true}
local techniqueClasses={["Force Adept"]=true,["Jedi Knight"]=true,["Sith Apprentice"]=true,["Imperial Knight"]=true}
local masterSecretClasses={["Jedi Master"]=true,["Sith Lord"]=true}

local function hypotheticalCounts(nodes,skip)
    local counts={}
    local level=0
    for _,x in ipairs(nodes) do
        if x~=skip then
            level=level+1
            local nm=tostring(x.className or "")
            counts[nm]=(counts[nm] or 0)+1
        end
    end
    return level,counts
end

local function manualFeatCount(root)
    local c=0
    for _,f in ipairs(children(root,"chosenFeats")) do if f.automatic~=true then c=c+1 end end
    return c
end

local function countSkillTraining(root)
    local c=0
    for _,f in ipairs(children(root,"chosenFeats")) do
        if norm(baseName(f))=="skill training" then c=c+1 end
    end
    return c
end

local function trainedSkillCount(root)
    local c=0
    for _,sk in ipairs(children(root,"campoDasPericias")) do
        if sk.isClass==true then c=c+1 end
    end
    return c
end

local function choiceGrantedByLevel(root,field,removedLevel,slotType)
    for _,x in ipairs(children(root,field)) do
        if x.automatic~=true and n(x.grantLevel,0)==removedLevel and tostring(x.slotType or "")==slotType then
            return x
        end
    end
    return nil
end

local function capacityAfterRemoving(root,node)
    local level,counts=hypotheticalCounts(children(root,"classLevels"),node)
    local classBonus,talentSlots,techniques,secrets=0,0,0,0
    for nm,cnt in pairs(counts) do
        if nm~="Nonheroic" and nm~="Beast" and nm~="None" then
            if nm=="Crime Lord" then talentSlots=talentSlots+cnt
            else talentSlots=talentSlots+math.ceil(cnt/2) end
        end
        if basicHeroic[nm] then classBonus=classBonus+math.floor(cnt/2) end
        if techniqueClasses[nm] then techniques=techniques+math.floor(cnt/2) end
        if nm=="Force Disciple" then secrets=secrets+math.floor(cnt/2)
        elseif masterSecretClasses[nm] then secrets=secrets+math.max(0,cnt-1) end
    end
    local trained=0
    if level>0 then
        local first=nil
        for _,x in ipairs(children(root,"classLevels")) do
            if x~=node then first=x; break end
        end
        if first~=nil then
            local intMod=math.floor((n(root.realInt,8)-10)/2)
            trained=math.max(1,n(first.trainedSkillsBase,0)+intMod+n(root.bonusTrainedSkills,0))
        end
    end
    trained=trained+countSkillTraining(root)
    return {
        level=level,
        feats=((level>0) and (1+math.floor(level/3)) or 0)+n(root.bonusLevelFeat,0)+n(root.bonusFeatSlots,0)+classBonus+n(root.bonusClassFeat,0),
        talents=talentSlots+n(root.bonusTalent,0),
        techniques=techniques+n(root.bonusForceTechnique,0),
        secrets=secrets+n(root.bonusForceSecret,0),
        abilities=math.floor(level/4)*2,
        trainedSkills=trained
    }
end

function M.removeLastLevel(root,node)
    if root==nil or node==nil then return false,"Nível inválido." end
    local levels=children(root,"classLevels")
    if #levels==0 or levels[#levels]~=node then
        return false,"Só é permitido desfazer o nível de personagem mais recente."
    end

    local caps=capacityAfterRemoving(root,node)
    local removedLevel=n(node.levelIndex,#levels)
    local removedClass=tostring(node.className or "")

    local sourceFeat=choiceGrantedByLevel(root,"chosenFeats",removedLevel,"classBonus")
    if sourceFeat~=nil then
        return false,"Remova primeiro a Proeza bônus concedida por este nível: "..tostring(sourceFeat.namePt or sourceFeat.name or "").."."
    end
    local sourceTalent=choiceGrantedByLevel(root,"chosenTalents",removedLevel,"talent")
    if sourceTalent~=nil then
        return false,"Remova primeiro o Talento concedido por este nível: "..tostring(sourceTalent.namePt or sourceTalent.name or "").."."
    end
    if manualFeatCount(root)>caps.feats then return false,"Remova primeiro a Proeza excedente obtida neste patamar." end
    if #children(root,"chosenTalents")>caps.talents then return false,"Remova primeiro o Talento excedente obtido neste patamar." end
    if #children(root,"chosenForceTechniques")>caps.techniques then return false,"Remova primeiro a Técnica da Força excedente obtida neste patamar." end
    if #children(root,"chosenForceSecrets")>caps.secrets then return false,"Remova primeiro o Segredo da Força excedente obtido neste patamar." end
    if #children(root,"abilityAdvances")>caps.abilities then return false,"Remova primeiro os aumentos de atributo excedentes deste patamar." end
    if trainedSkillCount(root)>caps.trainedSkills then return false,"Desmarque primeiro as perícias treinadas excedentes deste patamar." end

    for _,f in ipairs(children(root,"chosenFeats")) do
        if f.automatic==true and tostring(f.automaticSource or "")=="class" and n(f.grantLevel,0)==removedLevel then
            local used,by=choiceUses(root,f)
            if used then
                return false,"A Proeza automática "..tostring(f.namePt or f.name or "").." ainda é pré-requisito de "..tostring(by)..". Remova ou substitua primeiro a escolha dependente."
            end
        end
    end

    for _,f in ipairs(children(root,"chosenFeats")) do
        if f.automatic==true and tostring(f.automaticSource or "")=="class" and n(f.grantLevel,0)==removedLevel then
            NDB.deleteNode(f)
        end
    end

    if tostring(root.pendingMulticlassClass or "")==removedClass and n(root.pendingMulticlassLevelIndex,0)==removedLevel then
        root.pendingMulticlassClass=""
        root.pendingMulticlassClassPt=""
        root.pendingMulticlassLevelIndex=nil
        root.multiclassFeatChoice=nil
    end

    NDB.deleteNode(node)
    local left=children(root,"classLevels")
    for i,x in ipairs(left) do x.levelIndex=i end

    local newLevel=#left
    local fpBase=0
    if newLevel>0 then
        local lastClass=findCatalog(CAT.classes,tostring(left[#left].className or ""))
        if lastClass~=nil then fpBase=n(lastClass.force_points,0) end
    end
    local newForceMax=(fpBase>0) and (fpBase+math.floor(newLevel/2)) or 0
    root.forcePointsMax=newForceMax
    if root.forcePoints==nil or n(root.forcePoints,0)>newForceMax then root.forcePoints=newForceMax end
    if newLevel==0 then
        root.startingCreditUnit=0
        root.classTraits=""
    end

    root.classRevision=n(root.classRevision,0)+1
    root.choiceRevision=n(root.choiceRevision,0)+1
    return true,nil
end

return M
