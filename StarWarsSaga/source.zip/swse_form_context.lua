-- Each form owns its script globals. Child records can find their owning form.
-- Standard SDK globals are read through the original plugin environment.
local M={}
local stable={"assert","error","getmetatable","ipairs","next","pairs","pcall","rawequal","rawget","rawlen","rawset","select","setmetatable","tonumber","tostring","type","xpcall","math","string","table","utf8","coroutine","require","setTimeout","clearTimeout","GUI","NDB","Firecast","Dialogs","Utils"}
function M.new(form,shared)
 local env={}
 -- Standard functions and SDK libraries do not depend on the owning character.
 -- Keep self, sheet and character helpers dynamic, including after reparenting.
 for _,key in ipairs(stable) do
  local value=shared[key]
  if value~=nil then rawset(env,key,value) end
 end
 setmetatable(env,{__index=function(_,key)
  local parent=form.parent
  for _=1,64 do
   if parent==nil then break end
   local owner=rawget(parent,"_swseScriptEnvironment")
   if owner then
    local value=rawget(owner,key)
    if value~=nil then return value end
   end
   parent=parent.parent
  end
  return shared[key]
 end})
 rawset(form,"_swseScriptEnvironment",env)
 return env
end
return M
