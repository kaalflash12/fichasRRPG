return {
tech_specialist_weapons={
{name="Improved Accuracy",name_pt="Precisão Aprimorada",cost=2000,effect_pt="Modificação de arma do Tech Specialist."},
{name="Improved Damage",name_pt="Dano Aprimorado",cost=2000,effect_pt="Modificação de arma do Tech Specialist."},
{name="Selective Fire",name_pt="Fogo Seletivo",cost=2000,effect_pt="Modificação de arma do Tech Specialist."},
{name="Improved Accuracy (self-made)",name_pt="Precisão Aprimorada (fabricada pelo personagem)",cost=1000,effect_pt="Versão de fabricação própria."},
{name="Improved Damage (self-made)",name_pt="Dano Aprimorado (fabricada pelo personagem)",cost=1000,effect_pt="Versão de fabricação própria."},
{name="Selective Fire (self-made)",name_pt="Fogo Seletivo (fabricada pelo personagem)",cost=1000,effect_pt="Versão de fabricação própria."}
},
superior_tech_weapons={
{name="Superior Accuracy",name_pt="Precisão Superior",cost=4000,effect_pt="Modificação de arma do Superior Tech."},
{name="Superior Capacity",name_pt="Capacidade Superior",cost=4000,effect_pt="Modificação de arma do Superior Tech."},
{name="Superior Damage",name_pt="Dano Superior",cost=4000,effect_pt="Modificação de arma do Superior Tech."},
{name="Superior Range",name_pt="Alcance Superior",cost=4000,effect_pt="Modificação de arma do Superior Tech."},
{name="Superior Accuracy (self-made)",name_pt="Precisão Superior (fabricada pelo personagem)",cost=2000,effect_pt="Versão de fabricação própria."},
{name="Superior Capacity (self-made)",name_pt="Capacidade Superior (fabricada pelo personagem)",cost=2000,effect_pt="Versão de fabricação própria."},
{name="Superior Damage (self-made)",name_pt="Dano Superior (fabricada pelo personagem)",cost=2000,effect_pt="Versão de fabricação própria."},
{name="Superior Range (self-made)",name_pt="Alcance Superior (fabricada pelo personagem)",cost=2000,effect_pt="Versão de fabricação própria."}
},
sith_weapon_alchemy={
{name="Jagged Weapon",name_pt="Arma Serrilhada",cost=0,effect_pt="Criatura viva ferida sofre 1d4 de dano no início do próximo turno."},
{name="Master's Weapon",name_pt="Arma do Mestre",cost=0,effect_pt="Concede +2 em Bloquear e Defletir."},
{name="Vile Weapon",name_pt="Arma Vil",cost=0,effect_pt="A arma é tratada com veneno Sith."}
},
armor_tech={
{name="Agile Armor",name_pt="Armadura Ágil",cost=0,effect_pt="Modificação tecnológica de armadura."},
{name="Fortifying Armor",name_pt="Armadura Fortificante",cost=0,effect_pt="Modificação tecnológica de armadura."},
{name="ProtectiveArmor",name_pt="Armadura Protetora",cost=0,effect_pt="Modificação tecnológica de armadura."},
{name="Mobile Armor",name_pt="Armadura Móvel",cost=0,effect_pt="Modificação tecnológica de armadura."},
{name="Reinforced Armor",name_pt="Armadura Reforçada",cost=0,effect_pt="Modificação tecnológica de armadura."},
{name="Superior Agile Armor",name_pt="Armadura Ágil Superior",cost=0,effect_pt="Modificação tecnológica superior de armadura."},
{name="Superior Fortifying Armor",name_pt="Armadura Fortificante Superior",cost=0,effect_pt="Modificação tecnológica superior de armadura."},
{name="Superior Protective Armor",name_pt="Armadura Protetora Superior",cost=0,effect_pt="Modificação tecnológica superior de armadura."}
},
bioimplants={
{name="Bio-stabilizer implant",name_pt="Implante Bioestabilizador",cost=1750,effect_pt="Imunidade a veneno."},
{name="Cardio implant",name_pt="Implante Cardíaco",cost=4000,effect_pt="+1 PV por nível."},
{name="Combat implant",name_pt="Implante de Combate",cost=5000,effect_pt="Elimina penalidades por não proficiência com armas."},
{name="Memory implant",name_pt="Implante de Memória",cost=2000,effect_pt="Pode repetir qualquer teste de Conhecimento, mantendo o melhor resultado."},
{name="Nerve reinforcement implant",name_pt="Implante de Reforço Neural",cost=5000,effect_pt="+5 de bônus de equipamento no Limiar de Dano contra atordoamento."},
{name="Regenerative implant",name_pt="Implante Regenerativo",cost=4250,effect_pt="Recupera o dobro de PV com cura natural."},
{name="Sensory implant",name_pt="Implante Sensorial",cost=2500,effect_pt="Concede visão em baixa luminosidade; se já a possuir, concede visão no escuro."},
{name="Subelectronic converter implant",name_pt="Implante Conversor Subeletrônico",cost=23000,effect_pt="Permite usar poderes da Força que afetam a mente em droides."}
}
}
