return {
    languages={
        {
            name="(native language)",
            name_pt="(língua nativa)"
        },
        {
            name="Aleena",
            name_pt="Aleena"
        },
        {
            name="Amanese",
            name_pt="Amanês"
        },
        {
            name="Anzat",
            name_pt="Anzat"
        },
        {
            name="Aqualish",
            name_pt="Aqualish"
        },
        {
            name="Arconese",
            name_pt="Arconese"
        },
        {
            name="Arkanian",
            name_pt="Arkanian"
        },
        {
            name="Balosar",
            name_pt="Balosar"
        },
        {
            name="Barabel",
            name_pt="Barabel"
        },
        {
            name="Basic",
            name_pt="Básico"
        },
        {
            name="Basic (Understand)",
            name_pt="Básico (Entendido)"
        },
        {
            name="Basic (understand only)",
            name_pt="Básico (somente compreendido)"
        },
        {
            name="Basic (understand)",
            name_pt="Básico (compreensão)"
        },
        {
            name="Batorese",
            name_pt="Batorês"
        },
        {
            name="Binary",
            name_pt="Binário"
        },
        {
            name="Bith",
            name_pt="Bith"
        },
        {
            name="Bothese",
            name_pt="Bothese"
        },
        {
            name="Caamasi",
            name_pt="Caamasi"
        },
        {
            name="Catharese",
            name_pt="Catarese"
        },
        {
            name="Cerean",
            name_pt="Cereã"
        },
        {
            name="Chadra-Fan",
            name_pt="Chadra-Fan"
        },
        {
            name="Chagri",
            name_pt="Chagri"
        },
        {
            name="Cheunh",
            name_pt="Cheunh"
        },
        {
            name="Chistori",
            name_pt="Chistori"
        },
        {
            name="Clawdite",
            name_pt="Clawdite"
        },
        {
            name="Codruese",
            name_pt="Bacalhau"
        },
        {
            name="Dashadi",
            name_pt="Dashadi"
        },
        {
            name="Defel",
            name_pt="Defel"
        },
        {
            name="Deveronese",
            name_pt="Deveronês"
        },
        {
            name="Dosh",
            name_pt="Dosh"
        },
        {
            name="Draethos",
            name_pt="Draethos"
        },
        {
            name="Dromnyr",
            name_pt="Dromnyr"
        },
        {
            name="Dug",
            name_pt="Dug"
        },
        {
            name="Durese",
            name_pt="Durese"
        },
        {
            name="Ewokese",
            name_pt="Ewokese"
        },
        {
            name="Falleen",
            name_pt="Falleen"
        },
        {
            name="Feeorin",
            name_pt="Feorina"
        },
        {
            name="Felucianese",
            name_pt="Felucianês"
        },
        {
            name="Fosh",
            name_pt="Fosh"
        },
        {
            name="Gammorean",
            name_pt="Gammoreano"
        },
        {
            name="Gand",
            name_pt="Gand"
        },
        {
            name="Gen'Dai",
            name_pt="Gen'Dai"
        },
        {
            name="Geonosian",
            name_pt="Geonosiano"
        },
        {
            name="Givin",
            name_pt="Givin"
        },
        {
            name="Gotal",
            name_pt="Gotal"
        },
        {
            name="Gran",
            name_pt="Gran"
        },
        {
            name="Gunganese",
            name_pt="Gunganês"
        },
        {
            name="Herglic",
            name_pt="Herglico"
        },
        {
            name="Honoghran",
            name_pt="Honoghran"
        },
        {
            name="Houk",
            name_pt="Houk"
        },
        {
            name="Huttese",
            name_pt="Huttese"
        },
        {
            name="Iktotchese",
            name_pt="Iktotchese"
        },
        {
            name="Ithorese",
            name_pt="Itorese"
        },
        {
            name="Jawa",
            name_pt="Jawa"
        },
        {
            name="Jawa Trade Language",
            name_pt="Jawa Trade Language"
        },
        {
            name="Kaleesh",
            name_pt="Kaleesh"
        },
        {
            name="Kaminoan",
            name_pt="Kaminoan"
        },
        {
            name="Kel Dor",
            name_pt="Kel Dor"
        },
        {
            name="Kerkoidese",
            name_pt="Kerkoidese"
        },
        {
            name="Khilese",
            name_pt="Khilese"
        },
        {
            name="Lekku",
            name_pt="Lekku"
        },
        {
            name="Lurmese",
            name_pt="Lurmese"
        },
        {
            name="Mando'a",
            name_pt="Mando'a"
        },
        {
            name="Massan",
            name_pt="Massan"
        },
        {
            name="Miralukese",
            name_pt="Miralukese"
        },
        {
            name="Mon Calamarian",
            name_pt="Mon Calamarian"
        },
        {
            name="Mrlsstese",
            name_pt="Sr. Lisstese"
        },
        {
            name="Nagaian",
            name_pt="Nagaiano"
        },
        {
            name="Nautila",
            name_pt="Nautila"
        },
        {
            name="Nazren",
            name_pt="Nazren"
        },
        {
            name="Neimoidian",
            name_pt="Neimoidiano"
        },
        {
            name="Nelvaanese",
            name_pt="Nelvaanese"
        },
        {
            name="Nikto",
            name_pt="Nikto"
        },
        {
            name="Nosaurian",
            name_pt="Nassauro"
        },
        {
            name="Paecian",
            name_pt="Paeciano"
        },
        {
            name="Phindian",
            name_pt="Phindian"
        },
        {
            name="Quarrenese",
            name_pt="Quarrenese"
        },
        {
            name="Rakata",
            name_pt="Rakata"
        },
        {
            name="Rodese",
            name_pt="Rodesa"
        },
        {
            name="Ryl",
            name_pt="Ryl"
        },
        {
            name="Ryn",
            name_pt="Ryn"
        },
        {
            name="Savrip",
            name_pt="Savrip"
        },
        {
            name="Selkath",
            name_pt="Selkath"
        },
        {
            name="Semblan",
            name_pt="Semblan"
        },
        {
            name="Shistavanen",
            name_pt="Shistavanen"
        },
        {
            name="Shyriiwook",
            name_pt="Shyriiwook"
        },
        {
            name="Sith",
            name_pt="Sith"
        },
        {
            name="Skakoverbal",
            name_pt="Skakoverbal"
        },
        {
            name="Sluissese",
            name_pt="Slussese"
        },
        {
            name="Snivvian",
            name_pt="Snivvian"
        },
        {
            name="Squibbian",
            name_pt="Squibbian"
        },
        {
            name="Sriluurian",
            name_pt="Sriluuriano"
        },
        {
            name="Ssi-Ruuvi",
            name_pt="Ssi-Ruuvi"
        },
        {
            name="Sullustese",
            name_pt="Sullustese"
        },
        {
            name="Talz",
            name_pt="Talz"
        },
        {
            name="Thakwaashi",
            name_pt="Thakwaashi"
        },
        {
            name="Tibranese",
            name_pt="Tibranês"
        },
        {
            name="Tof",
            name_pt="Topf"
        },
        {
            name="Togorian",
            name_pt="Togoriano"
        },
        {
            name="Togruti",
            name_pt="Togruti"
        },
        {
            name="Toydarian",
            name_pt="Toydarian"
        },
        {
            name="Trianii",
            name_pt="Trianii"
        },
        {
            name="Tusken",
            name_pt="Tusken"
        },
        {
            name="Ubeninal",
            name_pt="Ubeninal"
        },
        {
            name="Ubese",
            name_pt="Ubese"
        },
        {
            name="Umbarese",
            name_pt="Umbarês"
        },
        {
            name="Utapese",
            name_pt="Utapese"
        },
        {
            name="Verpine",
            name_pt="Verpino"
        },
        {
            name="Whiphid",
            name_pt="Uísque"
        },
        {
            name="Wroonian",
            name_pt="Wroonian"
        },
        {
            name="Yarkora",
            name_pt="Yarkora"
        },
        {
            name="Yevethan",
            name_pt="Yevethan"
        },
        {
            name="Yuuzhan Vong",
            name_pt="Yuuzhan Vong"
        },
        {
            name="Yuzz",
            name_pt="Yuzz"
        },
        {
            name="Zabrak",
            name_pt="Zabrak"
        }
    },
    force_regimens={
        {
            name="Awaken Force Sensitivity",
            name_pt="Despertar Sensibilidade à Força",
            category="Treinamento da Força"
        },
        {
            name="Eyes of the Force",
            name_pt="Olhos da Força",
            category="Treinamento da Força"
        },
        {
            name="Oxygen Bottle",
            name_pt="Garrafa de Oxigênio",
            category="Treinamento da Força"
        },
        {
            name="Quiet the Mind",
            name_pt="Aquietar a Mente",
            category="Treinamento da Força"
        },
        {
            name="Telekinetic Practice",
            name_pt="Prática Telecinética",
            category="Treinamento da Força"
        },
        {
            name="Sparring Practice",
            name_pt="Prática de Combate",
            category="Treinamento com Sabre de Luz"
        },
        {
            name="Training Remote",
            name_pt="Droide de Treinamento",
            category="Treinamento com Sabre de Luz"
        },
        {
            name="Vo'ren's First Cadence",
            name_pt="Primeira Cadence de Vo'ren",
            category="Treinamento com Sabre de Luz"
        },
        {
            name="Vo'ren's Second Cadence",
            name_pt="Segunda Cadence de Vo'ren",
            category="Treinamento com Sabre de Luz"
        },
        {
            name="Vo'ren's Third Cadence",
            name_pt="Terceira Cadence de Vo'ren",
            category="Treinamento com Sabre de Luz"
        },
        {
            name="Vo'ren's Fourth Cadence",
            name_pt="Quarta Cadence de Vo'ren",
            category="Treinamento com Sabre de Luz"
        },
        {
            name="Vo'ren's Fifth Cadence",
            name_pt="Quinta Cadence de Vo'ren",
            category="Treinamento com Sabre de Luz"
        }
    },
    starship_maneuvers={
        {
            name="Ackbar Slash",
            name_pt="Ackbar Slash",
            descriptor="",
            descriptor_pt=""
        },
        {
            name="Afterburn",
            name_pt="Afterburn",
            descriptor="",
            descriptor_pt=""
        },
        {
            name="Angle Deflector Shields",
            name_pt="Escudos do deflector de ângulo",
            descriptor="attack patern",
            descriptor_pt="ataque patern"
        },
        {
            name="Attack Formation Zeta Nine",
            name_pt="Formação de ataque Zeta Nove",
            descriptor="attack patern",
            descriptor_pt="ataque patern"
        },
        {
            name="Attack Pattern Delta",
            name_pt="Delta Padrão de Ataque",
            descriptor="attack patern",
            descriptor_pt="ataque patern"
        },
        {
            name="Corellian Slip",
            name_pt="Corellian Slip",
            descriptor="",
            descriptor_pt=""
        },
        {
            name="Counter",
            name_pt="Contador",
            descriptor="dogfight",
            descriptor_pt="luta de cães"
        },
        {
            name="Darklighter Spin",
            name_pt="Girar o Luz Negra",
            descriptor="",
            descriptor_pt=""
        },
        {
            name="Devastating Hit",
            name_pt="Devastador Hit",
            descriptor="gunner",
            descriptor_pt="artilheiro"
        },
        {
            name="Engine Hit",
            name_pt="Motor atingido",
            descriptor="gunner",
            descriptor_pt="artilheiro"
        },
        {
            name="Evasive Action",
            name_pt="Ação Evasiva",
            descriptor="dogfight",
            descriptor_pt="luta de cães"
        },
        {
            name="Explosive Shot",
            name_pt="Tiro Explosivo",
            descriptor="gunner",
            descriptor_pt="artilheiro"
        },
        {
            name="Howlrunner Formation",
            name_pt="Formação Howlrunner",
            descriptor="attack patern",
            descriptor_pt="ataque patern"
        },
        {
            name="I Have You Now",
            name_pt="Tenho-te agora.",
            descriptor="",
            descriptor_pt=""
        },
        {
            name="Intercept",
            name_pt="Intercepto",
            descriptor="",
            descriptor_pt=""
        },
        {
            name="Overwhelming Assault",
            name_pt="Agressão esmagadora",
            descriptor="attack pattern",
            descriptor_pt="padrão de ataque"
        },
        {
            name="Segnor's Loop",
            name_pt="Loop de Segnor",
            descriptor="",
            descriptor_pt=""
        },
        {
            name="Shield Hit",
            name_pt="Escudo atingido",
            descriptor="gunner",
            descriptor_pt="artilheiro"
        },
        {
            name="Skim the Surface",
            name_pt="Escapar a superfície",
            descriptor="",
            descriptor_pt=""
        },
        {
            name="Skywalker Loop",
            name_pt="Skywalker Loop",
            descriptor="dogfight",
            descriptor_pt="luta de cães"
        },
        {
            name="Snap Roll",
            name_pt="Snap Roll",
            descriptor="",
            descriptor_pt=""
        },
        {
            name="Tallon Roll",
            name_pt="Rolo Tallon",
            descriptor="attack pattern",
            descriptor_pt="padrão de ataque"
        },
        {
            name="Target Lock",
            name_pt="Bloqueio do Alvo",
            descriptor="dogfight",
            descriptor_pt="luta de cães"
        },
        {
            name="Target Sense",
            name_pt="Sentido do Alvo",
            descriptor="Force",
            descriptor_pt="Forçar"
        },
        {
            name="Thruster Hit",
            name_pt="Ataque do Thruster",
            descriptor="gunner",
            descriptor_pt="artilheiro"
        },
        {
            name="Wotan Weave",
            name_pt="Wotan Weave",
            descriptor="",
            descriptor_pt=""
        }
    },
    droid_systems={
        {
            name="Antitheft comlink locator",
            name_pt="Localização de comunicação anti-roubo",
            category="Acessórios",
            cost=100,
            weight=0.5,
            availability=""
        },
        {
            name="Audio enhancers",
            name_pt="Melhoradores de áudio",
            category="Acessórios",
            cost=2000,
            weight=1,
            availability=""
        },
        {
            name="Audio-radial stunner",
            name_pt="atordoador de raios áudio",
            category="Acessórios",
            cost=5000,
            weight=3,
            availability="Restricted"
        },
        {
            name="Automap",
            name_pt="Mapa automático",
            category="Acessórios",
            cost=1000,
            weight=2,
            availability=""
        },
        {
            name="Blaster recharge interface",
            name_pt="Interface de recarga Blaster",
            category="Acessórios",
            cost=300,
            weight=1,
            availability="Licensed"
        },
        {
            name="Collapsible construction",
            name_pt="Construção colapsível",
            category="Acessórios",
            cost=4000,
            weight=20,
            availability=""
        },
        {
            name="Concealed item",
            name_pt="Artigo oculto",
            category="Acessórios",
            cost=0,
            weight=0,
            availability="Restricted"
        },
        {
            name="Courier compartments",
            name_pt="Compartimentos postais",
            category="Acessórios",
            cost=400,
            weight=4,
            availability=""
        },
        {
            name="Credit reader",
            name_pt="Leitor de crédito",
            category="Acessórios",
            cost=50,
            weight=1,
            availability="Licensed"
        },
        {
            name="Droid oil bath",
            name_pt="Banho de óleo dróide",
            category="Acessórios",
            cost=1000,
            weight=1200,
            availability=""
        },
        {
            name="Earphone binary-to-basic translator",
            name_pt="Tradutor binário a básico do fone de ouvido",
            category="Acessórios",
            cost=20,
            weight=0.5,
            availability=""
        },
        {
            name="Electric defense grid",
            name_pt="Grade de defesa elétrica",
            category="Acessórios",
            cost=6000,
            weight=200,
            availability="Restricted"
        },
        {
            name="Hidden holster",
            name_pt="Coldre escondido",
            category="Acessórios",
            cost=1000,
            weight=4,
            availability="Licensed"
        },
        {
            name="High-speed cutting torch and welder",
            name_pt="Tocha de corte de alta velocidade e soldador",
            category="Acessórios",
            cost=2500,
            weight=500,
            availability="Licensed"
        },
        {
            name="Holographic game system",
            name_pt="Sistema holográfico de jogos",
            category="Acessórios",
            cost=300,
            weight=3,
            availability=""
        },
        {
            name="Holographic image disguiser",
            name_pt="Disfarçador de imagem holográfico",
            category="Acessórios",
            cost=40000,
            weight=40,
            availability="Restricted"
        },
        {
            name="ID dodge",
            name_pt="Escape de ID",
            category="Acessórios",
            cost=5000,
            weight=1,
            availability="Illegal"
        },
        {
            name="Improved coordination circuitry",
            name_pt="Circuitos de coordenação melhorados",
            category="Acessórios",
            cost=1000,
            weight=1,
            availability=""
        },
        {
            name="Interference generator",
            name_pt="Gerador de interferências",
            category="Acessórios",
            cost=2500,
            weight=1,
            availability="Restricted"
        },
        {
            name="Internal defenses",
            name_pt="Defesas internas",
            category="Acessórios",
            cost=20,
            weight=2,
            availability="Licensed"
        },
        {
            name="Internal grapple gun",
            name_pt="Arma de carga interna",
            category="Acessórios",
            cost=200,
            weight=4,
            availability=""
        },
        {
            name="Mesh tape dispenser",
            name_pt="Dispensador de fita de malha",
            category="Acessórios",
            cost=10,
            weight=5,
            availability=""
        },
        {
            name="Micro shield",
            name_pt="Micro- escudo",
            category="Acessórios",
            cost=1200,
            weight=20,
            availability="Licensed"
        },
        {
            name="Multifunction apparatus",
            name_pt="Aparelhos multifunções",
            category="Acessórios",
            cost=160,
            weight=30,
            availability=""
        },
        {
            name="Multispectrum searchlight",
            name_pt="Luz de pesquisa multiespectro",
            category="Acessórios",
            cost=100,
            weight=2,
            availability=""
        },
        {
            name="Radiant heat element",
            name_pt="Elemento de calor radiante",
            category="Acessórios",
            cost=400,
            weight=40,
            availability=""
        },
        {
            name="Remote viewer",
            name_pt="Visualizador remoto",
            category="Acessórios",
            cost=1000,
            weight=20,
            availability=""
        },
        {
            name="Rental restraining bolt",
            name_pt="Parafusos de retenção para aluguer",
            category="Acessórios",
            cost=10,
            weight=0.5,
            availability=""
        },
        {
            name="Repulsorcam",
            name_pt="Repulsorcam",
            category="Acessórios",
            cost=1000,
            weight=20,
            availability=""
        },
        {
            name="Scomp link",
            name_pt="Ligação Scop",
            category="Acessórios",
            cost=100,
            weight=1,
            availability=""
        },
        {
            name="Silence-bubble generator",
            name_pt="Gerador de bolhas de silêncio",
            category="Acessórios",
            cost=7000,
            weight=40,
            availability="Licensed"
        },
        {
            name="Space-beacon launcher",
            name_pt="Lançador de feixes de espaço",
            category="Acessórios",
            cost=5000,
            weight=10,
            availability=""
        },
        {
            name="Survival kit",
            name_pt="Kit de sobrevivência",
            category="Acessórios",
            cost=100,
            weight=1,
            availability=""
        },
        {
            name="Taser",
            name_pt="Taser",
            category="Acessórios",
            cost=250,
            weight=2,
            availability="Licensed"
        },
        {
            name="Video screen",
            name_pt="Tela de vídeo",
            category="Acessórios",
            cost=nil,
            weight=1,
            availability=""
        },
        {
            name="Voice-print command lock",
            name_pt="Bloqueio de comando de impressão vocal",
            category="Acessórios",
            cost=400,
            weight=1,
            availability=""
        },
        {
            name="Weapon detector",
            name_pt="Detector de armas",
            category="Acessórios",
            cost=1500,
            weight=5,
            availability="Licensed"
        },
        {
            name="Probe",
            name_pt="Sonda",
            category="Apêndices",
            cost=2,
            weight=0.5
        },
        {
            name="Tool",
            name_pt="Ferramenta",
            category="Apêndices",
            cost=10,
            weight=2
        },
        {
            name="Instrument",
            name_pt="Instrumento",
            category="Apêndices",
            cost=5,
            weight=1
        },
        {
            name="Claw",
            name_pt="Garra",
            category="Apêndices",
            cost=20,
            weight=5
        },
        {
            name="Hand",
            name_pt="Mão",
            category="Apêndices",
            cost=50,
            weight=5
        },
        {
            name="Processador remoto — 5-km range",
            name_pt="Processador remoto — Faixa de 5 km",
            category="Processadores",
            cost=1000,
            weight=10
        },
        {
            name="Processador remoto — 50-km range",
            name_pt="Processador remoto — Faixa de 50 km",
            category="Processadores",
            cost=10000,
            weight=100
        },
        {
            name="Processador remoto — 500-km range",
            name_pt="Processador remoto — Alcance de 500 km",
            category="Processadores",
            cost=100000,
            weight=1000
        },
        {
            name="Processador remoto — 5000-km range",
            name_pt="Processador remoto — Gama de 5000 km",
            category="Processadores",
            cost=1000000,
            weight=10000
        },
        {
            name="Gerador de escudo SR 5",
            name_pt="Gerador de escudo SR 5",
            category="Escudos",
            cost=2500,
            weight=10,
            sr=5,
            max_size=4
        },
        {
            name="Gerador de escudo SR 10",
            name_pt="Gerador de escudo SR 10",
            category="Escudos",
            cost=5000,
            weight=20,
            sr=10,
            max_size=5
        },
        {
            name="Gerador de escudo SR 15",
            name_pt="Gerador de escudo SR 15",
            category="Escudos",
            cost=7500,
            weight=30,
            sr=15,
            max_size=6
        },
        {
            name="Gerador de escudo SR 20",
            name_pt="Gerador de escudo SR 20",
            category="Escudos",
            cost=10000,
            weight=40,
            sr=20,
            max_size=7
        },
        {
            name="Unidade tradutora CD 20",
            name_pt="Unidade tradutora CD 20",
            category="Tradução",
            cost=200,
            weight=1,
            dc=20
        },
        {
            name="Unidade tradutora CD 15",
            name_pt="Unidade tradutora CD 15",
            category="Tradução",
            cost=500,
            weight=2,
            dc=15
        },
        {
            name="Unidade tradutora CD 10",
            name_pt="Unidade tradutora CD 10",
            category="Tradução",
            cost=1000,
            weight=4,
            dc=10
        },
        {
            name="Unidade tradutora CD 5",
            name_pt="Unidade tradutora CD 5",
            category="Tradução",
            cost=2000,
            weight=8,
            dc=5
        },
        {
            name="Walking",
            name_pt="Caminhada",
            category="Locomoção",
            speed_small=4,
            speed_medium=6,
            speed_large=8,
            cost_factor=10
        },
        {
            name="Wheeled",
            name_pt="Rodas",
            category="Locomoção",
            speed_small=6,
            speed_medium=8,
            speed_large=10,
            cost_factor=5
        },
        {
            name="Tracked",
            name_pt="Esteiras",
            category="Locomoção",
            speed_small=4,
            speed_medium=6,
            speed_large=8,
            cost_factor=20
        },
        {
            name="Hovering",
            name_pt="Repulsor",
            category="Locomoção",
            speed_small=6,
            speed_medium=6,
            speed_large=6,
            cost_factor=100
        },
        {
            name="Flying",
            name_pt="Voo",
            category="Locomoção",
            speed_small=9,
            speed_medium=12,
            speed_large=12,
            cost_factor=200
        },
        {
            name="Burrow",
            name_pt="Escavação",
            category="Locomoção",
            speed_small=4,
            speed_medium=6,
            speed_large=8,
            cost_factor=200
        },
        {
            name="Underwater",
            name_pt="Subaquático",
            category="Locomoção",
            speed_small=4,
            speed_medium=6,
            speed_large=8,
            cost_factor=20
        },
        {
            name="Durasteel plating",
            name_pt="Chapas durasteel",
            category="Armaduras de Droide",
            cost=3600,
            reflex=6,
            max_dex=3,
            weight=12,
            size="l",
            availability="",
            armor_type="Light"
        },
        {
            name="Durasteel shell",
            name_pt="Concha durasteel",
            category="Armaduras de Droide",
            cost=1600,
            reflex=4,
            max_dex=4,
            weight=8,
            size="c",
            availability="",
            armor_type="Light"
        },
        {
            name="Duravlex shell",
            name_pt="Duravlex shell",
            category="Armaduras de Droide",
            cost=1000,
            reflex=4,
            max_dex=3,
            weight=10,
            size="l",
            availability="",
            armor_type="Light"
        },
        {
            name="Laminanium plating",
            name_pt="Chapas de laminanium",
            category="Armaduras de Droide",
            cost=3000,
            reflex=4,
            max_dex=3,
            weight=15,
            size="m",
            availability="",
            armor_type="Light"
        },
        {
            name="Plasteel shell",
            name_pt="Plasteel shell",
            category="Armaduras de Droide",
            cost=400,
            reflex=2,
            max_dex=5,
            weight=2,
            size="c",
            availability="",
            armor_type="Light"
        },
        {
            name="Quadanium plating",
            name_pt="Chapa quadrada",
            category="Armaduras de Droide",
            cost=2500,
            reflex=5,
            max_dex=3,
            weight=10,
            size="l",
            availability="",
            armor_type="Light"
        },
        {
            name="Quadanium shell",
            name_pt="Carapaça de quadânio",
            category="Armaduras de Droide",
            cost=900,
            reflex=3,
            max_dex=4,
            weight=3,
            size="c",
            availability="",
            armor_type="Light"
        },
        {
            name="Duranium plating",
            name_pt="Revestimento de duranium",
            category="Armaduras de Droide",
            cost=6400,
            reflex=8,
            max_dex=2,
            weight=16,
            size="r",
            availability="",
            armor_type="Medium"
        },
        {
            name="Durasteel battle armor",
            name_pt="Armadura de batalha Durasteel",
            category="Armaduras de Droide",
            cost=9600,
            reflex=8,
            max_dex=3,
            weight=8,
            size="r",
            availability="",
            armor_type="Medium"
        },
        {
            name="Crystadurium plating",
            name_pt="Chapas de crystadurium",
            category="Armaduras de Droide",
            cost=50000,
            reflex=10,
            max_dex=2,
            weight=30,
            size="m",
            availability="r",
            armor_type="Heavy"
        },
        {
            name="Duranium battle armor",
            name_pt="Armadura de batalha Duranium",
            category="Armaduras de Droide",
            cost=10000,
            reflex=10,
            max_dex=2,
            weight=10,
            size="m",
            availability="",
            armor_type="Heavy"
        },
        {
            name="Heavy laminanium plating",
            name_pt="Chapas de laminado pesado",
            category="Armaduras de Droide",
            cost=20000,
            reflex=12,
            max_dex=2,
            weight=15,
            size="m",
            availability="r",
            armor_type="Heavy"
        },
        {
            name="Mandalorian steel shell",
            name_pt="Carapaça de aço mandaroriano",
            category="Armaduras de Droide",
            cost=8100,
            reflex=9,
            max_dex=3,
            weight=9,
            size="m",
            availability="r",
            armor_type="Heavy"
        },
        {
            name="Neutronium plating",
            name_pt="Revestimento de neutrónio",
            category="Armaduras de Droide",
            cost=12100,
            reflex=11,
            max_dex=1,
            weight=20,
            size="m",
            availability="",
            armor_type="Heavy"
        },
        {
            name="Comlink, internal",
            name_pt="Comlink, interno",
            category="Comunicações",
            cost=250.0,
            weight=0.1
        },
        {
            name="Communications countermeasures",
            name_pt="Contramedidas de comunicação",
            category="Comunicações",
            cost=1000.0,
            weight=3.0
        },
        {
            name="Communications jammer",
            name_pt="Bloqueador de comunicações",
            category="Comunicações",
            cost=5000.0,
            weight=5.0
        },
        {
            name="Diagnostics package",
            name_pt="Pacote de diagnóstico",
            category="Comunicações",
            cost=250.0,
            weight=4.0
        },
        {
            name="Droid caller",
            name_pt="Chamador dróide",
            category="Comunicações",
            cost=10.0,
            weight=0.2
        },
        {
            name="Remote reciever jammer",
            name_pt="Bloqueador remoto reciever",
            category="Comunicações",
            cost=2000.0,
            weight=2.0
        },
        {
            name="Remote reciever signal booster",
            name_pt="Booster de sinal reciever remoto",
            category="Comunicações",
            cost=500.0,
            weight=2.0
        },
        {
            name="Vocabulator",
            name_pt="Vocabulador",
            category="Comunicações",
            cost=50.0,
            weight=0.5
        },
        {
            name="Internal Storage Space",
            name_pt="Espaço de Armazenamento Interno",
            category="Armazenamento",
            cost=nil,
            weight=nil
        },
        {
            name="Spring-loaded mechanism",
            name_pt="Mecanismo carregado por mola",
            category="Armazenamento",
            cost=150.0,
            weight=3.0
        },
        {
            name="Locked access",
            name_pt="Acesso bloqueado",
            category="Armazenamento",
            cost=50.0,
            weight=nil
        },
        {
            name="Heuristic processor",
            name_pt="Processador heurístico",
            category="Processadores",
            cost=2000.0,
            weight=5.0
        },
        {
            name="Remote processor",
            name_pt="Processador remoto",
            category="Processadores",
            cost=nil,
            weight=nil
        },
        {
            name="Remote reciever",
            name_pt="Reciever remoto",
            category="Processadores",
            cost=nil,
            weight=1.0
        },
        {
            name="Backup processor",
            name_pt="Processador de backup",
            category="Processadores",
            cost=100.0,
            weight=nil
        },
        {
            name="Synchronized fire circuits",
            name_pt="Circuitos de incêndio sincronizados",
            category="Processadores",
            cost=150.0,
            weight=1.0
        },
        {
            name="Restraining bolt",
            name_pt="Parafusos de retenção",
            category="Processadores",
            cost=5.0,
            weight=nil
        },
        {
            name="Secondary battery",
            name_pt="Bateria secundária",
            category="Processadores",
            cost=400.0,
            weight=4.0
        },
        {
            name="Self-destruct system",
            name_pt="Sistema de autodestruição",
            category="Processadores",
            cost=24.0,
            weight=24.0
        },
        {
            name="Droid remote control",
            name_pt="Controle remoto dróide",
            category="Processadores",
            cost=500.0,
            weight=0.5
        },
        {
            name="Hidden core",
            name_pt="Núcleo oculto",
            category="Processadores",
            cost=200.0,
            weight=1.0
        },
        {
            name="Personality downloader",
            name_pt="Baixeiro de Personalidade",
            category="Processadores",
            cost=nil,
            weight=nil
        },
        {
            name="Remote starship starter",
            name_pt="Iniciador de nave estelar remota",
            category="Processadores",
            cost=50.0,
            weight=2.0
        },
        {
            name="Specialized subprocessor",
            name_pt="Subprocessador especializado",
            category="Processadores",
            cost=1000.0,
            weight=2.0
        },
        {
            name="Tactician battle computer",
            name_pt="Computador de batalha táctico",
            category="Processadores",
            cost=5000.0,
            weight=10.0
        },
        {
            name="Improved sensor package",
            name_pt="Pacote de sensor melhorado",
            category="Sensores",
            cost=200.0,
            weight=2.5
        },
        {
            name="Darkvision",
            name_pt="Visão escura",
            category="Sensores",
            cost=150.0,
            weight=1.5
        },
        {
            name="Sensor booster",
            name_pt="Reforço do sensor",
            category="Sensores",
            cost=nil,
            weight=nil
        },
        {
            name="Sensor countermeasure package",
            name_pt="Pacote de contramedidas do sensor",
            category="Sensores",
            cost=nil,
            weight=nil
        },
        {
            name="YV sensor package",
            name_pt="Pacote de sensores YV",
            category="Sensores",
            cost=nil,
            weight=nil
        },
        {
            name="Emergency oxygen supply",
            name_pt="Fornecimento de oxigénio de emergência",
            category="Acessórios",
            cost=nil,
            weight=nil
        }
    },
    droid_chassis={
        {
            name="Astromech Droid Chassis",
            name_pt="Astromech Droid Chassis",
            description="Astromech droids are constructed with the following droid systems installed in each: \n\nwheeled locomotion 6\nwalking locomotion 4\nmagnetic feet\nheuristic processor\n6 tool appendages\n1 claw appendage\nastrogation buffer (5 memory units)\ndiagnostics package\ninternal storage (2 kg)",
            description_pt="Os dróides Astromech são construídos com os seguintes sistemas dróides instalados em cada um deles:\n\nlocomoção de rodas 6\nlocomoção em marcha 4\npés magnéticos\nprocessador heurístico\n6 apêndices de ferramentas\n1 apêndice de garra\nbuffer de astrogation (5 unidades de memória)\npacote de diagnóstico\narmazenagem interna (2 kg)"
        },
        {
            name="Battle Droid Chassis",
            name_pt="Combater o Chassi Dróide",
            description="Battle droids are constructed with the following droid systems installed in each:\n\nwalking locomotion 6\nplasteel shell (+2 armor)\nbasic processor\ninternal comlink\nlocked access\n2 hand appendages\nvocabulator",
            description_pt="Os dróides de batalha são construídos com os seguintes sistemas dróides instalados em cada um deles:\n\nlocomoção em marcha 6\nrevestimento de plasteel (+2 armadura)\nprocessador básico\ncomunicação interna\nacesso bloqueado\n2 apêndices manuais\nvocabulário"
        },
        {
            name="Labor Droid Chassis",
            name_pt="Chassis Dróide do Trabalho",
            description="Labor droids are constructed with the following droid systems installed in each:\n\nwalking locomotion 6\ndurasteel shell (+4 armor)\nbasic processor\n2 claw appendages\nvocabulator",
            description_pt="Os dróides do trabalho são construídos com os seguintes sistemas dróides instalados em cada um:\n\nlocomoção em marcha 6\nconcha durasteel (+4 armadura)\nprocessador básico\n2 apêndices de garras\nvocabulário"
        },
        {
            name="Mechanic Droid Chassis",
            name_pt="Chassis Dróide Mecânica",
            description="Mechanic droids are constructed with the following droid systems installed in each:\n\nwalking locomotion 6 (or tracked or wheeled locomotion)\nbasic processor\n2 hand appendages\n4 tool appendages\ndiagnostics package\ninternal storage (2 kg)\nvocabulator",
            description_pt="Os dróides mecânicos são construídos com os seguintes sistemas dróides instalados em cada um deles:\n\nlocomoção caminhada 6 (ou locomoção rastreada ou de rodas)\nprocessador básico\n2 apêndices manuais\n4 anexos de ferramentas\npacote de diagnóstico\narmazenagem interna (2 kg)\nvocabulário"
        },
        {
            name="Medical Droid Chassis",
            name_pt="Chassis Dróide Médico",
            description="Medical droids are constructed with the following droid systems installed in each:\n\nwalking locomotion\nheuristic processor\n2 hand appendages\n1 tool appendage\nvocabulator\nimproved sensor package",
            description_pt="Os dróides médicos são construídos com os seguintes sistemas dróides instalados em cada um deles:\n\nlocomoção da marcha\nprocessador heurístico\n2 apêndices manuais\n1 apêndice da ferramenta\nvocabulário\npacote de sensor melhorado"
        },
        {
            name="Probe Droid Chassis",
            name_pt="Chassi Dróide Sonda",
            description="Probe droids are designed for surveillance and are constructed with the following droid systems installed in each:\n\nhovering locomotion 6\nheuristic processor\ninternal comlink\nlocked access\n1 hand appendage\n1 tool appendage\nimproved sensor package\ndarkvision",
            description_pt="Os dróides sonda são projetados para vigilância e são construídos com os seguintes sistemas dróides instalados em cada um deles:\n\nlocomoção pairando 6\nprocessador heurístico\ncomunicação interna\nacesso bloqueado\n1 apêndice da mão\n1 apêndice da ferramenta\npacote de sensor melhorado\nvisão escura"
        },
        {
            name="Protocol Droid Chassis",
            name_pt="Protocolo Droid Chassis",
            description="Protocol droids are constructed with the following droid systems installed in each:\n\nwalking locomotion 6\nbasic processor\n2 hand appendages\nvocabulator\ntranslator unit (DC 10)",
            description_pt="Os dróides de protocolo são construídos com os seguintes sistemas dróides instalados em cada um deles:\n\nlocomoção em marcha 6\nprocessador básico\n2 apêndices manuais\nvocabulário\nUnidade tradutora (DC 10)"
        },
        {
            name="Service Droid Chassis",
            name_pt="Chassis Dróide de Serviço",
            description="Service droids are constructed with the following droid systems installed in each:\n\nwalking locomotion 6\nbasic processor\n2 hand appendages\n1 tool mount\nvocabulator",
            description_pt="Os dróides de serviço são construídos com os seguintes sistemas dróides instalados em cada um deles:\n\nlocomoção em marcha 6\nprocessador básico\n2 apêndices manuais\n1 montagem de ferramentas\nvocabulário"
        }
    },
    droid_manufacturers={
        {
            name="Arakyd Industries",
            name_pt="Arakyd Industries",
            description="Once per day, an Arakyd droid can make a Persuasion check or a Use Computer check against a DC equal to its own Will Defense. If the check is successful, the droid's behavioral inhibitor allows it to take prohibited actions until the forbidden action is completed. After completion, the inhibitor returns to normal functioning.",
            description_pt="Uma vez por dia, um dróide Arakyd pode fazer uma verificação de Persuasão ou uma verificação Use Computer contra uma DC igual à sua própria defesa de vontade. Se o check for bem sucedido, o inibidor comportamental do dróide permite que ele tome ações proibidas até que a ação proibida seja concluída. Após a conclusão, o inibidor retorna ao funcionamento normal."
        },
        {
            name="Baktoid Combat Automata",
            name_pt="Baktoid Combat Automata",
            description="A character can make a Persuasion check opposed by a Baktoid droid's Perception skill to attempt to temporarily confuse it with contradictory data or brash, seemingly illogical action. If the check is successful, the droid can take no action for one round as it tries to f ind an appropriate response. If the Persuasion check is unsuccessful, the droid recognizes the ruse and proclaims it loudly while taking an immediate swift action as a reaction.",
            description_pt="Um personagem pode fazer uma verificação de persuasão oposta pela habilidade de percepção de um dróide baktoid para tentar confundi-lo temporariamente com dados contraditórios ou ação aparentemente ilógica. Se a verificação for bem sucedida, o dróide não pode tomar nenhuma ação para uma rodada, uma vez que tenta f ind uma resposta adequada. Se a verificação de persuasão não for bem sucedida, o dróide reconhece o estratagema e o proclama em voz alta enquanto toma uma ação rápida imediata como uma reação."
        },
        {
            name="Balmorran Arms",
            name_pt="Balmorran Arms",
            description="When creating or purchasing a new Balmorran Arms droid, increase one ability score by 1",
            description_pt="Ao criar ou comprar um novo dróide Balmorran Arms, aumente uma pontuação de habilidade em 1"
        },
        {
            name="Colicoid Creation Nest",
            name_pt="Colicoid Creation Nest",
            description="Once per encounter, a Colicoid droid can ignore all negative penalties from its location on the condition track when making an attack.",
            description_pt="Uma vez por encontro, um dróide colicoide pode ignorar todas as penalidades negativas de sua localização na pista de condição ao fazer um ataque."
        },
        {
            name="Cybot Galactica",
            name_pt="Cybot Galactica",
            description="Cybot systems are so commonplace that nondroid heroes with Skill Focus (Mechanics) can modify or repair Cybot droids in half the time that would be required for a normal droid",
            description_pt="Os sistemas Cybots são tão comuns que heróis não dróides com Skill Focus (Mecânica) podem modificar ou reparar dróides Cybots na metade do tempo que seria necessário para um dróide normal"
        },
        {
            name="Czerka Corporation",
            name_pt="Czerka Corporation",
            description="A Czerka droid can use its Intelligence or Wisdom modifier instead of its Charisma modifier to determine its Persuasion skill modifier.",
            description_pt="Um dróide Czerka pode usar seu modificador Inteligência ou Sabedoria em vez de seu modificador Carisma para determinar seu modificador de habilidade Persuasão."
        },
        {
            name="Duwani Mechanical Products",
            name_pt="Duwani Mechanical Products",
            description="Once per encounter, when it has half or fewer of its maximum hit points, as a reaction, a Duwani droid can either gain 5 bonus hit points or add 5 to its damage threshold for one round.",
            description_pt="Uma vez por encontro, quando ele tem metade ou menos de seus pontos de ataque máximos, como uma reação, um dróide Duwani pode ganhar 5 pontos de bônus ou adicionar 5 ao seu limiar de dano para uma rodada."
        },
        {
            name="Holowan Mechanicals",
            name_pt="Holowan Mechanicals",
            description="Once per encounter, a Holowan droid can add 1 die of damage to an attack.",
            description_pt="Uma vez por encontro, um dróide Holowan pode adicionar 1 morte de dano a um ataque."
        },
        {
            name="Imperial Department of Military Research",
            name_pt="Imperial Department of Military Research",
            description="Imperial droids vary greatly in mission and specifications. However, their prototypes are constructed with built-in tracking devices and recording equipment to document the droid's performance. The droids transmit the data upon command to a central reporting station or, when in the field, to the nearest Imperial installation.",
            description_pt="Os dróides imperiais variam muito em missão e especificações. No entanto, seus protótipos são construídos com dispositivos de rastreamento incorporados e equipamentos de gravação para documentar o desempenho do dróide. Os dróides transmitem os dados sob comando para uma estação central de notificação ou, quando em campo, para a instalação imperial mais próxima."
        },
        {
            name="Industrial Automaton",
            name_pt="Industrial Automaton",
            description="When assisting on a Mechanics check, an Industrial Automaton droid trained in Mechanics can add its Intelligence bonus (minimum + 1) to the normal +2 bonus.",
            description_pt="Ao ajudar em uma verificação Mecânica, um dróide Industrial Automaton treinado em Mecânica pode adicionar seu bônus de inteligência (mínimo + 1) ao bônus normal +2."
        },
        {
            name="MerenData",
            name_pt="MerenData",
            description="When making a Persuasion check to intimidate, a MerenData droid adds its Wi sdom bonus to the skill check. When attempting to intimidate another droid, it adds its Wisdom bonus and its Charisma bonus to the check.",
            description_pt="Ao fazer uma verificação de persuasão para intimidar, um dróide MerenData adiciona seu bônus Wi sdom à verificação de habilidade. Ao tentar intimidar outro dróide, ele adiciona seu bônus Sabedoria e seu bônus Carisma ao cheque."
        },
        {
            name="Roche",
            name_pt="Roche",
            description="When modifying an appendage, an accessory, a tool, a weapon, or an instrument mounted on an appendage, apply a +5 circumstance bonus to the Mechanics check.",
            description_pt="Ao modificar um apêndice, um acessório, uma ferramenta, uma arma ou um instrumento montado em um apêndice, aplique um bônus de circunstância +5 na verificação Mecânica."
        },
        {
            name="Tendrando Arms",
            name_pt="Tendrando Arms",
            description="A Tendrando Arms droid gains a +2 circumstance bonus to its Reflex Defense and Will Defense against Yuuzhan Vong.",
            description_pt="Um dróide Tendrando Arms ganha um bônus de +2 circunstâncias para sua Defesa Reflexa e Defesa de Vontade contra Yuuzhan Vong."
        },
        {
            name="Veril Line Systems",
            name_pt="Veril Line Systems",
            description="Once per day, a Veriline droid can make a DC 20 Endurance check to extend its run time by 25 hours or to move + 1 step on the condition track.",
            description_pt="Uma vez por dia, um dróide Veriline pode fazer uma verificação DC 20 Endurance para estender seu tempo de execução por 25 horas ou para mover + 1 passo na pista de condição."
        }
    },
    droid_quirks={
        {
            name="Aggressive",
            name_pt="Agressivo",
            hardware="",
            software="S",
            description="The droid does not back down from a fight unless it has direct orders from its master or is facing obviouslyoverwhelming opposition.",
            description_pt="O dróide não recua de uma luta a menos que tenha ordens diretas de seu mestre ou esteja enfrentando obviamente uma oposição esmagadora."
        },
        {
            name="Alien Appearance",
            name_pt="Aparência Alienígena",
            hardware="H",
            software="",
            description="This droid has a truly alien appearance that attracts attention. Interaction with most species causes a -2 penalty toCharisma-based skill checks, although the droid gains a +2 bonus when using the Persuasion skill to intimidate.",
            description_pt="Este dróide tem uma aparência alienígena que atrai a atenção. A interação com a maioria das espécies causa uma penalidade -2 para verificações de habilidades baseadas em Carisma, embora o dróide ganhe um bônus +2 ao usar a habilidade de Persuasão para intimidar."
        },
        {
            name="Alternate Personality",
            name_pt="Personalidade alternativa",
            hardware="H",
            software="S",
            description="The droid holds another personality as a leftover from a previous owner or because of damaged processorsor data. Alternate personalities are usually software quirks, but those caused by damaged systems are hardware quirks.",
            description_pt="O dróide possui outra personalidade como sobra de um proprietário anterior ou por causa de dados danificados. Personalidades alternativas geralmente são peculiaridades de software, mas aquelas causadas por sistemas danificados são peculiaridades de hardware."
        },
        {
            name="Amenable",
            name_pt="Amenizável",
            hardware="",
            software="S",
            description="The droid defers to others and attempts to keep all parties happy at all times, sometimes even during combat.",
            description_pt="O dróide cede aos outros e tenta manter todas as partes felizes em todos os momentos, às vezes mesmo durante o combate."
        },
        {
            name="Argumentative",
            name_pt="Argumentativo",
            hardware="",
            software="S",
            description="The droid develops an urge to argue in any situation, often demanding the last word.",
            description_pt="O dróide desenvolve um desejo de argumentar em qualquer situação, muitas vezes exigindo a última palavra."
        },
        {
            name="Arrogant",
            name_pt="Arrogante",
            hardware="",
            software="S",
            description="The droid is extremely arrogant and condescending to its owner and everyone else.",
            description_pt="O dróide é extremamente arrogante e condescendente com o seu dono e com todos os outros."
        },
        {
            name="Audio Glitch",
            name_pt="Falha de Áudio",
            hardware="H",
            software="S",
            description="The droid's audio sensors have trouble detecting certain frequencies or become hypersensitive, causing a -2 penaltyto audio-based Perception checks.",
            description_pt="Os sensores de áudio do dróide têm dificuldade em detectar certas frequências ou tornar-se hipersensível, causando uma -2 penalização à percepção baseada em áudio."
        },
        {
            name="Blaster Happy",
            name_pt="Blaster Feliz",
            hardware="",
            software="S",
            description="The combat-related droid tends to shoot first and listen to orders later. It also might continue to fire at a defeated enemyjust to make sure.",
            description_pt="O dróide relacionado ao combate tende a atirar primeiro e ouvir ordens mais tarde. Também pode continuar a disparar contra um inimigo derrotado apenas para ter certeza."
        },
        {
            name="Center of Attention",
            name_pt="Centro de Atenção",
            hardware="",
            software="S",
            description="The droid insists on being the center of attention, and it attempts to dominate any conversation.",
            description_pt="O dróide insiste em ser o centro das atenções, e tenta dominar qualquer conversa."
        },
        {
            name="Curious/Inquisitive",
            name_pt="Curioso/Inquisitivo",
            hardware="",
            software="S",
            description="The droid seeks knowledge or information about its immediate surroundings. The droid enters locations andsituations in which it is unwanted or not allowed.",
            description_pt="O dróide busca conhecimento ou informação sobre seu entorno imediato. O dróide entra em locais e situações em que é indesejado ou não permitido."
        },
        {
            name="Easily Distracted",
            name_pt="Distraído Facilmente",
            hardware="",
            software="S",
            description="The droid is easy to distract from a given task. The droid must resist a 1d20+5 attack against its Will Defense whenattempting tasks that take longer than a full-round action to complete. A successful attack results in the droid's jumping to the next task or becoming distracted by something in its immediate surroundings.",
            description_pt="O dróide é fácil de distrair de uma determinada tarefa. O dróide deve resistir a um ataque 1d20+5 contra sua Defesa de Vontade ao tentar tarefas que levem mais tempo do que uma ação completa para completar. Um ataque bem sucedido resulta em o dróide saltar para a próxima tarefa ou se distrair por algo em seu entorno imediato."
        },
        {
            name="Excitable",
            name_pt="Excitável",
            hardware="",
            software="S",
            description="The droid is high strung, speaking, moving, and working rapidly in thrilling situations.",
            description_pt="O dróide é muito tenso, falando, se movendo e trabalhando rapidamente em situações emocionantes."
        },
        {
            name="Faulty Wiring",
            name_pt="Fiação com defeito",
            hardware="H",
            software="",
            description="The droid's wiring is in bad condition. When the droid moves down the condition track as a result of damage that exceedsits damage threshold, the condition becomes persistent until repaired.",
            description_pt="A fiação do dróide está em más condições. Quando o dróide se move para baixo da pista condição como resultado de danos que excedem o seu limiar de dano, a condição torna-se persistente até reparado."
        },
        {
            name="Focused",
            name_pt="Focado",
            hardware="",
            software="S",
            description="The droid becomes fixated on a task until it is completed, even if more critical tasks appear. It takes a -2 penalty to Perceptionchecks when fixated.",
            description_pt="O dróide fica fixado em uma tarefa até que ela seja concluída, mesmo que apareçam tarefas mais críticas. É preciso uma penalidade -2 para Perceptionchecks quando fixado."
        },
        {
            name="Helpful",
            name_pt="Útil",
            hardware="",
            software="S",
            description="The droid is overly dedicated to helping its master with any task it is capable of, and it is willing to attempt tasks that it is nottrained to do.",
            description_pt="O dróide é excessivamente dedicado a ajudar seu mestre com qualquer tarefa que ele é capaz de fazer, e está disposto a tentar tarefas que ele não é treinado para fazer."
        },
        {
            name="Honest",
            name_pt="Honesto.",
            hardware="",
            software="S",
            description="The droid is honest to a fault and is incapable of lying. It cannot make Deception checks.",
            description_pt="O dróide é honesto com uma falha e é incapaz de mentir. Não pode fazer verificações de engano."
        },
        {
            name="Impulsive",
            name_pt="Impulsivo",
            hardware="",
            software="S",
            description="The droid makes snap judgments or decisions, thinking only in the short term, which might be as short as only a few seconds.",
            description_pt="O dróide faz julgamentos rápidos ou decisões, pensando apenas a curto prazo, o que pode ser tão curto quanto apenas alguns segundos."
        },
        {
            name="Incomplete Memory Wipe",
            name_pt="Limpar Memória Incompleta",
            hardware="",
            software="S",
            description="The droid's last memory wipe was not completely successful. The droid gets confused when it remembersfragmented memories or when it attempts a skill that it was formerly trained in but now lacks complete instructions for. The droid is still considered untrained in the skill.",
            description_pt="A última limpeza da memória do dróide não foi completamente bem sucedida. O dróide fica confuso quando se lembra de memórias fragmentadas ou quando tenta uma habilidade em que foi anteriormente treinado, mas agora carece de instruções completas para. O dróide ainda é considerado destreinado na habilidade."
        },
        {
            name="Leaky",
            name_pt="Leaky",
            hardware="H",
            software="",
            description="The droid regularly leaks hydraulic fluid, cooling gas, or a similar substance in an amount that does not significantly hinderoperations but does make a mess.",
            description_pt="O dróide regularmente vaza fluido hidráulico, gás de resfriamento, ou uma substância similar em uma quantidade que não dificulta significativamente as operações, mas faz uma bagunça."
        },
        {
            name="Locomotion Malfunction",
            name_pt="Mal funcionamento da locomoção",
            hardware="H",
            software="",
            description="The droid's locomotion system malfunctions regularly, but not necessarily constantly. Examples are trouble",
            description_pt="O sistema de locomoção do dróide funciona regularmente, mas não necessariamente constantemente. Exemplos são problemas"
        },
        {
            name="Loyal",
            name_pt="Leal",
            hardware="",
            software="S",
            description="The droid has an unshakable loyalty to its master or another organic entity. It embarrasses its owner with its concern for his orher well-being.",
            description_pt="O dróide tem uma lealdade inabalável ao seu mestre ou outra entidade orgânica. Envergonha o seu dono com a sua preocupação com o seu bem-estar."
        },
        {
            name="Morose",
            name_pt="Moroso",
            hardware="",
            software="S",
            description="The droid is morbid in conversation. This quirk is particularly disturbing when manifested by medical droids and battle droids.",
            description_pt="O dróide é mórbido na conversa. Esta peculiaridade é particularmente perturbadora quando manifestada por dróides médicos e dróides de batalha."
        },
        {
            name="Nervous",
            name_pt="Nervoso",
            hardware="",
            software="S",
            description="The droid is nervous in common situations. It might be nervous about performing its function successfully, speaking toits masters, or entering combat.",
            description_pt="O dróide está nervoso em situações comuns. Pode ficar nervoso sobre o desempenho de sua função com sucesso, falando com seus mestres, ou entrando em combate."
        },
        {
            name="Noisy",
            name_pt="Barulhenta",
            hardware="H",
            software="",
            description="The droid is unusually noisy, drawing attention to itself. The source of the racket might be a grinding locomotion system, asquealing appendage, jet-like internal cooling fans, piercing high-pitched whines from its processor, or a similar mechanical malady. The droid takes a -5 penalty to Stealth checks when the offending system is used.",
            description_pt="O dróide é incomummente barulhento, chamando atenção para si mesmo. A fonte da raquete pode ser um sistema de moagem locomoção, apêndice asquealing, jato-como ventiladores de resfriamento interno, piercing alto-picking de seu processador, ou uma doença mecânica semelhante. O dróide leva uma penalidade -5 para verificações Stealth quando o sistema ofensivo é usado."
        },
        {
            name="Obsessive",
            name_pt="Obsessivo",
            hardware="",
            software="S",
            description="The droid focuses on using a single skill or piece of equipment in its arsenal.",
            description_pt="O dróide foca em usar uma única habilidade ou peça de equipamento em seu arsenal."
        },
        {
            name="Overconfident",
            name_pt="Sobreconfiante",
            hardware="",
            software="S",
            description="The droid believes it (or possibly its master) is thoroughly capable of succeeding at any task it is trained in or proficient in.",
            description_pt="O dróide acredita que ele (ou possivelmente seu mestre) é completamente capaz de ter sucesso em qualquer tarefa em que é treinado ou proficiente."
        },
        {
            name="Overprotective",
            name_pt="Superprotector",
            hardware="",
            software="",
            description="The droid becomes overly protective of its master, a vehicle, an object, or another droid. It resists being away from the objectof its overprotection, and it might undertake irrational acts to ensure the object's safety.",
            description_pt="O dróide torna-se excessivamente protetor de seu mestre, um veículo, um objeto ou outro dróide. Resiste a estar longe do objecto da sua superprotecção, e pode empreender actos irracionais para garantir a segurança do objecto."
        },
        {
            name="Paranoid",
            name_pt="Paranóico",
            hardware="",
            software="S",
            description="The droid believes something-or possibly everything-is out to get it. Because the droid is constantly on the lookout, it getseither a +2 bonus or a -2 penalty to Perception checks, depending on the situation.",
            description_pt="O dróide acredita que alguma coisa, ou possivelmente tudo, está fora para obtê-lo. Como o dróide está constantemente atento, ele recebe um bônus +2 ou uma penalidade -2 para a Percepção, dependendo da situação."
        },
        {
            name="Possessive",
            name_pt="Possível",
            hardware="",
            software="S",
            description="The droid latches on to possessions or other items and refuses to give an item up without extensive coaxing and reassurancethat the item will be returned, requiring an opposed Persuasion check against the droid's Will Defense.",
            description_pt="O dróide se prende a possessões ou outros itens e se recusa a dar um item sem grande coaxia e segurança de que o item será devolvido, exigindo uma verificação de Persuasão oposta contra a Defesa de Vontade do dróide."
        },
        {
            name="Rude",
            name_pt="Rude",
            hardware="",
            software="S",
            description="The droid is rude to everyone-organic or mechanical-and is unpleasant to be around. It takes a -5 penalty to Persuasion checksto improve another's attitude.",
            description_pt="O dróide é rude para todos, orgânico ou mecânico, e é desagradável estar por perto. Para melhorar a atitude dos outros, é necessária uma penalização de -5 para os controlos de persuasão."
        },
        {
            name="Short Circuit",
            name_pt="Circuito Curto",
            hardware="H",
            software="",
            description="The droid suffers from short circuits in its processors, which occasionally disrupt its speech, movement, or skill usefor one round.",
            description_pt="O dróide sofre de curto-circuitos em seus processadores, que ocasionalmente interrompem sua fala, movimento, ou habilidade de uso para uma rodada."
        },
        {
            name="Slow",
            name_pt="Devagar",
            hardware="H",
            software="S",
            description="The droid does not move or process information quickly. Select one of the following penalties: -2 squares to speed, -2 to allInitiative checks, or -2 to Intelligence-based skill checks.",
            description_pt="O dróide não move ou processa informações rapidamente. Selecione uma das seguintes penalidades: -2 quadrados para acelerar, -2 para todas as verificações iniciais, ou -2 para verificações de habilidades baseadas em inteligência."
        },
        {
            name="Sprung Hatch",
            name_pt="Sprung Hatch",
            hardware="H",
            software="",
            description="One or more of the droid's maintenance panels cannot close or latch properly. Whenever the droid takes damage greaterthan its damage threshold, one of the hatches pops open. It can be closed again as a swift action, but it remains closed for only one round before popping open again. Temporarily securing the hatch requires a DC 15 Mechanics check as a full-round action, but it does not permanently remove the quirk.",
            description_pt="Um ou mais painéis de manutenção do dróide não podem fechar ou fechar corretamente. Sempre que o dróide sofre danos maiores do que o limiar de danos, uma das escotilhas se abre. Pode ser fechado novamente como uma ação rápida, mas permanece fechado por apenas uma rodada antes de estourar aberto novamente. A fixação temporária da escotilha requer uma verificação da mecânica DC 15 como uma ação completa, mas não remove permanentemente a peculiaridade."
        },
        {
            name="stopping forward movement, limping, hovering at a lower or inconsistent level, or a sticking tread or joint. When malfunctioning, the droid loses 2 squares of speed and/or its Dexterity bonus",
            name_pt="parar o movimento para a frente, mancar, pairar a um nível inferior ou inconsistente, ou uma pegada ou articulação. Quando mau funcionamento, o dróide perde 2 quadrados de velocidade e / ou seu bônus de Dexterity",
            hardware="",
            software="",
            description="",
            description_pt=""
        },
        {
            name="Sullen",
            name_pt="Suleno",
            hardware="",
            software="S",
            description="The droid is depressed, with a dim outlook on the future.",
            description_pt="O dróide está deprimido, com uma visão fraca do futuro."
        },
        {
            name="Suspicious",
            name_pt="Suspeita",
            hardware="",
            software="S",
            description="The droid doesn't trust an individual, a corporate or government entity, or some other group, no matter how much its mastersor others attempt to convince it otherwise. It treats the object of its suspicions as unfriendly at best.",
            description_pt="O dróide não confia em um indivíduo, uma entidade corporativa ou governamental, ou em algum outro grupo, não importa o quanto seus mestres ou outros tentem convencê-lo do contrário. Trata o objecto das suas suspeitas como, na melhor das hipóteses, hostil."
        },
        {
            name="Talkative",
            name_pt="Conversativo",
            hardware="",
            software="S",
            description="The droid talks incessantly, with few information filters and at inappropriate moments.",
            description_pt="O dróide fala incessantemente, com poucos filtros de informação e em momentos inadequados."
        },
        {
            name="Temperature Variations",
            name_pt="Variações de temperatura",
            hardware="H",
            software="",
            description="The droid runs hotter than normal, so anyone stand ing next to it or sharing an enclosed space with it becomesuncomfortable. A droid with an internal heating and cooling system might fluctuate between very hot and very cold temperatures.",
            description_pt="O dróide corre mais quente do que o normal, por isso qualquer pessoa fica ao seu lado ou partilha um espaço fechado com ele torna-se desconfortável. Um dróide com um sistema interno de aquecimento e refrigeração pode flutuar entre temperaturas muito quentes e muito frias."
        },
        {
            name="Visual Impairment",
            name_pt="Incapacidade Visual",
            hardware="H",
            software="S",
            description="The droid's visual sensors are slightly impaired. The droid might not see all colors, see only black and white, orlose sight for brief periods. This quirk is typically a hardware glitch that results in a -2 penalty to related visually based Perception checks.",
            description_pt="Os sensores visuais do dróide estão ligeiramente danificados. O dróide pode não ver todas as cores, ver apenas preto e branco, ou perder visão por breves períodos. Esta peculiaridade é tipicamente uma falha de hardware que resulta em uma penalidade -2 para as verificações de percepção visual relacionadas."
        },
        {
            name="Vocoder Glitch",
            name_pt="Vocoder Glitch",
            hardware="H",
            software="",
            description="The droid's vocoder becomes stuck, causing the droid's voice to be squeaky, deep, monosyllabic, or sing-songy.This quirk might occur for only a few seconds, or it might last for days.",
            description_pt="O vocoder do dróide fica preso, fazendo com que a voz do dróide seja estridente, profunda, monossilábica ou sing-songy. Esta peculiaridade pode ocorrer por apenas alguns segundos, ou pode durar por dias."
        }
    },
    destinies={
        {
            name="Champion",
            name_pt="Campeão",
            bonus="+1 to all defenses",
            bonus_pt="+1 para todas as defesas",
            penalty="-2 to all defenses",
            penalty_pt="- 2 a todas as defesas",
            completed="",
            completed_pt=""
        },
        {
            name="Corruption",
            name_pt="Corrupção",
            bonus="+1 skills and ability checks",
            bonus_pt="+1 habilidades e verificação de capacidade",
            penalty="-2 skills and ability checks",
            penalty_pt="-2 verificações de competências e de capacidades",
            completed="+1 to two ability scores",
            completed_pt="+1 a dois escores de capacidade"
        },
        {
            name="Creation",
            name_pt="Criação",
            bonus="+1 skills and ability checks",
            bonus_pt="+1 habilidades e verificação de capacidade",
            penalty="-2 skills and ability checks",
            penalty_pt="-2 verificações de competências e de capacidades",
            completed="Spend 2 Force points per round with object",
            completed_pt="Passe 2 pontos de força por rodada com objeto"
        },
        {
            name="Destruction",
            name_pt="Destruição",
            bonus="+2 damage",
            bonus_pt="+2 danos",
            penalty="-2 damage",
            penalty_pt="-2 danos",
            completed="+2 to one ability score",
            completed_pt="+2 a uma pontuação de habilidade"
        },
        {
            name="Discovery",
            name_pt="Descoberta",
            bonus="+1 to all defenses",
            bonus_pt="+1 para todas as defesas",
            penalty="-2 to all defenses",
            penalty_pt="- 2 a todas as defesas",
            completed="+1 to all defenses",
            completed_pt="+1 para todas as defesas"
        },
        {
            name="Education",
            name_pt="Educação",
            bonus="+1 skills and ability checks",
            bonus_pt="+1 habilidades e verificação de capacidade",
            penalty="-2 skills and ability checks",
            penalty_pt="-2 verificações de competências e de capacidades",
            completed="+5 bounus to one class skill",
            completed_pt="+5 Bounus para uma habilidade de classe"
        },
        {
            name="Liberation",
            name_pt="Libertação",
            bonus="+2 damage",
            bonus_pt="+2 danos",
            penalty="-2 damage",
            penalty_pt="-2 danos",
            completed="+1 to all defenses",
            completed_pt="+1 para todas as defesas"
        },
        {
            name="Redemption",
            name_pt="Redenção",
            bonus="Gain a Force point",
            bonus_pt="Ganhe um ponto de força",
            penalty="Lose a Force point or -1 on attack until you gain a level",
            penalty_pt="Perder um ponto de força ou -1 em ataque até ganhar um nível",
            completed="",
            completed_pt=""
        },
        {
            name="Rescue",
            name_pt="Resgate",
            bonus="+2 damage",
            bonus_pt="+2 danos",
            penalty="-2 attack",
            penalty_pt="- Dois ataques.",
            completed="+1 to two ability scores",
            completed_pt="+1 a dois escores de capacidade"
        },
        {
            name="Ackbar Legacy (Denied)",
            name_pt="Legado Ackbar (Negado)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Ackbar Legacy (Embraced)",
            name_pt="Legado Ackbar (Aceito)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Antares Legacy (Embraced)",
            name_pt="Legado Antares (Aceito)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Antilles Legacy (Denied)",
            name_pt="Legado Antilles (Negado)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Antilles Legacy (Embraced)",
            name_pt="Legado Antilles (Aceito)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Askar (clan) Legacy (Denied)",
            name_pt="Legado Askar (clan) (Negado)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Askar (clan) Legacy (Embraced)",
            name_pt="Legado Askar (clan) (Aceito)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="-bacca (suffix) Legacy (Denied)",
            name_pt="Legado -bacca (suffix) (Negado)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="-bacca (suffix) Legacy (Embraced)",
            name_pt="Legado -bacca (suffix) (Aceito)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Bomu (clan) Legacy (Denied)",
            name_pt="Legado Bomu (clan) (Negado)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Bomu (clan) Legacy (Embraced)",
            name_pt="Legado Bomu (clan) (Aceito)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Chattza (clan) Legacy (Denied)",
            name_pt="Legado Chattza (clan) (Negado)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Chattza (clan) Legacy (Embraced)",
            name_pt="Legado Chattza (clan) (Aceito)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Chekkoo (clan) Legacy (Denied)",
            name_pt="Legado Chekkoo (clan) (Negado)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Chekkoo (clan) Legacy (Embraced)",
            name_pt="Legado Chekkoo (clan) (Aceito)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Cracken Legacy (Denied)",
            name_pt="Legado Cracken (Negado)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Cracken Legacy (Embraced)",
            name_pt="Legado Cracken (Aceito)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Darklighter Legacy (Denied)",
            name_pt="Legado Darklighter (Negado)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Darklighter Legacy (Embraced)",
            name_pt="Legado Darklighter (Aceito)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Dodonna Legacy (Denied)",
            name_pt="Legado Dodonna (Negado)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Dodonna Legacy (Embraced)",
            name_pt="Legado Dodonna (Aceito)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Doneeta (clan) Legacy (Denied)",
            name_pt="Legado Doneeta (clan) (Negado)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Doneeta (clan) Legacy (Embraced)",
            name_pt="Legado Doneeta (clan) (Aceito)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Draco Legacy (Denied)",
            name_pt="Legado Draco (Negado)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Draco Legacy (Embraced)",
            name_pt="Legado Draco (Aceito)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Farlander Legacy (Denied)",
            name_pt="Legado Farlander (Negado)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Farlander Legacy (Embraced)",
            name_pt="Legado Farlander (Aceito)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Fel Legacy (Denied)",
            name_pt="Legado Fel (Negado)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Fel Legacy (Embraced)",
            name_pt="Legado Fel (Aceito)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Fett Legacy (Denied)",
            name_pt="Legado Fett (Negado)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Fett Legacy (Embraced)",
            name_pt="Legado Fett (Aceito)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Fey'lya Legacy (Denied)",
            name_pt="Legado Fey'lya (Negado)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Fey'lya Legacy (Embraced)",
            name_pt="Legado Fey'lya (Aceito)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Fortuna Legacy (Denied)",
            name_pt="Legado Fortuna (Negado)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Fortuna Legacy (Embraced)",
            name_pt="Legado Fortuna (Aceito)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Gahan Legacy (Denied)",
            name_pt="Legado Gahan (Negado)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Gahan Legacy (Embraced)",
            name_pt="Legado Gahan (Aceito)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Gakfedd (clan) Legacy (Denied)",
            name_pt="Legado Gakfedd (clan) (Negado)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Gakfedd (clan) Legacy (Embraced)",
            name_pt="Legado Gakfedd (clan) (Aceito)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Halcyon Legacy (Denied)",
            name_pt="Legado Halcyon (Negado)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Halcyon Legacy (Embraced)",
            name_pt="Legado Halcyon (Aceito)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Horn Legacy (Denied)",
            name_pt="Legado Horn (Negado)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Horn Legacy (Embraced)",
            name_pt="Legado Horn (Aceito)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Ilya (clan) Legacy (Denied)",
            name_pt="Legado Ilya (clan) (Negado)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Ilya (clan) Legacy (Embraced)",
            name_pt="Legado Ilya (clan) (Aceito)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Klagg (clan) Legacy (Denied)",
            name_pt="Legado Klagg (clan) (Negado)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Klagg (clan) Legacy (Embraced)",
            name_pt="Legado Klagg (clan) (Aceito)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Madine Legacy (Denied)",
            name_pt="Legado Madine (Negado)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Madine Legacy (Embraced)",
            name_pt="Legado Madine (Aceito)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Nep Legacy (Denied)",
            name_pt="Legado Nep (Negado)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Nep Legacy (Embraced)",
            name_pt="Legado Nep (Aceito)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Nunb Legacy (Denied)",
            name_pt="Legado Nunb (Negado)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Nunb Legacy (Embraced)",
            name_pt="Legado Nunb (Aceito)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Organa Legacy (Denied)",
            name_pt="Legado Organa (Negado)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Organa Legacy (Embraced)",
            name_pt="Legado Organa (Aceito)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Rogak (clan) Legacy (Denied)",
            name_pt="Legado Rogak (clan) (Negado)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Rogak (clan) Legacy (Embraced)",
            name_pt="Legado Rogak (clan) (Aceito)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Secura Legacy (Denied)",
            name_pt="Legado Secura (Negado)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Secura Legacy (Embraced)",
            name_pt="Legado Secura (Aceito)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Skywalker Legacy (Denied)",
            name_pt="Legado Skywalker (Negado)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Skywalker Legacy (Embraced)",
            name_pt="Legado Skywalker (Aceito)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Solo Legacy (Denied)",
            name_pt="Legado Solo (Negado)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Solo Legacy (Embraced)",
            name_pt="Legado Solo (Aceito)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Solusar Legacy (Denied)",
            name_pt="Legado Solusar (Negado)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Solusar Legacy (Embraced)",
            name_pt="Legado Solusar (Aceito)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Tetsu (clan) Legacy (Denied)",
            name_pt="Legado Tetsu (clan) (Negado)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Tetsu (clan) Legacy (Embraced)",
            name_pt="Legado Tetsu (clan) (Aceito)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Tion Legacy (Denied)",
            name_pt="Legado Tion (Negado)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Tion Legacy (Embraced)",
            name_pt="Legado Tion (Aceito)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Try'lis Legacy (Denied)",
            name_pt="Legado Try'lis (Negado)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Try'lis Legacy (Embraced)",
            name_pt="Legado Try'lis (Aceito)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Vao Legacy (Denied)",
            name_pt="Legado Vao (Negado)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Vao Legacy (Embraced)",
            name_pt="Legado Vao (Aceito)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Whitesun Legacy (Denied)",
            name_pt="Legado Whitesun (Negado)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Whitesun Legacy (Embraced)",
            name_pt="Legado Whitesun (Aceito)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Yage Legacy (Denied)",
            name_pt="Legado Yage (Negado)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Yage Legacy (Embraced)",
            name_pt="Legado Yage (Aceito)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Qel Droma Legacy (Denied)",
            name_pt="Legado Qel Droma (Negado)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        },
        {
            name="Qel Droma Legacy (Embraced)",
            name_pt="Legado Qel Droma (Aceito)",
            bonus="+2 to single attack or skill roll",
            bonus_pt="+2 para ataque único ou rolo de habilidade",
            penalty="-2 to first attack in every encounter",
            penalty_pt="-2 para o primeiro ataque em cada encontro",
            completed="",
            completed_pt=""
        }
    },
    backgrounds={
        {
            name="Bankrupt",
            name_pt="Falência",
            skill_count="1",
            language="",
            language_pt="",
            skills="Deception, Gather Information and Survival",
            skills_pt="Enganar, reunir informações e sobrevivência",
            notes="Can use Survival skill to sustain yourself on urban or civilized environments",
            notes_pt="Pode usar a habilidade de sobrevivência para se sustentar em ambientes urbanos ou civilizados"
        },
        {
            name="Conspiracy",
            name_pt="Conspiração",
            skill_count="1",
            language="",
            language_pt="",
            skills="Deception, Stealth and Use Computer",
            skills_pt="Enganar, furtar e usar o computador",
            notes="Can reroll any Perception check made to sense Deception or influence, keeping the better result",
            notes_pt="Pode repetir qualquer verificação de percepção feita para o sentido Decepção ou influência, mantendo o melhor resultado"
        },
        {
            name="Crippled",
            name_pt="Parafuso",
            skill_count="1",
            language="",
            language_pt="",
            skills="Endurance, Mechanics and Treat Injury",
            skills_pt="Perseverança, Mecânica e Lesão de Tratamento",
            notes="When your Fort Def is reduced due to moving down the condition track, your damage threshold remains the same",
            notes_pt="Quando o seu Fort Def é reduzido devido a mover-se para baixo a pista de condição, seu limiar de dano permanece o mesmo"
        },
        {
            name="Disgraced",
            name_pt="Desagradável",
            skill_count="1",
            language="",
            language_pt="",
            skills="Deception, Gather Information and Stealth",
            skills_pt="Enganar, reunir informações e roubar",
            notes="When you try to disguise yourself with a difficult deception, you instead treat it as a moderate deception",
            notes_pt="Quando tentas disfarçar-te com um engano difícil, tratas-o como um engano moderado."
        },
        {
            name="Enslaved",
            name_pt="Escravo",
            skill_count="1",
            language="",
            language_pt="",
            skills="Climb, Endurance and Jump",
            skills_pt="Escalar, perseverar e pular",
            notes="You gain a +2 bonus to all grapple checks",
            notes_pt="Você ganha um bônus +2 para todas as verificações de grapple"
        },
        {
            name="Exiled",
            name_pt="Exilado",
            skill_count="1",
            language="",
            language_pt="",
            skills="Gather Information, Knowledge (galactic lore) and Survival",
            skills_pt="Recolha de Informações, Conhecimentos e Sobrevivência",
            notes="You can plot a safe course for hyperspace travel in half the normal time. Adittionally, if trained in Knowledge (Galactic Lore), you gain Skill Focus (Galactic Lore)",
            notes_pt="Você pode traçar um curso seguro para viajar no hiperespaço em metade do tempo normal. Adicionalmente, se você for treinado em Conhecimento (Lore Galáctico), você ganha Habilidade Foco (Lore Galáctico)"
        },
        {
            name="Imprisoned",
            name_pt="Prisão",
            skill_count="1",
            language="",
            language_pt="",
            skills="Acrobatics, Gather Information and Stealth",
            skills_pt="Acrobacias, recolha informações e furtivo",
            notes="You can obtain black market good in half the normal time (minimum 1 day)",
            notes_pt="Você pode obter mercado negro bom na metade do tempo normal (mínimo 1 dia)"
        },
        {
            name="Marooned",
            name_pt="Marrom",
            skill_count="1",
            language="",
            language_pt="",
            skills="Ride, Survival and Swim",
            skills_pt="Passeio, Sobrevivência e Nade",
            notes="No penalty to Treat Injury checks made to heal yourself (or to Mechanics checks to repair yourself, if you are a droid)",
            notes_pt="Nenhuma penalidade para tratar verificações de lesões feitas para curar a si mesmo (ou para cheques de mecânica para reparar a si mesmo, se você é um dróide)"
        },
        {
            name="Orphaned",
            name_pt="Órfãos",
            skill_count="1",
            language="",
            language_pt="",
            skills="Gather Information, Survival and Treat Injury",
            skills_pt="Recolha informações, sobrevivência e tratar lesões",
            notes="When you spend a Force Point to add to a skill check in an untrained skill, add an extra 1d6 to the skill check",
            notes_pt="Quando você gasta um ponto de força para adicionar a uma verificação de habilidade em uma habilidade não treinada, adicione um 1d6 extra para a verificação de habilidade"
        },
        {
            name="Scarred",
            name_pt="Cicatriz",
            skill_count="1",
            language="",
            language_pt="",
            skills="Deception, Persuasion and Treat Injury",
            skills_pt="Decepção, Persuasão e Lesão",
            notes="When you make a persuasion check to intimidate you always have favorable circumstances",
            notes_pt="Quando você faz uma verificação de persuasão para intimidar você sempre tem circunstâncias favoráveis"
        },
        {
            name="Widowed",
            name_pt="Viúvo",
            skill_count="1",
            language="",
            language_pt="",
            skills="Gather Information, Knowledge (galactic lore) and Use Computer",
            skills_pt="Recolha de informação, conhecimento (saber galáctico) e usar o computador",
            notes="You can take 20 on Gather Information checks, but it takes 20 times as long as normal to gain the information",
            notes_pt="Você pode tomar 20 em Recolha de informações, mas leva 20 vezes mais tempo que o normal para obter a informação"
        },
        {
            name="Academic",
            name_pt="Acadêmico",
            skill_count="1",
            language="",
            language_pt="",
            skills="Knowledge (any one skill), Persuasion and Use Computer",
            skills_pt="Conhecimento (qualquer habilidade), Persuasão e Usar o Computador",
            notes="You gain a +2 competence bonus oto untrained skill checks with the skills in your occupation's list of relevant skills",
            notes_pt="Você ganha um bônus de competência +2 oto verificação de habilidades não treinadas com as habilidades na lista de habilidades relevantes da sua profissão"
        },
        {
            name="Celebrity",
            name_pt="Celebridade",
            skill_count="1",
            language="",
            language_pt="",
            skills="Deception, Gather Information and Persuasion",
            skills_pt="Enganar, reunir informações e persuasão",
            notes="You gain a +2 competence bonus oto untrained skill checks with the skills in your occupation's list of relevant skills",
            notes_pt="Você ganha um bônus de competência +2 oto verificação de habilidades não treinadas com as habilidades na lista de habilidades relevantes da sua profissão"
        },
        {
            name="Criminal",
            name_pt="Criminal",
            skill_count="1",
            language="",
            language_pt="",
            skills="Deception, Gather Information and Stealth",
            skills_pt="Enganar, reunir informações e roubar",
            notes="You gain a +2 competence bonus oto untrained skill checks with the skills in your occupation's list of relevant skills",
            notes_pt="Você ganha um bônus de competência +2 oto verificação de habilidades não treinadas com as habilidades na lista de habilidades relevantes da sua profissão"
        },
        {
            name="Executive",
            name_pt="Executivo",
            skill_count="1",
            language="",
            language_pt="",
            skills="Initiative, Persuasion and Use Computer",
            skills_pt="Iniciativa, Persuasão e Computador de Uso",
            notes="You gain a +2 competence bonus oto untrained skill checks with the skills in your occupation's list of relevant skills",
            notes_pt="Você ganha um bônus de competência +2 oto verificação de habilidades não treinadas com as habilidades na lista de habilidades relevantes da sua profissão"
        },
        {
            name="Labor",
            name_pt="Trabalho",
            skill_count="1",
            language="",
            language_pt="",
            skills="Climb, Endurance and Jump",
            skills_pt="Escalar, perseverar e pular",
            notes="You gain a +2 competence bonus oto untrained skill checks with the skills in your occupation's list of relevant skills",
            notes_pt="Você ganha um bônus de competência +2 oto verificação de habilidades não treinadas com as habilidades na lista de habilidades relevantes da sua profissão"
        },
        {
            name="Law_Enforcement",
            name_pt="Aplicação da Lei",
            skill_count="1",
            language="",
            language_pt="",
            skills="Acrobatics, Gather Information and Knowledge (bureaucracy)",
            skills_pt="Acrobacias, recolha de informação e conhecimento (burocracia)",
            notes="You gain a +2 competence bonus oto untrained skill checks with the skills in your occupation's list of relevant skills",
            notes_pt="Você ganha um bônus de competência +2 oto verificação de habilidades não treinadas com as habilidades na lista de habilidades relevantes da sua profissão"
        },
        {
            name="Medical",
            name_pt="Médico",
            skill_count="1",
            language="",
            language_pt="",
            skills="Knowledge (life sciences), Treat Injury and Use Computer",
            skills_pt="Conhecimento (ciências da vida), tratar lesões e usar computador",
            notes="You gain a +2 competence bonus oto untrained skill checks with the skills in your occupation's list of relevant skills",
            notes_pt="Você ganha um bônus de competência +2 oto verificação de habilidades não treinadas com as habilidades na lista de habilidades relevantes da sua profissão"
        },
        {
            name="Military",
            name_pt="Militar",
            skill_count="1",
            language="",
            language_pt="",
            skills="Endurance, Ride and Treat Injury",
            skills_pt="Endurance, passeio e tratar lesões",
            notes="You gain a +2 competence bonus oto untrained skill checks with the skills in your occupation's list of relevant skills",
            notes_pt="Você ganha um bônus de competência +2 oto verificação de habilidades não treinadas com as habilidades na lista de habilidades relevantes da sua profissão"
        },
        {
            name="Pilot",
            name_pt="Piloto",
            skill_count="1",
            language="",
            language_pt="",
            skills="Knowledge (galactic lore), Mechanics and Use Computer",
            skills_pt="Conhecimento (saber galáctico), Mecânica e Computador de Uso",
            notes="You gain a +2 competence bonus oto untrained skill checks with the skills in your occupation's list of relevant skills",
            notes_pt="Você ganha um bônus de competência +2 oto verificação de habilidades não treinadas com as habilidades na lista de habilidades relevantes da sua profissão"
        },
        {
            name="Politics",
            name_pt="Política",
            skill_count="1",
            language="",
            language_pt="",
            skills="Deception, Gather Information and Persuasion",
            skills_pt="Enganar, reunir informações e persuasão",
            notes="You gain a +2 competence bonus oto untrained skill checks with the skills in your occupation's list of relevant skills",
            notes_pt="Você ganha um bônus de competência +2 oto verificação de habilidades não treinadas com as habilidades na lista de habilidades relevantes da sua profissão"
        },
        {
            name="Technology",
            name_pt="Tecnologia",
            skill_count="1",
            language="",
            language_pt="",
            skills="Knowledge (technology), Mechanics and Use Computer",
            skills_pt="Conhecimento (tecnologia), Mecânica e Computador de Uso",
            notes="You gain a +2 competence bonus oto untrained skill checks with the skills in your occupation's list of relevant skills",
            notes_pt="Você ganha um bônus de competência +2 oto verificação de habilidades não treinadas com as habilidades na lista de habilidades relevantes da sua profissão"
        },
        {
            name="Alderaan",
            name_pt="Alderaan",
            skill_count="2",
            language="High Galactic",
            language_pt="Galáctico Alto",
            skills="Knowledge (any one skill), Persuasion and Treat Injury",
            skills_pt="Conhecimento (qualquer habilidade), Persuasão e Lesão",
            notes="",
            notes_pt=""
        },
        {
            name="Bakura",
            name_pt="Bakura",
            skill_count="2",
            language="High Galactic",
            language_pt="Galáctico Alto",
            skills="Mechanics, Treat Injury and Use Computer",
            skills_pt="Mecânica, tratar a lesão e usar o computador",
            notes="",
            notes_pt=""
        },
        {
            name="Bespin",
            name_pt="Bespin",
            skill_count="2",
            language="Bocce",
            language_pt="Bocce",
            skills="Deception, Knowledge (bureaucracy) and Persuasion",
            skills_pt="Decepção, Conhecimento (burocracia) e Persuasão",
            notes="",
            notes_pt=""
        },
        {
            name="Bothawui",
            name_pt="Bothawui",
            skill_count="2",
            language="Bothese",
            language_pt="Bothese",
            skills="Deception, Gather Information and Persuasion",
            skills_pt="Enganar, reunir informações e persuasão",
            notes="",
            notes_pt=""
        },
        {
            name="Cerea",
            name_pt="Cerea",
            skill_count="2",
            language="Cerean",
            language_pt="Cereã",
            skills="Acrobatics, Knowledge (life sciences) and Survival",
            skills_pt="Acrobacias, Conhecimento (ciências da vida) e Sobrevivência",
            notes="",
            notes_pt=""
        },
        {
            name="Corellia",
            name_pt="Corelia",
            skill_count="2",
            language="Old Corellian",
            language_pt="Corelian antigo",
            skills="Initiative, Knowledge (technology) and Mechanics",
            skills_pt="Iniciativa, Conhecimento (tecnologia) e Mecânica",
            notes="",
            notes_pt=""
        },
        {
            name="Coruscant",
            name_pt="Coruscant",
            skill_count="2",
            language="High Galactic",
            language_pt="Galáctico Alto",
            skills="Gather Information, Knowledge (bureaucracy) and Knowledge (galactic lore)",
            skills_pt="Recolha de Informação, Conhecimento (burocracia) e Conhecimento (lore galáctico)",
            notes="",
            notes_pt=""
        },
        {
            name="Dorin",
            name_pt="Dorin",
            skill_count="2",
            language="Kel Dor",
            language_pt="Kel Dor",
            skills="Endurance, Survival and Treat Injury",
            skills_pt="Endurance, Survival and Treat Leury",
            notes="",
            notes_pt=""
        },
        {
            name="Duro",
            name_pt="Duro",
            skill_count="2",
            language="Durese",
            language_pt="Durese",
            skills="Knowledge (technology), Mechanics and Use Computer",
            skills_pt="Conhecimento (tecnologia), Mecânica e Computador de Uso",
            notes="",
            notes_pt=""
        },
        {
            name="Fondor",
            name_pt="Fondor",
            skill_count="2",
            language="Bocce",
            language_pt="Bocce",
            skills="Knowledge (technology), Mechanics and Use Computer",
            skills_pt="Conhecimento (tecnologia), Mecânica e Computador de Uso",
            notes="",
            notes_pt=""
        },
        {
            name="Gamorr",
            name_pt="Gamorr",
            skill_count="2",
            language="Gamorrean",
            language_pt="Gamorreano",
            skills="Climb, Endurance and Survival",
            skills_pt="Escalar, perseverar e sobreviver",
            notes="",
            notes_pt=""
        },
        {
            name="Iridonia",
            name_pt="Iridonia",
            skill_count="2",
            language="Zabrak",
            language_pt="Zabrak",
            skills="Acrobatics, Endurance and Survival",
            skills_pt="Acrobacias, perseverança e sobrevivência",
            notes="",
            notes_pt=""
        },
        {
            name="Ithor",
            name_pt="Ithor",
            skill_count="2",
            language="Ithorese",
            language_pt="Itorese",
            skills="Knowledge (life sciences), Persuasion and Treat Injury",
            skills_pt="Conhecimento (ciências da vida), Persuasão e Lesão",
            notes="",
            notes_pt=""
        },
        {
            name="Kashyyyk",
            name_pt="Kashyyyk",
            skill_count="2",
            language="Shyriiwook (understand only)",
            language_pt="Shyriiwook",
            skills="Climb, Persuasion and Survival",
            skills_pt="Escalar, Persuasão e Sobrevivência",
            notes="",
            notes_pt=""
        },
        {
            name="Mon_Calamari",
            name_pt="Mon Calamari",
            skill_count="2",
            language="Mon Calamarian or Quarrenese",
            language_pt="Mon Calamarian ou Quarrenese",
            skills="Mechanics, Persuasion and Swim",
            skills_pt="Mecânica, Persuasão e Nade",
            notes="",
            notes_pt=""
        },
        {
            name="Naboo",
            name_pt="Naboo",
            skill_count="2",
            language="Gunganese",
            language_pt="Gunganês",
            skills="Ride, Persuasion and Swim",
            skills_pt="Passeio, Persuasão e Nade",
            notes="",
            notes_pt=""
        },
        {
            name="Nar_Shaddaa",
            name_pt="Nar Shaddaa",
            skill_count="2",
            language="Huttese",
            language_pt="Huttese",
            skills="Deception, Gather Information and Stealth",
            skills_pt="Enganar, reunir informações e roubar",
            notes="",
            notes_pt=""
        },
        {
            name="Rodia",
            name_pt="Rodia",
            skill_count="2",
            language="Rodese",
            language_pt="Rodesa",
            skills="Climb, Stealth and Survival",
            skills_pt="Escalar, Roubar e Sobreviver",
            notes="",
            notes_pt=""
        },
        {
            name="Ryloth",
            name_pt="Ryloth",
            skill_count="2",
            language="Ryl",
            language_pt="Ryl",
            skills="Deception, Persuasion and Survival",
            skills_pt="Decepção, Persuasão e Sobrevivência",
            notes="",
            notes_pt=""
        },
        {
            name="Socorro",
            name_pt="Socorro",
            skill_count="2",
            language="Socorran",
            language_pt="Solurão",
            skills="Deception, Stealth and Survival",
            skills_pt="Decepção, Furtividade e Sobrevivência",
            notes="",
            notes_pt=""
        },
        {
            name="Sullust",
            name_pt="Sullust",
            skill_count="2",
            language="Sullustese",
            language_pt="Sullustese",
            skills="Climb, Mechanics and Survival",
            skills_pt="Escalar, Mecânica e Sobrevivência",
            notes="",
            notes_pt=""
        },
        {
            name="Taris",
            name_pt="Taris",
            skill_count="2",
            language="Sy Bisti",
            language_pt="Sy Bisti",
            skills="Deception, Mechanics and Survival",
            skills_pt="Decepção, Mecânica e Sobrevivência",
            notes="",
            notes_pt=""
        },
        {
            name="Tatooine",
            name_pt="Tatooine",
            skill_count="2",
            language="Jawa Trade Language",
            language_pt="Jawa Trade Language",
            skills="Endurance, Ride and Survival",
            skills_pt="Perseverança, Passeio e Sobrevivência",
            notes="",
            notes_pt=""
        },
        {
            name="Trandosha",
            name_pt="Trandosha",
            skill_count="2",
            language="Dosh",
            language_pt="Dosh",
            skills="Endurance, Persuasion and Survival",
            skills_pt="Endurance, Persuasão e Sobrevivência",
            notes="",
            notes_pt=""
        }
    }
}
