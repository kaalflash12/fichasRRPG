return {
    species={
        {
            racial_abilities="Ajuste da capacidade",
            bonus_feats={},
            description="Aumente uma pontuação de habilidade em 2 e reduza outra em 2 para dar ênfase a certos atributos (como força ou inteligência).",
            languages={"Básico","Aleena"},
            name="Aleena",
            trained_skills={},
            skill_focus={},
            display="Aleena",
            special={"Nimble","Energia Rápida"}
        },
        {
            racial_abilities="Curador Able",
            bonus_feats={},
            description="Outros personagens curados pelo personagem ganham mais 5 pontos de sucesso; uma vez por encontro como uma ação rápida, conceda um aliado adjacente 10 + bônus de nível de caracteres pontos de sucesso até o final do encontro",
            languages={"Amanês"},
            name="Amanin",
            trained_skills={},
            skill_focus={},
            display="Amanin",
            special={"Primitivo","Rolar","Escalador Especialista","Alcançar 2"}
        },
        {
            racial_abilities="Proeza acrobática",
            bonus_feats={},
            description="Um Trianii pode reroll qualquer verificação Acrobatics, mas o resultado do reroll deve ser aceito mesmo que seja pior",
            languages={"Anzat","Básico"},
            name="Anzati",
            trained_skills={},
            skill_focus={},
            display="Anzati",
            special={"Sentido de Presença","Mesmerizar","Beber Sopa","Instintos de Caçador","Visão de Baixa Luz"}
        },
        {
            racial_abilities="Braços adicionais",
            bonus_feats={"Dureza"},
            description="Até 2 braços adicionais. Ao fazer vários ataques, o personagem pode reduzir a penalidade para o rolo de ataque em 2.",
            languages={"Básico","Aqualish"},
            name="Aqualish",
            trained_skills={},
            skill_focus={},
            display="Aqualish",
            special={"Respirar sob a água","Nadador especialista"}
        },
        {
            racial_abilities="Diplomata Adept",
            bonus_feats={},
            description="Pode optar por refazer quaisquer verificações de Persuasão, mantendo o melhor resultado",
            languages={"Arconese"},
            name="Arcona",
            trained_skills={},
            skill_focus={},
            display="Arcona",
            special={"Perfume"}
        },
        {
            racial_abilities="Aerotransportado",
            bonus_feats={},
            description="Pode rerolar os controlos de iniciativa, mas deve manter o segundo rolo",
            languages={"Arkanian"},
            name="Arkanian",
            trained_skills={},
            skill_focus={},
            display="Arkanian",
            special={"Visão escura","Reputação Intelectual","Flash de Gênio"}
        },
        {
            racial_abilities="Conhecimento Antigo",
            bonus_feats={},
            description="Penas de proficiência em armas e armaduras reduzidas; pode usar um uso de Mecânica, Piloto, Tratamento de Lesões ou Usar Computador uma vez por encontro, mesmo que não treinado",
            languages={"Arkanian"},
            name="Disparar Arkanian",
            trained_skills={},
            skill_focus={},
            display="Disparar Arkanian",
            special={"Determinação"}
        },
        {
            racial_abilities="Manipulador de Animais",
            bonus_feats={},
            description="Pode repetir qualquer verificação Ride, mas o resultado do reroll deve ser aceito mesmo que seja pior; pode fazer verificações de Persuasão para mudar a atitude de uma criatura desmesticada de Inteligência 2 ou inferior",
            languages={"Básico","Binário"},
            name="Astromech Droid Chassis",
            trained_skills={"Mecânica"},
            skill_focus={"Mecânica","Usar Computador"},
            display="Droid Astromech",
            special={"2o Grau","Traços Dróides","Desenho com fios rígidos (Mecânica)"}
        },
        {
            racial_abilities="Antenapalpas",
            bonus_feats={},
            description="À curta distância (dentro de 10 quadrados) ignorar cobertura e ocultação para efeitos de verificação de percepção. Enquanto as antenas são estendidas sofrer uma penalidade -2 para defesas contra ataques sônicos",
            languages={"Básico","Balosar"},
            name="Balosar",
            trained_skills={},
            skill_focus={},
            display="Balosar",
            special={"Antenapalpas","Resistência Venenosa","Ambiguidade Moral"}
        },
        {
            racial_abilities="Aquático",
            bonus_feats={},
            description="Não pode afogar-se em água e não precisa fazer verificações de natação; visão de baixa luz",
            languages={"Barabel"},
            name="Barabel",
            trained_skills={},
            skill_focus={},
            display="Barabel",
            special={"Resistência à radiação","Visão escura","Primitivo","Intimidante","Resistência ao choque"}
        },
        {
            racial_abilities="Árctico",
            bonus_feats={},
            description="Pode reroll verificações de sobrevivência para resistir ao frio extremo, manter o melhor resultado",
            languages={"Básico","Binário"},
            name="Combater o Chassi Dróide",
            trained_skills={},
            skill_focus={},
            display="Dróide de Batalha",
            special={"4o Grau","Traços Dróides","Bônus da armadura","Arma de Bônus Feat"}
        },
        {
            racial_abilities="Escalas blindadas",
            bonus_feats={},
            description="As escalas naturalmente duras do Ssi-Ruuk concedem-lhes um bônus de armadura natural +2 para sua defesa reflexa. Um bônus de armadura natural empilha com um bônus de armadura.",
            languages={},
            name="Fera",
            trained_skills={},
            skill_focus={},
            display="0",
            special={}
        },
        {
            racial_abilities="Treinamento de armaduras",
            bonus_feats={},
            description="Aumente o bônus máximo de Dexterity para armadura usada por 1",
            languages={"Básico","Bith"},
            name="Bith",
            trained_skills={},
            skill_focus={},
            display="Bith",
            special={"Trance Meditativo","Perfume","Intelecto Evoluído"}
        },
        {
            racial_abilities="Atlético",
            bonus_feats={},
            description="Rebole qualquer verificação Escalada ou Salto, mas o resultado deve ser aceito, mesmo que pior. Toma 10 em cheques de Escalada e Salto.",
            languages={"Básico","Batorês"},
            name="Carver de Sangue",
            trained_skills={},
            skill_focus={"Acrobacia"},
            display="Carver de Sangue",
            special={"Ataque mortal"}
        },
        {
            racial_abilities="Autoridade",
            bonus_feats={},
            description="Adicionar +1 a qualquer insight ou moral bônus concedidos a si mesmos ou outros personagens",
            languages={"Básico","Bothese"},
            name="Bothan",
            trained_skills={},
            skill_focus={"Obter Informações"},
            display="Bothan",
            special={}
        },
        {
            racial_abilities="Bellow",
            bonus_feats={},
            description="Pode abrir todas as quatro gargantas como uma ação padrão (1d20 + nível de caracteres) contra a defesa de fortaleza de todas as criaturas e objetos desacompanhados em um cone 6-quadrado, lidando com 3d6 danos sônicos e movendo o caractere um passo para a trilha da condição; para cada d6 extra de dano adicionado o caractere move mais um passo para a trilha da condição",
            languages={"Básico","Caamasi"},
            name="Caamasi",
            trained_skills={},
            skill_focus={},
            display="Caamasi",
            special={"Diplomata Adept","Pacifismo","Partilha de Memórias"}
        },
        {
            racial_abilities="Aumento da biotecnologia",
            bonus_feats={},
            description="Aumentado com biotecnologia. Selecione um bio-implante (ver páginas 67-68 do Guia de Campanha da Era Legacv).",
            languages={"Básico","Catarese"},
            name="Cátaro",
            trained_skills={"Escalar","Furtividade"},
            skill_focus={},
            display="Cátaro",
            special={"Garra Reactiva","Instintos cátaros"}
        },
        {
            racial_abilities="Bonus Feat",
            bonus_feats={},
            description="Escolha um feito adicional",
            languages={"Básico (compreensão)"},
            name="Celegian",
            trained_skills={},
            skill_focus={},
            display="Celegian",
            special={"Respirador de Cianogénio","Nadador especialista","Telepata de Transmissão"}
        },
        {
            racial_abilities="Bônus Treinado Habilidade",
            bonus_feats={},
            description="Escolha uma habilidade de classe adicional para treinar",
            languages={"Básico","Cereã"},
            name="Cereã",
            trained_skills={},
            skill_focus={"Iniciativa"},
            display="Cereã",
            special={"Iniciativa Intuitiva"}
        },
        {
            racial_abilities="Respirar sob a água",
            bonus_feats={},
            description="Não pode afogar-se na água",
            languages={"Básico","Chadra-Fan"},
            name="Chadra-Fan",
            trained_skills={},
            skill_focus={},
            display="Chadra-Fan",
            special={"Consciência aumentada","Tinkerer","Visão escura"}
        },
        {
            racial_abilities="Telepata de Transmissão",
            bonus_feats={},
            description="Use a aplicação de Telepatia Use a habilidade Força destreinada, automaticamente consiga se comunicar com alvos dentro de 60 quadrados e linha de visão",
            languages={"Básico","Chagri"},
            name="Chagrian",
            trained_skills={},
            skill_focus={},
            display="Chagrian",
            special={"Respirar sob a água","Visão de Baixa Luz","Resistência à radiação"}
        },
        {
            racial_abilities="Brutal",
            bonus_feats={},
            description="Uma vez por encontro, pode tratar o limiar de dano de um oponente como se fosse 5 pontos mais baixo ao determinar o resultado de um ataque melee",
            languages={"Cheunh"},
            name="Chiss",
            trained_skills={},
            skill_focus={},
            display="Chiss",
            special={"Visão de Baixa Luz","Bônus Treinado Habilidade"}
        },
        {
            racial_abilities="Carapaça",
            bonus_feats={},
            description="Krevaaki ganha um bônus de armadura natural +1 para Defesa de Reflexos e um bônus +1 para Defesa de Fortitude",
            languages={"Chistori"},
            name="Chistori",
            trained_skills={},
            skill_focus={},
            display="Chistori",
            special={"Raiva","Sangue Frio"}
        },
        {
            racial_abilities="Trabalhador Cuidadoso",
            bonus_feats={},
            description="Um Sluissi que leva o dobro do tempo normal necessário para usar a habilidade Mecânica ganha um bônus + 10 circunstâncias para a verificação Mecânica.",
            languages={"Básico","Clawdite"},
            name="Clawdite",
            trained_skills={},
            skill_focus={},
            display="Clawdite",
            special={"Mudança de forma","Assalto"}
        },
        {
            racial_abilities="Instintos cátaros",
            bonus_feats={},
            description="Escalada e Stealth são habilidades de classe",
            languages={"Básico"},
            name="Clone",
            trained_skills={},
            skill_focus={},
            display="Clone",
            special={"Bônus Treinado Habilidade","Bonus Feat"}
        },
        {
            racial_abilities="Adaptação climática",
            bonus_feats={},
            description="Resistente a um clima específico. Selecione um: congelamento, atmosfera rarefeita, queima, fumaça, tropical, ou aguado. Quando desafiado por um fator ambiental nesse clima (escolhido daqueles listados, ou outros a critério do Gamemaster), pode refazer uma verificação de Endurance ou de Sobrevivência, levando o melhor resultado.",
            languages={"Básico"},
            name="Herói Clone",
            trained_skills={},
            skill_focus={},
            display="Herói Clone",
            special={"Bônus Treinado Habilidade","Bonus Feat"}
        },
        {
            racial_abilities="Herança do Escalador",
            bonus_feats={"Mestre de Armas Duplas I"},
            description="Escalar é uma habilidade de classe",
            languages={"Básico","Bacalhau"},
            name="Codru-Ji",
            trained_skills={},
            skill_focus={},
            display="Codru-Ji",
            special={"Braços Extra","Grappler habilidoso"}
        },
        {
            racial_abilities="Sangue Frio",
            bonus_feats={},
            description="-2 para defesa de fortaleza contra frio extremo, +5 contra calor extremo",
            languages={"Dashadi"},
            name="Dashade",
            trained_skills={},
            skill_focus={},
            display="Dashade",
            special={"Adaptação Ambiental","Temível Reputação","Resistência à Força"}
        },
        {
            racial_abilities="Resistência a frio",
            bonus_feats={},
            description="+5 Defesa de fortaleza contra frio extremo",
            languages={"Básico","Defel"},
            name="Defel",
            trained_skills={},
            skill_focus={},
            display="Defel",
            special={"Invisibilidade Parcial","Equipamento especial (Defel)"}
        },
        {
            racial_abilities="Condutor",
            bonus_feats={},
            description="Naturalmente gerar uma pequena quantidade de energia elétrica e usar como uma arma natural em um ataque desarmado, lidando com 1d6 pontos de danos de energia. O caráter é sempre considerado armado com uma arma natural.",
            languages={"Básico","Deveronês"},
            name="Devaronian",
            trained_skills={},
            skill_focus={"Enganação"},
            display="Devaronian",
            special={"Curiosidade Natural"}
        },
        {
            racial_abilities="Confusão",
            bonus_feats={"Proficiência da arma (melee avançado)"},
            description="Uma vez por encontro como uma ação padrão, faça uma verificação Decepção contra a Defesa de Vontade de um alvo dentro de 6 quadrados para impedi-los de ameaçar quaisquer quadrados até sua próxima vez",
            languages={"Draethos"},
            name="Draethos",
            trained_skills={},
            skill_focus={},
            display="Draethos",
            special={"Telepata Natural","Visão de Baixa Luz"}
        },
        {
            racial_abilities="Ligações",
            bonus_feats={},
            description="Forgo custo de crédito para aprender informações secretas com uma verificação Recolher informações; pode tentar novamente após o fracasso, mas deve pagar o preço regular",
            languages={"Básico","Binário"},
            name="Droide",
            trained_skills={},
            skill_focus={},
            display="Droide",
            special={"Traços Dróides"}
        },
        {
            racial_abilities="Cooperativa",
            bonus_feats={},
            description="Automaticamente consegue quando tenta ajudar outro em uma verificação de habilidades para um aliado adjacente e compreensivo",
            languages={"Dug"},
            name="Dug",
            trained_skills={},
            skill_focus={},
            display="Dug",
            special={"Atlético"}
        },
        {
            racial_abilities="Espírito Cooperativo",
            bonus_feats={},
            description="Pode ajudar outro, ou ser ajudado, como uma ação rápida sobre adversários adjacentes com Escalada, Endurance, Reunir informações, Saltar, Conhecimento, Mecânica, Piloto, Passeio, Sobrevivência, Nade, Tratar lesões, ou Usar verificações de computador",
            languages={"Básico","Durese"},
            name="Duros",
            trained_skills={},
            skill_focus={},
            display="Duros",
            special={"Piloto Especialista"}
        },
        {
            racial_abilities="Cibernética cultural",
            bonus_feats={},
            description="Cultura geralmente aumenta os membros com cybernetics fram nascimento. Selecione um realce cibernético.",
            languages={"Ewokese"},
            name="Ewok",
            trained_skills={},
            skill_focus={"Sobrevivência"},
            display="Ewok",
            special={"Primitivo","Perfume","Sneaky"}
        },
        {
            racial_abilities="Respirador de Cianogénio",
            bonus_feats={},
            description="A menos que envoltos numa câmara especial do ambiente, os celegianos sufocam",
            languages={"Básico","Falleen"},
            name="Falleen",
            trained_skills={},
            skill_focus={},
            display="Falleen",
            special={"Feromonas","Suspenda a respiração","Aclimação do feromônio"}
        },
        {
            racial_abilities="Visão escura",
            bonus_feats={},
            description="Ignorar o encobrimento da escuridão; não perceber cores na escuridão total",
            languages={"Feorina"},
            name="Feorina",
            trained_skills={},
            skill_focus={},
            display="Feorina",
            special={"Visão de Baixa Luz","Mais forte por idade","Brutal","Resiliência Inata"}
        },
        {
            racial_abilities="Ataque mortal",
            bonus_feats={"Sensibilidade à Força"},
            description="Qualquer vez que um ataque melee é feito contra um oponente que é negado seu bônus de Dexterity para Defesa de Reflexos, o ataque de Blood Carver, se bem sucedido, dá +1 morte de dano",
            languages={"Felucianês"},
            name="Feluciano",
            trained_skills={},
            skill_focus={},
            display="Feluciano",
            special={"Respirar sob a água","Visão de Baixa Luz","Camuflagem Natural","Forçar Explosão","Primitivo"}
        },
        {
            racial_abilities="Enganador",
            bonus_feats={},
            description="Pode optar por refazer qualquer verificação de decepção, mas o resultado do reroll deve ser aceito mesmo que seja pior",
            languages={"Básico","Fosh"},
            name="Fosh",
            trained_skills={},
            skill_focus={},
            display="Fosh",
            special={"Enganador","Glândulas curativas"}
        },
        {
            racial_abilities="Raciocínio Dedutivo",
            bonus_feats={"Limiar de Danos Melhor"},
            description="Givin avalia constantemente os dados, descartando resultados inconclusivos. Um Givin pode reroll qualquer verificação de conhecimento, mas o resu lt do reroll deve ser aceito, mesmo que seja pior.",
            languages={"Básico (Entendido)","Gammoreano"},
            name="Gamorreano",
            trained_skills={},
            skill_focus={},
            display="Gamorreano",
            special={"Primitivo"}
        },
        {
            racial_abilities="Trabalhador Confiável",
            bonus_feats={},
            description="Pode tratar Escalada, Endurance, Recolha de Informações, Pular, Conhecimento, Mecânica, Piloto, Passeio, Sobrevivência, Nade, Tratar Lesão, ou Usar Cheques de computador como se tomasse 10 uma vez por encontro após rolar",
            languages={"Gand"},
            name="Gand",
            trained_skills={},
            skill_focus={},
            display="Gand",
            special={"Visão escura","Hardy","Equipamento especial (Gand)","Regeneração de membros"}
        },
        {
            racial_abilities="Deserto",
            bonus_feats={},
            description="Pode voltar a rolar verificações de sobrevivência para resistir ao calor extremo, manter o melhor resultado",
            languages={"Básico","Gen'Dai"},
            name="Gen'Dai",
            trained_skills={},
            skill_focus={},
            display="Gen'Dai",
            special={"Gen'Dai Surge","Hibernação","Instabilidade Mental","Fisiologia Resiliente"}
        },
        {
            racial_abilities="Desert Dweller",
            bonus_feats={"Proficiência da arma (melee avançado)"},
            description="Ao fazer verificações de sobrevivência para resistir aos efeitos do calor extremo, rerole a verificação e manter o melhor resultado",
            languages={"Geonosiano"},
            name="Geonosiano",
            trained_skills={},
            skill_focus={"Mecânica"},
            display="Geonosiano",
            special={"Resistência à radiação","Visão de Baixa Luz","Velocidade de Voo (8)"}
        },
        {
            racial_abilities="Determinação",
            bonus_feats={},
            description="Pode repetir uma verificação de habilidade falhada com uma habilidade treinada uma vez por encontro, mas deve ter o segundo resultado",
            languages={"Básico","Givin"},
            name="Givin",
            trained_skills={},
            skill_focus={},
            display="Givin",
            special={"Exoesqueleto","Raciocínio Dedutivo","Fisiologia Única"}
        },
        {
            racial_abilities="Dirigido",
            bonus_feats={},
            description="+5 espécie bônus para Will Defesa contra efeitos que afetam a mente",
            languages={"Básico","Gotal"},
            name="Gotal",
            trained_skills={},
            skill_focus={},
            display="Gotal",
            special={"Leitura de Energia","Visão de Baixa Luz","Sensor Cones"}
        },
        {
            racial_abilities="Droid Shell",
            bonus_feats={},
            description="Manutenção como dróide, imune ao veneno, doença, radiação, riscos atmosféricos não corrosivos, vácuo, vulnerável a danos iônicos, usar sistemas dróides e acessórios",
            languages={"Básico","Gran"},
            name="Gran",
            trained_skills={},
            skill_focus={},
            display="Gran",
            special={"Visão escura","Consciência do alvo","Visão tripla"}
        },
        {
            racial_abilities="Traços Dróides",
            bonus_feats={},
            description="Inibidores comportamentais, Vulnerabilidade de danos iônicos, Manutenção, Memória, Não Vivos, Reparar, Desligar, Habilidades, Sistemas (ver SECR página 187)",
            languages={"Básico","Gunganês"},
            name="Gungan",
            trained_skills={},
            skill_focus={},
            display="Gungan",
            special={"Nadador especialista","Suspenda a respiração","Visão de Baixa Luz","Velocidade de natação (4)"}
        },
        {
            racial_abilities="Obrigação limitada",
            bonus_feats={},
            description="Uma vez por encontro ao receber um bônus moral, ganhar pontos de bônus igual a 4 x nível de caráter até o final do encontro",
            languages={"Básico","Herglico"},
            name="Herglico",
            trained_skills={},
            skill_focus={"Obter Informações"},
            display="Herglico",
            special={"Sturdy"}
        },
        {
            racial_abilities="Consciência Ecológica",
            bonus_feats={},
            description="Devido à sua consciência e impulso para proteger o ambiente natural de seu mundo natal, Ishi lib pode rolar duas vezes ao fazer uma verificação Conhecimento (ciências da vida), mantendo o melhor resultado.",
            languages={"Básico","Houk"},
            name="Houk",
            trained_skills={},
            skill_focus={},
            display="Houk",
            special={"Fisicamente Intimidante"}
        },
        {
            racial_abilities="Empate",
            bonus_feats={},
            description="Pode usar a aplicação de telepatia do Use a Força ski ll destreinada, e sem ter o feito de Sensibilidade à Força. Além disso, pode sentir as emoções de um alvo se a verificação Use a Força for igual ou superior à Defesa de Vontade do alvo.",
            languages={"Básico"},
            name="Humano",
            trained_skills={},
            skill_focus={},
            display="Humano",
            special={"Bônus Treinado Habilidade","Bonus Feat"}
        },
        {
            racial_abilities="Leitura de Energia",
            bonus_feats={},
            description="Os Gotais podem ler as emoções de qualquer ser senciente dentro de 6 quadrados. Como uma ação padrão, um Gotal pode fazer uma verificação de percepção contra a defesa de vontade de um alvo. Uma verificação bem sucedida revela o estado emocional do alvo (como feliz, triste, nervoso ou assustado).",
            languages={"Básico","Huttese"},
            name="Hutt",
            trained_skills={},
            skill_focus={},
            display="Hutt",
            special={"Resistência à Força","Estabilidade Suprema","Persuasivo"}
        },
        {
            racial_abilities="Adaptação Ambiental",
            bonus_feats={},
            description="Dashade ganhar um bônus +5 espécies para sua defesa de fortaleza contra o efeito de calor extremo, frio extremo e radiação",
            languages={"Básico","Iktotchese"},
            name="Iktotchi",
            trained_skills={},
            skill_focus={},
            display="Iktotchi",
            special={"Precognição limitada","Piloto Especialista"}
        },
        {
            racial_abilities="Intelecto Evoluído",
            bonus_feats={},
            description="Sempre que uma bith gasta um ponto de força por qualquer razão, a bith ganha um ponto de força temporário que deve ser gasto para adicionar a uma verificação de habilidade baseada em inteligência. Se o Ponto de Força temporário não tiver sido usado até o final do encontro, ele se perde.",
            languages={"Básico","Tibranês"},
            name="Ishi Tib",
            trained_skills={},
            skill_focus={},
            display="Ishi Tib",
            special={"Respirar sob a água","Consciência Ecológica","Nadador especialista","Velocidade de natação (4)","Visão de Baixa Luz"}
        },
        {
            racial_abilities="Exoesqueleto",
            bonus_feats={},
            description="As conchas duras de Givin concedem-lhes DR 2 e um bônus de +2 espécies para Defesa de Fortitude.",
            languages={"Básico","Itorese"},
            name="Itoriano",
            trained_skills={},
            skill_focus={"Conhecimento (Ciências da Vida)"},
            display="Itoriano",
            special={"Bellow","Instinto de Sobrevivência"}
        },
        {
            racial_abilities="Escalador Especialista",
            bonus_feats={},
            description="Pode optar por tomar 10 em verificações de subida mesmo quando distraído ou ameaçado",
            languages={"Jawa","Jawa Trade Language"},
            name="Jawa",
            trained_skills={"Mecânica"},
            skill_focus={},
            display="Jawa",
            special={"Visão escura","Desert Dweller","Escavador"}
        },
        {
            racial_abilities="Piloto Especialista",
            bonus_feats={},
            description="Pode optar por refazer qualquer verificação Pilot, mas o resultado do reroll deve ser aceito mesmo que seja pior",
            languages={"Básico","Kaleesh"},
            name="Kaleesh",
            trained_skills={},
            skill_focus={"Sobrevivência"},
            display="Kaleesh",
            special={"Visão escura","Dirigido","Persistente"}
        },
        {
            racial_abilities="Nadador especialista",
            bonus_feats={},
            description="Pode optar por rebobinar qualquer verificação Swim, mas o resultado do reroll deve ser aceito mesmo que seja pior; pode levar 10 em verificações Swim mesmo quando distraído ou ameaçado",
            languages={"Básico","Kaminoan"},
            name="Kaminoan",
            trained_skills={},
            skill_focus={"Tratar Ferimentos"},
            display="Kaminoan",
            special={"Resistente"}
        },
        {
            racial_abilities="Braços Extra",
            bonus_feats={},
            description="Pode segurar até quatro tiems ou armas de cada vez. Esta habilidade não concede ataques extras; no entanto, permite que duas armas de duas mãos sejam empunhadas de uma vez",
            languages={"Básico","Kel Dor"},
            name="Kel Dor",
            trained_skills={},
            skill_focus={},
            display="Kel Dor",
            special={"Sentido de Força Keen","Visão de Baixa Luz","Equipamento especial"}
        },
        {
            racial_abilities="Temível Reputação",
            bonus_feats={},
            description="Dashade pode reroll verificações de persuasão feitas para intimidar outro, mantendo o melhor resultado",
            languages={"Básico","Kerkoidese"},
            name="Kerkoiden",
            trained_skills={},
            skill_focus={},
            display="Kerkoiden",
            special={"Herança do Predador","Cunning social"}
        },
        {
            racial_abilities="Flash de Gênio",
            bonus_feats={},
            description="Pode adicionar +5 bônus ao conhecimento, mecânica ou usar verificação de habilidade do computador uma vez por encontro",
            languages={"Khilese"},
            name="Khil",
            trained_skills={},
            skill_focus={},
            display="Khil",
            special={"Hullepi","Trabalhador Confiável","Espírito Cooperativo"}
        },
        {
            racial_abilities="Velocidade de voo (6)",
            bonus_feats={},
            description="Pode mover-se a uma velocidade de 6 quadrados ao voar",
            languages={"Sith"},
            name="Kissai",
            trained_skills={},
            skill_focus={},
            display="Kissai",
            special={"Inspirado","Consciência do guerreiro","Familiaridade da Arma"}
        },
        {
            racial_abilities="Velocidade de Voo (8)",
            bonus_feats={},
            description="Pode mover-se a uma velocidade de 8 quadrados ao voar",
            languages={"Huttese"},
            name="Klatooinian",
            trained_skills={},
            skill_focus={},
            display="Klatooinian",
            special={"Will de Ferro"}
        },
        {
            racial_abilities="Forçar Explosão",
            bonus_feats={},
            description="Uma vez por encontro, faça um destreinado Use a verificação de força para ativar a explosão de força",
            languages={"Básico","Dromnyr"},
            name="Krevaaki",
            trained_skills={},
            skill_focus={},
            display="Krevaaki",
            special={"Carapaça","Estóico","Tentáculos"}
        },
        {
            racial_abilities="Forçar o Cego",
            bonus_feats={},
            description="Não pode levar o feito de Sensibilidade à Força e não pode fazer Use as verificações da Força",
            languages={"Básico","Binário"},
            name="Chassis Dróide do Trabalho",
            trained_skills={},
            skill_focus={},
            display="Dróide do Trabalho",
            special={"5o Grau","Traços Dróides","Levantamento pesado","Dróide do Trabalho"}
        },
        {
            racial_abilities="Imunidade de Força",
            bonus_feats={},
            description="Não pode aceitar o feito de Sensibilidade à Força, não pode fazer Use os cheques da Força e não pode ganhar Pontos de Força; imune aos efeitos da Força visando Defesa da Vontade",
            languages={"Básico","Lurmese"},
            name="Lurmen",
            trained_skills={},
            skill_focus={},
            display="Lurmen",
            special={"Mender","Primitivo","Rolo","Escalador Especialista"}
        },
        {
            racial_abilities="Resistência à Força",
            bonus_feats={},
            description="+5 espécie bônus para Will Defesa contra qualquer usar a verificação de força",
            languages={"Savrip"},
            name="Mantellian Savrip",
            trained_skills={},
            skill_focus={},
            display="Mantellian Savrip",
            special={"Raiva","Primitivo","Garras Venenosas"}
        },
        {
            racial_abilities="Visão de Força",
            bonus_feats={},
            description="Consegue ver através da Força apesar de ser cego. Isso funciona como a técnica de força aprimorada Sense Surroundings",
            languages={"Sith"},
            name="Massassi",
            trained_skills={},
            skill_focus={"Sobrevivência"},
            display="Massassi",
            special={"Obrigação limitada","Primitivo","Consciência do guerreiro","Familiaridade da Arma"}
        },
        {
            racial_abilities="Gen'Dai Surge",
            bonus_feats={},
            description="Sempre que um Gen'Dai toma um segundo vento, ele recupera 5 pontos de sucesso no final de sua rodada, cada rodada até que ele é morto, o final do encontro, ou ele atinge metade pontos de sucesso",
            languages={"Básico","Binário"},
            name="Chassis Dróide Mecânica",
            trained_skills={"Mecânica"},
            skill_focus={},
            display="Dróide Mecânico",
            special={"2o Grau","Traços Dróides","Desenho com fios rígidos (Mecânica)","Mecanicamente Cuidadoso"}
        },
        {
            racial_abilities="Tentáculos de agarramento",
            bonus_feats={},
            description="Krevaaki ganha um bônus de +2 espécies em verificações de escalada e um bônus de +2 espécies em verificações de grapple",
            languages={"Básico","Binário"},
            name="Chassis Dróide Médico",
            trained_skills={"Tratar Ferimentos"},
            skill_focus={},
            display="Dróide Médico",
            special={"1o Grau","Traços Dróides","Desenho com fios rígidos (Lesão de tratamento)"}
        },
        {
            racial_abilities="Hardy",
            bonus_feats={"Treinamento na Força"},
            description="Sempre que o Segundo Vento for usado, ganhe um número adicional de pontos de impacto igual a 5 + nível de caracteres",
            languages={"Básico","Miralukese"},
            name="Miraluka",
            trained_skills={},
            skill_focus={},
            display="Miraluka",
            special={"Visão de Força"}
        },
        {
            racial_abilities="Glândulas curativas",
            bonus_feats={},
            description="Fosh pode expelir um fluido poderoso de seus dutos lacrimais que podem ajudar no processo de cura para a maioria das espécies. Um Fosh é sempre considerado ter um medpac ou kit médico para fins de fazer a verificação de Lesão de Tratar, e pode realizar somente aplicações de habilidade de Lesão de Tratar mesmo quando não treinado.",
            languages={"Básico","Mon Calamarian"},
            name="Mon Calamari",
            trained_skills={},
            skill_focus={"Percepção"},
            display="Mon Calamari",
            special={"Respirar sob a água","Nadador especialista","Visão de Baixa Luz","Velocidade de natação (4)"}
        },
        {
            racial_abilities="Levantamento pesado",
            bonus_feats={},
            description="Rerole qualquer verificação de força ou verificação de habilidade baseada em força e manter qualquer resultado",
            languages={"Básico","Sr. Lisstese"},
            name="Sr. lssi.",
            trained_skills={"Mecânica"},
            skill_focus={"Persuasão"},
            display="Sr. lssi.",
            special={"Inclinação Científica"}
        },
        {
            racial_abilities="Consciência aumentada",
            bonus_feats={},
            description="Pode optar por rever qualquer verificação de percepção, mas o resultado do reroll deve ser aceito mesmo que seja pior",
            languages={"Básico","Nagaiano"},
            name="Nagai",
            trained_skills={},
            skill_focus={},
            display="Nagai",
            special={"Voz calmante"}
        },
        {
            racial_abilities="Hibernação",
            bonus_feats={},
            description="Pode entrar em um estado semelhante a uma Força Trance e usar essa aplicação da habilidade Use a Força sem treinamento e pode permanecer no transe indefinidamente",
            languages={"Básico","Nautila"},
            name="Nautolan",
            trained_skills={},
            skill_focus={},
            display="Nautolan",
            special={"Respirar sob a água","Sensor feromonal","Visão de Baixa Luz","Nadador especialista","Velocidade de natação (4)"}
        },
        {
            racial_abilities="Suspenda a respiração",
            bonus_feats={},
            description="Pode prender a respiração para o número de rodadas igual a 25 vezes a pontuação Constituição antes de precisar fazer verificações Endurance para prender a respiração",
            languages={"Básico","Nazren"},
            name="Nazren",
            trained_skills={},
            skill_focus={},
            display="Nazren",
            special={"Resistência de Nazren"}
        },
        {
            racial_abilities="Hullepi",
            bonus_feats={},
            description="Não sofra os efeitos da fome excepto em ambientes estéreis",
            languages={"Básico","Paeciano","Zabrak"},
            name="Quase-Humano",
            trained_skills={},
            skill_focus={},
            display="Dathomiri",
            special={"Bonus Feat","Consciência aumentada"}
        },
        {
            racial_abilities="Resiliência Inata",
            bonus_feats={},
            description="Pode usar Second Wind mesmo quando inconsciente e mover +3 passos na pista condição",
            languages={"Básico","Neimoidiano"},
            name="Neimoidiano",
            trained_skills={},
            skill_focus={"Enganação","Persuasão"},
            display="Neimoidiano",
            special={}
        },
        {
            racial_abilities="Inspirado",
            bonus_feats={},
            description="Aumente qualquer insight ou bônus moral recebido por 1",
            languages={"Nelvaanese"},
            name="Nelvaaniano",
            trained_skills={},
            skill_focus={},
            display="Nelvaaniano",
            special={"Primitivo","Perfume","Velocidade das Sombras"}
        },
        {
            racial_abilities="Pele isolante",
            bonus_feats={},
            description="Receba um bônus de +5 espécies para Defesa de Fortitude para resistir aos efeitos do frio extremo",
            languages={"Nikto","Básico","Huttese"},
            name="Nikto",
            trained_skills={},
            skill_focus={},
            display="Nikto",
            special={"Grande fortaleza","Armadura Natural","Instinto de Sobrevivência"}
        },
        {
            racial_abilities="Reputação Intelectual",
            bonus_feats={},
            description="Pode usar modificador de inteligência em vez de modificador de Carisma para Persuasão",
            languages={"Honoghran"},
            name="Noghri",
            trained_skills={},
            skill_focus={},
            display="Noghri",
            special={"Perfume","Primitivo"}
        },
        {
            racial_abilities="Intimidante",
            bonus_feats={},
            description="Pode repetir qualquer verificação de persuasão feita para intimidar os outros, mas o resultado do reroll deve ser aceito mesmo que seja pior",
            languages={"Básico","Nassauro"},
            name="Nassauro",
            trained_skills={"Escalar"},
            skill_focus={},
            display="Nassauro",
            special={"Herança do Escalador","Instinto de Sobrevivência"}
        },
        {
            racial_abilities="Iniciativa Intuitiva",
            bonus_feats={},
            description="Pode reroll qualquer verificação Iniciativa, mas o resultado do reroll deve ser aceito mesmo que seja pior",
            languages={"Básico","Utapese"},
            name="Pau'an",
            trained_skills={},
            skill_focus={"Persuasão"},
            display="Pau'an",
            special={"Autoridade","Visão de Baixa Luz"}
        },
        {
            racial_abilities="Sentido de Força Keen",
            bonus_feats={},
            description="Pode optar por rebobinar qualquer Use a verificação Força feita para pesquisar seus sentimentos ou sentir a Força, mantendo o melhor resultado",
            languages={"Phindian"},
            name="Phindian",
            trained_skills={},
            skill_focus={"Mecânica"},
            display="Phindian",
            special={}
        },
        {
            racial_abilities="Cheiro Keen",
            bonus_feats={},
            description="Ssi-Ruuk usa seu olfato afiado para detectar mudanças no estado emocional de um alvo. Quando dentro de 6 quadrados de um alvo na mesma sala ou área aberta, um Ssi-Ruuk pode refazer os controlos de Persuasão contra esse alvo, mantendo o melhor dos dois resultados.",
            languages={"Massan","Básico (somente compreendido)"},
            name="Polis Massan",
            trained_skills={},
            skill_focus={"Tratar Ferimentos"},
            display="Polis Massan",
            special={"Visão escura","Telepatia Limitada","Mudo"}
        },
        {
            racial_abilities="Dróide do Trabalho",
            bonus_feats={},
            description="Rerole qualquer verificação de força ou verificação de habilidade baseada em força e manter qualquer resultado",
            languages={"Básico","Binário"},
            name="Chassi Dróide Sonda",
            trained_skills={"Percepção"},
            skill_focus={},
            display="Droid Sonda",
            special={"4o Grau","Traços Dróides","Desenho com fios rígidos (Percepção)"}
        },
        {
            racial_abilities="Sensibilidade à Luz",
            bonus_feats={"Treinamento em Perícia"},
            description="Exposição abrupta a luz brilhante (como a luz solar) persianas para 1 rodada; sofrer uma penalidade -1 para todos os rolos de ataque, defesas e verificações ao operar em luz brilhante sem óculos protetores",
            languages={"Básico","Binário"},
            name="Protocolo Droid Chassis",
            trained_skills={"Persuasão"},
            skill_focus={},
            display="Droid Protocolo",
            special={"3o Grau","Traços Dróides","Desenho com fios (Persuasão)"}
        },
        {
            racial_abilities="Regeneração de membros",
            bonus_feats={},
            description="Regrow um membro perdido em 1d10 dias",
            languages={"Básico","Quarrenese"},
            name="Quarren",
            trained_skills={},
            skill_focus={"Persuasão"},
            display="Quarren",
            special={"Respirar sob a água","Nadador especialista","Visão de Baixa Luz","Velocidade de natação (4)"}
        },
        {
            racial_abilities="Precognição limitada",
            bonus_feats={"Foco na Arma (simples)","Foco na Arma ()","Foco na Arma ()"},
            description="Uma vez por encontro, um Iktotchi pode conceder a si mesmo ou a qualquer veículo que pilote um bônus de +2 espécies para Defesa de Reflexos contra um único ataque (como reação)",
            languages={"Rakata"},
            name="Rakata",
            trained_skills={},
            skill_focus={},
            display="Rakata",
            special={"Conhecimento Antigo","Forçar o Cego","Primitivo","Raiva"}
        },
        {
            racial_abilities="Telepatia Limitada",
            bonus_feats={},
            description="Pode usar o aspecto Telepatia do Use a habilidade Força destreinada (mesmo se não Força sensível). Se o alvo estiver dentro de 10 quadrados, nenhuma verificação de habilidade é necessária para iniciar o contato telepático",
            languages={"(língua nativa)"},
            name="Replica Droid (grande)",
            trained_skills={},
            skill_focus={"Enganação"},
            display="Replica dróide",
            special={"Traços Dróides","4o Grau"}
        },
        {
            racial_abilities="Visão de Baixa Luz",
            bonus_feats={},
            description="Ignorar a dissimulação (mas não total) das trevas",
            languages={"(língua nativa)"},
            name="Replica Droid (médio)",
            trained_skills={},
            skill_focus={"Enganação"},
            display="Replica dróide",
            special={"Traços Dróides","4o Grau"}
        },
        {
            racial_abilities="Aptitude Mecânica",
            bonus_feats={},
            description="Uma vez por encontro, um Yevetha pode tratar qualquer verificação Mecânica como se o rolo de morrer é um natural 20",
            languages={"(língua nativa)"},
            name="Replica Droid (pequeno)",
            trained_skills={},
            skill_focus={"Enganação"},
            display="Replica dróide",
            special={"Traços Dróides","4o Grau"}
        },
        {
            racial_abilities="Sabão Mecânico",
            bonus_feats={},
            description="Uma vez por encontro, pode fazer uma ação padrão Mecânica ou usar verificação de computador como uma ação rápida.",
            languages={"Básico","Rodesa"},
            name="Rodian",
            trained_skills={},
            skill_focus={"Sobrevivência"},
            display="Rodian",
            special={"Consciência aumentada","Visão de Baixa Luz"}
        },
        {
            racial_abilities="Mecanicamente Cuidadoso",
            bonus_feats={},
            description="Dróides mecânicos podem reroll qualquer verificação Mecânica",
            languages={"Básico","Ryn"},
            name="Ryn",
            trained_skills={},
            skill_focus={},
            display="Ryn",
            special={"Bico Musical","Coroa Preênsil","Ligações"}
        },
        {
            racial_abilities="Trance Meditativo",
            bonus_feats={},
            description="Em vez de dormir por 8 horas, pode entrar em um transe que dura 4 horas com os mesmos resultados; pode ser usado uma vez por dia; permanece um pouco consciente do ambiente e pode fazer verificações Percepção para evitar ser surpreendido",
            languages={"Selkath"},
            name="Selkath",
            trained_skills={},
            skill_focus={},
            display="Selkath",
            special={"Respirar sob a água","Nadador especialista","Curador Able"}
        },
        {
            racial_abilities="Partilha de Memórias",
            bonus_feats={"Treinamento em Perícia"},
            description="Pode compartilhar memórias com personagens adjacentes Caamasi e Force-using (com um DC 15 Use a verificação Força) iniciada como uma ação completa para conceder circunstâncias favoráveis a qualquer verificação de conhecimento relacionada à memória",
            languages={"Básico","Binário"},
            name="Chassis Dróide de Serviço",
            trained_skills={},
            skill_focus={},
            display="Droid de Serviço",
            special={"3o Grau","Traços Dróides"}
        },
        {
            racial_abilities="Mender",
            bonus_feats={},
            description="Se treinado em tratar lesões, reduzir o tratamento lesões DC para todas as aplicações da habilidade por",
            languages={"Básico","Binário"},
            name="Shard (Dróide)",
            trained_skills={"Usar Computador"},
            skill_focus={},
            display="Shard",
            special={"Droid Shell"}
        },
        {
            racial_abilities="Instabilidade Mental",
            bonus_feats={},
            description="Para cada categoria de idade um Gen'Dai avança além do Adulto, leva uma perda adicional de -1 Sabedoria e nunca ganha Sabedoria devido à idade",
            languages={"Shistavanen"},
            name="Shistavanen",
            trained_skills={"Sobrevivência"},
            skill_focus={},
            display="Shistavanen",
            special={"Armas Naturais","Reflexos Rápidos","Rastreador estranho","Visão de Baixa Luz"}
        },
        {
            racial_abilities="Mesmerizar",
            bonus_feats={"Proficiência da armadura (luz)"},
            description="#Valor!",
            languages={"Básico","Skakoverbal"},
            name="Skakoan",
            trained_skills={},
            skill_focus={"Mecânica"},
            display="Skakoan",
            special={"Equipamento especial (Skakoan)","Sabão Mecânico"}
        },
        {
            racial_abilities="Ambiguidade Moral",
            bonus_feats={},
            description="-5 pena para Will Defesa contra Persuasão verifica se prometido lucro ou poder",
            languages={"Básico","Slussese"},
            name="Sluissi",
            trained_skills={},
            skill_focus={},
            display="Sluissi",
            special={"Trabalhador Cuidadoso","Serpentina"}
        },
        {
            racial_abilities="Várias Personalidades",
            bonus_feats={},
            description="Uma vez por encontro, como uma ação livre no início de sua vez, negar ou remover quaisquer efeitos que afetam a mente",
            languages={"Snivvian"},
            name="Snivvian",
            trained_skills={},
            skill_focus={},
            display="Snivvian",
            special={"Resistência a frio","Observador"}
        },
        {
            racial_abilities="Bico Musical",
            bonus_feats={},
            description="Ao usar bico para imitar sons ou ruídos, pode reroll Deception verifica e ter o melhor resultado; jogar voz para 10 quadrados; Como uma ação rápida, use ventriloquim para criar uma distração para esconder",
            languages={"Básico","Squibbian"},
            name="Squib",
            trained_skills={"Persuasão"},
            skill_focus={},
            display="Squib",
            special={"Diplomata Natural","Exploração Tecnológica","Familiaridade da Arma"}
        },
        {
            racial_abilities="Mudo",
            bonus_feats={},
            description="Polis Massans não tem cordas vocais, e deve contar com uma combinação de linguagem de sinais, computadores e telepatia para se comunicar com os outros. Quando aprendem novas línguas, podem entender, mas não as falam.",
            languages={"Ssi-Ruuvi"},
            name="Ssi- Ruuk",
            trained_skills={},
            skill_focus={"Persuasão"},
            display="Ss-Ruuk",
            special={"Forçar o Cego","Cheiro Keen","Escalas blindadas"}
        },
        {
            racial_abilities="Armadura Natural",
            bonus_feats={},
            description="+1 bônus de armadura natural para Defesa Reflexa. Um bônus de armadura natural empilha com um bônus de armadura",
            languages={"Básico","Sullustese"},
            name="Sullustano",
            trained_skills={},
            skill_focus={},
            display="Sullustano",
            special={"Visão escura","Escalador Especialista","Consciência aumentada"}
        },
        {
            racial_abilities="Camuflagem Natural",
            bonus_feats={},
            description="Pode reroll qualquer verificação Stealth feito para esgueirar, mantendo o melhor resultado",
            languages={"Talz"},
            name="Talz",
            trained_skills={},
            skill_focus={"Mecânica"},
            display="Talz",
            special={"Visão escura"}
        },
        {
            racial_abilities="Curiosidade Natural",
            bonus_feats={},
            description="Uma vez por encontro como uma ação padrão, um Devaronian pode fazer uma verificação de percepção contra um único alvo dentro da linha de visão (DC 15 ou o resultado de uma verificação Stealth oposta, se o alvo está ativamente tentando esconder). Se bem-sucedido, o Devaronian ganha um bônus +1 insight em rolos de ataque contra esse alvo.",
            languages={"Básico","Mando'a"},
            name="Taung",
            trained_skills={},
            skill_focus={},
            display="Taung",
            special={"Treinamento de armaduras","Defesas Superiores","Cultura Guerreira"}
        },
        {
            racial_abilities="Diplomata Natural",
            bonus_feats={},
            description="Um Squib ganha um bônus de +5 espécies para verificações de persuasão feitas para Haggle (ver página 71 do livro de regras principais Saga Edition). Além disso, Persuasão é sempre uma habilidade de classe para Squibs.",
            languages={"Thakwaashi"},
            name="Thakwaash",
            trained_skills={},
            skill_focus={},
            display="Thakwaash",
            special={"Várias Personalidades","Armadura Natural"}
        },
        {
            racial_abilities="Telepata Natural",
            bonus_feats={"Artes marciais I","Forte balanço"},
            description="+5 bônus de espécies para o aspecto de Telepatia de Use a Força e pode fazer destreinada Use as verificações de Força sem Sensibilidade à Força",
            languages={"Topf"},
            name="Tops",
            trained_skills={},
            skill_focus={},
            display="Tops",
            special={}
        },
        {
            racial_abilities="Arma natural",
            bonus_feats={},
            description="Pode usar garras naturais em um ataque desarmado, lidando com 1d6 pontos de corte de danos em vez de danos normais desarmados. O caráter é sempre considerado armado com as armas naturais.",
            languages={"Básico","Togoriano"},
            name="Togoriano",
            trained_skills={},
            skill_focus={},
            display="Togoriano",
            special={"Visão de Baixa Luz","Intimidação física"}
        },
        {
            racial_abilities="Naturalmente acrobático",
            bonus_feats={},
            description="Considerado treinado na habilidade acrobática, mesmo que normalmente não seja uma habilidade de classe para o personagem.",
            languages={"Básico","Togruti"},
            name="Togruta",
            trained_skills={},
            skill_focus={},
            display="Togruta",
            special={"Pack Hunter","Sneaky","Consciência espacial"}
        },
        {
            racial_abilities="Resistência de Nazren",
            bonus_feats={},
            description="Uma vez por encontro, após ter sofrido danos iguais ou superiores ao limiar de dano, reduzir o número de degraus deslocados para baixo da pista de condição em 1",
            languages={"Toydarian","Huttese"},
            name="Toydarian",
            trained_skills={},
            skill_focus={"Enganação"},
            display="Toydarian",
            special={"Resistência à Força","Velocidade de voo (6)"}
        },
        {
            racial_abilities="Nômades",
            bonus_feats={"Dureza"},
            description="Pode reroll qualquer verificação de sobrevivência, mas o resultado do reroll deve ser aceito mesmo que seja pior",
            languages={"Básico","Dosh"},
            name="Trandoshan",
            trained_skills={},
            skill_focus={},
            display="Trandoshan",
            special={"Visão escura","Regeneração de membros"}
        },
        {
            racial_abilities="Observador",
            bonus_feats={},
            description="Pode usar o modificador de habilidade Percepção no lugar do modificador de habilidade Persuasão ou Decepção uma vez por encontro",
            languages={"Trianii"},
            name="Trianii",
            trained_skills={},
            skill_focus={},
            display="Trianii",
            special={"Proeza acrobática","Coroa Preênsil"}
        },
        {
            racial_abilities="Pacifismo",
            bonus_feats={},
            description="Como uma ação padrão, faça uma verificação de Persuasão contra Defesa de Vontade para mover um alvo -1 passo ao longo da faixa de condição se eles fazem qualquer ataque antes do próximo turno do personagem",
            languages={"Tusken"},
            name="Tusken Raider",
            trained_skills={},
            skill_focus={},
            display="Tusken Raider",
            special={"Instinto de Sobrevivência","Sneaky"}
        },
        {
            racial_abilities="Pack Hunter",
            bonus_feats={},
            description="Deal +2 danos em ataques melee contra adversários flanqueados",
            languages={"Básico","Ryl","Lekku"},
            name="Twi'lek",
            trained_skills={},
            skill_focus={},
            display="Twi'lek",
            special={"Enganador","Visão de Baixa Luz"}
        },
        {
            racial_abilities="Invisibilidade Parcial",
            bonus_feats={},
            description="A pele de um Defel ajuda a dobrar a luz ultravioleta, tornando-o quase invisível. Um Defel em iluminação sombreada ou condições mais escuras é tratado como tendo total ocultação. Defel são totalmente visíveis e não ganham nenhuma ocultação contra adversários com visão escura.",
            languages={"Básico","Ubese","Ubeninal"},
            name="Ubese",
            trained_skills={},
            skill_focus={"Percepção"},
            display="Ubese",
            special={"Agressivo","Instinto de Sobrevivência","Equipamento especial (Ubese)"}
        },
        {
            racial_abilities="Persistente",
            bonus_feats={},
            description="Rebole qualquer verificação Endurance, mas o resultado do reroll deve ser aceito, mesmo que seja pior",
            languages={"Básico","Umbarês"},
            name="Umbarã",
            trained_skills={},
            skill_focus={"Obter Informações"},
            display="Umbarã",
            special={"Visão escura","Furtivo"}
        },
        {
            racial_abilities="Persistente",
            bonus_feats={},
            description="Pode refazer uma verificação Endurance.",
            languages={"Utapese"},
            name="Utai",
            trained_skills={},
            skill_focus={},
            display="Utai",
            special={"Manipulador de Animais","Cooperativa","Visão de Baixa Luz"}
        },
        {
            racial_abilities="Persuasivo",
            bonus_feats={},
            description="Pode optar por repetir qualquer verificação de Persuasão, mas o resultado do reroll deve ser aceito mesmo que seja pior",
            languages={"Básico","Verpino"},
            name="Verpino",
            trained_skills={},
            skill_focus={},
            display="Verpino",
            special={"Consciência aumentada","Comunicação verpina"}
        },
        {
            racial_abilities="Comunicação Pheromonal",
            bonus_feats={},
            description="Pode comunicar-se com outros membros da mesma tribo, criando um perfume que aqueles com comunicação feromonal ou Scent pode detectar, mas só aqueles da mesma tribo pode entender; Nagem máxima de 20 quadrados",
            languages={"Básico","Dromnyr"},
            name="Vultão",
            trained_skills={},
            skill_focus={},
            display="Vultão",
            special={"Bônus Treinado Habilidade"}
        },
        {
            racial_abilities="Sensor feromonal",
            bonus_feats={},
            description="Pode optar por refazer qualquer verificação de percepção para sentir enganos ou influência de sentido, mas o resultado do reroll deve ser aceito mesmo que seja pior; subaquático, pode em vez disso reroll e manter o melhor resultado",
            languages={"Básico","Semblan"},
            name="Vurk",
            trained_skills={},
            skill_focus={},
            display="Vurk",
            special={"Respirar sob a água","Nadador especialista","Placida","Nômades","Velocidade de natação (4)"}
        },
        {
            racial_abilities="Aclimação do feromônio",
            bonus_feats={},
            description="Ganhe um bônus de +5 espécies à defesa de fortaleza contra os feromônios de outros Falleen",
            languages={"Sriluuriano"},
            name="Weequay",
            trained_skills={},
            skill_focus={},
            display="Weequay",
            special={"Comunicação Pheromonal","Armadura Natural"}
        },
        {
            racial_abilities="Feromonas",
            bonus_feats={},
            description="Como uma ação padrão, faça um ataque especial contra a criatura adjacente (nível de caracteres + modificador Carisma vs. Defesa de fortaleza). Se o ataque tiver sucesso, o alvo se move -1 para baixo da pista de condição. Em vez de cair em inconsciência em -5 passos, torna-se, em vez disso, amigável em atitude. Um ataque falhado torna o alvo imune aos feromônios durante 24 horas",
            languages={"Uísque"},
            name="Uísque",
            trained_skills={},
            skill_focus={},
            display="Uísque",
            special={"Pele isolante","Perfume"}
        },
        {
            racial_abilities="Fisicamente Intimidante",
            bonus_feats={},
            description="Pode usar modificador de força em vez de modificador Charisma para fazer verificações de Persuasão para intimidar outros",
            languages={"Shyriiwook","Básico (somente compreendido)"},
            name="Wookiee",
            trained_skills={},
            skill_focus={},
            display="Wookiee",
            special={"Raiva","Escalador Especialista","Intimidante"}
        },
        {
            racial_abilities="Fisicamente Intimidante",
            bonus_feats={},
            description="Yuzzem usar seu modificador de força em vez de seu modificador Carisma para verificações de persuasão feitas para intimidar outros",
            languages={"Básico","Wroonian"},
            name="Wroonian",
            trained_skills={},
            skill_focus={},
            display="Wroonian",
            special={"Habilidades"}
        },
        {
            racial_abilities="Placida",
            bonus_feats={},
            description="Uma vez por encontro, como uma ação livre, remover um efeito de medo que atualmente afeta você",
            languages={"Básico","Yarkora"},
            name="Yarkora",
            trained_skills={"Obter Informações"},
            skill_focus={},
            display="Yarkora",
            special={"Confusão","Enganador","Rua"}
        },
        {
            racial_abilities="Garras Venenosas",
            bonus_feats={},
            description="Alvos vivos danificados por ataque de garra são envenenados por um rolo de ataque (1d20 + nível de personagem de Savrip) contra a defesa de fortaleza para mover -1 descer a trilha de condição",
            languages={"Yevethan"},
            name="Yevetha",
            trained_skills={},
            skill_focus={},
            display="Yevetha",
            special={"Aptitude Mecânica","Xenofobia"}
        },
        {
            racial_abilities="Resistência Venenosa",
            bonus_feats={},
            description="+5 espécies bônus à defesa de fortaleza para resistir aos efeitos do veneno",
            languages={"Yuuzhan Vong"},
            name="Yuuzhan Vong",
            trained_skills={},
            skill_focus={},
            display="Yuuzhan Vong",
            special={"Imunidade de Força","Tecnofóbico"}
        },
        {
            racial_abilities="Herança do Predador",
            bonus_feats={},
            description="+2 bônus para rolos de danos contra um alvo que foi danificado desde o início da última vez do Kerkoiden",
            languages={"Yuzz"},
            name="Yuzzem",
            trained_skills={},
            skill_focus={},
            display="Yuzzem",
            special={"Fisicamente Intimidante","Perfume","Escalador Especialista"}
        },
        {
            racial_abilities="Coroa Preênsil",
            bonus_feats={},
            description="Segurar efetivamente (mas não empunhar) um item pequeno ou menor com cauda; pode segurar um item médio ou maior, considerado sobrecarregado e carregando uma carga pesada",
            languages={"Básico","Zabrak"},
            name="Zabrak",
            trained_skills={},
            skill_focus={},
            display="Zabrak",
            special={"Consciência aumentada","Defesas Superiores"}
        },
        {
            racial_abilities="Sentido de Presença",
            bonus_feats={},
            description="Ao fazer uma verificação de sobrevivência para rastrear uma criatura viva, um Anzat ganha um bônus de espécie igual ao total de Ponto da Força da pedreira.",
            languages={"Básico"},
            name="Zeltron",
            trained_skills={},
            skill_focus={},
            display="Zeltron",
            special={"Pheromones de Zeltron","Zeltron Empatia"}
        },
        {
            racial_abilities="Primitivo",
            bonus_feats={"Artes marciais I"},
            description="Não ganhe Proficiência em Armas (pistols, rifles, armas pesadas) como proezas iniciais no 1o nível",
            languages={"Básico"},
            name="Zygerrian",
            trained_skills={},
            skill_focus={},
            display="Zygerrian",
            special={"Will de Ferro","Força de Convicção"}
        }
    },
    classes={
        {
            special="",
            name="Nenhum",
            class_features="Capa de Comando",
            prereqs={}
        },
        {
            special="",
            name="Jedi",
            class_features="Redução de Danos",
            prereqs={}
        },
        {
            special="",
            name="Nobre",
            class_features="Atrasar danos",
            prereqs={}
        },
        {
            special="",
            name="Malandro",
            class_features="Fã Familiar",
            prereqs={}
        },
        {
            special="",
            name="Batedor",
            class_features="Destemido",
            prereqs={}
        },
        {
            special="",
            name="Soldado",
            class_features="Indomável",
            prereqs={}
        },
        {
            special="",
            name="Não Heroico",
            class_features="Profeta",
            prereqs={}
        },
        {
            special="",
            name="Fera",
            class_features="Serenidade",
            prereqs={}
        },
        {
            special="",
            name="Piloto Ace",
            class_features="Compartilhar Talento",
            prereqs={"Nível mínimo: 7o","Habilidades treinadas: Piloto","Feats: Combate Veicular"}
        },
        {
            special="",
            name="Assassino",
            class_features="Tentação",
            prereqs={"Nível mínimo: 7o","Habilidades treinadas: Stealth","Feat: Sniper","Talentos: Ataque Dastardly"}
        },
        {
            special="",
            name="Caçador de recompensas",
            class_features="Braço lateral confiável",
            prereqs={"Nível mínimo: 7o","Habilidades treinadas: Sobrevivência","Talentos: Quaisquer dois da Consciência"}
        },
        {
            special="",
            name="Charlatão",
            class_features="Veículo Dodge",
            prereqs={"Nível mínimo: 7o","Habilidades treinadas: Decepção, Persuasão","Talentos: Qualquer um das árvores de talento Desgraça, Influência ou Linhagem"}
        },
        {
            special="Deve ser empregado por uma grande corporação interestelar",
            name="Agente Empresarial",
            class_features="Construir um sabre de luz",
            prereqs={"Nível mínimo: 7o","Competências formadas: reunir informação, conhecimento (burocracia)","Feats: Skill Focus (Conhecimento [burocracia])"}
        },
        {
            special="",
            name="Senhor do Crime",
            class_features="Liderança Executiva",
            prereqs={"Nível mínimo: 7o","Habilidades treinadas: Decepção, Persuasão","Talentos: Qualquer um da fortuna, linha ou azar"}
        },
        {
            special="",
            name="Comandante Dróide",
            class_features="Incandescentes",
            prereqs={"Nível mínimo: 7o","Habilidades treinadas: Conhecimento (táticas), Use o computador","Talentos: Qualquer um das árvores de talentos Liderança ou Comando","Especial: Apenas dróides"}
        },
        {
            special="",
            name="Elite Trooper",
            class_features="Mestre de Movimento",
            prereqs={"Bônus de ataque básico mínimo +7","Feats: Proficiência da armadura (luz), Proficiência da armadura (médium), Artes Marciais I, Tiro em Branco ou Flurry","Talentos: Qualquer um do Especialista em Armadura, Comando ou Especialista em Armas"}
        },
        {
            special="Deve pertencer a uma organização de segurança da lei ou similar",
            name="Aplicador",
            class_features="Recursos",
            prereqs={"Nível mínimo: 7o","Habilidades treinadas: reunir informações, percepção","Talentos: Qualquer um de Survivor"}
        },
        {
            special="",
            name="Forçar o Adepto",
            class_features="Suspeito-alvo",
            prereqs={"Nível mínimo: 7o","Habilidades treinadas: Use a força","Feats: Força Sensível","Talentos: Quaisquer três talentos da Força"}
        },
        {
            special="",
            name="Forçar Discípulo",
            class_features="Sapience",
            prereqs={"Nível mínimo: 12o","Habilidades treinadas: Use a força","Feats: Força Sensível","Talentos: Quaisquer dois de Lado Sombrio Devotee, Force Adept ou Force Item","Poderes de Força: Farseeing","Técnicas de Força: Qualquer um"}
        },
        {
            special="",
            name="Gladiador",
            class_features="Espírito Independente",
            prereqs={"Nível mínimo: 7o","Bônus de ataque básico mínimo: +7","Feats: Limiar de Danos Melhorado, Proficiência de Armas (armas melee avançadas)"}
        },
        {
            special="",
            name="Gunslinger",
            class_features="Stun Desarmado",
            prereqs={"Nível mínimo: 7o","Feats: Tiro em branco ponto, Tiro preciso, Desenho rápido, Proficiência de arma (pistols)"}
        },
        {
            special="Deve ser um defensor jurado do Imperador Roan Fel.",
            name="Cavaleiro Imperial",
            class_features="Infiltrador de chumbo",
            prereqs={"Bônus de ataque básico mínimo: +7","Habilidades treinadas: Use a força","Feats: Força Sensível, Proficiência da armadura (luz, meio), Proficiência da arma (lightsabers)"}
        },
        {
            special="",
            name="Dróide Independente",
            class_features="Privado Veterano",
            prereqs={"Nível mínimo: 3o","Habilidades treinadas: Use o computador","Sytem: Processador Heurístico","Especial: Apenas dróides"}
        },
        {
            special="",
            name="Infiltrador",
            class_features="Segredo Médico",
            prereqs={"Nível mínimo: 7o","Habilidades treinadas: Percepção, Stealth","Feats: Skill Focus (Stealth)","Talentos: Quaisquer dois de Camuflagem ou Espião"}
        },
        {
            special="Deve ter construído o próprio sabre de luz. Deve ser um membro da tradição Jedi.",
            name="Cavaleiro Jedi",
            class_features="Resultados Inesperados",
            prereqs={"Bônus de ataque básico mínimo: +7","Habilidades treinadas: Use a força","Feats: Força Sensível, Proficiência da Arma (Iluminadores)"}
        },
        {
            special="Deve ser um membro da tradição Jedi.",
            name="Mestre Jedi",
            class_features="Destrutivo",
            prereqs={"Nível mínimo: 12o","Habilidades treinadas: Use a força","Feats: Força Sensível, Proficiência da Arma (Iluminadores)","Técnicas de Força: Qualquer um"}
        },
        {
            special="",
            name="Mestre Privado",
            class_features="Sabotagem Rápida",
            prereqs={"Nível mínimo: 7o","Habilidades treinadas: Decepção, Piloto","Feats: Combate Veicular","Talentos: Quaisquer dois de Misfortune, Contrabandista ou Espaçador"}
        },
        {
            special="",
            name="Médico",
            class_features="Mestre Saboteur",
            prereqs={"Nível mínimo: 7o","Competências formadas: Conhecimento (ciências da vida), Tratar lesões","Feats: Perícia cirúrgica"}
        },
        {
            special="",
            name="Duelista Melee",
            class_features="Marcar",
            prereqs={"Nível mínimo: 7o","Bônus de ataque básico mínimo: +7","Feats: Defesa de Melee, Ataque Rápido, Arma Concentre-se com qualquer arma melee"}
        },
        {
            special="",
            name="Engenheiro Militar",
            class_features="Pontuação",
            prereqs={"Nível mínimo: 7o","Habilidades treinadas: Mecânica, Computador de Uso"}
        },
        {
            special="Deve pertencer a uma organização com uma divisão militar ou paramilitar",
            name="Oficial",
            class_features="Enganar",
            prereqs={"Nível mínimo: 7o","Competências Formadas: Conhecimento (táticas)","Talentos: Qualquer um do Comando ou Liderança"}
        },
        {
            special="Você deve ser procurado pelas autoridades em pelo menos um sistema estelar",
            name="Foragido",
            class_features="Fugitivo",
            prereqs={"Nível mínimo: 7o","Habilidades treinadas: furtivo, sobrevivência","Talentos: Qualquer um das árvores de talento Desgraça ou Desfortuna"}
        },
        {
            special="",
            name="Sabotador",
            class_features="Mente em Rede",
            prereqs={"Nível mínimo: 7o","Habilidades treinadas: Decepção, Mecânica, Usar o Computador"}
        },
        {
            special="",
            name="Shaper",
            class_features="Arma Criada em Campo",
            prereqs={"Nível mínimo: 7o","Competências formadas: Conhecimento (ciências da vida), Tratar lesões","Feat: Especialista em Biotecnologia","Espécie: Yuuzhan Vong"}
        },
        {
            special="Deve ser um membro da tradição Sith.",
            name="Aprendiz Sith",
            class_features="Ataque surpresa",
            prereqs={"Nível mínimo: 7o","Habilidades treinadas: Use a força","Feats: Força Sensível","Lado Sombrio Score deve ser igual ao Wisdom score"}
        },
        {
            special="Deve ser um membro da tradição Sith.",
            name="Sith Lord",
            class_features="Shaper Lore",
            prereqs={"Nível mínimo: 12o","Habilidades treinadas: Use a força","Feats: Força Sensível, Proficiência da Arma (Iluminadores)","Técnicas de Força: Qualquer um","Lado Sombrio Score deve ser igual ao Wisdom score"}
        },
        {
            special="",
            name="Vanguarda",
            class_features="Happer Hand",
            prereqs={"Nível mínimo: 7o","Habilidades treinadas: Percepção, Stealth","Talentos: Quaisquer dois de Camuflagem ou Comando"}
        },
        {
            special="",
            name="Improvisador",
            class_features="Contrabando",
            prereqs={"Nível mínimo: 7o"}
        },
        {
            special="",
            name="Identificador de caminhos",
            class_features="Não são necessárias ferramentas",
            prereqs={"Nível mínimo: 7o"}
        },
        {
            special="",
            name="Mestre de Artes Marciais",
            class_features="Criar uma Capa",
            prereqs={}
        }
    }
}
