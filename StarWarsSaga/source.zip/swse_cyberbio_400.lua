return {
bio_augments={
{name="Body spikes",name_pt="Espinhos Corporais",cost=1400,effect_pt="Causa 1d4 de dano perfurante e cortante enquanto estiver agarrando."},
{name="Cosmetic enhancements",name_pt="Aprimoramentos Cosméticos",cost=200,effect_pt="Alterações cosméticas."},
{name="Enhanced vision",name_pt="Visão Aprimorada",cost=1900,effect_pt="Concede Visão no Escuro."},
{name="Natural armor",name_pt="Armadura Natural",cost=7000,effect_pt="+1 de armadura natural na Defesa de Reflexos."},
{name="Natural weapon",name_pt="Arma Natural",cost=4000,effect_pt="Armas naturais causam 1d6 de dano."},
{name="Poison filter",name_pt="Filtro de Veneno",cost=2500,effect_pt="+5 de bônus de equipamento na Defesa de Fortitude contra veneno."},
{name="Replacement body part",name_pt="Parte Corporal de Reposição",cost=2000,effect_pt="Substitui um membro ou outra parte do corpo."}
},
cybernetics={
{name="Borg construct",name_pt="Construção Borg",cost=80000,surgery=70000,rejection=14,availability="R",effect_pt="Conecta-se a computadores em até 10 m; +2 em perícias e -5 em Persuasão."},
{name="Comlink, subcutaneous",name_pt="Comlink Subcutâneo",cost=4000,surgery=3000,rejection=3,availability="R",effect_pt="Permite enviar comunicações silenciosamente."},
{name="Cybernetic prosthesis",name_pt="Prótese Cibernética",cost=1500,surgery=500,rejection=0,availability="C",effect_pt="Substitui um membro ou parte corporal. Cada prótese conta para a penalidade de Usar a Força, até o limite aplicável."},
{name="Eye, infrared sensor",name_pt="Olho — Sensor Infravermelho",cost=300,surgery=2250,rejection=14,availability="R",effect_pt="Concede Visão no Escuro."},
{name="Eye, targeting",name_pt="Olho — Mira",cost=500,surgery=3750,rejection=16,availability="M",effect_pt="Funciona como Pacote de Capacete."},
{name="Eye, telescopic",name_pt="Olho — Telescópico",cost=500,surgery=3750,rejection=9,availability="R",effect_pt="Penalidades de alcance em Percepção ocorrem a cada 20 quadrados em vez de 10."},
{name="Skeletal reinforcement",name_pt="Reforço Esquelético",cost=10000,surgery=50000,rejection=12,availability="R",effect_pt="+2 no Limiar de Dano."},
{name="Sensory enhancement",name_pt="Aprimoramento Sensorial",cost=800,surgery=3000,rejection=14,availability="R",effect_pt="Reduz em 2 as penalidades de Percepção contra ocultação."},
{name="Tremor sensor",name_pt="Sensor de Tremor",cost=400,surgery=3750,rejection=7,availability="R",effect_pt="Ignora a penalidade de Percepção por ocultação se o alvo tiver se movido."},
{name="Rhen-Orm Biocomputer",name_pt="Biocomputador Rhen-Orm",cost=0,surgery=0,rejection=0,availability="",effect_pt="Adiciona o total de Pontos da Força do alvo aos testes de Sobrevivência para rastreá-lo; custo não informado na tabela-fonte."}
}
}