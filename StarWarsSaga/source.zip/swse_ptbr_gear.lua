return {
    armor={
        {
            special="",
            name="Armadura personalizada",
            availability="Frequentes",
            type=""
        },
        {
            special="Capacete; Selos de vácuo",
            name="Fato de voo",
            availability="Frequentes",
            type=""
        },
        {
            special="Capacete; Selos de vácuo, melhorado",
            name="Naipe de Espaço",
            availability="Frequentes",
            type=""
        },
        {
            special="Capacete com capacete pacote; Comlink interno, de curto alcance; Capacete pacote",
            name="Armadura ARC",
            availability="Militar",
            type="L"
        },
        {
            special="Ganhe DR 2 contra energia e fogo",
            name="Blindagem de micróbios Barabel",
            availability="Licenciado",
            type="L"
        },
        {
            special="",
            name="Armadura de batalha, luz",
            availability="Militar",
            type="L"
        },
        {
            special="Capacete com capacete pacote; Capacete pacote",
            name="Armadura de batalha, com luz",
            availability="Militar",
            type="L"
        },
        {
            special="Capacete com capacete pacote; 6; Ferro Mandalorian",
            name="Beskar'gam, luz",
            availability="Licenciado",
            type="L"
        },
        {
            special="Capacete",
            name="Capacete de explosão e colete",
            availability="Frequentes",
            type="L"
        },
        {
            special="",
            name="Jaqueta de explosão",
            availability="Frequentes",
            type="L"
        },
        {
            special="Capacete com capacete pacote; Comlink interno, de curto alcance; Capacete pacote",
            name="Armadura de soldado clonado",
            availability="Militar",
            type="L"
        },
        {
            special="",
            name="Macacão de combate",
            availability="Licenciado",
            type="L"
        },
        {
            special="Capacete; Selos de vácuo",
            name="Armadura de comando",
            availability="Licenciado",
            type="L"
        },
        {
            special="Capacete com capacete pacote; Comlink interno, de curto alcance; Capacete pacote",
            name="Coruscant Guarda armadura",
            availability="Militar",
            type="L"
        },
        {
            special="",
            name="Armadura escura, luz",
            availability="Frequentes",
            type="L"
        },
        {
            special="Capacete com capacete pacote; +10 bônus de equipamentos contra venenos aéreos; Comlink interno, curto alcance; Capacete pacote",
            name="Armadura EVO",
            availability="Militar",
            type="L"
        },
        {
            special="Ganhar DR 10 uma vez por encontro contra um ataque variado",
            name="Armadura de fibra",
            availability="Licenciado",
            type="L"
        },
        {
            special="Capacete; Selos de vácuo",
            name="Fato de voo, blindado",
            availability="Licenciado",
            type="L"
        },
        {
            special="Capacete; Selos de vácuo",
            name="Fato de voo, acolchoado",
            availability="Frequentes",
            type="L"
        },
        {
            special="",
            name="Armadura da Aliança Galáctica",
            availability="Militar",
            type="L"
        },
        {
            special="Capacete",
            name="Variante da armadura da Aliança Galáctica",
            availability="Frequentes",
            type="L"
        },
        {
            special="",
            name="túnica de guerreiro geonosiano",
            availability="Licenciado",
            type="L"
        },
        {
            special="1/ encontro nega danos adicionais de Sneak Attack ou habilidades semelhantes",
            name="Meio-vest",
            availability="Restrito",
            type="L"
        },
        {
            special="Capacete com capacete pacote; Comlink interno, de curto alcance; Capacete pacote",
            name="Armadura de masmorra pesada",
            availability="Militar",
            type="L"
        },
        {
            special="",
            name="Armadura de batalha Jedi, luz",
            availability="Frequentes",
            type="L"
        },
        {
            special="Capacete com capacete pacote; Comlink interno, de curto alcance; Capacete pacote",
            name="Armadura de saltador",
            availability="Militar",
            type="L"
        },
        {
            special="",
            name="Armadura Krath",
            availability="Militar",
            type="L"
        },
        {
            special="Capacete",
            name="Armadura Krath",
            availability="Militar",
            type="L"
        },
        {
            special="Capacete; Selos de vácuo",
            name="Armadura de combate leve",
            availability="Licenciado",
            type="L"
        },
        {
            special="Capacete com capacete pacote; 6; Selos de vácuo; Comlink interno, de curto alcance; Capacete pacote; Jet Pack",
            name="Fato de combate Mandaloriano",
            availability="Frequentes",
            type="L"
        },
        {
            special="Capacete com capacete pacote; 6; Selos de vácuo; Comlink interno, de curto alcance; Capacete pacote; Jet Pack",
            name="Armadura leve Mandalorian Neo-Crusader",
            availability="Militar",
            type="L"
        },
        {
            special="Adaptação aquática; Selos de vácuo, melhorado",
            name="Armadura marinha",
            availability="Restrito",
            type="L"
        },
        {
            special="",
            name="Merr-Sonn KZZ armadura de choque",
            availability="Militar",
            type="L"
        },
        {
            special="Capacete com capacete pacote; Comlink interno, de curto alcance; Capacete pacote",
            name="Armadura de Soldado Escuro de Fase Zero",
            availability="Militar",
            type="L"
        },
        {
            special="Capacete com capacete pacote; Comlink interno, curto alcance; Capacete pacote; Escudo de radiação",
            name="Armadura Radtrooper",
            availability="Militar",
            type="L"
        },
        {
            special="Capacete; Comlink interno, de curto alcance",
            name="República armadura leve",
            availability="Frequentes",
            type="L"
        },
        {
            special="Capacete com capacete pacote; Comlink interno, curto alcance; Sistemas ambientais (calor); Capacete pacote",
            name="Armaduras de aparelhagem",
            availability="Militar",
            type="L"
        },
        {
            special="Capacete com capacete pacote; Comlink interno, de curto alcance; Capacete pacote",
            name="Armadura de escoteiro",
            availability="Militar",
            type="L"
        },
        {
            special="Capacete com capacete pacote; Nade; 2; Profundidade máxima 10 atmosferas; Comlink interno, curto alcance; Capacete pacote; Pacote de propulsão",
            name="Armaduras para embarcações",
            availability="Militar",
            type="L"
        },
        {
            special="Capacete com capacete pacote; Stealth; 2; Darkvision, imune à detecção",
            name="Armadura da tropa da sombra",
            availability="Militar",
            type="L"
        },
        {
            special="+5 para cheques furtivos na ocultação",
            name="Fato de sombra",
            availability="Militar",
            type="L"
        },
        {
            special="+5 para cheques furtivos na ocultação",
            name="Fato de sombra (CWCS)",
            availability="Militar",
            type="L"
        },
        {
            special="Capacete com capacete pacote; Comlink interno, de curto alcance; Capacete pacote",
            name="Armadura de soldado Sith",
            availability="Militar",
            type="L"
        },
        {
            special="Capacete; Selos de vácuo",
            name="Fato de pressão leve Skakoan",
            availability="Licenciado",
            type="L"
        },
        {
            special="Capacete com capacete pacote; Comlink interno, de curto alcance; Sistemas ambientais (frio); Capacete pacote",
            name="Armaduras para bonecos de neve",
            availability="Militar",
            type="L"
        },
        {
            special="Capacete; Selos de vácuo",
            name="Armadura SpecForce",
            availability="Licenciado",
            type="L"
        },
        {
            special="Capacete com capacete pacote; Comlink interno, de curto alcance; Capacete pacote",
            name="Armadura de Stormtrooper",
            availability="Militar",
            type="L"
        },
        {
            special="Deal 3d8 atordoar danos em grapple",
            name="Capa atordoada",
            availability="Licenciado",
            type="L"
        },
        {
            special="Suporte de vida de 1 hora, +5 bônus para defesa de fortaleza para resistir a ambientes extremos",
            name="Fato",
            availability="Frequentes",
            type="L"
        },
        {
            special="Conservar até 24 itens de 1 kg e tratar como meio peso",
            name="Colete de utilitário de rastreamento",
            availability="Frequentes",
            type="L"
        },
        {
            special="Capacete; Máscara de respiração; Modulador de voz Ubese; Máscara de respiração, modulador de voz; Equipamento integrado, 2 slots",
            name="Fato ambiental Ubese",
            availability="Frequentes",
            type="L"
        },
        {
            special="",
            name="Caranguejo de Vonduun",
            availability="Frequentes",
            type="L"
        },
        {
            special="",
            name="WJ-880 capacete de cegamento",
            availability="Frequentes",
            type="L"
        },
        {
            special="",
            name="Armadura de batalha",
            availability="Militar",
            type="M"
        },
        {
            special="Capacete com capacete pacote; Capacete pacote",
            name="Armadura de batalha, alimentada",
            availability="Militar",
            type="M"
        },
        {
            special="Capacete com capacete pacote; 6; Ferro Mandalorian",
            name="Beskar'gam, médio",
            availability="Restrito",
            type="M"
        },
        {
            special="",
            name="Fato de risco biológico",
            availability="Licenciado",
            type="M"
        },
        {
            special="+10 para Stealth ao se esconder",
            name="Armadura Camo",
            availability="Restrito",
            type="M"
        },
        {
            special="Pele de Sombra",
            name="Armadura de escoteiros Camo",
            availability="Licenciado",
            type="M"
        },
        {
            special="Capacete",
            name="Armadura cerimonial",
            availability="Restrito",
            type="M"
        },
        {
            special="+2 bônus de equipamento para força",
            name="Fato de potência corelian",
            availability="Restrito",
            type="M"
        },
        {
            special="",
            name="Armadura escura, média",
            availability="Frequentes",
            type="M"
        },
        {
            special="Capacete com capacete pacote; 4; Selos de vácuo; Jet Pack, repulsor de potência reduzida; Capacete pacote",
            name="Blindagem GTU AV-1S",
            availability="Militar",
            type="M"
        },
        {
            special="Adicionar DR pessoal contra sabres de luz",
            name="Armadura Imperial Cavaleiro",
            availability="Raros",
            type="M"
        },
        {
            special="",
            name="Armadura de batalha Jedi, média",
            availability="Frequentes",
            type="M"
        },
        {
            special="Capacete com capacete pacote; Bacta tanques; Comlink interno, de curto alcance; Selos de vácuo, melhorado",
            name="Armadura de comando classe Katarn",
            availability="Militar",
            type="M"
        },
        {
            special="Capacete com capacete pacote; +5 Vai Defesa contra Use o pacote Força; Capacete",
            name="Armadura para cavaleiros",
            availability="Militar",
            type="M"
        },
        {
            special="Capacete com capacete pacote; 6; Dispensador de cabo líquido (15 metros); +2 para Controles de força para levantar, arrastar ou puxar, dispensador de cabo líquido; Selos de vácuo; Equipamento integrado, 1 slot; Pacote de capacete; Jet Pack",
            name="Armadura pessoal Krail 210",
            availability="Militar",
            type="M"
        },
        {
            special="Capacete com capacete pacote; 6; Selos de vácuo; Comlink interno, de curto alcance; Capacete pacote; Jet Pack",
            name="Armadura de batalha Mandalorian Neo-Crusader",
            availability="Frequentes",
            type="M"
        },
        {
            special="Ganhar DR 20 uma vez por encontro contra um ataque variado",
            name="Armadura de malha",
            availability="Restrito",
            type="M"
        },
        {
            special="Capacete com visão de baixa luz; Comlink interno, curto alcance",
            name="Armadura de combate da República",
            availability="Frequentes",
            type="M"
        },
        {
            special="Capacete com capacete pacote; Capacete pacote",
            name="Armadura da Guarda Real",
            availability="Restrito",
            type="M"
        },
        {
            special="Capacete com capacete pacote; Capacete pacote",
            name="Armadura guarda sombra",
            availability="Restrito",
            type="M"
        },
        {
            special="",
            name="Fato de batalha Sith",
            availability="Frequentes",
            type="M"
        },
        {
            special="",
            name="Fato de pressão médio de Skakoan",
            availability="Militar",
            type="M"
        },
        {
            special="",
            name="Armaduras para furtivos",
            availability="Licenciado",
            type="M"
        },
        {
            special="",
            name="Armadura de trama",
            availability="Restrito",
            type="M"
        },
        {
            special="",
            name="Armadura de batalha, pesada",
            availability="Militar",
            type="H"
        },
        {
            special="Capacete com capacete pacote; Capacete pacote",
            name="Armadura de batalha, pesada",
            availability="Restrito",
            type="H"
        },
        {
            special="Capacete com capacete pacote; 4; Ferro Mandalorian",
            name="Beskar'gam, pesado",
            availability="Restrito",
            type="H"
        },
        {
            special="",
            name="Armadura escura, pesada",
            availability="Frequentes",
            type="H"
        },
        {
            special="Capacete com capacete pacote; 6; Selos de vácuo; Jet Pack, repulsorlift; Capacete pacote",
            name="Armadura de combate GTU AV-1C",
            availability="Restrito",
            type="H"
        },
        {
            special="Capacete com capacete pacote; 4; Selos de vácuo, melhorado; Comlink interno, de curto alcance; Capacete pacote; Jet Pack",
            name="Armadura de assalto Mandalorian Neo-Crusader",
            availability="Militar",
            type="H"
        },
        {
            special="Ganhar DR 30 uma vez por encontro contra um ataque variado",
            name="Armadura matricial",
            availability="Restrito",
            type="H"
        },
        {
            special="DR 10 mesmo contra sabres de luz",
            name="Armadura orbalisca",
            availability="Frequentes",
            type="H"
        },
        {
            special="Capacete com capacete pacote; 6; Liga de Phrik; Comlink interno, de curto alcance; Capacete pacote; Jet Pack",
            name="Armadura de patrulha escura de fase II",
            availability="Militar",
            type="H"
        },
        {
            special="Capacete com capacete pacote; Liga de Phrik; Comlink interno, de curto alcance; Capacete pacote",
            name="Armadura de patrulha escura de fase III",
            availability="Militar",
            type="H"
        },
        {
            special="Capacete com visão de baixa luz; DR 2 contra energia, visão de baixa luz; Selos de vácuo, melhorado; Comlink interno, curto alcance",
            name="Armadura pesada da República",
            availability="Frequentes",
            type="H"
        },
        {
            special="Capacete; Selos de vácuo, melhorado",
            name="Fato de pressão pesada de Skakoan",
            availability="Militar",
            type="H"
        },
        {
            special="Capacete; Selos de vácuo, melhorado",
            name="Fato espacial, blindado",
            availability="Restrito",
            type="H"
        },
        {
            special="2 horas de suporte de vida, comunicação de longo alcance, powerlamp, kit de reparo",
            name="Pod de vácuo",
            availability="Frequentes",
            type="H"
        },
        {
            special="Capacete; Ativar jatos de salto como ação rápida para se mover normalmente em zero-g; Selos de vácuo, melhorado",
            name="Armadura de ataque de veneno",
            availability="Militar",
            type="H"
        },
        {
            special="Capacete com capacete pacote; Selos de vácuo, melhorado; Comlink interno, de curto alcance; Capacete pacote; Montagem de arma",
            name="Armadura stormtrooper Zero-g",
            availability="Militar",
            type="H"
        }
    },
    weapons={
        {
            ammo="Célula de Energia",
            damage_type="Abastecimento e energia",
            group="#N/A",
            range="lançado",
            stun="Sim.",
            name="Eletropole",
            special="",
            type="M"
        },
        {
            ammo="Célula de Energia",
            damage_type="Abastecimento e energia",
            group="melee avançado",
            range="",
            stun="Sim.",
            name="Electrostaff",
            special="",
            type="M"
        },
        {
            ammo="Célula de Energia",
            damage_type="Piercing e Energia",
            group="melee avançado",
            range="",
            stun="",
            name="Lança de energia",
            special="Se treinado em Ride, pode empunhar uma mão enquanto montado, caso contrário -1 para atacar",
            type="M"
        },
        {
            ammo="Célula de Energia",
            damage_type="Piercing e Energia",
            group="melee avançado",
            range="",
            stun="Sim.",
            name="Forçar pique",
            special="",
            type="M"
        },
        {
            ammo="Célula de Energia",
            damage_type="Budgeoning",
            group="melee avançado",
            range="",
            stun="",
            name="Martelo de potência",
            special="Dano extra de ataque de energia aplica-se a veículos e objetos",
            type="M"
        },
        {
            ammo="Célula de Energia",
            damage_type="Abastecimento e energia",
            group="melee avançado",
            range="",
            stun="",
            name="Lança de alimentação",
            special="Se treinado em Ride, pode empunhar uma mão enquanto montado, caso contrário -1 para atacar",
            type="M"
        },
        {
            ammo="Célula de Energia",
            damage_type="Energia e espancamento",
            group="melee avançado",
            range="",
            stun="Sim.",
            name="Pessoal de San-ni",
            special="Faça uso do talento Block",
            type="M"
        },
        {
            ammo="",
            damage_type="Energia",
            group="melee avançado",
            range="",
            stun="3d6",
            name="Pau de choque",
            special="pode ser montado como uma baioneta e não é necessário ter feito melee avançado",
            type="M"
        },
        {
            ammo="Célula de Energia",
            damage_type="Budgeoning",
            group="melee avançado",
            range="",
            stun="",
            name="Choque",
            special="May Grab ou Trip, chegar 2, lidar 2d6 danos como rápido contra agarrado",
            type="M"
        },
        {
            ammo="Célula de Energia",
            damage_type="Abastecimento e energia",
            group="melee avançado",
            range="",
            stun="Sim.",
            name="Shockstaff",
            special="Retém DR contra sabres de luz",
            type="M"
        },
        {
            ammo="",
            damage_type="Energia e piercing",
            group="melee avançado",
            range="",
            stun="2d6",
            name="Pique estático",
            special="pode ser lançado como uma lança",
            type="M"
        },
        {
            ammo="Célula de Energia",
            damage_type="Cortar",
            group="melee avançado",
            range="",
            stun="",
            name="Vibro-ax",
            special="",
            type="M"
        },
        {
            ammo="Célula de Energia",
            damage_type="Piercing",
            group="melee avançado",
            range="",
            stun="",
            name="Vibrobayonet",
            special="",
            type="M"
        },
        {
            ammo="Célula de Energia",
            damage_type="Cortar ou perfurar",
            group="melee avançado",
            range="",
            stun="",
            name="Vibroblade",
            special="",
            type="M"
        },
        {
            ammo="Célula de Energia",
            damage_type="Cortar ou perfurar",
            group="melee avançado",
            range="",
            stun="",
            name="Vibroblade, dire",
            special="",
            type="M"
        },
        {
            ammo="Célula de Energia",
            damage_type="Cortar",
            group="melee avançado",
            range="",
            stun="",
            name="Vibroblade, duplo",
            special="",
            type="M"
        },
        {
            ammo="Célula de Energia",
            damage_type="Cortar ou perfurar",
            group="melee avançado",
            range="",
            stun="",
            name="Vibrodagger",
            special="",
            type="M"
        },
        {
            ammo="Célula de Energia",
            damage_type="Cortar",
            group="melee avançado",
            range="",
            stun="",
            name="Vibroknucklers",
            special="",
            type="M"
        },
        {
            ammo="",
            damage_type="Piercing",
            group="melee avançado",
            range="",
            stun="",
            name="Vibrolance",
            special="não pode ser lançado",
            type="M"
        },
        {
            ammo="Célula de Energia",
            damage_type="Cortar",
            group="melee avançado",
            range="",
            stun="",
            name="Vibrorapier",
            special="Operação silenciosa",
            type="M"
        },
        {
            ammo="Célula de Energia",
            damage_type="Cortar ou perfurar",
            group="melee avançado",
            range="",
            stun="",
            name="Vibrosword",
            special="",
            type="M"
        },
        {
            ammo="",
            damage_type="Energia e Corte",
            group="sabres de luz",
            range="",
            stun="",
            name="Guarda Shoto",
            special="Ignorar DR, +2 para bloquear e defletir",
            type="M"
        },
        {
            ammo="Célula de Energia",
            damage_type="Energia e Corte",
            group="sabres de luz",
            range="",
            stun="",
            name="Folha de luz",
            special="",
            type="M"
        },
        {
            ammo="Célula de Energia Especial",
            damage_type="Energia e corte",
            group="sabres de luz",
            range="",
            stun="",
            name="Folha de luz, arcaica",
            special="Trate como pequeno quando benéfico, não pode ser empunhado duas mãos",
            type="M"
        },
        {
            ammo="Célula de Energia Especial",
            damage_type="Energia e Corte",
            group="sabres de luz",
            range="",
            stun="",
            name="Sabre de luz",
            special="Ignorar DR",
            type="M"
        },
        {
            ammo="Célula de Energia Especial",
            damage_type="Energia e Corte",
            group="sabres de luz",
            range="",
            stun="",
            name="Pique de sabre de luz",
            special="",
            type="M"
        },
        {
            ammo="Célula de Energia Especial",
            damage_type="Energia e Corte",
            group="sabres de luz",
            range="",
            stun="",
            name="Pique de sabre de luz",
            special="",
            type="M"
        },
        {
            ammo="Célula de Energia Especial",
            damage_type="Energia e corte",
            group="sabres de luz",
            range="",
            stun="",
            name="Sabre claro, arcaico",
            special="",
            type="M"
        },
        {
            ammo="Célula de Energia Especial",
            damage_type="Energia e corte",
            group="sabres de luz",
            range="",
            stun="",
            name="Sabre claro, guarda cruzada",
            special="Uso do talento do bloco cumulativo -2 em vez de -5, -2 para usar a força para defletir",
            type="M"
        },
        {
            ammo="Célula de Energia Especial",
            damage_type="Energia e Corte",
            group="sabres de luz",
            range="",
            stun="",
            name="Sabre de luz, duplo",
            special="Ignorar DR",
            type="M"
        },
        {
            ammo="Célula de Energia Especial",
            damage_type="Energia e corte",
            group="sabres de luz",
            range="",
            stun="",
            name="Sabre de luz, em fase dupla",
            special="Como Swift ação ganhar chegar 2 mas -2 para Reflex Defesa contra alvos adjacentes",
            type="M"
        },
        {
            ammo="Célula de Energia Especial",
            damage_type="Energia e corte",
            group="sabres de luz",
            range="",
            stun="",
            name="Sabre de luz, variante em fase dupla",
            special="Como interruptor de ação Swift entre cristais sintonizados",
            type="M"
        },
        {
            ammo="Célula de Energia Especial",
            damage_type="Energia e corte",
            group="sabres de luz",
            range="",
            stun="",
            name="Sabres de luz, duelos",
            special="+1 para Ataques de Oportunidade",
            type="M"
        },
        {
            ammo="Célula de Energia Especial",
            damage_type="Energia e corte",
            group="sabres de luz",
            range="",
            stun="",
            name="Sabre de luz, ótimo.",
            special="Não punível para criaturas médias ou menores",
            type="M"
        },
        {
            ammo="Célula de Energia Especial",
            damage_type="Energia e Corte",
            group="sabres de luz",
            range="",
            stun="",
            name="Sabre de luz, curto",
            special="Ignorar DR",
            type="M"
        },
        {
            ammo="Célula de Energia Especial",
            damage_type="Energia e Corte",
            group="sabres de luz",
            range="",
            stun="",
            name="Brilho",
            special="Pino de maio ou viagem, alcance 2",
            type="M"
        },
        {
            ammo="Célula de Energia Especial",
            damage_type="Energia e corte",
            group="sabres de luz",
            range="",
            stun="",
            name="Sabre de luz de mão longa",
            special="Duas mãos esqueceram o bônus de dano para negociar 2d10 em vez",
            type="M"
        },
        {
            ammo="Célula de Energia Especial",
            damage_type="Energia e corte",
            group="sabres de luz",
            range="",
            stun="",
            name="Sabre de luz de mão longa (d10)",
            special="Duas mãos esqueceram o bônus de dano para negociar 2d10 em vez",
            type="M"
        },
        {
            ammo="Célula de Energia Especial",
            damage_type="Energia e corte",
            group="sabres de luz",
            range="",
            stun="",
            name="Sabre de luz de mão longa (haft)",
            special="Duas mãos esqueceram o bônus de dano para negociar 2d10 em vez",
            type="M"
        },
        {
            ammo="Célula de Energia Especial",
            damage_type="Energia e corte",
            group="sabres de luz",
            range="",
            stun="",
            name="Retrosabro",
            special="Como Swift ação negócio 2d10 até o final da próxima rodada, mas 2d4 a seguinte rodada",
            type="M"
        },
        {
            ammo="",
            damage_type="Cortar",
            group="simples",
            range="",
            stun="",
            name="Eixo",
            special="",
            type="M"
        },
        {
            ammo="",
            damage_type="Piercing",
            group="simples",
            range="",
            stun="",
            name="Bayonet",
            special="",
            type="M"
        },
        {
            ammo="",
            damage_type="Budgeoning",
            group="simples",
            range="",
            stun="",
            name="Clube/Baton",
            special="",
            type="M"
        },
        {
            ammo="Célula de Energia",
            damage_type="Budgeoning ou Energia",
            group="simples",
            range="",
            stun="Sim (2d8)",
            name="Paralisador de contacto",
            special="",
            type="M"
        },
        {
            ammo="",
            damage_type="Piercing",
            group="simples",
            range="",
            stun="",
            name="Datadagger",
            special="+5 Furtivo para esconder",
            type="M"
        },
        {
            ammo="",
            damage_type="Cortar ou perfurar",
            group="simples",
            range="",
            stun="",
            name="Ferramenta de entrelaçamento",
            special="- 2 atk",
            type="M"
        },
        {
            ammo="",
            damage_type="Energia e corte",
            group="simples",
            range="",
            stun="",
            name="Lâmina de fogo",
            special="ignora DR de objetos não vigiados",
            type="M"
        },
        {
            ammo="",
            damage_type="Budgeoning e Slashing",
            group="simples",
            range="",
            stun="",
            name="Gaderffii",
            special="",
            type="M"
        },
        {
            ammo="",
            damage_type="Cortar ou perfurar",
            group="simples",
            range="",
            stun="",
            name="Faca",
            special="",
            type="M"
        },
        {
            ammo="",
            damage_type="Budgeoning",
            group="simples",
            range="",
            stun="",
            name="Mace",
            special="",
            type="M"
        },
        {
            ammo="",
            damage_type="Cortar",
            group="simples",
            range="",
            stun="",
            name="Machado de Mitossauro",
            special="",
            type="M"
        },
        {
            ammo="",
            damage_type="Budgeoning",
            group="simples",
            range="",
            stun="",
            name="Quarterstaff",
            special="",
            type="M"
        },
        {
            ammo="",
            damage_type="Cortar ou perfurar",
            group="simples",
            range="",
            stun="",
            name="Espada Sith",
            special="Pode gastar um ponto de força para adicionar Lado Sombrio Score aos danos",
            type="M"
        },
        {
            ammo="",
            damage_type="Budgeoning",
            group="simples",
            range="",
            stun="",
            name="Bastão de encaixe",
            special="",
            type="M"
        },
        {
            ammo="",
            damage_type="Piercing",
            group="simples",
            range="",
            stun="",
            name="Lança",
            special="Pode ser lançado",
            type="M"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="simples",
            range="",
            stun="",
            name="Aríete",
            special="",
            type="M"
        },
        {
            ammo="",
            damage_type="Budgeoning",
            group="simples",
            range="",
            stun="Sim.",
            name="Bastão de choque",
            special="",
            type="M"
        },
        {
            ammo="",
            damage_type="Energia",
            group="simples",
            range="",
            stun="Apenas",
            name="Gauntlet impressionante",
            special="Não pode ser desarmado.",
            type="M"
        },
        {
            ammo="",
            damage_type="Cortar",
            group="simples",
            range="",
            stun="",
            name="Faca de sobrevivência",
            special="",
            type="M"
        },
        {
            ammo="",
            damage_type="Cortar ou perfurar",
            group="simples",
            range="",
            stun="",
            name="Espada, terrível",
            special="",
            type="M"
        },
        {
            ammo="",
            damage_type="Cortar ou perfurar",
            group="simples",
            range="",
            stun="",
            name="Espada, de lâmina dupla",
            special="",
            type="M"
        },
        {
            ammo="",
            damage_type="Cortar ou perfurar",
            group="simples",
            range="",
            stun="",
            name="Espada, curta",
            special="",
            type="M"
        },
        {
            ammo="",
            damage_type="Cortar ou perfurar",
            group="simples",
            range="",
            stun="",
            name="Espada, guerra",
            special="",
            type="M"
        },
        {
            ammo="",
            damage_type="Budgeoning",
            group="simples",
            range="",
            stun="",
            name="Luvas de combate",
            special="Não pode ser desarmado.",
            type="M"
        },
        {
            ammo="",
            damage_type="#N/A",
            group="simples",
            range="",
            stun="",
            name="#N/A",
            special="",
            type="M"
        },
        {
            ammo="",
            damage_type="Budgeoning e energia",
            group="simples",
            range="",
            stun="Sim.",
            name="Luvas para caixas de choque",
            special="definido para atordoar como rápido",
            type="M"
        },
        {
            ammo="",
            damage_type="Budgeoning",
            group="simples",
            range="",
            stun="",
            name="Desarmados",
            special="",
            type="M"
        },
        {
            ammo="",
            damage_type="Energia (ion)",
            group="improvisado",
            range="",
            stun="",
            name="Sonda de electrochoque",
            special="",
            type="M"
        },
        {
            ammo="",
            damage_type="Energia",
            group="improvisado",
            range="",
            stun="",
            name="Cortador de fusão",
            special="",
            type="M"
        },
        {
            ammo="",
            damage_type="Energia",
            group="improvisado",
            range="",
            stun="",
            name="Soldador laser",
            special="",
            type="M"
        },
        {
            ammo="",
            damage_type="Budgeoning",
            group="improvisado",
            range="",
            stun="",
            name="Prybar de potência",
            special="",
            type="M"
        },
        {
            ammo="",
            damage_type="Energia (sónica)",
            group="improvisado",
            range="",
            stun="",
            name="Soldador Sonic",
            special="",
            type="M"
        },
        {
            ammo="",
            damage_type="",
            group="Amphistaff",
            range="",
            stun="",
            name="Amphistaff",
            special="",
            type="M"
        },
        {
            ammo="",
            damage_type="Budgeoning",
            group="Amphistaff",
            range="",
            stun="",
            name="Amphistaff (forma de pessoal de quarto)",
            special="",
            type="M"
        },
        {
            ammo="",
            damage_type="Piercing",
            group="Amphistaff",
            range="",
            stun="",
            name="Amphistaff",
            special="Veneno, pode ser lançado",
            type="M"
        },
        {
            ammo="",
            damage_type="Piercing",
            group="Amphistaff",
            range="",
            stun="",
            name="Amphistaff",
            special="Veneno, Alcance 2 quadrados, Pin ou viagem",
            type="M"
        },
        {
            ammo="",
            damage_type="Cortar",
            group="Arg'garok",
            range="",
            stun="",
            name="Arg'garok",
            special="",
            type="M"
        },
        {
            ammo="",
            damage_type="Budgeoning",
            group="Atlatl",
            range="",
            stun="",
            name="Atlatl",
            special="Pode lançar bolas de energia",
            type="M"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="blastsword",
            range="",
            stun="",
            name="Blastsword",
            special="",
            type="M"
        },
        {
            ammo="",
            damage_type="Budgeoning",
            group="Cesta",
            range="",
            stun="",
            name="Cesta",
            special="Pode lançar bolas de energia",
            type="M"
        },
        {
            ammo="",
            damage_type="Cortar",
            group="Pau Escuro",
            range="",
            stun="",
            name="Pau Escuro",
            special="se empunhar múltiplos pode ser considerado empunhando um para 2d8 represa, se lançado e sobre Ref Def por 5 retorna à mão imediatamente",
            type="M"
        },
        {
            ammo="",
            damage_type="Cortar",
            group="Lâmina de crânio feluciano",
            range="",
            stun="",
            name="Lâmina de crânio feluciano",
            special="",
            type="M"
        },
        {
            ammo="",
            damage_type="Cortar ou perfurar",
            group="Fira",
            range="",
            stun="",
            name="Fira",
            special="",
            type="M"
        },
        {
            ammo="",
            damage_type="Cortar",
            group="Garrote",
            range="",
            stun="Sim.",
            name="Garrote",
            special="",
            type="M"
        },
        {
            ammo="",
            damage_type="Cortar",
            group="Lanvarok, Massassi",
            range="",
            stun="",
            name="Lanvarok, Massassi (melee)",
            special="",
            type="M"
        },
        {
            ammo="Célula de Energia",
            damage_type="Abastecimento e energia",
            group="chicote neurónico",
            range="",
            stun="Apenas",
            name="chicote neurónico",
            special="1 alcance quadrado",
            type="M"
        },
        {
            ammo="",
            damage_type="Cortar",
            group="Lâmina Ryyk",
            range="",
            stun="",
            name="Lâmina Ryyk",
            special="+2 para verificações de sobrevivência para sobrevivência básica na floresta ou selva",
            type="M"
        },
        {
            ammo="",
            damage_type="Cortar ou perfurar",
            group="Shyarn",
            range="",
            stun="",
            name="Shyarn",
            special="Sem penalidade para a greve rápida",
            type="M"
        },
        {
            ammo="Célula de Energia",
            damage_type="Perfuração e corte",
            group="Lâmina Tehk'la",
            range="",
            stun="",
            name="Lâmina Tehk'la",
            special="Deal +1d6 início de dano da próxima rodada se o ataque também bater Fort defesa",
            type="M"
        },
        {
            ammo="Célula de Energia",
            damage_type="Cortar",
            group="vibro-saw",
            range="",
            stun="",
            name="Vibro-saw",
            special="Ignora o DR",
            type="M"
        },
        {
            ammo="",
            damage_type="Cortar e espancar",
            group="Wan-shen",
            range="",
            stun="",
            name="Wan-shen",
            special="Alcançar 2",
            type="M"
        },
        {
            ammo="",
            damage_type="Cortar",
            group="Zhaboka",
            range="",
            stun="",
            name="Zhaboka",
            special="Sem penalidade para a greve rápida",
            type="M"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="pesado",
            range="pesado",
            stun="",
            name="Canhão Blaster",
            special="Efeito da área",
            type="R"
        },
        {
            ammo="20",
            damage_type="Energia",
            group="pesado",
            range="",
            stun="",
            name="Canhão de explosão, rotativo",
            special="pode atingir uma área de 2x4, se não for com suporte adicional -5 atk com penalidades normais",
            type="R"
        },
        {
            ammo="Gerador de energia",
            damage_type="Energia",
            group="pesado",
            range="pesado",
            stun="",
            name="Blaster, E-web repetindo",
            special="Arma da tripulação, Tripod.",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="pesado",
            range="pesado",
            stun="",
            name="Blaster, repetição pesada",
            special="Gerador opcional",
            type="R"
        },
        {
            ammo="Cartidge de Carbonita",
            damage_type="Energia",
            group="pesado",
            range="pesado",
            stun="Apenas",
            name="Espingarda carbonita",
            special="Imobilização",
            type="R"
        },
        {
            ammo="",
            damage_type="",
            group="pesado",
            range="pesado",
            stun="3d8",
            name="Electronet",
            special="",
            type="R"
        },
        {
            ammo="20",
            damage_type="Fogo",
            group="pesado",
            range="",
            stun="",
            name="Canhão de Chamas",
            special="cone 12sq longo x 8sq largo, meia represa na falha, rodada completa para recarga, tanques pesam 20 kg",
            type="R"
        },
        {
            ammo="Granada, frag",
            damage_type="Cortar",
            group="pesado",
            range="pesado",
            stun="",
            name="Lançador de granadas",
            special="Explosão 2-quadrado",
            type="R"
        },
        {
            ammo="Mísseis anti- blindados",
            damage_type="Energia",
            group="pesado",
            range="pesado",
            stun="",
            name="Lançador de projéteis HH-15",
            special="1-espilho quadrado, penetração 10",
            type="R"
        },
        {
            ammo="Míssil de concussão leve",
            damage_type="Cortar",
            group="pesado",
            range="pesado",
            stun="",
            name="Lançador de mísseis de concussão leve",
            special="Salpico 2-quadrado",
            type="R"
        },
        {
            ammo="",
            damage_type="Energia",
            group="pesado",
            range="pesado",
            stun="",
            name="Merr- Sonn PLX-2M",
            special="Raio de explosão 3-quadrado, modo de procura",
            type="R"
        },
        {
            ammo="Torpedo mini-próton",
            damage_type="Energia",
            group="pesado",
            range="pesado",
            stun="",
            name="Mini-proton lança torpedos",
            special="Raio de explosão 2-quadrado ou modo alvo único",
            type="R"
        },
        {
            ammo="Revista",
            damage_type="golpeamento",
            group="pesado",
            range="pesado",
            stun="",
            name="Lançador de mísseis",
            special="Efeito da área",
            type="R"
        },
        {
            ammo="Mísseis",
            damage_type="golpeamento",
            group="pesado",
            range="pesado",
            stun="",
            name="Lançador de mísseis, E-web",
            special="Efeito da área",
            type="R"
        },
        {
            ammo="",
            damage_type="Cortar",
            group="pesado",
            range="",
            stun="",
            name="Lançador de morteiros",
            special="Arco, não pode ser usado em PB, tratar arma como sendo 20sq no ar para LOS & cobertura, conchas idênticas a granadas",
            type="R"
        },
        {
            ammo="",
            damage_type="Energia",
            group="pesado",
            range="",
            stun="",
            name="Raio tractor táctico",
            special="se em tripé tratar como um tamanho menor, só pode afetar Enorme ou menor, pode mover 10sq ou lançar 10sq (alvo leva represa = tamanho do objeto lançado CR 254), 2o membro da tripulação stan para regular a potência ou -2 atk",
            type="R"
        },
        {
            ammo="50",
            damage_type="Energia",
            group="pistolas",
            range="",
            stun="3d8",
            name="Arma de Ascensão",
            special="swif para alternar modos, spd 12 sq para cima como tirar vertical ou zipline, elevador 720 kg, na faixa de modo de ascensão é 30sq, -5 Stealth para ocultar, 2 usos de sintetizador",
            type="R"
        },
        {
            ammo="Tiro de Pistola de Pó Negro",
            damage_type="Piercing",
            group="pistolas",
            range="pistolas",
            stun="",
            name="Pistola de pólvora negra",
            special="Ação completa para recarregar",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="pistolas",
            range="pistolas",
            stun="Sim.",
            name="BlasTech DH-23",
            special="",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="pistolas",
            range="pistolas",
            stun="Sim.",
            name="BlasTech DT-12",
            special="",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="pistolas",
            range="pistolas",
            stun="Sim.",
            name="Pistola Blaster",
            special="",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="pistolas",
            range="pistolas",
            stun="Sim.",
            name="Pistola de explosão, parafuso azul",
            special="Pode atordoar de 8 quadrados, mas usa duas cargas",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="pistolas",
            range="pistolas",
            stun="Sim.",
            name="Pistola Blaster, pesada",
            special="",
            type="R"
        },
        {
            ammo="Célula de Energia",
            damage_type="Energia",
            group="pistolas",
            range="pistolas",
            stun="",
            name="Pistola Blaster, espera.",
            special="+5 Furtivo para esconder",
            type="R"
        },
        {
            ammo="250",
            damage_type="Energia",
            group="pistolas",
            range="",
            stun="3d6",
            name="Pistola Blaster, arma lateral",
            special="deve reiniciar gatilho como swif se usar tiro rápido",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="pistolas",
            range="pistolas",
            stun="",
            name="Pistola Blaster, tiro rápido",
            special="+5 a verificações furtivas para ocultar",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="pistolas",
            range="pistolas",
            stun="Sim.",
            name="Pistola blaster, desportiva",
            special="",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="pistolas",
            range="pistolas",
            stun="Sim.",
            name="Pistola Blaster, Theed Arms S-5",
            special="Inbuit Ascension Gun e lança dardos",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="pistolas",
            range="pistolas",
            stun="",
            name="Blaster, sub-repetindo",
            special="",
            type="R"
        },
        {
            ammo="Célula de Energia",
            damage_type="Energia",
            group="pistolas",
            range="pistolas",
            stun="",
            name="Blaster, pulso",
            special="",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="pistolas",
            range="pistolas",
            stun="",
            name="Pistola Bryar",
            special="",
            type="R"
        },
        {
            ammo="10",
            damage_type="Piercing",
            group="simples",
            range="",
            stun="",
            name="Arco, repetindo",
            special="",
            type="R"
        },
        {
            ammo="Pistola Clip",
            damage_type="Piercing",
            group="pistolas",
            range="pistolas",
            stun="",
            name="Czerka Adjudicator",
            special="",
            type="R"
        },
        {
            ammo="Dardo",
            damage_type="Piercing",
            group="pistolas",
            range="pistolas",
            stun="",
            name="Darter",
            special="Pode entregar venenos.",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="pistolas",
            range="pistolas",
            stun="",
            name="Pistola de disruptor DX-2",
            special="Trata o limiar de dano do alvo como 5 pontos mais baixo",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="pistolas",
            range="pistolas",
            stun="",
            name="Defensor Gee-Tech 12",
            special="",
            type="R"
        },
        {
            ammo="Clip de munição",
            damage_type="Piercing",
            group="pistolas",
            range="pistolas",
            stun="",
            name="Pistola de tiro pesado",
            special="-1 penalidade para atacar com Ataque Duplo, Ataque Triplo ou Tiro Rápido",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia (ion)",
            group="pistolas",
            range="pistolas",
            stun="",
            name="Pistola de iões",
            special="Meio dano a não-dróides",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="pistolas",
            range="pistolas",
            stun="Sim.",
            name="Merr-Sonn Model 434",
            special="",
            type="R"
        },
        {
            ammo="Clip de munição",
            damage_type="Piercing",
            group="pistolas",
            range="pistolas",
            stun="",
            name="Agulha",
            special="",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="pistolas",
            range="pistolas",
            stun="",
            name="Pistola de onda de impulso",
            special="+4 danos à queima-roupa",
            type="R"
        },
        {
            ammo="Clip de munição",
            damage_type="Cortar",
            group="pistolas",
            range="pistolas",
            stun="",
            name="Estripador",
            special="Derrama danos 1d4 quando excede o limiar de dano",
            type="R"
        },
        {
            ammo="Pistola Clip",
            damage_type="Piercing",
            group="pistolas",
            range="pistolas",
            stun="",
            name="Pistola de lança-lemas",
            special="",
            type="R"
        },
        {
            ammo="Cartucho de Pistola",
            damage_type="Budgeoning",
            group="pistolas",
            range="pistolas",
            stun="Sim (1d4",
            name="Pistola de raspão",
            special="Pode agarrar, Pin e viagem",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia (sónica)",
            group="pistolas",
            range="pistolas",
            stun="",
            name="Disruptor Sonic",
            special="Incêndios uma vez por rodada, não podem ser desviados",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia (sónica)",
            group="pistolas",
            range="pistolas",
            stun="",
            name="Pistola sónica",
            special="Não é possível desviar",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia (sónica)",
            group="pistolas",
            range="pistolas",
            stun="",
            name="Pistola Sonic, pesada",
            special="Não é possível desviar",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia (sónica)",
            group="pistolas",
            range="pistolas",
            stun="Apenas",
            name="Stonner Sonic",
            special="",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="pistolas",
            range="especial",
            stun="Sim (3d6)",
            name="Pistola de choque",
            special="Intervalo de 20 quadrados",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="espingardas",
            range="espingardas",
            stun="Sim.",
            name="BlasTech 500 \"ESPO\"",
            special="-2 penalização quando usado em modo single-shot",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="espingardas",
            range="espingardas",
            stun="Sim.",
            name="Blastech 500 arma de choque",
            special="-1 para atacar em modo de tiro único, +2 com auto-fogo",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="espingardas",
            range="espingardas",
            stun="",
            name="BlasTech DLT-20A",
            special="",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="espingardas",
            range="espingardas",
            stun="Sim.",
            name="Blaster carbina",
            special="",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="espingardas",
            range="espingardas",
            stun="Sim.",
            name="Carbina Blaster (sem reservas)",
            special="Nenhuma unidade populacional retrátil",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="espingardas",
            range="espingardas",
            stun="Sim.",
            name="Carbina de blaster, de cano duplo",
            special="Modo de disparo duplo (automático) com ação rápida",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="espingardas",
            range="espingardas",
            stun="Sim.",
            name="Blaster carabina, caça",
            special="Distribui d10s em um crítico",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="espingardas",
            range="espingardas",
            stun="Sim.",
            name="Blaster carbina, repetição",
            special="",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="espingardas",
            range="espingardas",
            stun="Sim.",
            name="Carabina Blaster, desportiva",
            special="Não tratada como imprecisa quando empunhada com duas mãos",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="espingardas",
            range="espingardas",
            stun="Sim.",
            name="Espingarda Blaster",
            special="",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="espingardas",
            range="espingardas",
            stun="Sim.",
            name="Arma de fogo (sem armação)",
            special="Nenhuma unidade populacional retrátil",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="espingardas",
            range="espingardas",
            stun="Sim.",
            name="Fuzil Blaster, assalto",
            special="",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="espingardas",
            range="espingardas",
            stun="",
            name="rifle Blaster, comando especial",
            special="",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="espingardas",
            range="espingardas",
            stun="Sim.",
            name="Fuzil Blaster, pesado",
            special="",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="espingardas",
            range="espingardas",
            stun="",
            name="Artilheiro Blaster, assalto pesado",
            special="Distribui d12s em um hit crítico",
            type="R"
        },
        {
            ammo="500",
            damage_type="Energia",
            group="espingardas",
            range="",
            stun="3d6",
            name="Fuzil Blaster, variável pesada",
            special="3d8 dam x10 shots, 3d10 dam x 20 shots, swif para alternar modos, spd 12 sq para cima como tira vertical ou zipline, elevador 720 kg, na faixa de modo de ascensão é 30sq, -5 Stealth para ocultar, 2 usos de synthrope",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="espingardas",
            range="espingardas",
            stun="",
            name="Fuzil Blaster, atirador.",
            special="",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="espingardas",
            range="espingardas",
            stun="",
            name="Fuzil de tiro, sniper (SaV)",
            special="",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="espingardas",
            range="espingardas",
            stun="Sim.",
            name="Arma de fogo, de desporto",
            special="",
            type="R"
        },
        {
            ammo="500",
            damage_type="Energia",
            group="espingardas",
            range="",
            stun="3d4",
            name="Fuzileiro de blaster, variável",
            special="3d6 dam x5 shots, 3d8 dam x10 shots",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="espingardas",
            range="espingardas",
            stun="",
            name="Blaster, repetição de luz",
            special="",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="espingardas",
            range="espingardas",
            stun="",
            name="Fuzileiro Bryar",
            special="",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia (sónica)",
            group="espingardas",
            range="espingardas",
            stun="",
            name="Fuzileiro de concussão",
            special="Ataque vs. fortaleza para bater propensa",
            type="R"
        },
        {
            ammo="Clip do rifle",
            damage_type="Piercing",
            group="espingardas",
            range="espingardas",
            stun="",
            name="Czerka Adventurer",
            special="",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="espingardas",
            range="espingardas",
            stun="",
            name="DC-19 \"Stealth\" Carbina",
            special="Operação silenciosa, modo de tiro invisível (10 tiros)",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="espingardas",
            range="espingardas",
            stun="",
            name="rifle disruptor DXR-6",
            special="Trata o limiar de dano do alvo como 5 pontos mais baixo",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Piercing e Energia",
            group="espingardas",
            range="espingardas",
            stun="",
            name="Lança de energia (parafuso de plasma)",
            special="Se treinado em Ride, pode empunhar uma mão enquanto montado, caso contrário -1 para atacar",
            type="R"
        },
        {
            ammo="Flechette Cluster",
            damage_type="Piercing",
            group="espingardas",
            range="espingardas",
            stun="",
            name="Lançador Flechette",
            special="Salpico 1-quadrado",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="espingardas",
            range="espingardas",
            stun="",
            name="Fuzileiro incinerador",
            special="",
            type="R"
        },
        {
            ammo="",
            damage_type="Energia",
            group="espingardas",
            range="",
            stun="3d8",
            name="Sistema de Armas Intermutáveis",
            special="mudar tipos de armas como stan",
            type="R"
        },
        {
            ammo="1",
            damage_type="Cortar",
            group="espingardas",
            range="",
            stun="",
            name="Sistema de armas intercambiáveis, anti-armamento",
            special="lança granada w/3-sq explosão e tratar como arma pesada",
            type="R"
        },
        {
            ammo="",
            damage_type="Energia",
            group="espingardas",
            range="",
            stun="",
            name="Sistema de Armas Intermutáveis, Atirador",
            special="inclui o âmbito de referência, -2 no PB não modificado",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia (ion)",
            group="espingardas",
            range="espingardas",
            stun="",
            name="Carbina iónica",
            special="",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia (ion)",
            group="espingardas",
            range="espingardas",
            stun="",
            name="Fuzil de iões",
            special="Meio dano a não-dróides",
            type="R"
        },
        {
            ammo="Micro Granada",
            damage_type="",
            group="espingardas",
            range="espingardas",
            stun="",
            name="Lança-granadas micro",
            special="Explosão 2-quadrado",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="espingardas",
            range="espingardas",
            stun="",
            name="Espingarda de onda de pulso",
            special="+5 danos à queima roupa",
            type="R"
        },
        {
            ammo="Canister Explosivo Especial",
            damage_type="Piercing",
            group="espingardas",
            range="espingardas",
            stun="",
            name="Arma de detonador de caminho-de-ferro",
            special="Salpico 1-quadrado",
            type="R"
        },
        {
            ammo="10",
            damage_type="Piercing",
            group="espingardas",
            range="",
            stun="",
            name="Arma de dispersão",
            special="3d8 barragem PB, 2d8 curta, nenhuma gama @ M ou L, conchas pesam 0,1 kg",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="espingardas",
            range="espingardas",
            stun="2d8",
            name="Espingarda de jacto SG-4",
            special="Meio intervalo em água",
            type="R"
        },
        {
            ammo="Arpão",
            damage_type="Piercing",
            group="espingardas",
            range="espingardas",
            stun="",
            name="Espingarda de jacto SG-4 (submarina)",
            special="Meio intervalo fora de água",
            type="R"
        },
        {
            ammo="Clip do rifle",
            damage_type="Energia",
            group="espingardas",
            range="espingardas",
            stun="",
            name="Espingarda",
            special="",
            type="R"
        },
        {
            ammo="Cartucho",
            damage_type="Budgeoning",
            group="espingardas",
            range="espingardas",
            stun="1d6",
            name="Espingarda",
            special="",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia (sónica)",
            group="espingardas",
            range="espingardas",
            stun="",
            name="Fuzil sônico",
            special="Não é possível desviar",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="espingardas",
            range="espingardas",
            stun="4d6",
            name="SoroSuub Firelance",
            special="",
            type="R"
        },
        {
            ammo="Caixa de Spraymist",
            damage_type="Energia",
            group="espingardas",
            range="espingardas",
            stun="Apenas",
            name="Pinça de pulverização Stokhli",
            special="Pode agarrar ou agarrar",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="espingardas",
            range="espingardas",
            stun="",
            name="Explosor subrepeante",
            special="",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="espingardas",
            range="espingardas",
            stun="Sim.",
            name="Espingarda mirante",
            special="Aumenta d6s para d8s ao apontar",
            type="R"
        },
        {
            ammo="Quiver",
            damage_type="Piercing",
            group="simples",
            range="simples",
            stun="",
            name="Arco",
            special="",
            type="R"
        },
        {
            ammo="Parafusos de arco",
            damage_type="Piercing",
            group="simples",
            range="pistolas",
            stun="",
            name="Arco",
            special="",
            type="R"
        },
        {
            ammo="",
            damage_type="Energia",
            group="simples",
            range="simples",
            stun="",
            name="Bola energética",
            special="",
            type="R"
        },
        {
            ammo="",
            damage_type="Energia",
            group="simples",
            range="lançado",
            stun="",
            name="Granada, adesivo",
            special="Imobilização",
            type="R"
        },
        {
            ammo="",
            damage_type="Budgeoning",
            group="simples",
            range="simples",
            stun="",
            name="Granada, concussão",
            special="Raio de explosão 2-quadrado",
            type="R"
        },
        {
            ammo="",
            damage_type="Energia",
            group="simples",
            range="lançado",
            stun="",
            name="Granada, Cryoban",
            special="Reduz a velocidade",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia (ion)",
            group="simples",
            range="lançado",
            stun="",
            name="Granada, PEM",
            special="Explosão 2-quadrado",
            type="R"
        },
        {
            ammo="",
            damage_type="Cortar",
            group="simples",
            range="lançado",
            stun="",
            name="Granada, frag",
            special="2 furos quadrados",
            type="R"
        },
        {
            ammo="",
            damage_type="",
            group="simples",
            range="simples",
            stun="",
            name="Granada, gás",
            special="Raio de explosão 4-quadrado",
            type="R"
        },
        {
            ammo="",
            damage_type="Energia (ion)",
            group="simples",
            range="lançado",
            stun="",
            name="Granada, íon",
            special="2 furos quadrados",
            type="R"
        },
        {
            ammo="",
            damage_type="Energia",
            group="simples",
            range="",
            stun="",
            name="Granada, radiação",
            special="atk v. Fort Def, meia barragem sobre a falha e efeitos da exposição moderada à radiação (CR 255-256)",
            type="R"
        },
        {
            ammo="",
            damage_type="Energia",
            group="simples",
            range="lançado",
            stun="",
            name="Granada, remota",
            special="Detonado remotamente, recursos de segurança",
            type="R"
        },
        {
            ammo="",
            damage_type="",
            group="simples",
            range="",
            stun="",
            name="Granada, fumo",
            special="fornece ocultação e cria um risco de fumaça para 10 rodadas (CR 256)",
            type="R"
        },
        {
            ammo="",
            damage_type="Energia",
            group="simples",
            range="lançado",
            stun="Apenas",
            name="Granada, atordoamento",
            special="2 furos quadrados",
            type="R"
        },
        {
            ammo="",
            damage_type="",
            group="simples",
            range="simples",
            stun="",
            name="Rede",
            special="Pode agarrar ou agarrar",
            type="R"
        },
        {
            ammo="",
            damage_type="Energia",
            group="simples",
            range="simples",
            stun="",
            name="Caixa flash R-9",
            special="",
            type="R"
        },
        {
            ammo="",
            damage_type="Cortar",
            group="simples",
            range="lançado",
            stun="",
            name="Erro na Navalha",
            special="Tratado como uma arma simples para determinar o alcance",
            type="R"
        },
        {
            ammo="",
            damage_type="Budgeoning",
            group="simples",
            range="simples",
            stun="",
            name="Sling",
            special="",
            type="R"
        },
        {
            ammo="",
            damage_type="Energia",
            group="simples",
            range="",
            stun="",
            name="Laser de mira",
            special="atk roll ignora bônus de armadura do alvo para Ref Def, aliados ganham +2 atk com lança mísseis ou granadas ou arma de veículo",
            type="R"
        },
        {
            ammo="",
            damage_type="Energia",
            group="simples",
            range="lançado",
            stun="",
            name="Detonador térmico",
            special="4 rajada quadrada",
            type="R"
        },
        {
            ammo="",
            damage_type="Budgeoning",
            group="simples",
            range="lançado",
            stun="Sim.",
            name="Erro Thud",
            special="Tratado como uma arma simples para determinar o alcance, atordoado até curto alcance",
            type="R"
        },
        {
            ammo="",
            damage_type="Especial",
            group="Amphistaff",
            range="pistolas",
            stun="",
            name="Amphistaff (pit)",
            special="Veneno",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia (sónica)",
            group="Blaster aurial",
            range="pistolas",
            stun="",
            name="Blaster aurial",
            special="Percepção de Danos",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="canhão de explosão",
            range="armas pesadas",
            stun="",
            name="Canhão de explosão",
            special="+1d8 danos adjacentes, 1-quadrado respingo não adjacente",
            type="R"
        },
        {
            ammo="Quiver Bowcaster",
            damage_type="Energia e perfuração",
            group="bowcaster",
            range="espingardas",
            stun="",
            name="Bowcaster",
            special="",
            type="R"
        },
        {
            ammo="Dardo",
            damage_type="Piercing",
            group="lançador de dardos oculto",
            range="pistolas",
            stun="Sim (3d8)",
            name="Lançador de dardos escondido",
            special="+5 a verificações furtivas para ocultar",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="Varredor de convés",
            range="pistolas",
            stun="3d6",
            name="Varredor de convés",
            special="",
            type="R"
        },
        {
            ammo="",
            damage_type="Cortar",
            group="Discblade",
            range="",
            stun="",
            name="Discblade",
            special="",
            type="R"
        },
        {
            ammo="Cartucho químico",
            damage_type="Fogo",
            group="Lança-chamas",
            range="especial",
            stun="",
            name="Lança-chamas",
            special="Área (6 cone quadrado)",
            type="R"
        },
        {
            ammo="Disco",
            damage_type="Budgeoning",
            group="Lanvarok, Massassi",
            range="simples",
            stun="",
            name="Lanvarok, Massassi (disc)",
            special="",
            type="R"
        },
        {
            ammo="Disco",
            damage_type="Budgeoning",
            group="Lanvarok, Sith",
            range="simples",
            stun="",
            name="Lanvarok, Sith",
            special="",
            type="R"
        },
        {
            ammo="Parafusos Magna Caster",
            damage_type="Piercing",
            group="Roda Magna",
            range="pistolas",
            stun="",
            name="Roda Magna",
            special="Silencioso",
            type="R"
        },
        {
            ammo="",
            damage_type="Piercing",
            group="Inibidor neural",
            range="pistolas",
            stun="",
            name="Inibidor neural",
            special="",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="Fuzil de pulso",
            range="espingardas",
            stun="",
            name="Fuzil de pulso",
            special="6-square burst, falta causa metade de dano",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="Lança Siang",
            range="espingardas",
            stun="Sim.",
            name="Lança Siang",
            special="",
            type="R"
        },
        {
            ammo="Pacote de Energia",
            damage_type="Energia",
            group="Fuzil tensor Squib",
            range="espingardas",
            stun="",
            name="Fuzil tensor Squib",
            special="Ataque vs. Força para mover - 1 passo",
            type="R"
        },
        {
            ammo="Clip de arma de raspar Verpine",
            damage_type="Energia",
            group="Arma de estilhaços verpínicos",
            range="pistolas",
            stun="",
            name="Arma de estilhaços verpínicos",
            special="+1d10 em crítico, desativado se danificado",
            type="R"
        },
        {
            ammo="",
            damage_type="Budgeoning",
            group="Lança-foguetes de pulso",
            range="pistolas",
            stun="",
            name="Lança-foguetes de pulso",
            special="",
            type="R"
        },
        {
            ammo="Caixa de gás Xerrol Nightstinger",
            damage_type="Energia",
            group="Xerrol nighttinger",
            range="espingardas",
            stun="",
            name="Xerrol nighttinger",
            special="Disparar tiros invisíveis",
            type="R"
        },
        {
            ammo="",
            damage_type="",
            group="",
            range="",
            stun="",
            name="Mina, antiveículo",
            special="",
            type=""
        },
        {
            ammo="",
            damage_type="",
            group="",
            range="",
            stun="",
            name="Mina, protão antiveículo",
            special="",
            type=""
        },
        {
            ammo="",
            damage_type="",
            group="",
            range="",
            stun="",
            name="Meu, Flechette",
            special="",
            type=""
        },
        {
            ammo="",
            damage_type="",
            group="",
            range="",
            stun="",
            name="Mina, antipessoal HX2",
            special="",
            type=""
        },
        {
            ammo="",
            damage_type="",
            group="",
            range="",
            stun="",
            name="Mina, terra",
            special="",
            type=""
        },
        {
            ammo="",
            damage_type="golpeamento",
            group="",
            range="",
            stun="",
            name="Mina, viagem a laser",
            special="",
            type=""
        },
        {
            ammo="",
            damage_type="golpeamento",
            group="",
            range="",
            stun="",
            name="Mina, proximidade",
            special="",
            type=""
        },
        {
            ammo="0",
            damage_type="",
            group="simples",
            range="",
            stun="",
            name="Personalizado 1",
            special="",
            type="M"
        },
        {
            ammo="0",
            damage_type="",
            group="simples",
            range="",
            stun="",
            name="Personalizado 2",
            special="",
            type="M"
        },
        {
            ammo="0",
            damage_type="",
            group="simples",
            range="",
            stun="",
            name="Personalizado 3",
            special="",
            type="M"
        },
        {
            ammo="0",
            damage_type="",
            group="simples",
            range="",
            stun="",
            name="Personalizado 4",
            special="",
            type="M"
        },
        {
            ammo="0",
            damage_type="",
            group="simples",
            range="",
            stun="",
            name="Personalizado 5",
            special="",
            type="M"
        },
        {
            ammo="0",
            damage_type="",
            group="simples",
            range="",
            stun="",
            name="Personalizado 6",
            special="",
            type="M"
        }
    },
    ammo={
        {
            name="Clip de munição",
            singular="clipe de munição",
            plural="clips de munição"
        },
        {
            name="Mísseis anti- blindados",
            singular="míssil anti-armamento",
            plural="mísseis anti-armamento"
        },
        {
            name="Quiver Bowcaster",
            singular="bowcaster treme",
            plural="bowcaster treme"
        },
        {
            name="Cartucho de Carbonita",
            singular="cartucho de carbonita",
            plural="cartuchos de carbonita"
        },
        {
            name="Cartucho químico",
            singular="cartucho químico",
            plural="cartuchos químicos"
        },
        {
            name="Célula de Energia",
            singular="célula de energia",
            plural="Células energéticas"
        },
        {
            name="Flechette Cluster",
            singular="cluster flechette",
            plural="grupos flechette"
        },
        {
            name="Granada, frag",
            singular="granada frag",
            plural="granadas frag"
        },
        {
            name="Granada, íon",
            singular="granada de íon",
            plural="granadas de íon"
        },
        {
            name="Granada, atordoamento",
            singular="grânulos de atordoamento",
            plural="granadas de atordoamento"
        },
        {
            name="Míssil de concussão leve",
            singular="míssil de concussão leve",
            plural="mísseis de concussão leve"
        },
        {
            name="Revista",
            singular="revista",
            plural="revistas"
        },
        {
            name="Mísseis",
            singular="míssil",
            plural="mísseis"
        },
        {
            name="Pistola Clip",
            singular="pistoleiro",
            plural="Pistolas"
        },
        {
            name="Gerador de energia",
            singular="gerador de energia",
            plural="geradores de energia"
        },
        {
            name="Pacote de Energia",
            singular="pacote de energia",
            plural="pacotes de energia"
        },
        {
            name="Quiver",
            singular="tremor",
            plural="tremores"
        },
        {
            name="Clip do rifle",
            singular="clipe de rifle",
            plural="clipes de espingardas"
        },
        {
            name="Célula de Energia Especial",
            singular="célula de energia especial",
            plural="células de energia especiais"
        },
        {
            name="Canister Explosivo Especial",
            singular="recipiente explosivo especial",
            plural="recipientes explosivos especiais"
        },
        {
            name="Caixa de Spraymist",
            singular="frasco pulverizador",
            plural="latas pulverizadoras"
        }
    },
    equipment={
        {
            category="d",
            name="Pacote médico 8-2A",
            singular="Pacote médico 8-2A",
            plural="8-2A pacotes médicos"
        },
        {
            category="t",
            name="Comutador ABC",
            singular="Comutador ABC",
            plural="Comutadores ABC"
        },
        {
            category="d",
            name="Invólucro de temperatura total",
            singular="manto de todas as temperaturas",
            plural="Capas de proteção antitemperatura"
        },
        {
            category="f",
            name="Amplificador auricular ambiente",
            singular="amplificador aural ambiente",
            plural="amplificadores auriculares ambiente"
        },
        {
            category="d",
            name="Camisas Jedi antigas",
            singular="vestes Jedi antigos",
            plural="vestes Jedi antigos"
        },
        {
            category="d",
            name="Antigos mantos Sith",
            singular="vestes Sith antigas",
            plural="vestes Sith antigas"
        },
        {
            category="f",
            name="Sintetizador antidoto",
            singular="sintetizador antídoto",
            plural="sintetizadores de antídotos"
        },
        {
            category="d",
            name="Máscara antiox para respiração",
            singular="máscara de respiração antiox",
            plural="máscaras de respiração antiox"
        },
        {
            category="f",
            name="Dose anti-rad",
            singular="dose anti-rad",
            plural="doses de anti-rad"
        },
        {
            category="f",
            name="Lâminas anti-segurança",
            singular="Lâmina anti-segurança",
            plural="Lâminas anti-segurança"
        },
        {
            category="f",
            name="Antitoxina",
            singular="adesivo antitoxina",
            plural="adesivos antitoxina"
        },
        {
            category="f",
            name="Respirador Aquata",
            singular="aquata respirador",
            plural="respiradores de água"
        },
        {
            category="f",
            name="Gravador de áudio",
            singular="gravador de áudio",
            plural="gravadores de áudio"
        },
        {
            category="f",
            name="Amplificador auricular",
            singular="amplificador auricular",
            plural="amplificadores auriculares"
        },
        {
            category="l",
            name="Tanque de Bacta (vazio)",
            singular="tanque bacta",
            plural="tanques bacta"
        },
        {
            category="t",
            name="Bacta, 1 litro",
            singular="litro de bacta",
            plural="litros de bacta"
        },
        {
            category="t",
            name="Bandolier",
            singular="bandolier",
            plural="bandoliers"
        },
        {
            category="f",
            name="Algemas",
            singular="Algemas",
            plural="Algemas"
        },
        {
            category="f",
            name="Bioscanner",
            singular="bioscanner",
            plural="bioscanners"
        },
        {
            category="f",
            name="Implante bioestabilizador",
            singular="implante bioestabilizador",
            plural="implantes bioestabilizadores"
        },
        {
            category="d",
            name="Kit de ferramentas Biotech",
            singular="Kit de ferramentas biotecnológicas",
            plural="Kits de ferramentas biotecnológicas"
        },
        {
            category="d",
            name="Camisas pretas",
            singular="robes pretos",
            plural="robes pretos"
        },
        {
            category="f",
            name="Computador Bracer",
            singular="computador bracer",
            plural="computadores brasser"
        },
        {
            category="t",
            name="Máscara de respiração",
            singular="máscara respiratória",
            plural="máscaras de respiração"
        },
        {
            category="d",
            name="Caixa de atmosfera da máscara respiratória/filtro",
            singular="recipiente de atmosfera",
            plural="recipientes de atmosfera"
        },
        {
            category="s",
            name="Rede de camoflagem",
            singular="rede de camuflagem",
            plural="Redes de camoflagem"
        },
        {
            category="d",
            name="Camoflage poncho",
            singular="camoflage poncho",
            plural="ponchos de camuflagem"
        },
        {
            category="s",
            name="Redes de camuflagem",
            singular="Rede de camuflagem",
            plural="Redes de camuflagem"
        },
        {
            category="f",
            name="Implante cardiológico",
            singular="implante cardiológico",
            plural="implantes cardiológicos"
        },
        {
            category="t",
            name="Máscara de morte de Hendanyn Cerimonial",
            singular="máscara de morte Hendanyn cerimonial",
            plural="máscaras cerimoniais Hendanyn morte"
        },
        {
            category="t",
            name="Corrente (3 metros)",
            singular="cadeia",
            plural="cadeias"
        },
        {
            category="f",
            name="Arreios de escalada",
            singular="arnês de escalada",
            plural="arreios de escalada"
        },
        {
            category="f",
            name="Cilindro de código",
            singular="cilindro de código",
            plural="cilindros de código"
        },
        {
            category="s",
            name="Com embaralhador",
            singular="com misturador",
            plural="Comutadores"
        },
        {
            category="f",
            name="Implante de combate",
            singular="implante de combate",
            plural="Implantes de combate"
        },
        {
            category="f",
            name="Comlink, fone de ouvido",
            singular="comlink, fone de ouvido",
            plural="comlink, fones de ouvido"
        },
        {
            category="d",
            name="Comlink, encriptado de longo alcance",
            singular="comunicação de longo alcance criptografada",
            plural="comunicações de longo alcance criptografadas"
        },
        {
            category="d",
            name="Comlink, holo de longo alcance criptografado",
            singular="comunicação de longo alcance criptografada com capacidade holo",
            plural="comunicações de longo alcance criptografadas com recursos holo"
        },
        {
            category="d",
            name="Comlink, vídeo criptografado de longo alcance",
            singular="comunicação de longo alcance criptografada com capacidade de vídeo",
            plural="comunicações de longo alcance criptografadas com recursos de vídeo"
        },
        {
            category="f",
            name="Comlink, miniaturizado criptografado de longo alcance",
            singular="comlink criptografado (miniaturizado)",
            plural="comunicações criptografadas (miniaturizadas)"
        },
        {
            category="f",
            name="Holo de longo alcance criptografado",
            singular="comlink criptografado (miniaturizado) com capacidade holo",
            plural="comlinks criptografados (miniaturizados) com recursos holo"
        },
        {
            category="f",
            name="Comlink, vídeo criptografado miniaturizado de longo alcance",
            singular="comlink criptografado (miniaturizado) com capacidade de vídeo",
            plural="comunicações criptografadas (miniaturizadas) com capacidades de vídeo"
        },
        {
            category="f",
            name="Comlink, curto alcance criptografado",
            singular="comlink criptografado",
            plural="comunicações criptografadas"
        },
        {
            category="f",
            name="Comlink, holo de curto alcance criptografado",
            singular="comunicação criptografada com capacidade holo",
            plural="comunicações criptografadas com recursos holo"
        },
        {
            category="f",
            name="Comlink, vídeo criptografado de curto alcance",
            singular="comunicação criptografada com capacidade de vídeo",
            plural="comunicações criptografadas com recursos de vídeo"
        },
        {
            category="f",
            name="Comlink, mãos livres",
            singular="comunicação mãos-livre",
            plural="comunicações mãos-livres"
        },
        {
            category="d",
            name="Comlink, de longo alcance",
            singular="comunicação de longo alcance",
            plural="comunicações de longo alcance"
        },
        {
            category="d",
            name="Comlink, holo de longo alcance",
            singular="comunicação de longo alcance",
            plural="comunicações de longo alcance"
        },
        {
            category="d",
            name="Comlink, vídeo de longo alcance",
            singular="comunicação de longo alcance",
            plural="comunicações de longo alcance"
        },
        {
            category="f",
            name="Comlink, miniaturizado de longo alcance",
            singular="comunicação (miniaturizada)",
            plural="comunicações (miniaturizadas)"
        },
        {
            category="f",
            name="Comlink, miniaturizado holo de longo alcance",
            singular="comlink (miniaturizado) com capacidade holo",
            plural="comlinks (miniaturizados) com capacidades holo"
        },
        {
            category="f",
            name="Comlink, vídeo miniaturizado de longo alcance",
            singular="comlink (miniaturizado) com capacidade de vídeo",
            plural="comlinks (miniaturizados) com capacidades de vídeo"
        },
        {
            category="f",
            name="Comlink, curto alcance",
            singular="comlink",
            plural="comunicações"
        },
        {
            category="f",
            name="Comlink, holo de curto alcance",
            singular="comlink",
            plural="comunicações"
        },
        {
            category="f",
            name="Comlink, vídeo de curto alcance",
            singular="comlink",
            plural="comunicações"
        },
        {
            category="f",
            name="Comlink, tightbeam",
            singular="comunicação de feixe apertado",
            plural="comlinks de feixe apertado"
        },
        {
            category="f",
            name="Viseira de interface de computador",
            singular="viseira de interface de computador",
            plural="visores de interface de computador"
        },
        {
            category="d",
            name="Ponto do computador",
            singular="pico de computador",
            plural="picos de computador"
        },
        {
            category="d",
            name="Scanner de comunicação",
            singular="scanner de comunicação",
            plural="scanners de comunicação"
        },
        {
            category="d",
            name="Cortose Gauntlet",
            singular="cortose gauntlet",
            plural="gauntlets de cortose"
        },
        {
            category="f",
            name="Ficha de crédito",
            singular="chip de crédito",
            plural="fichas de crédito"
        },
        {
            category="d",
            name="Bolsa criogénica",
            singular="bolsa criogénica",
            plural="bolsas criogénicas"
        },
        {
            category="m",
            name="Próteses cibernéticas",
            singular="prótese cibernética",
            plural="próteses cibernéticas"
        },
        {
            category="d",
            name="Camisas escuras",
            singular="vestes escuras",
            plural="vestes escuras"
        },
        {
            category="d",
            name="Camisas Jedi de cor escura",
            singular="vestes Jedi de cor escura",
            plural="vestes Jedi de cor escura"
        },
        {
            category="f",
            name="Cartões de dados em branco [10]",
            singular="cartões de dados em branco",
            plural="cartões de dados em branco"
        },
        {
            category="f",
            name="Datapad",
            singular="datapad",
            plural="datapads"
        },
        {
            category="f",
            name="Datapad, básico",
            singular="datapad básico",
            plural="datapads básicos"
        },
        {
            category="f",
            name="Sensor de demolições",
            singular="sensor de demolições",
            plural="sensores de demolição"
        },
        {
            category="f",
            name="Chamador dróide",
            singular="chamador dróide",
            plural="Chamadores de dróides"
        },
        {
            category="d",
            name="Diagnóstico dróide",
            singular="diagnóstico de dróides",
            plural="diagnóstico de dróides"
        },
        {
            category="d",
            name="Eletrobinoculares",
            singular="electrobinocular",
            plural="electrobinocular"
        },
        {
            category="f",
            name="Selo de vácuo de emergência",
            singular="Selo de vácuo de emergência",
            plural="Selos de vácuo de emergência"
        },
        {
            category="f",
            name="Célula energética",
            singular="célula de energia",
            plural="Células energéticas"
        },
        {
            category="f",
            name="FastFlesh medpac",
            singular="FastFlesh medpac",
            plural="FastFlesh medpacs"
        },
        {
            category="t",
            name="Transformador de alimentos de campo",
            singular="processador de alimentos de campo",
            plural="processadores de alimentos de campo"
        },
        {
            category="t",
            name="Kit de campo",
            singular="kit de campo",
            plural="kits de campo"
        },
        {
            category="t",
            name="Extintor de incêndio",
            singular="extintor de incêndio",
            plural="Extintores de incêndio"
        },
        {
            category="f",
            name="Pasta de fogo",
            singular="pasta de fogo",
            plural="pastas de fogo"
        },
        {
            category="f",
            name="Barra de fogo",
            singular="haste de fogo",
            plural="varetas de fogo"
        },
        {
            category="f",
            name="Supressor de flash/silenciador",
            singular="supressor/silenciador flash",
            plural="supressor/silenciadores flash"
        },
        {
            category="s",
            name="Enjaulamento de força",
            singular="gaiola de força",
            plural="gaiolas de força"
        },
        {
            category="s",
            name="Detector de força",
            singular="Detector de força",
            plural="Detectores de força"
        },
        {
            category="d",
            name="Auxílios à formação de forças",
            singular="Auxílios à formação de forças",
            plural="Ajudas à formação de forças"
        },
        {
            category="f",
            name="Célula de Combustível",
            singular="Célula de combustível",
            plural="Células de combustível"
        },
        {
            category="t",
            name="Lanterna de fusão",
            singular="lanterna de fusão",
            plural="lanternas de fusão"
        },
        {
            category="t",
            name="Aparelhos respiratórios para gand",
            singular="Aparelhos respiratórios para gand",
            plural="Gand respiração apparatum"
        },
        {
            category="f",
            name="Filtro respiratório de gand (fornecimento do ano)",
            singular="anos de fornecimento de filtros de respiração Gand",
            plural="anos de fornecimento de filtros de respiração Gand"
        },
        {
            category="d",
            name="Barra de brilho",
            singular="haste de brilho",
            plural="varetas de brilho"
        },
        {
            category="t",
            name="Barra de brilho, chamariz",
            singular="engodo da haste de brilho",
            plural="engodo da haste de brilho"
        },
        {
            category="d",
            name="Lâmpada de halo",
            singular="Lâmpada de halo",
            plural="Lâmpadas de halo"
        },
        {
            category="f",
            name="Sensor de calor",
            singular="sensor de calor",
            plural="sensores de calor"
        },
        {
            category="d",
            name="Embalagem para capacetes",
            singular="Pacote de capacete",
            plural="embalagens de capacetes"
        },
        {
            category="f",
            name="HiBaka 2000 Mem-Stik",
            singular="HiBaka 2000 Mem-Stik",
            plural="HiBaka 2000 Mem-Stiks"
        },
        {
            category="t",
            name="Conversor holo",
            singular="conversor holo",
            plural="conversores holográficos"
        },
        {
            category="f",
            name="Holoprojector, pessoal",
            singular="holoprojector pessoal",
            plural="holoprojetores pessoais"
        },
        {
            category="f",
            name="Hologravador",
            singular="holograver",
            plural="hologravadores"
        },
        {
            category="f",
            name="Holoshrud",
            singular="holoshrud",
            plural="holoshruds"
        },
        {
            category="f",
            name="Coldre, escondido",
            singular="Coldre escondido",
            plural="coldres escondidos"
        },
        {
            category="f",
            name="Coldre, quadril",
            singular="coldre de quadril",
            plural="coldres de anca"
        },
        {
            category="f",
            name="pulseira do hipoinjector",
            singular="pulseira de hipoinjector",
            plural="pulseiras hipoinjectoras"
        },
        {
            category="d",
            name="Camisas de mestre Jedi",
            singular="Camisas de mestre Jedi",
            plural="Camisas de mestre Jedi"
        },
        {
            category="d",
            name="Camisas de padawan Jedi",
            singular="Camisas de padawan Jedi",
            plural="Camisas de padawan Jedi"
        },
        {
            category="d",
            name="Camisas Jedi",
            singular="Camisas Jedi",
            plural="Camisas Jedi"
        },
        {
            category="s",
            name="Jetpack",
            singular="jet pack",
            plural="Pacotes de jatos"
        },
        {
            category="s",
            name="Jetpack, Arakyd Silêncio-Sobre",
            singular="Arakyd Hush-Sobre jetpack pessoal",
            plural="Arakyd Hush-Sobre jetpacks pessoais"
        },
        {
            category="t",
            name="Jetpack, Arakyd Hush-About, miniaturizado",
            singular="Miniaturizado Arakyd Hush-About jet pack",
            plural="Miniaturizado Arakyd Hush-About jet packs"
        },
        {
            category="t",
            name="Miniaturizado",
            singular="Jet pack miniaturizado",
            plural="Pacotes de jato miniaturizados"
        },
        {
            category="f",
            name="Kel Dor filtros antiox (fornecimento de ano)",
            singular="Kel Dor filtros antiox (fornecimento de ano)",
            plural="fornecimento de anos de filtros antiox Kel Dor"
        },
        {
            category="d",
            name="Lectroticker",
            singular="lecroticker",
            plural="lectrotickers"
        },
        {
            category="f",
            name="Distribuidor de cabos líquidos (15 metros)",
            singular="dispensador de cabo líquido",
            plural="Disjuntores de cabos líquidos"
        },
        {
            category="t",
            name="Bloquear kit de quebra",
            singular="kit de quebra de bloqueio",
            plural="kits de quebra de bloqueio"
        },
        {
            category="s",
            name="Armadilha para homens",
            singular="armadilha de homem",
            plural="armadilhas de homem"
        },
        {
            category="f",
            name="Disparo manual",
            singular="gatilho manual",
            plural="gatilhos manuais"
        },
        {
            category="f",
            name="Medissensor MDS-50",
            singular="Medissensor MDS-50",
            plural="Medissensores MDS-50"
        },
        {
            category="f",
            name="Viseira de interface mecânica",
            singular="viseira de interface mecânica",
            plural="viseiras de interface mecânica"
        },
        {
            category="f",
            name="Viseira de interface médica",
            singular="viseira de interface médica",
            plural="viseiras de interface médica"
        },
        {
            category="s",
            name="Kit médico",
            singular="kit médico",
            plural="kits médicos"
        },
        {
            category="s",
            name="Kit médico, miniaturizado",
            singular="kit médico miniaturizado",
            plural="kits médicos miniaturizados"
        },
        {
            category="d",
            name="Medpac",
            singular="medpac",
            plural="medpacs"
        },
        {
            category="f",
            name="Implante de memória",
            singular="implante de memória",
            plural="implantes de memória"
        },
        {
            category="f",
            name="Fita de malha",
            singular="fita de malha",
            plural="rolos de fita de malha"
        },
        {
            category="f",
            name="Microlab",
            singular="microlab",
            plural="microlabs"
        },
        {
            category="f",
            name="Viseira de sensor de movimento",
            singular="viseira de sensor de movimento",
            plural="visores de sensor de movimento"
        },
        {
            category="f",
            name="Implante de reforço de nervos",
            singular="implante de reforço de nervo",
            plural="implantes de reforço de nervos"
        },
        {
            category="f",
            name="Banda neural",
            singular="banda neural",
            plural="bandas neurais"
        },
        {
            category="d",
            name="Camisas de irmã nocturna",
            singular="Camisas de irmã nocturna",
            plural="Camisas de irmã nocturna"
        },
        {
            category="f",
            name="Mascara de Ooglith",
            singular="ooglith masquer",
            plural="mascarados de ooglith"
        },
        {
            category="f",
            name="Anel de pânico",
            singular="anel de pânico",
            plural="anéis de pânico"
        },
        {
            category="t",
            name="Abrigo de campo pessoal",
            singular="abrigo de campo pessoal",
            plural="abrigos de campo pessoais"
        },
        {
            category="f",
            name="Multitool pessoal",
            singular="multitool pessoal",
            plural="multitools pessoais"
        },
        {
            category="f",
            name="Tradutor pessoal",
            singular="tradutor pessoal",
            plural="tradutores pessoais"
        },
        {
            category="l",
            name="Ponte de plasma",
            singular="ponte de plasma",
            plural="pontes de plasma"
        },
        {
            category="t",
            name="Plastent",
            singular="plastent",
            plural="Plastents"
        },
        {
            category="f",
            name="Comutador de bolso",
            singular="comutador de bolso",
            plural="comutadores de bolso"
        },
        {
            category="s",
            name="Sinalizador portátil",
            singular="farol portátil",
            plural="faróis portáteis"
        },
        {
            category="t",
            name="Computador portátil",
            singular="computador portátil",
            plural="computadores portáteis"
        },
        {
            category="s",
            name="Gerador de energia",
            singular="gerador de energia",
            plural="geradores de energia"
        },
        {
            category="s",
            name="Gerador de energia, miniaturizado",
            singular="Gerador de energia miniaturizado",
            plural="geradores de energia miniaturizados"
        },
        {
            category="f",
            name="Pacote de alimentação",
            singular="pacote de energia",
            plural="pacotes de energia"
        },
        {
            category="d",
            name="Recarregador de energia",
            singular="recarregador de energia",
            plural="recarregadores de energia"
        },
        {
            category="s",
            name="Pacote de Propulsão",
            singular="Pacote de propulsão",
            plural="Pacotes de propulsão"
        },
        {
            category="f",
            name="Proximidade",
            singular="chama de proximidade",
            plural="flares de proximidade"
        },
        {
            category="f",
            name="Detector de radiação",
            singular="detector de radiação",
            plural="detectores de radiação"
        },
        {
            category="f",
            name="Embalagem de ração",
            singular="pacote de rações",
            plural="embalagens de ração"
        },
        {
            category="f",
            name="Cristal de reorientação",
            singular="cristal de redirecionamento",
            plural="cristais de redirecionamento"
        },
        {
            category="f",
            name="Implante regenerativo",
            singular="implante regenerativo",
            plural="implantes regenerativos"
        },
        {
            category="t",
            name="Botas de repulsor",
            singular="botas de repulsor",
            plural="botas de repulsor"
        },
        {
            category="t",
            name="Colisão do repulsor",
            singular="engate repulsor",
            plural="engates repulsores"
        },
        {
            category="s",
            name="Repulsor",
            singular="almofada de repulsor",
            plural="almofadas repulsoras"
        },
        {
            category="f",
            name="Parafusos de retenção",
            singular="parafuso de retenção",
            plural="parafusos de retenção"
        },
        {
            category="s",
            name="Escudo de choque",
            singular="escudo de choque",
            plural="escudos de choque"
        },
        {
            category="t",
            name="Sela, cavalgando",
            singular="sela, montar",
            plural="sela, equitação"
        },
        {
            category="s",
            name="Sela, guerra",
            singular="sela, guerra",
            plural="sela, guerras"
        },
        {
            category="d",
            name="Kit de segurança",
            singular="kit de segurança",
            plural="kits de segurança"
        },
        {
            category="s",
            name="Embalagem de sensores",
            singular="pacote de sensores",
            plural="Pacotes de sensores"
        },
        {
            category="t",
            name="Embalagem de sensores miniaturizada",
            singular="Pacote de sensores miniaturizados",
            plural="Pacotes de sensores miniaturizados"
        },
        {
            category="f",
            name="Implante sensorial",
            singular="implante sensorial",
            plural="implantes sensoriais"
        },
        {
            category="s",
            name="Gaiola de escudos",
            singular="gaiola de proteção",
            plural="gaiolas de proteção"
        },
        {
            category="d",
            name="Navios",
            singular="Fato de navio",
            plural="Fatos de navegação"
        },
        {
            category="f",
            name="Varinha de sinal",
            singular="varinha de sinal",
            plural="varinhas de sinal"
        },
        {
            category="d",
            name="Camisas de prata",
            singular="túnicas de prata",
            plural="túnicas de prata"
        },
        {
            category="d",
            name="Vestimentas de aprendiz Sith",
            singular="Vestimentas de aprendiz Sith",
            plural="Vestimentas de aprendiz Sith"
        },
        {
            category="m",
            name="Arnês de batalha Sith",
            singular="Arnês de batalha Sith",
            plural="Arreios de batalha Sith"
        },
        {
            category="d",
            name="As vestes do senhor Sith",
            singular="As vestes do senhor Sith",
            plural="As vestes do senhor Sith"
        },
        {
            category="d",
            name="Vestidos de mestre Sith",
            singular="Vestidos de mestre Sith",
            plural="Vestidos de mestre Sith"
        },
        {
            category="d",
            name="Vestidos de Sith",
            singular="Vestidos de Sith",
            plural="Vestidos de Sith"
        },
        {
            category="d",
            name="Mapeador de sonar",
            singular="sonar mapper",
            plural="Mapeadores sonar"
        },
        {
            category="d",
            name="Esponja de som",
            singular="esponja de som",
            plural="esponjas de som"
        },
        {
            category="s",
            name="O peito do espaçador",
            singular="peito do espaçador",
            plural="peito do espaçador"
        },
        {
            category="f",
            name="Insecto espião",
            singular="erro espião",
            plural="erros de espionagem"
        },
        {
            category="f",
            name="Gerador de campo furtivo",
            singular="Gerador de campo furtivo",
            plural="Geradores de campo furtivos"
        },
        {
            category="f",
            name="Conversor subelectrónico",
            singular="conversor subelectrónico",
            plural="conversores subelectrónicos"
        },
        {
            category="f",
            name="Emissor de campo subsónico",
            singular="emissor de campo subsónico",
            plural="emissores de campo subsónicos"
        },
        {
            category="s",
            name="Kit cirúrgico",
            singular="kit de cirurgia",
            plural="kits de cirurgia"
        },
        {
            category="f",
            name="Detector de vigilância",
            singular="detector de vigilância",
            plural="detectores de vigilância"
        },
        {
            category="f",
            name="Marcador de vigilância",
            singular="etiquetador de vigilância",
            plural="taggers de vigilância"
        },
        {
            category="t",
            name="Síntese (45 metros)",
            singular="sintetrope",
            plural="bobinas de sintetrope"
        },
        {
            category="f",
            name="Indicador de destino",
            singular="farol de mira",
            plural="Faróis de mira"
        },
        {
            category="d",
            name="Âmbito de mira, luz baixa melhorada",
            singular="Abrangendo o alvo de baixa luz",
            plural="Âmbitos de mira de baixa luz melhorados"
        },
        {
            category="f",
            name="Âmbito de referência, norma",
            singular="Âmbito de aplicação da orientação",
            plural="Âmbitos de referência"
        },
        {
            category="d",
            name="Kit de ferramentas",
            singular="kit de ferramentas",
            plural="kits de ferramentas"
        },
        {
            category="f",
            name="Detector de toxinas",
            singular="Detector de toxinas",
            plural="Detectores de toxinas"
        },
        {
            category="f",
            name="Transliterador",
            singular="transliterador",
            plural="transliteradores"
        },
        {
            category="f",
            name="Viseira de triangulação",
            singular="viseira de triangulação",
            plural="visores de triangulação"
        },
        {
            category="f",
            name="Filtro respiratório Ubese (fornecimento do ano)",
            singular="fornecimento anos de filtros de respiração Ubese",
            plural="fornecimento anos de filtros de respiração Ubese"
        },
        {
            category="f",
            name="Modulador de voz Ubese",
            singular="modulador de voz",
            plural="moduladores de voz"
        },
        {
            category="l",
            name="Gaiola de energia universal",
            singular="gaiola de energia universal",
            plural="gaiolas de energia universal"
        },
        {
            category="f",
            name="Cinto utilitário",
            singular="cinto de utilidade",
            plural="cintos utilitários"
        },
        {
            category="f",
            name="Cinto de utilidade, miniaturizado",
            singular="cinto utilitário (miniaturizado)",
            plural="Cintos utilitários (miniaturizados)"
        },
        {
            category="f",
            name="Máscara de vácuo",
            singular="máscara de vácuo",
            plural="máscaras de vácuo"
        },
        {
            category="d",
            name="Bolsa de sobrevivência ao vácuo",
            singular="bolsa de sobrevivência de vácuo",
            plural="bolsas de sobrevivência de vácuo"
        },
        {
            category="f",
            name="Verificador",
            singular="veridificador",
            plural="veridificadores"
        },
        {
            category="f",
            name="Gravador de vídeo",
            singular="gravador de vídeo",
            plural="gravadores de vídeo"
        },
        {
            category="f",
            name="Comutador Vid-vox",
            singular="comutador vid-vox",
            plural="comutadores vid-vox"
        },
        {
            category="f",
            name="Compressão visual do pulso",
            singular="comunicação visual do pulso",
            plural="comunicação visual do pulso"
        },
        {
            category="f",
            name="Caixa Vox",
            singular="caixa vox",
            plural="caixas de vox"
        },
        {
            category="t",
            name="Extractor de água",
            singular="Extrator de água",
            plural="Extractores de água"
        },
        {
            category="",
            name="- Munição...",
            singular="",
            plural=""
        },
        {
            category="f",
            name="Clip de munição",
            singular="clipe de munição",
            plural="clipes de munição"
        },
        {
            category="f",
            name="Clip de munição",
            singular="clipe de munição",
            plural="clips de munição"
        },
        {
            category="t",
            name="Mísseis anti- blindados",
            singular="míssil anti-armamento",
            plural="mísseis anti-armamento"
        },
        {
            category="f",
            name="Tiro de Pistola de Pó Negro",
            singular="tiros (50)",
            plural="tiros (50)"
        },
        {
            category="d",
            name="Quiver Bowcaster",
            singular="bowcaster treme",
            plural="bowcaster treme"
        },
        {
            category="d",
            name="Cartucho de Carbonita",
            singular="cartucho de carbonita",
            plural="cartuchos de carbonita"
        },
        {
            category="t",
            name="Cartucho químico",
            singular="cartucho químico",
            plural="cartuchos químicos"
        },
        {
            category="f",
            name="Parafusos de arco",
            singular="parafusos (10)",
            plural="parafusos (10)"
        },
        {
            category="f",
            name="Dardo",
            singular="dardo",
            plural="dardos"
        },
        {
            category="f",
            name="Célula de Energia",
            singular="célula de energia",
            plural="Células energéticas"
        },
        {
            category="f",
            name="Flechette Cluster",
            singular="cluster flechette",
            plural="grupos flechette"
        },
        {
            category="f",
            name="Granada, frag",
            singular="granada frag",
            plural="granadas frag"
        },
        {
            category="f",
            name="Granada, íon",
            singular="granada de íon",
            plural="granadas de íon"
        },
        {
            category="f",
            name="Granada, atordoamento",
            singular="grânulos de atordoamento",
            plural="granadas de atordoamento"
        },
        {
            category="s",
            name="Míssil de concussão leve",
            singular="míssil de concussão leve",
            plural="mísseis de concussão leve"
        },
        {
            category="s",
            name="Revista",
            singular="revista",
            plural="revistas"
        },
        {
            category="d",
            name="Parafusos Magna Caster",
            singular="Rodízios magnéticos (10)",
            plural="Rodízios magnéticos (10)"
        },
        {
            category="d",
            name="Mísseis",
            singular="míssil",
            plural="mísseis"
        },
        {
            category="f",
            name="Pistola Clip",
            singular="pistoleiro",
            plural="Pistolas"
        },
        {
            category="f",
            name="Célula de Energia",
            singular="Célula de potência do blaster do pulso",
            plural="Células de potência do blaster do pulso"
        },
        {
            category="s",
            name="Gerador de energia",
            singular="gerador de energia",
            plural="geradores de energia"
        },
        {
            category="f",
            name="Pacote de Energia",
            singular="pacote de energia",
            plural="pacotes de energia"
        },
        {
            category="f",
            name="Quiver",
            singular="tremor",
            plural="tremores"
        },
        {
            category="f",
            name="Clip do rifle",
            singular="clipe de rifle",
            plural="clipes de espingardas"
        },
        {
            category="d",
            name="Cartucho de Pistola",
            singular="cartucho de pistola de laço",
            plural="cartuchos de pistola de laço"
        },
        {
            category="f",
            name="Célula de Energia Especial",
            singular="célula de energia especial",
            plural="células de energia especiais"
        },
        {
            category="f",
            name="Canister Explosivo Especial",
            singular="recipiente explosivo especial",
            plural="recipientes explosivos especiais"
        },
        {
            category="f",
            name="Caixa de Spraymist",
            singular="frasco pulverizador",
            plural="latas pulverizadoras"
        },
        {
            category="f",
            name="Clip de arma de raspar Verpine",
            singular="Verpine cortador de arma",
            plural="Clipes de pistolas de esmagamento verpínico"
        },
        {
            category="f",
            name="Caixa de gás Xerrol Nightstinger",
            singular="Caixa de gás Xerrol nightinger",
            plural="Caixas de gás Xerrol nightinger"
        }
    },
    cybernetics={
        {
            description="implante bioestabilizador",
            name="Bioestabilizador"
        },
        {
            description="implante cardiológico",
            name="Cardio"
        },
        {
            description="implante de combate",
            name="Combate"
        },
        {
            description="implante de memória",
            name="Memória"
        },
        {
            description="implante de reforço de nervo",
            name="Reforço do nervo"
        },
        {
            description="implante regenerativo",
            name="Regenerativo"
        },
        {
            description="implante sensorial",
            name="Sensório"
        }
    }
}
