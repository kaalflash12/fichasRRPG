local M={}
local NDB=require("ndb.lua")
local SUP=require("swse_supplement.lua")
-- Supports standalone sheets and ship records inside the character's Hangar.
function M.getVehicleRoot(node)
    local current=node
    for _=1,64 do
        if current==nil then break end
        if current.hangarShipId~=nil or (current.vehicleWeapons~=nil and current.vehicleSize~=nil) then return current end
        current=NDB.getParent(current)
    end
    return NDB.getRoot(node)
end


local function n(v,d)
    local x=tonumber(v)
    if x==nil then return d or 0 end
    return x
end
M.n=n

local function mod(score)
    return math.floor((n(score,10)-10)/2)
end
M.mod=mod

local SIZE={
    l ={name="Grande",ref=-1,threshold=5,grapple=5},
    h ={name="Enorme",ref=-2,threshold=10,grapple=10},
    g ={name="Imenso",ref=-5,threshold=20,grapple=15},
    c ={name="Colossal",ref=-10,threshold=50,grapple=20},
    cf={name="Colossal (Fragata)",ref=-10,threshold=100,grapple=25},
    cc={name="Colossal (Cruzador)",ref=-10,threshold=200,grapple=30},
    cs={name="Colossal (Estação)",ref=-10,threshold=500,grapple=35}
}
M.SIZE=SIZE

local CREW={
    untrained={name="Destreinada",attack=-5,check=0,cl=-1,maneuvers=0,gunnerManeuvers=0,vehicularCombat=false},
    normal={name="Normal",attack=0,check=5,cl=0,maneuvers=0,gunnerManeuvers=0,vehicularCombat=false},
    skilled={name="Hábil",attack=2,check=6,cl=1,maneuvers=1,gunnerManeuvers=1,vehicularCombat=true},
    expert={name="Especialista",attack=5,check=8,cl=2,maneuvers=2,gunnerManeuvers=2,vehicularCombat=true},
    ace={name="Ás",attack=10,check=12,cl=4,maneuvers=4,gunnerManeuvers=4,vehicularCombat=true}
}
M.CREW=CREW

local CONDITION={ [0]=0,[1]=-1,[2]=-2,[3]=-5,[4]=-10,[5]=-10 }
M.CONDITION=CONDITION

local RANGE={pointblank=0,short=-2,medium=-5,long=-10}
M.RANGE=RANGE

local function children(root,field)
    if root==nil or root[field]==nil then return {} end
    return NDB.getChildNodes(root[field])
end

local function ensureList(root,field)
    if root[field]==nil then root[field]={} end
end

local function sizeInfo(root)
    return SIZE[tostring(root.vehicleSize or "l")] or SIZE.l
end

local function crewInfo(root)
    return CREW[tostring(root.crewQuality or "normal")] or CREW.normal
end

local function conditionPenalty(root)
    return CONDITION[math.max(0,math.min(5,math.floor(n(root.vehicleCondition,0))))] or 0
end

local function rootChat(root,msg)
    local mesa=Firecast.getMesaDe(root)
    if mesa~=nil and mesa.activeChat~=nil then mesa.activeChat:escrever(msg) end
end

local function roll(root,expr,title)
    local mesa=Firecast.getMesaDe(root)
    if mesa==nil then return false,"Sem mesa ativa." end
    local r=Firecast.interpretarRolagem(expr)
    if not r.possuiAlgumDado then return false,"Expressão de rolagem inválida: "..tostring(expr) end
    mesa.activeChat:rolarDados(r,title)
    return true
end

local function rollLocal(root,expr,title)
    local r=Firecast.interpretarRolagem(expr)
    if not r.possuiAlgumDado then return false,nil,"Expressão de rolagem inválida: "..tostring(expr) end
    r:rolarLocalmente()
    local total=n(r.resultado,0)
    rootChat(root,"**"..tostring(title or "Teste").."**: "..tostring(r.asString or expr).." = **"..tostring(total).."**")
    return true,total,nil
end
M.rollLocal=rollLocal

function M.ensure(root)
    if root==nil then return end
    ensureList(root,"vehicleWeapons")
    ensureList(root,"vehicleManeuvers")
    ensureList(root,"vehicleNotesLog")
    if root.vehicleSize==nil then root.vehicleSize="l" end
    if root.crewMode==nil then root.crewMode="unique" end
    if root.crewQuality==nil then root.crewQuality="normal" end
    if root.vehicleStr==nil then root.vehicleStr=10 end
    if root.vehicleDex==nil then root.vehicleDex=10 end
    if root.vehicleInt==nil then root.vehicleInt=10 end
    if root.vehicleCon==nil then root.vehicleCon=10 end
    if root.vehicleHPMax==nil then root.vehicleHPMax=1 end
    if root.vehicleHP==nil then root.vehicleHP=root.vehicleHPMax end
    if root.vehicleSRMax==nil then root.vehicleSRMax=0 end
    if root.vehicleSR==nil then root.vehicleSR=root.vehicleSRMax end
    if root.vehicleDR==nil then root.vehicleDR=0 end
    if root.vehicleArmor==nil then root.vehicleArmor=0 end
    if root.vehicleCondition==nil then root.vehicleCondition=0 end
    if root.vehicleSpeed==nil then root.vehicleSpeed=0 end
    if root.vehicleStarshipSpeed==nil then root.vehicleStarshipSpeed=0 end
    if root.shieldsRaised==nil then root.shieldsRaised=(n(root.vehicleSR,0)>0) end
    if root.pilotTrained==nil then root.pilotTrained=false end
    if root.vehicleFullStop==nil then root.vehicleFullStop=false end
    if root.vehiclePoweredDown==nil then root.vehiclePoweredDown=false end
    if root.vehicleDisabled==nil then root.vehicleDisabled=false end
    if root.vehicleDestroyed==nil then root.vehicleDestroyed=false end
    M.recalc(root)
end

function M.recalc(root)
    if root==nil then return end
    local s=sizeInfo(root)
    local crew=crewInfo(root)
    local strMod=mod(root.vehicleStr)
    local dexMod=mod(root.vehicleDex)
    local intMod=mod(root.vehicleInt)
    local conMod=mod(root.vehicleCon)
    root.vehicleStrMod=strMod
    root.vehicleDexMod=dexMod
    root.vehicleIntMod=intMod
    root.vehicleConMod=conMod
    root.vehicleSizeName=s.name
    root.vehicleSizeRefMod=s.ref
    root.vehicleThresholdSizeBonus=s.threshold
    root.vehicleGrappleSizeBonus=s.grapple
    root.vehicleConditionPenalty=conditionPenalty(root)

    local armorOrHero=n(root.vehicleArmor,0)
    if tostring(root.crewMode or "unique")=="unique" then
        armorOrHero=math.max(armorOrHero,n(root.pilotHeroicLevel,0))
    end
    root.vehicleDefenseSource=(armorOrHero==n(root.vehicleArmor,0)) and "Armadura" or "Nível heroico do piloto"

    local defenseDex=dexMod
    if root.vehicleFullStop==true or root.vehiclePoweredDown==true or root.vehicleDisabled==true then defenseDex=-5 end
    local tempRef=n(root.vehicleTempReflex,0)+n(root.vehicleAttackRunReflexPenalty,0)+n(root.vehicleDefensiveReflexBonus,0)
    root.vehicleReflex=10+defenseDex+s.ref+armorOrHero+tempRef+conditionPenalty(root)
    local flatDex=(root.vehicleFullStop==true or root.vehiclePoweredDown==true or root.vehicleDisabled==true) and -5 or math.min(0,dexMod)
    root.vehicleReflexFlat=10+flatDex+s.ref+armorOrHero+tempRef+conditionPenalty(root)

    local fortAbility=(root.livingVehicle==true) and conMod or strMod
    root.vehicleFortitude=10+fortAbility+n(root.vehicleFortMisc,0)+conditionPenalty(root)
    root.vehicleDamageThreshold=root.vehicleFortitude+s.threshold+n(root.vehicleThresholdMisc,0)
    root.vehicleGrapple=(tostring(root.crewMode or "unique")=="quality" and crew.attack or n(root.pilotBAB,0))
        +strMod+s.grapple+n(root.vehicleGrappleMisc,0)+conditionPenalty(root)

    local pilotBase
    if tostring(root.crewMode or "unique")=="quality" then pilotBase=crew.check else pilotBase=n(root.pilotSkillMod,0) end
    root.vehiclePilotCheck=pilotBase+s.ref+dexMod+conditionPenalty(root)
    if tostring(root.crewMode or "unique")=="quality" then
        root.vehiclePerception=crew.check+intMod+conditionPenalty(root)
    else
        root.vehiclePerception=n(root.systemOperatorPerception,n(root.vehiclePerception,0))+intMod+conditionPenalty(root)
    end
    local initBase
    if tostring(root.crewMode or "unique")=="quality" then initBase=crew.check
    elseif root.usePilotForInitiative==true and root.pilotTrained==true then initBase=n(root.pilotSkillMod,0)
    else initBase=n(root.pilotInitiativeMod,0) end
    root.vehicleInitiative=initBase+s.ref+dexMod+conditionPenalty(root)

    if tostring(root.crewMode or "unique")=="quality" then
        root.crewAttackBase=crew.attack
        root.crewCheckBase=crew.check
        root.crewCLModifier=crew.cl
        root.genericManeuverSlots=crew.maneuvers
        root.genericGunnerManeuverSlots=crew.gunnerManeuvers
        root.genericVehicularCombat=crew.vehicularCombat
    else
        root.crewAttackBase=n(root.gunnerBAB,0)
        root.crewCheckBase=n(root.pilotSkillMod,0)
        root.crewCLModifier=0
        root.genericManeuverSlots=n(root.starshipManeuverSlots,0)
        root.genericGunnerManeuverSlots=0
        root.genericVehicularCombat=root.pilotVehicularCombat==true
    end

    root.vehicleCurrentSpeed=(root.vehicleFullStop==true or root.vehicleDisabled==true or root.vehiclePoweredDown==true)
        and 0 or (n(root.vehicleSpeed,0)+n(root.vehicleSpeedBoost,0))
    root.vehicleCurrentStarshipSpeed=(root.vehicleFullStop==true or root.vehicleDisabled==true or root.vehiclePoweredDown==true)
        and 0 or (n(root.vehicleStarshipSpeed,0)+n(root.vehicleStarshipSpeedBoost,0))

    root.vehicleStateText=root.vehicleDestroyed==true and "DESTRUÍDO"
        or root.vehicleDisabled==true and "DESABILITADO"
        or root.vehiclePoweredDown==true and "DESLIGADO"
        or root.vehicleFullStop==true and "PARADO"
        or "OPERACIONAL"

    for _,w in ipairs(children(root,"vehicleWeapons")) do M.recalcWeapon(root,w) end
end

function M.recalcWeapon(root,w)
    if root==nil or w==nil then return end
    local crew=crewInfo(root)
    local intMod=mod(root.vehicleInt)
    local base
    if tostring(root.crewMode or "unique")=="quality" then
        base=crew.attack
    else
        base=n(w.gunnerBAB,n(root.gunnerBAB,n(root.pilotBAB,0)))
    end
    local total=base+intMod+(RANGE[tostring(w.rangeBand or "pointblank")] or 0)+n(w.attackMisc,0)+conditionPenalty(root)
    if w.pilotControlled==true and root.pilotTrained==true then total=total+2 end
    if root.vehicleAttackRunActive==true and w.pilotControlled==true then total=total+2 end
    total=total+n(root.vehicleAttackPenalty,0)

    local vehicleSize=tostring(root.vehicleSize or "l")
    local targetSize=tostring(w.targetSize or "")
    local capital=(vehicleSize=="cf" or vehicleSize=="cc" or vehicleSize=="cs")
    if capital and targetSize~="" and targetSize~="c" and targetSize~="cf" and targetSize~="cc" and targetSize~="cs" and w.pointDefense~=true then
        total=total-20
        w.capitalTrackingPenalty=true
    else
        w.capitalTrackingPenalty=false
    end

    w.attackTotal=total
    local heroLevel=n(w.gunnerHeroicLevel,n(root.gunnerHeroicLevel,n(root.pilotHeroicLevel,0)))
    local hero=math.floor(heroLevel/2)
    local bonus=hero+n(w.damageMisc,0)
    w.damageHeroicBonus=hero
    w.damageTotalText=tostring(w.damage or "")..(bonus>0 and ("+"..bonus) or (bonus<0 and tostring(bonus) or "")).." x"..tostring(math.max(1,math.floor(n(w.multiplier,1))))
end

function M.addWeapon(root)
    M.ensure(root)
    local w=NDB.createChildNode(root.vehicleWeapons,"item")
    w.name="Nova arma de veículo"
    w.weaponType="laser"
    w.damage="4d10"
    w.multiplier=1
    w.rangeBand="pointblank"
    w.pilotControlled=false
    w.pointDefense=false
    w.gunnerBAB=n(root.gunnerBAB,n(root.pilotBAB,0))
    w.gunnerHeroicLevel=n(root.gunnerHeroicLevel,n(root.pilotHeroicLevel,0))
    w.targetSize="g"
    w.attackMisc=0
    w.damageMisc=0
    M.recalcWeapon(root,w)
    return w
end

function M.deleteWeapon(w)
    if w~=nil then
        local root=M.getVehicleRoot(w)
        NDB.deleteNode(w)
        if root~=nil then M.recalc(root) end
    end
end

function M.rollWeaponAttack(root,w)
    M.recalcWeapon(root,w)
    local total=n(w.attackTotal,0)
    local expr="1d20"..(total>=0 and ("+"..total) or tostring(total))
    return roll(root,expr,"Ataque de veículo — "..tostring(w.name or "Arma").." — "..tostring(root.vehicleName or "Veículo"))
end

function M.rollWeaponDamage(root,w)
    M.recalcWeapon(root,w)
    local base=tostring(w.damage or "")
    if base=="" then return false,"Dano da arma não configurado." end
    local heroLevel=n(w.gunnerHeroicLevel,n(root.gunnerHeroicLevel,n(root.pilotHeroicLevel,0)))
    local bonus=math.floor(heroLevel/2)+n(w.damageMisc,0)
    local expr=base
    if bonus>0 then expr=expr.."+"..bonus elseif bonus<0 then expr=expr..bonus end
    local mult=math.max(1,math.floor(n(w.multiplier,1)))
    local title="Dano de veículo — "..tostring(w.name or "Arma").." — "..tostring(root.vehicleName or "Veículo")
    if mult>1 then
        title=title.." — MULTIPLICADOR x"..mult.." (aplique x"..mult.." ao total rolado)"
    end
    if w.ion==true then title="ION — "..title end
    return roll(root,expr,title)
end

function M.rollPilot(root,label,extra)
    M.recalc(root)
    local total=n(root.vehiclePilotCheck,0)+n(extra,0)
    local expr="1d20"..(total>=0 and ("+"..total) or tostring(total))
    return roll(root,expr,label or ("Pilotar — "..tostring(root.vehicleName or "Veículo")))
end

function M.rollInitiative(root)
    M.recalc(root)
    local total=n(root.vehicleInitiative,0)
    local expr="1d20"..(total>=0 and ("+"..total) or tostring(total))
    return roll(root,expr,"Iniciativa de veículo — "..tostring(root.vehicleName or "Veículo"))
end

function M.applyDamage(root,amount,kind)
    M.recalc(root)
    local raw=math.max(0,n(amount,0))
    if raw<=0 then return false,"Informe dano maior que zero." end
    kind=tostring(kind or "normal")
    local srBefore=(root.shieldsRaised==true) and math.max(0,n(root.vehicleSR,0)) or 0
    local afterSR=math.max(0,raw-srBefore)
    local srLoss=0
    if srBefore>0 and raw>srBefore then
        srLoss=5
        root.vehicleSR=math.max(0,n(root.vehicleSR,0)-5)
    end
    local afterDR=math.max(0,afterSR-math.max(0,n(root.vehicleDR,0)))

    local hpDamage=afterDR
    local thresholdDamage=afterDR
    local steps=0
    if kind=="ion" then
        hpDamage=math.floor(afterDR/2)
        thresholdDamage=afterDR
        if thresholdDamage>=n(root.vehicleDamageThreshold,999999) then steps=2 end
    else
        if thresholdDamage>=n(root.vehicleDamageThreshold,999999) then steps=1 end
    end

    local before=math.max(0,n(root.vehicleHP,n(root.vehicleHPMax,1)))
    root.vehicleHP=math.max(0,before-hpDamage)
    if steps>0 then root.vehicleCondition=math.min(5,n(root.vehicleCondition,0)+steps) end

    local destroyed=false
    local disabled=false
    if root.vehicleHP<=0 then
        root.vehicleCondition=5
        root.vehicleFullStop=true
        if kind~="ion" and thresholdDamage>=n(root.vehicleDamageThreshold,999999) then
            destroyed=true
            root.vehicleDestroyed=true
            root.vehicleDisabled=false
            root.occupantDestructionDamage=math.max(0,math.floor((thresholdDamage-n(root.vehicleDamageThreshold,0))/2))
        else
            disabled=true
            root.vehicleDisabled=true
            root.vehicleDestroyed=false
            root.occupantDestructionDamage=0
        end
    elseif root.vehicleCondition>=5 then
        disabled=true
        root.vehicleDisabled=true
        root.vehicleFullStop=true
    end

    root.lastDamageRaw=raw
    root.lastDamageAfterSR=afterSR
    root.lastDamageAfterDR=afterDR
    root.lastHPDamage=hpDamage
    root.lastShieldLoss=srLoss
    root.lastDamageKind=kind
    root.lastDamageResult="Bruto "..raw.." → após SR "..afterSR.." → após RD "..afterDR
        ..(kind=="ion" and (" → PV "..hpDamage.." (Ion)") or (" → PV "..hpDamage))
        ..(steps>0 and (" → Condição -"..steps.." passo(s)") or "")
        ..(destroyed and " → DESTRUÍDO" or (disabled and " → DESABILITADO" or ""))
    M.recalc(root)
    return true,root.lastDamageResult
end

function M.heal(root,amount)
    local a=math.max(0,n(amount,0))
    if a<=0 then return false,"Informe reparo maior que zero." end
    if root.vehicleDestroyed==true then return false,"Veículo destruído não pode ser reparado pelas regras normais." end
    root.vehicleHP=math.min(math.max(1,n(root.vehicleHPMax,1)),math.max(0,n(root.vehicleHP,0))+a)
    if root.vehicleHP>0 and root.vehicleDisabled==true and n(root.vehicleCondition,0)>=5 then
        root.vehicleCondition=math.max(0,n(root.vehicleCondition,0)-1)
        root.vehicleDisabled=false
        root.vehicleFullStop=false
    end
    M.recalc(root)
    return true,"PV reparados: "..a
end

function M.raiseShields(root,on)
    root.shieldsRaised=(on==true)
    M.recalc(root)
    return true,on and "Escudos erguidos." or "Escudos baixados."
end

function M.rechargeShields(root,mechanicsTotal)
    if root.vehicleSRMax==nil or n(root.vehicleSRMax,0)<=0 then return false,"O veículo não possui SR máximo." end
    if n(mechanicsTotal,0)<20 then return false,"Recarga falhou: Mechanics abaixo de CD 20." end
    root.vehicleSR=math.min(n(root.vehicleSRMax,0),n(root.vehicleSR,0)+5)
    M.recalc(root)
    return true,"SR restaurado em +5."
end

function M.attemptRechargeShields(root)
    M.recalc(root)
    local m=n(root.engineerMechanicsMod,0)+conditionPenalty(root)
    local expr="1d20"..(m>=0 and ("+"..m) or tostring(m))
    local ok,total,err=rollLocal(root,expr,"Recarregar Escudos (Mechanics CD 20)")
    if not ok then return false,err end
    local pass,msg=M.rechargeShields(root,total)
    root.lastVehicleAction=msg.." Resultado "..total.."."
    return pass,root.lastVehicleAction
end

function M.reroutePower(root,mechanicsTotal)
    if n(mechanicsTotal,0)<20 then return false,"Rerrotear energia falhou: Mechanics abaixo de CD 20." end
    if n(root.vehicleCondition,0)<=0 then return false,"O veículo já está no topo da Trilha de Condição." end
    root.vehicleCondition=math.max(0,n(root.vehicleCondition,0)-1)
    if root.vehicleCondition<5 then root.vehicleDisabled=false end
    M.recalc(root)
    return true,"Veículo moveu +1 passo na Trilha de Condição."
end

function M.attemptReroutePower(root)
    M.recalc(root)
    local m=n(root.engineerMechanicsMod,0)+conditionPenalty(root)
    local expr="1d20"..(m>=0 and ("+"..m) or tostring(m))
    local ok,total,err=rollLocal(root,expr,"Rerrotear Energia (Mechanics CD 20)")
    if not ok then return false,err end
    local pass,msg=M.reroutePower(root,total)
    root.lastVehicleAction=msg.." Resultado "..total.."."
    return pass,root.lastVehicleAction
end

function M.fullStop(root)
    root.vehicleFullStop=true
    root.vehicleSpeedBoost=0
    root.vehicleStarshipSpeedBoost=0
    M.recalc(root)
    return true,"Veículo em parada total."
end

function M.resumeMovement(root)
    if root.vehicleDisabled==true or root.vehicleDestroyed==true or root.vehiclePoweredDown==true then return false,"O veículo não pode retomar movimento no estado atual." end
    root.vehicleFullStop=false
    M.recalc(root)
    return true,"Movimento normal retomado."
end

function M.attackRun(root,on)
    root.vehicleAttackRunActive=(on==true)
    root.vehicleAttackRunReflexPenalty=(on==true) and -2 or 0
    M.recalc(root)
    return true,on and "Attack Run ativo: +2 no ataque pilotado e -2 Reflexos." or "Attack Run encerrado."
end

function M.fightDefensively(root,mode)
    mode=tostring(mode or "off")
    if mode=="off" then
        root.vehicleDefensiveReflexBonus=0
        root.vehicleAttackPenalty=0
    elseif mode=="attack" then
        root.vehicleAttackPenalty=-5
        root.vehicleDefensiveReflexBonus=(root.pilotTrained==true) and 5 or 2
    elseif mode=="noattack" then
        root.vehicleAttackPenalty=-10
        root.vehicleDefensiveReflexBonus=(root.pilotTrained==true) and 10 or 5
    end
    root.vehicleDefensiveMode=mode
    M.recalc(root)
    return true,"Modo defensivo atualizado."
end

function M.endTurn(root)
    root.vehicleAttackRunActive=false
    root.vehicleAttackRunReflexPenalty=0
    root.vehicleDefensiveReflexBonus=0
    root.vehicleAttackPenalty=0
    root.vehicleDefensiveMode="off"
    root.vehicleSpeedBoost=0
    root.vehicleStarshipSpeedBoost=0
    M.recalc(root)
    return true,"Modificadores temporários do turno removidos."
end

function M.increaseSpeedFromRoll(root,total)
    total=n(total,0)
    if total<20 then
        root.vehicleCondition=math.min(5,n(root.vehicleCondition,0)+1)
        M.recalc(root)
        return false,"Falha no aumento de velocidade: veículo move -1 passo na Trilha de Condição."
    end
    local bonus=1+math.floor((total-20)/5)
    root.vehicleSpeedBoost=bonus
    root.vehicleStarshipSpeedBoost=bonus
    M.recalc(root)
    return true,"Velocidade aumentada em +"..bonus.." quadrado(s) até o início do próximo turno."
end

function M.attemptIncreaseSpeed(root)
    if root.pilotTrained~=true and tostring(root.crewMode or "unique")~="quality" then
        return false,"Aumentar Velocidade exige treinamento em Pilot."
    end
    M.recalc(root)
    local m=n(root.vehiclePilotCheck,0)
    local expr="1d20"..(m>=0 and ("+"..m) or tostring(m))
    local ok,total,err=rollLocal(root,expr,"Aumentar Velocidade (Pilot CD 20)")
    if not ok then return false,err end
    local pass,msg=M.increaseSpeedFromRoll(root,total)
    root.lastVehicleAction=msg.." Resultado "..total.."."
    return pass,root.lastVehicleAction
end

function M.rollDogfight(root,mode)
    M.recalc(root)
    local penalty=(tostring(mode or "initiate")=="initiate") and -5 or 0
    local m=n(root.vehiclePilotCheck,0)+penalty
    local expr="1d20"..(m>=0 and ("+"..m) or tostring(m))
    local label=(penalty==-5) and "Iniciar Dogfight (Pilot -5)" or "Dogfight — teste oposto de Pilot"
    return roll(root,expr,label)
end

function M.addManeuver(root,name)
    ensureList(root,"vehicleManeuvers")
    name=tostring(name or "")
    if name=="" then return false,"Escolha uma manobra." end
    for _,x in ipairs(children(root,"vehicleManeuvers")) do if tostring(x.name or "")==name then return false,"Manobra já registrada." end end
    local src=nil
    for _,x in ipairs(SUP.starship_maneuvers or {}) do if tostring(x.name or "")==name then src=x; break end end
    if src==nil then return false,"Manobra não encontrada no catálogo." end
    local node=NDB.createChildNode(root.vehicleManeuvers,"item")
    node.name=src.name
    node.namePt=tostring(src.name_pt or src.name)
    node.detailPt=tostring(src.descriptor_pt or src.descriptor or "")
    node.notes=""
    return true,"Manobra adicionada."
end

function M.maneuverNames()
    local items,values={},{}
    for _,x in ipairs(SUP.starship_maneuvers or {}) do
        items[#items+1]=tostring(x.name_pt or x.name or "")
        values[#values+1]=tostring(x.name or "")
    end
    return items,values
end

function M.statBlock(root)
    M.recalc(root)
    local weapons={}
    for _,w in ipairs(children(root,"vehicleWeapons")) do
        M.recalcWeapon(root,w)
        weapons[#weapons+1]=tostring(w.name or "Arma").." +"..tostring(n(w.attackTotal,0)).." ("..tostring(w.damageTotalText or "")..")"
    end
    local lines={
        tostring(root.vehicleName or "Veículo").." — "..tostring(root.vehicleSizeName or "").." "..tostring(root.vehicleType or "Veículo"),
        "Iniciativa "..string.format("%+d",n(root.vehicleInitiative,0)).."; Percepção "..string.format("%+d",n(root.vehiclePerception,0)),
        "Defesas: Ref "..n(root.vehicleReflex,10).." (desprevenido "..n(root.vehicleReflexFlat,10).."), Fort "..n(root.vehicleFortitude,10),
        "PV "..n(root.vehicleHP,0).."/"..n(root.vehicleHPMax,0).."; RD "..n(root.vehicleDR,0).."; SR "..n(root.vehicleSR,0).."/"..n(root.vehicleSRMax,0).."; Limiar "..n(root.vehicleDamageThreshold,10),
        "Velocidade "..n(root.vehicleCurrentSpeed,0).." q"..(n(root.vehicleStarshipSpeed,0)>0 and ("; escala nave "..n(root.vehicleCurrentStarshipSpeed,0).." q") or ""),
        "FOR "..n(root.vehicleStr,10)..", DES "..n(root.vehicleDex,10)..", INT "..n(root.vehicleInt,10),
        "Tripulação "..tostring(root.vehicleCrew or "").."; Passageiros "..tostring(root.vehiclePassengers or "").."; Carga "..tostring(root.vehicleCargo or ""),
        "Hiperpropulsor "..tostring(root.vehicleHyperdrive or "").."; Consumíveis "..tostring(root.vehicleConsumables or ""),
        "Armas: "..(#weapons>0 and table.concat(weapons,"; ") or "nenhuma")
    }
    root.vehicleStatBlock=table.concat(lines,"\n")
    return root.vehicleStatBlock
end

return M
