-- Report only layout dimensions of this plugin's already displayed sheet.
-- No room/character values, window operations, or persistent NDB access.
local M={}
local function n(c,k) local ok,v=pcall(function() return c and c[k] end); return ok and tonumber(v) or 0 end
function M.schedule(form)
 if not form or form.name~='frmStarWarsSagaEdition' or form._swseGeometryTimer then return end
 form._swseGeometryTimer=setTimeout(function()
  form._swseGeometryTimer=nil
  pcall(function()
   if not form.isShowing then return end
   local state=form._hangarState; local editor=state and state.vehicle
   local host=form.hangarEditorHost
   local cards=form.hangarList and form.hangarList:getChildren() or {}
   local card=cards[1]
   local values={version='7.3.3',isShowing='true',
    formWidth=n(form,'width'),formHeight=n(form,'height'),
    hostWidth=n(host,'width'),hostHeight=n(host,'height'),
    editorWidth=n(editor,'width'),editorHeight=n(editor,'height'),
    frameWidth=n(editor and editor.swseScreenFrame,'width'),frameHeight=n(editor and editor.swseScreenFrame,'height'),
    navWidth=n(editor and editor.vehicleHoloNav,'width'),
    pageWidth=n(editor and editor.pageVehicleGeneral,'width'),pageHeight=n(editor and editor.pageVehicleGeneral,'height'),
    indexWidth=n(form.hangarList,'width'),cardWidth=n(card,'width'),cardFrameWidth=n(card and card.hangarShipCard,'width')}
   local keys={};for k in pairs(values) do keys[#keys+1]=k end;table.sort(keys)
   local parts={'<geometry'};for _,k in ipairs(keys) do parts[#parts+1]=' '..k..'="'..tostring(values[k])..'"' end
   parts[#parts+1]=' />';local body=table.concat(parts)
   if form._swseLastGeometry==body then return end
   local VHD=require('vhd.lua');local stream=VHD.openFile('live_geometry_731.xml','w')
   if stream then
    local bytes={};for i=1,#body do bytes[i]=body:byte(i) end
    stream:write(bytes,#bytes);stream:close();form._swseLastGeometry=body
   end
  end)
 end,800)
end
function M.stop(form)
 if form and form._swseGeometryTimer then clearTimeout(form._swseGeometryTimer);form._swseGeometryTimer=nil end
end
return M
