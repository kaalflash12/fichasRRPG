-- STARWARS-SAGA D/L: visual e FX locais. Nao altera regras nem grava NDB por frame.
local GUI = require("gui.lua")
local M = {version = "7.3.3-visible-components"}
M.palettes = {
  dark = {background="#03090FFF", panel="#071923F5", panelAlt="#0A202CF5", panelDeep="#04121CFF",
    border="#286074", borderSoft="#193C4B", text="#D5EFF6", muted="#85A9B5", cyan="#71D9F1",
    cyanSoft="#3A91AB", gold="#EFC56B", amber="#E09A56", success="#7BD5B3", warning="#F37C85",
    rich="#06121BFF", button="#0A2938", slot="#05141EFF", active="#103343", off="#06111B"},
  light = {background="#DFE9EDFF", panel="#F5FAFCFF", panelAlt="#E8F2F6FF", panelDeep="#D5E5ECFF",
    border="#578696", borderSoft="#92ACB7", text="#183947", muted="#506F7C", cyan="#13768D",
    cyanSoft="#568F9E", gold="#906111", amber="#9D591C", success="#36745C", warning="#AA3946",
    rich="#F4F8FBFF", button="#E0F0F6", slot="#F8FCFFFF", active="#C9EAF4", off="#E5EEF2"}
}
local SOURCE = {
  ["0b1118"]="panel", ["0a1016"]="panelAlt", ["0c1216"]="panel", ["02131b"]="panel",
  ["03151e"]="panelAlt", ["041b26"]="panelAlt", ["090d10"]="background", ["080d13"]="background",
  ["01070b"]="background", ["010a10"]="panelDeep", ["101820"]="panel", ["151f29"]="panelAlt",
  ["333333"]="rich", ["2b6574"]="border", ["1a7c9a"]="border", ["14546a"]="borderSoft",
  ["64717d"]="muted", ["7a8a92"]="muted", ["808080"]="muted", ["a7b0ba"]="muted",
  ["74aebe"]="muted", ["6fa5b5"]="muted", ["85a7b4"]="muted", ["a8dde9"]="text",
  ["d8faff"]="text", ["d8f8ff"]="text", ["c8f8ff"]="text", ["bcefff"]="text",
  ["f4d35e"]="gold", ["ffe082"]="gold", ["e6c956"]="gold", ["ffe071"]="gold",
  ["69d2e7"]="cyan", ["64c8d9"]="cyan", ["5ae9ff"]="cyan", ["49d9f5"]="cyan",
  ["38dcff"]="cyan", ["2fb9d8"]="cyanSoft", ["f29e4c"]="amber", ["d69b43"]="amber",
  ["a7d8c0"]="success", ["72e3bc"]="success", ["ff6675"]="warning", ["ff9aa4"]="warning",
  ["04202c"]="button", ["021019"]="slot", ["011017"]="slot", ["063447"]="active",
  ["062936"]="active", ["010b12"]="off", ["020a10"]="off"
}
local ART_STATE=setmetatable({}, {__mode="k"})
local function get(c,k) local ok,v=pcall(function() return c[k] end); if ok then return v end end
local function set(c,k,v)
  if c==nil or v==nil then return false end
  local state=ART_STATE[c]
  if state then
    if state[k]==v then return true end
    local ok=pcall(function() c[k]=v end)
    if ok then state[k]=v end
    return ok
  end
  return pcall(function() if c[k]~=v then c[k]=v end end)
end
local function kids(c) local ok,v=pcall(function() return c:getChildren() end); return ok and type(v)=="table" and v or {} end
local function tag(c)
  local cl=get(c,"class")
  for _=1,24 do if type(cl)~="table" then break end; local t=rawget(cl,"tagName"); if t then return t end; cl=rawget(cl,"super") end
  return ""
end
local function colorKey(v) return type(v)=="string" and v:match("^#(%x%x%x%x%x%x)") and v:sub(2,7):lower() or nil end
local function token(v)
  local k=colorKey(v); if not k then return nil end
  if SOURCE[k] then return SOURCE[k] end
  for _,p in pairs(M.palettes) do for name,col in pairs(p) do if colorKey(col)==k then return name end end end
end
local function grid(c,k) local g=get(c,"grid"); return g and get(g,k) end
local function visible(c)
  for _=1,50 do if c==nil then return true end; if get(c,"visible")==false then return false end; c=get(c,"parent") end
  return false
end
local function modeOf(form,mode)
  mode=tostring(mode or form._swseThemeMode or "dark"):lower(); return mode=="light" and "light" or "dark"
end
local function navName(n) return n:match('^shapeNav') or n:match('^shapeSub') or n:match('^shapeVehicle') end
local function tabKind(n) return n:match('^shapeSub') and 'subtab' or 'tab' end
local function navActive(form,c)
  local n=tostring(get(c,'name') or '')
  if n:match('^shapeNav') or n:match('^shapeVehicle') then
    local sh=get(form,'sheet'); local vehicle=n:match('^shapeVehicle')~=nil
    local key=tostring(sh and sh[vehicle and 'uiVehicleTab' or 'uiMainTab'] or 'general')
    local prefix=vehicle and 'shapeVehicle' or 'shapeNav'
    return n==prefix..key:sub(1,1):upper()..key:sub(2)
  end
  local page=form[n:gsub('^shapeSub','pageSub')]
  return page~=nil and get(page,'visible')~=false
end
local function classify(c,t)
  local n=tostring(get(c,'name') or '')
  if navName(n) then return tabKind(n) end
  if n=='fxStateButton' then return 'status' end
  if t=='layout' and (n=='hangarIndexPanel' or n=='hangarDetailPanel') then return 'panel' end
  if t~='rectangle' then return nil end
  local direct=kids(c); local input=false; local content=false
  for _,x in ipairs(direct) do
    local ct=tag(x)
    if ct=='edit' or ct=='comboBox' or ct=='textEditor' or ct=='imageCheckBox' then input=true end
    if get(x,'g') or grid(x,'role')=='col' or ct=='gridRecordList' or ct=='recordList' then content=true end
  end
  local h=tonumber(grid(c,'min-height')) or tonumber(get(c,'height')) or 0
  if input and h<80 then return 'input' end
  local tk=token(get(c,'color'))
  if tk=='button' or colorKey(get(c,'color'))=='241017' then return 'button' end
  if h>=80 and (content or input or #direct>=2) and (tk=='panel' or tk=='panelAlt' or tk=='panelDeep') then return 'panel' end
end
local function recolor(c,pal)
  for _,k in ipairs({'color','strokeColor','fontColor','backgroundColor','defaultFontColor'}) do
    local tok=token(get(c,k)); if tok and pal[tok] then set(c,k,pal[tok]) end
  end
end
local function walk(form,fn,visibleOnly)
  local seen={}
  local function visit(c,depth,shown,record)
    if c==nil or depth>45 or seen[c] then return end;seen[c]=true
    local t=tag(c)
    if c~=form and t=='form' and get(c,'name')=='frmStarWarsSagaEditionVehicle' then return end
    if tostring(get(c,'name') or ''):match('^swseLocalFX') then return end
    shown=shown and get(c,'visible')~=false
    if visibleOnly and not shown then return end
    if c~=form and t=='form' then record=c end
    fn(c,t,shown,record)
    for _,x in ipairs(kids(c)) do visit(x,depth+1,shown,record) end
  end
  visit(form,0,true,nil)
end
local function isTab(e) return e.kind=='tab' or e.kind=='subtab' end
local function hide(e) for _,c in pairs(e.art or {}) do set(c,'visible',false) end end
local function restore(e)
  if e.base then
    set(e.ctrl,'strokeColor',e.base.stroke);set(e.ctrl,'strokeSize',e.base.size)
    if e.base.fill then set(e.ctrl,'color',e.base.fill) end
  end
  hide(e)
end
local KIND_KEYS={tab='fxTabsEnabled',subtab='fxSubTabsEnabled',button='fxButtonsEnabled',input='fxInputsEnabled',panel='fxPanelsEnabled',status='fxStatusEnabled'}
local function enabledKind(sh,kind) return sh[KIND_KEYS[kind]]~=false end
local function bind(e,ctrl,event,fn)
  if not ctrl or not ctrl.addEventListener then return end
  local ok,id=pcall(function() return ctrl:addEventListener(event,fn) end)
  if ok then e.listeners[#e.listeners+1]={ctrl=ctrl,id=id} end
end
local ASSET='/FichaRPGmeister/frames/holo724_'
local function decorate(e,pal,perf)
  e.art=e.art or {}
  local function add(key,file)
    if e.art[key] then return end
    local r=file and GUI.newImage() or GUI.newRectangle()
    r.name='swseLocalFX'..key..e.id;r.parent=e.ctrl
    r.left=0;r.top=0;r.width=1;r.height=1
    if file then r.src=ASSET..file..'.png';r.style='stretch';r.editable=false;r.showProgress=false
    else r.color=pal.cyan;r.strokeSize=0 end
    r.opacity=0;r.visible=false;r.hitTest=false;r.canFocus=false;e.art[key]=r
    ART_STATE[r]={opacity=0,visible=false,left=0,top=0,width=1,height=1}
  end
  add('glowTop','glow_h');add('glowBottom','glow_h');add('glowLeft','glow_v');add('glowRight','glow_v')
  if e.kind=='input' or perf then return end
  add('scan','scan_band');add('scanlines','scanlines')
  if e.kind=='panel' then add('noise','noise_0');add('projection','projection') end
  if e.kind=='status' then add('ghost');add('ghostRed');add('glitch');add('glitchEcho');add('noise','noise_0') end
end
local function box(c,x,y,w,h,opacity,on)
  set(c,'left',math.max(0,x));set(c,'top',math.max(0,y))
  set(c,'width',math.max(0,w));set(c,'height',math.max(0,h))
  set(c,'opacity',math.min(1,math.max(0,opacity)));set(c,'visible',on==true)
end
local function fill(e,s,p,on)
  if not e.base.fill then return end
  local key=token(e.base.fill);local col=key and p[key] or e.base.fill
  if on and s.fxTransparencyEnabled~=false then
    local alpha=e.kind=='panel' and 'C7' or 'E8'
    set(e.ctrl,'color',col:sub(1,7)..alpha)
  else set(e.ctrl,'color',col) end
end
local function emission(e,s,p,w,h,gain,elapsed,perf)
  if e.lastPerf~=perf then hide(e);e.lastPerf=perf end
  decorate(e,p,perf)
  local a=e.art;local time=elapsed+e.phase
  local wave=(1-math.cos(time*e.speed))/2
  local interactive=e.hover or e.focus or e.pressedUntil>elapsed
  local subtle=e.kind=='panel' or e.kind=='subtab'
  local amount=e.kind=='panel' and 0.27 or (e.kind=='subtab' and 0.43 or 0.66)
  local pulse=not perf and s.fxPulseEnabled~=false and (isTab(e) or e.kind=='button' and interactive)
  local light=amount*gain*(pulse and (0.72+wave*0.28) or 1)
  local signal=e.kind=='status'
  local flicker=not perf and signal and s.fxFlickerEnabled~=false and ((time%7.9)<0.17)
  if flicker then light=light*0.6 end
  local glow=s.fxGlowEnabled~=false
  local edge=subtle and 4 or 6
  box(a.glowTop,2,0,w-4,edge,light,glow)
  box(a.glowBottom,2,h-edge,w-4,edge,light*0.9,glow)
  box(a.glowLeft,0,2,edge,h-4,light*0.5,glow)
  box(a.glowRight,w-edge,2,edge,h-4,light*0.5,glow)
  -- Inputs only respond through their own border. Their text never flickers.
  if e.kind=='input' or perf then return end
  local phase=(time*(e.kind=='panel' and 0.09 or 0.34))%1
  local scan=s.fxScanEnabled~=false
  if e.kind=='panel' then
    -- Panel scanning follows the emitter rail, outside the data and fields.
    box(a.scan,0,3+phase*math.max(1,h-13),3,10,0.6*gain,scan)
    box(a.scanlines,4,h-3,math.min(120,w-8),2,0.22*gain,scan)
    local cw=math.min(54,w*0.14)
    box(a.projection,w-cw-4,h-8,cw,6,0.24*gain,s.fxProjectionEnabled~=false)
    box(a.noise,w-30,1,26,3,0.16*gain,s.fxNoiseEnabled~=false)
    if s.fxNoiseEnabled~=false then set(a.noise,'src',ASSET..'noise_'..((math.floor(time*3)+e.id)%3)..'.png') end
    return
  end
  -- Tabs and buttons have a local travelling edge; no screen-wide sweep exists.
  local span=math.min(32,w*0.24)
  local x=3+phase*math.max(1,w-span-6)
  box(a.scan,x,h-4,span,2,0.56*gain,scan)
  box(a.scanlines,3,1,w-6,2,0.14*gain,scan and isTab(e))
  -- Ghost and glitches represent the signal indicator, never editable values.
  if signal then
    set(a.ghost,'color',p.cyan);set(a.ghostRed,'color','#C26ACD')
    box(a.ghost,x,h-6,span,1,0.38*gain,s.fxGhostEnabled~=false)
    box(a.ghostRed,math.min(w-span-1,x+2),h-5,span,1,0.2*gain,s.fxGhostEnabled~=false)
    local glitch=s.fxGlitchEnabled~=false and (time%6.7)<0.16
    set(a.glitch,'color',p.cyan);set(a.glitchEcho,'color','#C26ACD')
    box(a.glitch,4,1,math.min(24,w-8),1,0.68*gain,glitch)
    box(a.glitchEcho,7,2,math.min(16,w-10),1,0.4*gain,glitch)
    box(a.noise,w-18,1,14,2,0.18*gain,s.fxNoiseEnabled~=false)
    if s.fxNoiseEnabled~=false then set(a.noise,'src',ASSET..'noise_'..((math.floor(time*5)+e.id)%3)..'.png') end
  end
end
local function attach(form,idx,c,kind,pal)
  local old=idx.byControl[c];if old then return old end
  idx.nextId=(idx.nextId or 0)+1;local id=idx.nextId
  local e={ctrl=c,kind=kind,id=id,listeners={},hover=false,focus=false,pressedUntil=0,phase=(id*0.61803398875)%8,speed=1.1+(id%5)*0.17}
  e.base={stroke=get(c,'strokeColor') or pal.border,size=tonumber(get(c,'strokeSize')) or 1,fill=(tag(c)=='rectangle' and get(c,'color') or nil)}
  idx.byControl[c]=e;idx.entries[#idx.entries+1]=e
  bind(e,c,'onResize',function() M.invalidate(form) end)
  local target=isTab(e) and get(c,'parent') or c
  local function paint()
    local sh=get(form,'sheet');local p=M.palettes[modeOf(form)]
    local on=sh and sh.fxEnabled==true and enabledKind(sh,kind)
    local active=isTab(e) and navActive(form,c)
    local respond=on and (e.hover or e.focus)
    set(c,'strokeColor',respond and (e.focus and p.cyan or p.gold) or (active and p.cyan or e.base.stroke))
    set(c,'strokeSize',active and 2 or (respond and 1.5 or e.base.size))
    if M.interact then M.interact(form,e) end
  end
  if kind=='button' or kind=='input' or isTab(e) then
    bind(e,target,'onMouseEnter',function() e.hover=true;paint() end)
    bind(e,target,'onMouseLeave',function() e.hover=false;paint() end)
  end
  if kind=='button' then bind(e,c,'onClick',function() e.pressedUntil=(form._swseFxElapsed or 0)+0.36;paint() end) end
  if kind=='input' then
    for _,x in ipairs(kids(c)) do
      if tag(x)=='edit' or tag(x)=='comboBox' or tag(x)=='textEditor' then
        bind(e,x,'onEnter',function() e.focus=true;paint() end)
        bind(e,x,'onExit',function() e.focus=false;paint() end)
      end
    end
  end
  return e
end
local function readConfig(form)
  local sh=get(form,'sheet');if not sh then return nil end
  local cfg={enabled=sh.fxEnabled==true,fxPerformanceMode=sh.fxPerformanceMode==true,fxIntensity=tostring(sh.fxIntensity or 'medium'):lower()}
  for _,key in pairs(KIND_KEYS) do cfg[key]=sh[key]~=false end
  for _,key in ipairs({'fxScanEnabled','fxGhostEnabled','fxGlitchEnabled','fxPulseEnabled','fxGlowEnabled','fxNoiseEnabled','fxFlickerEnabled','fxTransparencyEnabled','fxProjectionEnabled'}) do cfg[key]=sh[key]~=false end
  cfg.gain=cfg.fxIntensity=='low' and 0.45 or (cfg.fxIntensity=='high' and 1 or 0.7)
  cfg.delay=cfg.fxIntensity=='high' and 80 or (cfg.fxIntensity=='low' and 170 or 110)
  return cfg
end
local function disposeEntry(e)
  for _,listener in ipairs(e.listeners) do
    if listener.id then pcall(function() listener.ctrl:removeEventListener(listener.id) end) end
  end
  for _,art in pairs(e.art or {}) do ART_STATE[art]=nil;pcall(function() art:destroy() end) end
end
function M.removeRecord(form,record)
  local idx=form and form._swseComponentIndex;if not idx or not record then return end
  for i=#idx.entries,1,-1 do
    local e=idx.entries[i]
    if e.record==record then
      disposeEntry(e);idx.byControl[e.ctrl]=nil;idx.animated[e]=nil;table.remove(idx.entries,i)
    end
  end
  M.invalidate(form)
end
local function watch(form,idx,c,t)
  if idx.watched[c] then return end
  if c==form then
    idx.watched[c]=true
    bind(idx,c,'onShow',function() form._swseFxShown=true;M.startFX(form) end)
    bind(idx,c,'onHide',function() form._swseFxShown=false;M.stopFX(form) end)
    bind(idx,c,'onResize',function() M.invalidate(form) end)
    bind(idx,c,'onNodeUnready',function() M.resetIndex(form) end)
  elseif t=='recordList' or t=='gridRecordList' then
    idx.watched[c]=true
    bind(idx,c,'onEndEnumeration',function() M.invalidate(form) end)
    bind(idx,c,'onItemRemoved',function(_,record) M.removeRecord(form,record) end)
  end
end
local function render(form,e,elapsed)
  local cfg=form._swseFxConfig;if not cfg then return end
  local p=M.palettes[modeOf(form)];local c=e.ctrl
  local on=cfg.enabled and e.visible and enabledKind(cfg,e.kind)
  local interactive=e.hover or e.focus or e.pressedUntil>elapsed
  local active=e.active
  fill(e,cfg,p,on)
  if not on or (isTab(e) and not active and not e.hover) then
    if e.rendering then hide(e);if not isTab(e) then restore(e) end end
    e.rendering=false;return false
  end
  local accent=interactive and (e.focus and p.cyan or p.gold) or (active and p.cyan or e.base.stroke)
  local size=active and 2 or (interactive and 1.5 or e.base.size)
  if not cfg.fxPerformanceMode and cfg.fxPulseEnabled and (active or e.kind=='button' and interactive) then
    size=size+(1-math.cos((elapsed+e.phase)*e.speed))*0.15*cfg.gain*(e.kind=='subtab' and 0.55 or 1)
  end
  set(c,'strokeColor',accent);set(c,'strokeSize',size)
  local wanted=e.kind=='panel' or e.kind=='status' or active or interactive
  if wanted and e.width>16 and e.height>10 then
    local ok,err=pcall(emission,e,cfg,p,e.width,e.height,cfg.gain,elapsed,cfg.fxPerformanceMode)
    if not ok then hide(e);form._swseFxLastError=tostring(err);return false end
    e.rendering=true
  else
    if e.rendering then hide(e) end;e.rendering=false;return false
  end
  if cfg.fxPerformanceMode or e.kind=='input' then return false end
  if e.kind=='panel' then return cfg.fxScanEnabled or cfg.fxNoiseEnabled end
  if e.kind=='status' then return cfg.fxScanEnabled or cfg.fxGhostEnabled or cfg.fxGlitchEnabled or cfg.fxFlickerEnabled or cfg.fxNoiseEnabled end
  return cfg.fxScanEnabled or cfg.fxPulseEnabled
end
local function rebuild(form)
  local idx=form._swseComponentIndex;local p=M.palettes[modeOf(form)]
  local old=idx.visible or {};local current={};local seen={}
  walk(form,function(c,t,_,record)
    watch(form,idx,c,t)
    local e=idx.byControl[c]
    if not e then
      local kind=classify(c,t)
      if kind then recolor(c,p);e=attach(form,idx,c,kind,p) end
    end
    if e then
      e.record=record;e.visible=true;e.active=isTab(e) and navActive(form,c) or false
      e.width=tonumber(get(c,'width')) or 0;e.height=tonumber(get(c,'height')) or 0
      current[#current+1]=e;seen[e]=true
    end
  end,true)
  for _,e in ipairs(old) do
    if not seen[e] then e.visible=false;e.hover=false;e.focus=false;restore(e);e.rendering=false end
  end
  idx.visible=current;idx.dirty=false
end
local scheduleTick
local function repaint(form)
  local idx=form._swseComponentIndex;if not idx then return end
  form._swseFxConfig=readConfig(form)
  if not form._swseFxConfig or not form._swseFxConfig.enabled then M.stopFX(form);return end
  if idx.dirty then rebuild(form) end
  idx.animated={}
  local elapsed=tonumber(form._swseFxElapsed) or 0
  for _,e in ipairs(idx.visible or {}) do if render(form,e,elapsed) then idx.animated[e]=true end end
  scheduleTick(form)
end
scheduleTick=function(form)
  local idx=form._swseComponentIndex
  if not form._swseFxActive or form._swseFxShown==false or not idx then return end
  if next(idx.animated)==nil then
    if form._swseFxTimer then clearTimeout(form._swseFxTimer);form._swseFxTimer=nil end
    return
  end
  if form._swseFxTimer then return end
  local cfg=form._swseFxConfig;local delay=cfg and cfg.delay or 110
  local gen=form._swseFxGeneration
  form._swseFxTimer=setTimeout(function()
    form._swseFxTimer=nil
    if form._swseFxGeneration~=gen or not form._swseFxActive then return end
    if form._swseFxShown==false then M.stopFX(form);return end
    if idx.dirty then repaint(form);return end
    local elapsed=(tonumber(form._swseFxElapsed) or 0)+delay/1000;form._swseFxElapsed=elapsed
    for e in pairs(idx.animated) do if not render(form,e,elapsed) then idx.animated[e]=nil end end
    scheduleTick(form)
  end,delay)
end
function M.invalidate(form)
  local idx=form and form._swseComponentIndex;if not idx then return end
  idx.dirty=true
  if not form._swseFxActive or form._swseFxShown==false or form._swseFxRefreshTimer then return end
  local gen=form._swseFxGeneration
  form._swseFxRefreshTimer=setTimeout(function()
    form._swseFxRefreshTimer=nil
    if form._swseFxActive and form._swseFxGeneration==gen and form._swseFxShown~=false then repaint(form) end
  end,30)
end
function M.interact(form,e)
  local idx=form._swseComponentIndex
  if not idx or not form._swseFxActive or form._swseFxShown==false or not e.visible then return end
  if render(form,e,tonumber(form._swseFxElapsed) or 0) then idx.animated[e]=true else idx.animated[e]=nil end
  scheduleTick(form)
end
function M.apply(form,mode,force)
  if not form then return end;mode=modeOf(form,mode);local pal=M.palettes[mode]
  if form._swseThemeApplied and form._swseThemeMode==mode and not force then M.invalidate(form);return mode end
  local idx=form._swseComponentIndex or {entries={},byControl={},listeners={},watched={},visible={},animated={},dirty=true}
  form._swseComponentIndex=idx
  pcall(function() form:setTheme(mode) end)
  walk(form,function(c,t,shown,record)
    watch(form,idx,c,t)
    local n=tostring(get(c,'name') or '')
    if navName(n) then
      if shown then local e=attach(form,idx,c,tabKind(n),pal);e.record=record end
      return
    end
    local e=idx.byControl[c];if e then restore(e) end
    recolor(c,pal)
    if t=='layout' and (n=='swseScreenFrame' or n=='holoPageHost' or n:match('^page') or n=='hangarIndexPanel' or n=='hangarDetailPanel') then
      set(c,'frameStyle','/FichaRPGmeister/frames/swse_'..(n=='swseScreenFrame' and 'screen_' or 'page_')..mode..'.xml')
    end
    if t=='edit' or t=='comboBox' or t=='textEditor' then
      set(c,'transparent',true);set(c,'fontColor',pal.text)
    elseif t=='label' and tostring(get(c,'field') or '')~='' then set(c,'fontColor',pal.text) end
    local kind=e and e.kind or (shown and classify(c,t))
    if kind then
      e=e or attach(form,idx,c,kind,pal);e.record=record
      e.base={stroke=get(c,'strokeColor') or pal.border,size=tonumber(get(c,'strokeSize')) or 1,fill=t=='rectangle' and get(c,'color') or nil}
    end
  end)
  form._swseThemeMode=mode;form._swseThemeApplied=true;idx.dirty=true
  return mode
end
function M.stopFX(form)
  if not form then return end
  form._swseFxGeneration=(tonumber(form._swseFxGeneration) or 0)+1;form._swseFxActive=false
  for _,key in ipairs({'_swseFxTimer','_swseFxRefreshTimer'}) do
    if form[key] then pcall(clearTimeout,form[key]);form[key]=nil end
  end
  local idx=form._swseComponentIndex;local p=M.palettes[modeOf(form)]
  if idx then
    idx.animated={}
    for _,e in ipairs(idx.entries) do
      e.rendering=false
      if isTab(e) then
        hide(e);local active=navActive(form,e.ctrl)
        set(e.ctrl,'strokeColor',active and p.cyan or p.borderSoft);set(e.ctrl,'strokeSize',active and 2 or 1)
      else restore(e) end
    end
  end
end
function M.startFX(form,mode)
  if not form then return end
  local sh=get(form,'sheet');if not sh or sh.fxEnabled~=true then M.stopFX(form);return end
  mode=modeOf(form,mode)
  if not form._swseComponentIndex or form._swseThemeMode~=mode then M.apply(form,mode) end
  if form._swseFxShown==nil then form._swseFxShown=get(form,'isShowing')~=false end
  if form._swseFxShown==false then return end
  if form._swseFxActive then return end
  form._swseFxGeneration=(tonumber(form._swseFxGeneration) or 0)+1;form._swseFxActive=true
  form._swseComponentIndex.dirty=true
  repaint(form)
end
function M.resetIndex(form)
  if not form then return end;M.stopFX(form)
  pcall(function() require('swse_runtime_geometry.lua').stop(form) end)
  local idx=form._swseComponentIndex
  if idx then
    for _,e in ipairs(idx.entries) do disposeEntry(e) end
    for _,listener in ipairs(idx.listeners) do if listener.id then pcall(function() listener.ctrl:removeEventListener(listener.id) end) end end
  end
  form._swseComponentIndex=nil;form._swseThemeApplied=nil;form._swseFxElapsed=nil;form._swseFxShown=nil;form._swseFxConfig=nil
end
return M
