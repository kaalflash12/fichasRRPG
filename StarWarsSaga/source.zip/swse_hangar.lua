-- Persistent ship records owned by one character. Existing vehicle rules are reused.
local NDB=require('ndb.lua')
local VEH=require('swse_vehicle_630.lua')
local M={version='7.3.2'}
local visualFields={'uiTheme','fxEnabled','fxIntensity','fxPerformanceMode','fxScanEnabled','fxGhostEnabled','fxGlitchEnabled','fxPulseEnabled','fxTabsEnabled','fxSubTabsEnabled','fxStatusEnabled','fxButtonsEnabled','fxInputsEnabled','fxPanelsEnabled','fxGlowEnabled','fxNoiseEnabled','fxFlickerEnabled','fxTransparencyEnabled','fxProjectionEnabled'}
M.visualFields=visualFields
function M.nodes(root)
 if not root or not root.hangarShips then return {} end
 return NDB.getChildNodes(root.hangarShips)
end
function M.belongs(root,node)
 if not root or not node then return false end
 for _,n in ipairs(M.nodes(root)) do if n==node then return true end end
 return false
end
function M.ensure(root)
 if not root then return end
 if root.hangarShips==nil then NDB.createChildNode(root,'hangarShips') end
 local seq=math.max(0,math.floor(tonumber(root.hangarSequence) or 0))
 local seen={}
 for _,n in ipairs(M.nodes(root)) do
  local id=tostring(n.hangarShipId or '')
  seq=math.max(seq,tonumber(id:match('^ship_(%d+)$')) or 0)
 end
 for _,n in ipairs(M.nodes(root)) do
  local id=tostring(n.hangarShipId or '')
  if id=='' or seen[id] then seq=seq+1; id='ship_'..seq; n.hangarShipId=id end
  seen[id]=true
 end
 if root.hangarSequence~=seq then root.hangarSequence=seq end
end
function M.syncVisual(root,node)
 if not M.belongs(root,node) then return end
 for _,field in ipairs(visualFields) do
  local value=root[field]
  if value~=nil and node[field]~=value then node[field]=value end
 end
end
function M.find(root,id)
 if id==nil or tostring(id)=='' then return nil end
 for _,n in ipairs(M.nodes(root)) do if tostring(n.hangarShipId)==tostring(id) then return n end end
end
function M.selected(root)
 return root and M.find(root,root.hangarSelectedId) or nil
end
function M.select(root,node)
 if not root then return false end
 if node and not M.belongs(root,node) then return false end
 local id=node and node.hangarShipId or nil
 if root.hangarSelectedId~=id then root.hangarSelectedId=id end
 return true
end
function M.add(root)
 if not root then return nil end
 M.ensure(root)
 local seq=(tonumber(root.hangarSequence) or 0)+1
 root.hangarSequence=seq
 local node=NDB.createChildNode(root.hangarShips,'ship')
 node.hangarShipId='ship_'..seq
 node.vehicleName='Nova nave'
 node.vehicleType='Nave'
 VEH.ensure(node)
 M.syncVisual(root,node)
 M.select(root,node)
 return node
end
function M.remove(root,node)
 if not M.belongs(root,node) then return false end
 if root.hangarSelectedId==node.hangarShipId then M.select(root,nil) end
 NDB.deleteNode(node)
 return true
end
return M
