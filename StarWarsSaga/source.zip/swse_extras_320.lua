return {
    languages={
        {
            name="Aleena",
            name_pt="Aleena"
        },
        {
            name="Amanese",
            name_pt="Amanês"
        },
        {
            name="Aqualish",
            name_pt="Aqualish"
        },
        {
            name="Arconese",
            name_pt="Arconese"
        },
        {
            name="Arkanian",
            name_pt="Arkanian"
        },
        {
            name="Balosar",
            name_pt="Balosar"
        },
        {
            name="Barabel",
            name_pt="Barabel"
        },
        {
            name="Basic",
            name_pt="Básico"
        },
        {
            name="Batorese",
            name_pt="Batorês"
        },
        {
            name="Binary",
            name_pt="Binário"
        },
        {
            name="Bith",
            name_pt="Bith"
        },
        {
            name="Bocce",
            name_pt="Bocce"
        },
        {
            name="Bothese",
            name_pt="Bothese"
        },
        {
            name="Caamasi",
            name_pt="Caamasi"
        },
        {
            name="Catharese",
            name_pt="Catarese"
        },
        {
            name="Cerean",
            name_pt="Cereã"
        },
        {
            name="Chagri",
            name_pt="Chagri"
        },
        {
            name="Cheunh",
            name_pt="Cheunh"
        },
        {
            name="Chistori",
            name_pt="Chistori"
        },
        {
            name="Clawdite",
            name_pt="Clawdite"
        },
        {
            name="Codruese",
            name_pt="Bacalhau"
        },
        {
            name="Dashadi",
            name_pt="Dashadi"
        },
        {
            name="Deveronese",
            name_pt="Deveronês"
        },
        {
            name="Dosh",
            name_pt="Dosh"
        },
        {
            name="Draethos",
            name_pt="Draethos"
        },
        {
            name="Dug",
            name_pt="Dug"
        },
        {
            name="Durese",
            name_pt="Durese"
        },
        {
            name="Ewokese",
            name_pt="Ewokese"
        },
        {
            name="Falleen",
            name_pt="Falleen"
        },
        {
            name="Feeorin",
            name_pt="Feorina"
        },
        {
            name="Felucianese",
            name_pt="Felucianês"
        },
        {
            name="Gammorean",
            name_pt="Gammoreano"
        },
        {
            name="Gand",
            name_pt="Gand"
        },
        {
            name="Gen'Dai",
            name_pt="Gen'Dai"
        },
        {
            name="Geonosian",
            name_pt="Geonosiano"
        },
        {
            name="Gran",
            name_pt="Gran"
        },
        {
            name="Gunganese",
            name_pt="Gunganês"
        },
        {
            name="Hapan",
            name_pt="Hapan"
        },
        {
            name="High Galactic",
            name_pt="Galáctico Alto"
        },
        {
            name="Honoghran",
            name_pt="Honoghran"
        },
        {
            name="Houk",
            name_pt="Houk"
        },
        {
            name="Huttese",
            name_pt="Huttese"
        },
        {
            name="Iktotchese",
            name_pt="Iktotchese"
        },
        {
            name="Ithorese",
            name_pt="Itorese"
        },
        {
            name="Jawa",
            name_pt="Jawa"
        },
        {
            name="Jawa Trade Language",
            name_pt="Jawa Trade Language"
        },
        {
            name="Kaleesh",
            name_pt="Kaleesh"
        },
        {
            name="Kaminoan",
            name_pt="Kaminoan"
        },
        {
            name="Kel Dor",
            name_pt="Kel Dor"
        },
        {
            name="Kerkoidese",
            name_pt="Kerkoidese"
        },
        {
            name="Khilese",
            name_pt="Khilese"
        },
        {
            name="Lekku",
            name_pt="Lekku"
        },
        {
            name="Lurmese",
            name_pt="Lurmese"
        },
        {
            name="Mando'a",
            name_pt="Mando'a"
        },
        {
            name="Massan",
            name_pt="Massan"
        },
        {
            name="Miralukese",
            name_pt="Miralukese"
        },
        {
            name="Mon Calamarian",
            name_pt="Mon Calamarian"
        },
        {
            name="Nagaian",
            name_pt="Nagaiano"
        },
        {
            name="Nautila",
            name_pt="Nautila"
        },
        {
            name="Nazren",
            name_pt="Nazren"
        },
        {
            name="Neimoidian",
            name_pt="Neimoidiano"
        },
        {
            name="Nelvaanese",
            name_pt="Nelvaanese"
        },
        {
            name="Nosaurian",
            name_pt="Nassauro"
        },
        {
            name="Pak Pak",
            name_pt="Pak Pak"
        },
        {
            name="Phindian",
            name_pt="Phindian"
        },
        {
            name="Quarrenese",
            name_pt="Quarrenese"
        },
        {
            name="Rakata",
            name_pt="Rakata"
        },
        {
            name="Rodese",
            name_pt="Rodesa"
        },
        {
            name="Ryl",
            name_pt="Ryl"
        },
        {
            name="Ryn",
            name_pt="Ryn"
        },
        {
            name="Savrip",
            name_pt="Savrip"
        },
        {
            name="Selkath",
            name_pt="Selkath"
        },
        {
            name="Semblan",
            name_pt="Semblan"
        },
        {
            name="Shyriiwook",
            name_pt="Shyriiwook"
        },
        {
            name="Sith",
            name_pt="Sith"
        },
        {
            name="Skakoverbal",
            name_pt="Skakoverbal"
        },
        {
            name="Snivvian",
            name_pt="Snivvian"
        },
        {
            name="Sriluurian",
            name_pt="Sriluuriano"
        },
        {
            name="Sullustese",
            name_pt="Sullustese"
        },
        {
            name="Talz",
            name_pt="Talz"
        },
        {
            name="Thakwaashi",
            name_pt="Thakwaashi"
        },
        {
            name="Togorian",
            name_pt="Togoriano"
        },
        {
            name="Togruti",
            name_pt="Togruti"
        },
        {
            name="Toydarian",
            name_pt="Toydarian"
        },
        {
            name="Trianii",
            name_pt="Trianii"
        },
        {
            name="Tusken",
            name_pt="Tusken"
        },
        {
            name="Ubeninal",
            name_pt="Ubeninal"
        },
        {
            name="Ubese",
            name_pt="Ubese"
        },
        {
            name="Umbarese",
            name_pt="Umbarês"
        },
        {
            name="Utapese",
            name_pt="Utapese"
        },
        {
            name="Whiphid",
            name_pt="Uísque"
        },
        {
            name="Wroonian",
            name_pt="Wroonian"
        },
        {
            name="Yarkora",
            name_pt="Yarkora"
        },
        {
            name="Yevethan",
            name_pt="Yevethan"
        },
        {
            name="Yuuzhan Vong",
            name_pt="Yuuzhan Vong"
        },
        {
            name="Yuzz",
            name_pt="Yuzz"
        },
        {
            name="Zabrak",
            name_pt="Zabrak"
        }
    },
    force_regimens={
        {
            name="Awaken Force Sensitivity",
            name_pt="Despertar Sensibilidade à Força"
        },
        {
            name="Eyes of the Force",
            name_pt="Olhos da Força"
        },
        {
            name="Oxygen Bottle",
            name_pt="Garrafa de Oxigênio"
        },
        {
            name="Quiet the Mind",
            name_pt="Aquietar a Mente"
        },
        {
            name="Telekinetic Practice",
            name_pt="Prática Telecinética"
        },
        {
            name="Sparring Practice",
            name_pt="Prática de Combate"
        },
        {
            name="Training Remote",
            name_pt="Remoto de Treinamento"
        },
        {
            name="Vo'ren's First Cadence",
            name_pt="Primeira Cadência de Vo'ren"
        },
        {
            name="Vo'ren's Second Cadence",
            name_pt="Segunda Cadência de Vo'ren"
        },
        {
            name="Vo'ren's Third Cadence",
            name_pt="Terceira Cadência de Vo'ren"
        },
        {
            name="Vo'ren's Fourth Cadence",
            name_pt="Quarta Cadência de Vo'ren"
        },
        {
            name="Vo'ren's Fifth Cadence",
            name_pt="Quinta Cadência de Vo'ren"
        }
    },
    starship_maneuvers={
        {
            name="Ackbar Slash",
            name_pt="Golpe de Ackbar",
            descriptor="",
            descriptor_pt=""
        },
        {
            name="Afterburn",
            name_pt="Pós-combustão",
            descriptor="",
            descriptor_pt=""
        },
        {
            name="Angle Deflector Shields",
            name_pt="Inclinar Escudos Defletores",
            descriptor="attack patern",
            descriptor_pt="padrão de ataque"
        },
        {
            name="Attack Formation Zeta Nine",
            name_pt="Formação de Ataque Zeta Nove",
            descriptor="attack patern",
            descriptor_pt="padrão de ataque"
        },
        {
            name="Attack Pattern Delta",
            name_pt="Padrão de Ataque Delta",
            descriptor="attack patern",
            descriptor_pt="padrão de ataque"
        },
        {
            name="Corellian Slip",
            name_pt="Deslizamento Corelliano",
            descriptor="",
            descriptor_pt=""
        },
        {
            name="Counter",
            name_pt="Contra-Manobra",
            descriptor="dogfight",
            descriptor_pt="combate aéreo"
        },
        {
            name="Darklighter Spin",
            name_pt="Giro Darklighter",
            descriptor="",
            descriptor_pt=""
        },
        {
            name="Devastating Hit",
            name_pt="Acerto Devastador",
            descriptor="gunner",
            descriptor_pt="artilheiro"
        },
        {
            name="Engine Hit",
            name_pt="Acerto no Motor",
            descriptor="gunner",
            descriptor_pt="artilheiro"
        },
        {
            name="Evasive Action",
            name_pt="Ação Evasiva",
            descriptor="dogfight",
            descriptor_pt="combate aéreo"
        },
        {
            name="Explosive Shot",
            name_pt="Disparo Explosivo",
            descriptor="gunner",
            descriptor_pt="artilheiro"
        },
        {
            name="Howlrunner Formation",
            name_pt="Formação Howlrunner",
            descriptor="attack patern",
            descriptor_pt="padrão de ataque"
        },
        {
            name="I Have You Now",
            name_pt="Agora Eu Te Peguei",
            descriptor="",
            descriptor_pt=""
        },
        {
            name="Intercept",
            name_pt="Interceptar",
            descriptor="",
            descriptor_pt=""
        },
        {
            name="Overwhelming Assault",
            name_pt="Assalto Avassalador",
            descriptor="attack pattern",
            descriptor_pt="padrão de ataque"
        },
        {
            name="Segnor's Loop",
            name_pt="Loop de Segnor",
            descriptor="",
            descriptor_pt=""
        },
        {
            name="Shield Hit",
            name_pt="Acerto no Escudo",
            descriptor="gunner",
            descriptor_pt="artilheiro"
        },
        {
            name="Skim the Surface",
            name_pt="Rasante de Superfície",
            descriptor="",
            descriptor_pt=""
        },
        {
            name="Skywalker Loop",
            name_pt="Loop de Skywalker",
            descriptor="dogfight",
            descriptor_pt="combate aéreo"
        },
        {
            name="Snap Roll",
            name_pt="Rolagem Brusca",
            descriptor="",
            descriptor_pt=""
        },
        {
            name="Tallon Roll",
            name_pt="Rolagem Tallon",
            descriptor="attack pattern",
            descriptor_pt="padrão de ataque"
        },
        {
            name="Target Lock",
            name_pt="Travar Alvo",
            descriptor="dogfight",
            descriptor_pt="combate aéreo"
        },
        {
            name="Target Sense",
            name_pt="Sentir Alvo",
            descriptor="Force",
            descriptor_pt="Força"
        },
        {
            name="Thruster Hit",
            name_pt="Acerto no Propulsor",
            descriptor="gunner",
            descriptor_pt="artilheiro"
        },
        {
            name="Wotan Weave",
            name_pt="Trançado Wotan",
            descriptor="",
            descriptor_pt=""
        },
        {
            name="Strike Formation",
            name_pt="Formação de Ataque",
            descriptor="attack pattern",
            descriptor_pt="padrão de ataque"
        }
    },
    droid_chassis={
        {
            name="Astromech Droid Chassis",
            name_pt="Chassi de Droide Astromecânico",
            description="Astromech droids are constructed with the following droid systems installed in each: \n\nwheeled locomotion 6\nwalking locomotion 4\nmagnetic feet\nheuristic processor\n6 tool appendages\n1 claw appendage\nastrogation buffer (5 memory units)\ndiagnostics package\ninternal storage (2 kg)",
            description_pt="Os dróides Astromech são construídos com os seguintes sistemas dróides instalados em cada um deles:\n\nlocomoção de rodas 6\nlocomoção em marcha 4\npés magnéticos\nprocessador heurístico\n6 apêndices de ferramentas\n1 apêndice de garra\nbuffer de astrogation (5 unidades de memória)\npacote de diagnóstico\narmazenagem interna (2 kg)"
        },
        {
            name="Battle Droid Chassis",
            name_pt="Chassi de Droide de Batalha",
            description="Battle droids are constructed with the following droid systems installed in each:\n\nwalking locomotion 6\nplasteel shell (+2 armor)\nbasic processor\ninternal comlink\nlocked access\n2 hand appendages\nvocabulator",
            description_pt="Os dróides de batalha são construídos com os seguintes sistemas dróides instalados em cada um deles:\n\nlocomoção em marcha 6\nrevestimento de plasteel (+2 armadura)\nprocessador básico\ncomunicação interna\nacesso bloqueado\n2 apêndices manuais\nvocabulário"
        },
        {
            name="Labor Droid Chassis",
            name_pt="Chassi de Droide de Trabalho",
            description="Labor droids are constructed with the following droid systems installed in each:\n\nwalking locomotion 6\ndurasteel shell (+4 armor)\nbasic processor\n2 claw appendages\nvocabulator",
            description_pt="Os dróides do trabalho são construídos com os seguintes sistemas dróides instalados em cada um:\n\nlocomoção em marcha 6\nconcha durasteel (+4 armadura)\nprocessador básico\n2 apêndices de garras\nvocabulário"
        },
        {
            name="Mechanic Droid Chassis",
            name_pt="Chassi de Droide Mecânico",
            description="Mechanic droids are constructed with the following droid systems installed in each:\n\nwalking locomotion 6 (or tracked or wheeled locomotion)\nbasic processor\n2 hand appendages\n4 tool appendages\ndiagnostics package\ninternal storage (2 kg)\nvocabulator",
            description_pt="Os dróides mecânicos são construídos com os seguintes sistemas dróides instalados em cada um deles:\n\nlocomoção caminhada 6 (ou locomoção rastreada ou de rodas)\nprocessador básico\n2 apêndices manuais\n4 anexos de ferramentas\npacote de diagnóstico\narmazenagem interna (2 kg)\nvocabulário"
        },
        {
            name="Medical Droid Chassis",
            name_pt="Chassi de Droide Médico",
            description="Medical droids are constructed with the following droid systems installed in each:\n\nwalking locomotion\nheuristic processor\n2 hand appendages\n1 tool appendage\nvocabulator\nimproved sensor package",
            description_pt="Os dróides médicos são construídos com os seguintes sistemas dróides instalados em cada um deles:\n\nlocomoção da marcha\nprocessador heurístico\n2 apêndices manuais\n1 apêndice da ferramenta\nvocabulário\npacote de sensor melhorado"
        },
        {
            name="Probe Droid Chassis",
            name_pt="Chassi de Droide Sonda",
            description="Probe droids are designed for surveillance and are constructed with the following droid systems installed in each:\n\nhovering locomotion 6\nheuristic processor\ninternal comlink\nlocked access\n1 hand appendage\n1 tool appendage\nimproved sensor package\ndarkvision",
            description_pt="Os dróides sonda são projetados para vigilância e são construídos com os seguintes sistemas dróides instalados em cada um deles:\n\nlocomoção pairando 6\nprocessador heurístico\ncomunicação interna\nacesso bloqueado\n1 apêndice da mão\n1 apêndice da ferramenta\npacote de sensor melhorado\nvisão escura"
        },
        {
            name="Protocol Droid Chassis",
            name_pt="Chassi de Droide de Protocolo",
            description="Protocol droids are constructed with the following droid systems installed in each:\n\nwalking locomotion 6\nbasic processor\n2 hand appendages\nvocabulator\ntranslator unit (DC 10)",
            description_pt="Os dróides de protocolo são construídos com os seguintes sistemas dróides instalados em cada um deles:\n\nlocomoção em marcha 6\nprocessador básico\n2 apêndices manuais\nvocabulário\nUnidade tradutora (DC 10)"
        },
        {
            name="Service Droid Chassis",
            name_pt="Chassi de Droide de Serviço",
            description="Service droids are constructed with the following droid systems installed in each:\n\nwalking locomotion 6\nbasic processor\n2 hand appendages\n1 tool mount\nvocabulator",
            description_pt="Os dróides de serviço são construídos com os seguintes sistemas dróides instalados em cada um deles:\n\nlocomoção em marcha 6\nprocessador básico\n2 apêndices manuais\n1 montagem de ferramentas\nvocabulário"
        }
    },
    droid_locomotion={
        {
            name="Walking",
            name_pt="Caminhada",
            small_max=4,
            medium_max=6,
            large_max=8,
            cost_factor=10
        },
        {
            name="Wheeled",
            name_pt="Rodas",
            small_max=6,
            medium_max=8,
            large_max=10,
            cost_factor=5
        },
        {
            name="Tracked",
            name_pt="Esteiras",
            small_max=4,
            medium_max=6,
            large_max=8,
            cost_factor=20
        },
        {
            name="Hovering",
            name_pt="Flutuação",
            small_max=6,
            medium_max=6,
            large_max=6,
            cost_factor=100
        },
        {
            name="Flying",
            name_pt="Voo",
            small_max=9,
            medium_max=12,
            large_max=12,
            cost_factor=200
        },
        {
            name="Burrow",
            name_pt="Escavação",
            small_max=4,
            medium_max=6,
            large_max=8,
            cost_factor=200
        },
        {
            name="Underwater",
            name_pt="Subaquático",
            small_max=4,
            medium_max=6,
            large_max=8,
            cost_factor=20
        }
    },
    droid_appendages={
        {
            name="Probe",
            name_pt="Sonda",
            cost=2,
            weight=0.5
        },
        {
            name="Tool",
            name_pt="Ferramenta",
            cost=10,
            weight=2
        },
        {
            name="Instrument",
            name_pt="Instrumento",
            cost=5,
            weight=1
        },
        {
            name="Claw",
            name_pt="Garra",
            cost=20,
            weight=5
        },
        {
            name="Hand",
            name_pt="Mão",
            cost=50,
            weight=5
        }
    },
    droid_armor={
        {
            name="Durasteel plating",
            name_pt="Chapas durasteel",
            cost=3600,
            reflex=6,
            max_dex=3,
            weight=12,
            availability="l",
            type=""
        },
        {
            name="Durasteel shell",
            name_pt="Concha durasteel",
            cost=1600,
            reflex=4,
            max_dex=4,
            weight=8,
            availability="c",
            type=""
        },
        {
            name="Duravlex shell",
            name_pt="Duravlex shell",
            cost=1000,
            reflex=4,
            max_dex=3,
            weight=10,
            availability="l",
            type=""
        },
        {
            name="Laminanium plating",
            name_pt="Chapas de laminanium",
            cost=3000,
            reflex=4,
            max_dex=3,
            weight=15,
            availability="m",
            type=""
        },
        {
            name="Plasteel shell",
            name_pt="Plasteel shell",
            cost=400,
            reflex=2,
            max_dex=5,
            weight=2,
            availability="c",
            type=""
        },
        {
            name="Quadanium plating",
            name_pt="Chapa quadrada",
            cost=2500,
            reflex=5,
            max_dex=3,
            weight=10,
            availability="l",
            type=""
        },
        {
            name="Quadanium shell",
            name_pt="Carapaça de quadânio",
            cost=900,
            reflex=3,
            max_dex=4,
            weight=3,
            availability="c",
            type=""
        },
        {
            name="Duranium plating",
            name_pt="Revestimento de duranium",
            cost=6400,
            reflex=8,
            max_dex=2,
            weight=16,
            availability="r",
            type=""
        },
        {
            name="Durasteel battle armor",
            name_pt="Armadura de batalha Durasteel",
            cost=9600,
            reflex=8,
            max_dex=3,
            weight=8,
            availability="r",
            type=""
        },
        {
            name="Crystadurium plating",
            name_pt="Chapas de crystadurium",
            cost=50000,
            reflex=10,
            max_dex=2,
            weight=30,
            availability="m",
            type="r"
        },
        {
            name="Duranium battle armor",
            name_pt="Armadura de batalha Duranium",
            cost=10000,
            reflex=10,
            max_dex=2,
            weight=10,
            availability="m",
            type=""
        },
        {
            name="Heavy laminanium plating",
            name_pt="Chapas de laminado pesado",
            cost=20000,
            reflex=12,
            max_dex=2,
            weight=15,
            availability="m",
            type="r"
        },
        {
            name="Mandalorian steel shell",
            name_pt="Carapaça de aço mandaroriano",
            cost=8100,
            reflex=9,
            max_dex=3,
            weight=9,
            availability="m",
            type="r"
        },
        {
            name="Neutronium plating",
            name_pt="Revestimento de neutrónio",
            cost=12100,
            reflex=11,
            max_dex=1,
            weight=20,
            availability="m",
            type=""
        }
    },
    droid_accessories={
        {
            name="Antitheft comlink locator",
            name_pt="Localização de comunicação anti-roubo",
            cost=100,
            cost_text="100",
            weight=0.5,
            weight_text=".5 kg ",
            availability=""
        },
        {
            name="Audio enhancers",
            name_pt="Melhoradores de áudio",
            cost=2000,
            cost_text="2000",
            weight=1.0,
            weight_text="1 kg ",
            availability=""
        },
        {
            name="Audio-radial stunner",
            name_pt="atordoador de raios áudio",
            cost=5000,
            cost_text="5000",
            weight=3.0,
            weight_text="3 kg ",
            availability="Restricted "
        },
        {
            name="Automap",
            name_pt="Mapa automático",
            cost=1000,
            cost_text="1000",
            weight=2.0,
            weight_text="2 kg ",
            availability=""
        },
        {
            name="Blaster recharge interface",
            name_pt="Interface de recarga Blaster",
            cost=300,
            cost_text="300",
            weight=1.0,
            weight_text="1 kg ",
            availability="Licensed "
        },
        {
            name="Collapsible construction",
            name_pt="Construção colapsível",
            cost=nil,
            cost_text="2,000 x cost factor ",
            weight=nil,
            weight_text="10x cost factor ",
            availability=""
        },
        {
            name="Concealed item",
            name_pt="Artigo oculto",
            cost=nil,
            cost_text="See text ",
            weight=nil,
            weight_text="",
            availability="Restricted "
        },
        {
            name="Courier compartments",
            name_pt="Compartimentos postais",
            cost=200,
            cost_text="200",
            weight=nil,
            weight_text="2 x cost factor ",
            availability=""
        },
        {
            name="Credit reader",
            name_pt="Leitor de crédito",
            cost=50,
            cost_text="50",
            weight=1.0,
            weight_text="1 kg ",
            availability="Licensed "
        },
        {
            name="Droid oil bath",
            name_pt="Banho de óleo dróide",
            cost=500,
            cost_text="500",
            weight=nil,
            weight_text="600 x cost factor ",
            availability=""
        },
        {
            name="Earphone binary-to-basic translator",
            name_pt="Tradutor binário a básico do fone de ouvido",
            cost=20,
            cost_text="20",
            weight=0.5,
            weight_text=".5 kg ",
            availability=""
        },
        {
            name="Electric defense grid",
            name_pt="Grade de defesa elétrica",
            cost=nil,
            cost_text="3,000 x cost factor ",
            weight=nil,
            weight_text="100 x cost factor ",
            availability="Restricted "
        },
        {
            name="Hidden holster",
            name_pt="Coldre escondido",
            cost=nil,
            cost_text="500 x cost factor ",
            weight=nil,
            weight_text="2 x cost factor ",
            availability="Licensed "
        },
        {
            name="High-speed cutting torch and welder",
            name_pt="Tocha de corte de alta velocidade e soldador",
            cost=2500,
            cost_text="2500",
            weight=500.0,
            weight_text="500 kg ",
            availability="Licensed "
        },
        {
            name="Holographic game system",
            name_pt="Sistema holográfico de jogos",
            cost=300,
            cost_text="300",
            weight=3.0,
            weight_text="3 kg ",
            availability=""
        },
        {
            name="Holographic image disguiser",
            name_pt="Disfarçador de imagem holográfico",
            cost=nil,
            cost_text="20,000 x cost factor ",
            weight=nil,
            weight_text="20 x cost factor ",
            availability="Restricted "
        },
        {
            name="ID dodge",
            name_pt="Escape de ID",
            cost=5000,
            cost_text="5000",
            weight=1.0,
            weight_text="1 kg ",
            availability="Illegal "
        },
        {
            name="Improved coordination circuitry",
            name_pt="Circuitos de coordenação melhorados",
            cost=1000,
            cost_text="1000",
            weight=1.0,
            weight_text="1 kg ",
            availability=""
        },
        {
            name="Interference generator",
            name_pt="Gerador de interferências",
            cost=2500,
            cost_text="2500",
            weight=1.0,
            weight_text="1 kg",
            availability="Restricted"
        },
        {
            name="Internal defenses",
            name_pt="Defesas internas",
            cost=nil,
            cost_text="10x cost factor",
            weight=nil,
            weight_text="1 x cost factor",
            availability="Licensed "
        },
        {
            name="Internal grapple gun",
            name_pt="Arma de carga interna",
            cost=nil,
            cost_text="100 x cost factor ",
            weight=nil,
            weight_text="2 x cost factor ",
            availability=""
        },
        {
            name="Mesh tape dispenser",
            name_pt="Dispensador de fita de malha",
            cost=nil,
            cost_text="10 x cost factor ",
            weight=5.0,
            weight_text="5 kg ",
            availability=""
        },
        {
            name="Micro shield",
            name_pt="Micro- escudo",
            cost=nil,
            cost_text="600 x cost factor ",
            weight=nil,
            weight_text="10 x cost factor ",
            availability="Licensed "
        },
        {
            name="Multifunction apparatus",
            name_pt="Aparelhos multifunções",
            cost=nil,
            cost_text="80 x cost factor ",
            weight=nil,
            weight_text="15 x cost factor ",
            availability=""
        },
        {
            name="Multispectrum searchlight",
            name_pt="Luz de pesquisa multiespectro",
            cost=100,
            cost_text="100",
            weight=2.0,
            weight_text="2 kg ",
            availability=""
        },
        {
            name="Radiant heat element",
            name_pt="Elemento de calor radiante",
            cost=200,
            cost_text="200",
            weight=nil,
            weight_text="20 x cost factor ",
            availability=""
        },
        {
            name="Remote viewer",
            name_pt="Visualizador remoto",
            cost=1000,
            cost_text="1000",
            weight=20.0,
            weight_text="20 kg ",
            availability=""
        },
        {
            name="Rental restraining bolt",
            name_pt="Parafusos de retenção para aluguer",
            cost=10,
            cost_text="10",
            weight=0.5,
            weight_text=".5 kg ",
            availability=""
        },
        {
            name="Repulsorcam",
            name_pt="Repulsorcam",
            cost=1000,
            cost_text="1000",
            weight=20.0,
            weight_text="20 kg ",
            availability=""
        },
        {
            name="Scomp link",
            name_pt="Ligação Scop",
            cost=100,
            cost_text="100",
            weight=1.0,
            weight_text="1 kg ",
            availability=""
        },
        {
            name="Silence-bubble generator",
            name_pt="Gerador de bolhas de silêncio",
            cost=3500,
            cost_text="3500",
            weight=nil,
            weight_text="20 x cost factor ",
            availability="Licensed "
        },
        {
            name="Space-beacon launcher",
            name_pt="Lançador de feixes de espaço",
            cost=5000,
            cost_text="5000",
            weight=10.0,
            weight_text="10 kg ",
            availability=""
        },
        {
            name="Survival kit",
            name_pt="Kit de sobrevivência",
            cost=100,
            cost_text="100",
            weight=1.0,
            weight_text="1 kg ",
            availability=""
        },
        {
            name="Taser",
            name_pt="Taser",
            cost=250,
            cost_text="250",
            weight=2.0,
            weight_text="2 kg ",
            availability="Licensed "
        },
        {
            name="Video screen",
            name_pt="Tela de vídeo",
            cost=nil,
            cost_text="1 x square mm ",
            weight=nil,
            weight_text="1 kg + .01 kg x square mm ",
            availability=""
        },
        {
            name="Voice-print command lock",
            name_pt="Bloqueio de comando de impressão vocal",
            cost=400,
            cost_text="400",
            weight=1.0,
            weight_text="1 kg ",
            availability=""
        },
        {
            name="Weapon detector",
            name_pt="Detector de armas",
            cost=1500,
            cost_text="1500",
            weight=5.0,
            weight_text="5 kg ",
            availability="Licensed "
        }
    },
    droid_systems={
        {
            name="Climbing Claws",
            name_pt="Garras de Escalada",
            category="Locomoção",
            cost=nil,
            weight=nil,
            cost_text="=IF(AND(G20=\"Yes\",H20=\"Yes\"),IF(ISERROR(MATCH(\"Walking\",LocomotionTakenList,0)),\"\",INDEX(LocomotionTakenTable,MATCH(\"Walking\",LocomotionTakenList,0),4)),\"\")",
            weight_text=""
        },
        {
            name="Extra Legs",
            name_pt="Pernas extras",
            category="Locomoção",
            cost=nil,
            weight=nil,
            cost_text="=IF(G21<>\"\",IF(ISERROR(MATCH(\"Walking\",LocomotionTakenList,0)),\"\",INDEX(LocomotionTakenTable,MATCH(\"Walking\",LocomotionTakenList,0),4)),\"\")",
            weight_text=""
        },
        {
            name="Jump Servos",
            name_pt="Servos de Salto",
            category="Locomoção",
            cost=nil,
            weight=nil,
            cost_text="=IF(G22<>\"\",IF(ISERROR(MATCH(\"Walking\",LocomotionTakenList,0)),\"\",INDEX(LocomotionTakenTable,MATCH(\"Walking\",LocomotionTakenList,0),4)),\"\")",
            weight_text="=IF(AND(H22<>\"No\",G22<>\"\"),2*DroidWeightModifier,\"\")"
        },
        {
            name="Magnetic Feet",
            name_pt="Pés magnéticos",
            category="Locomoção",
            cost=nil,
            weight=nil,
            cost_text="=IF(G23<>\"\",IF(ISERROR(MATCH(\"Walking\",LocomotionTakenList,0)),\"\",INDEX(LocomotionTakenTable,MATCH(\"Walking\",LocomotionTakenList,0),4)),\"\")",
            weight_text=""
        },
        {
            name="Gyroscopic Stabilizers",
            name_pt="Estabilizadores giroscópicos",
            category="Locomoção",
            cost=nil,
            weight=nil,
            cost_text="=IF(G24<>\"\",H13*H13*2*DroidCostFactor,\"\")",
            weight_text="=IF(G24<>\"\",4*DroidWeightModifier,\"\")"
        },
        {
            name="Comlink, internal",
            name_pt="Comlink interno",
            category="Comunicações",
            cost=250.0,
            weight=0.1,
            cost_text="=IF(G45<>\"\",250,\"\")",
            weight_text="=IF(G45<>\"\",0.1,\"\")"
        },
        {
            name="Communications countermeasures",
            name_pt="Contramedidas de comunicação",
            category="Comunicações",
            cost=1000.0,
            weight=3.0,
            cost_text="=IF(G46<>\"\",1000,\"\")",
            weight_text="=IF(G46<>\"\",3,\"\")"
        },
        {
            name="Communications jammer",
            name_pt="Bloqueador de comunicações",
            category="Comunicações",
            cost=5000.0,
            weight=5.0,
            cost_text="=IF(G47<>\"\",5000,\"\")",
            weight_text="=IF(G47<>\"\",5,\"\")"
        },
        {
            name="Diagnostics package",
            name_pt="Pacote de diagnóstico",
            category="Comunicações",
            cost=250.0,
            weight=4.0,
            cost_text="=IF(G48<>\"\",250,\"\")",
            weight_text="=IF(G48<>\"\",4,\"\")"
        },
        {
            name="Droid caller",
            name_pt="Chamador de Droide",
            category="Comunicações",
            cost=10.0,
            weight=0.2,
            cost_text="=IF(G49<>\"\",10,\"\")",
            weight_text="=IF(G49<>\"\",0.2,\"\")"
        },
        {
            name="Remote reciever jammer",
            name_pt="Bloqueador de Receptor Remoto",
            category="Comunicações",
            cost=2000.0,
            weight=2.0,
            cost_text="=IF(G50<>\"\",2000,\"\")",
            weight_text="=IF(G50<>\"\",2,\"\")"
        },
        {
            name="Remote reciever signal booster",
            name_pt="Amplificador de Sinal do Receptor Remoto",
            category="Comunicações",
            cost=500.0,
            weight=2.0,
            cost_text="=IF(G51<>\"\",500,\"\")",
            weight_text="=IF(G51<>\"\",2,\"\")"
        },
        {
            name="Vocabulator",
            name_pt="Vocabulator",
            category="Comunicações",
            cost=50.0,
            weight=0.5,
            cost_text="=IF(G52<>\"\",50,\"\")",
            weight_text="=IF(G52<>\"\",0.5,\"\")"
        },
        {
            name="Internal Storage Space",
            name_pt="Espaço de Armazenamento Interno",
            category="Armazenamento",
            cost=nil,
            weight=nil,
            cost_text="=IF(G55<>\"\",G55*50,\"\")",
            weight_text=""
        },
        {
            name="Spring-loaded mechanism",
            name_pt="Mecanismo com Mola",
            category="Armazenamento",
            cost=150.0,
            weight=3.0,
            cost_text="=IF(G56<>\"\",150,\"\")",
            weight_text="=IF(G56<>\"\",3,\"\")"
        },
        {
            name="Locked access",
            name_pt="Acesso bloqueado",
            category="Armazenamento",
            cost=50.0,
            weight=nil,
            cost_text="=IF(G57<>\"\",50,\"\")",
            weight_text=""
        },
        {
            name="Heuristic processor",
            name_pt="Processador heurístico",
            category="Processadores",
            cost=2000.0,
            weight=5.0,
            cost_text="=IF(G60<>\"\",2000,\"\")",
            weight_text="=IF(G60<>\"\",5,\"\")"
        },
        {
            name="Remote processor",
            name_pt="Processador Remoto",
            category="Processadores",
            cost=nil,
            weight=nil,
            cost_text="=IF(ISERROR(MATCH(G61,RemoteProcessorList,0)),\"\",INDEX(RemoteProcessorTable,MATCH(G61,RemoteProcessorList,0),2))",
            weight_text="=IF(ISERROR(MATCH(G61,RemoteProcessorList,0)),\"\",INDEX(RemoteProcessorTable,MATCH(G61,RemoteProcessorList,0),3))"
        },
        {
            name="Remote reciever",
            name_pt="Receptor Remoto",
            category="Processadores",
            cost=nil,
            weight=1.0,
            cost_text="=IF(G62<>\"\",-500,\"\")",
            weight_text="=IF(G62<>\"\",1,\"\")"
        },
        {
            name="Backup processor",
            name_pt="Processador de Reserva",
            category="Processadores",
            cost=100.0,
            weight=nil,
            cost_text="=IF(G63<>\"\",100,\"\")",
            weight_text=""
        },
        {
            name="Synchronized fire circuits",
            name_pt="Circuitos de Disparo Sincronizado",
            category="Processadores",
            cost=150.0,
            weight=1.0,
            cost_text="=IF(G64<>\"\",150,\"\")",
            weight_text="=IF(G64<>\"\",1,\"\")"
        },
        {
            name="Restraining bolt",
            name_pt="Parafuso Restritor",
            category="Processadores",
            cost=5.0,
            weight=nil,
            cost_text="=IF(G65<>\"\",5,\"\")",
            weight_text=""
        },
        {
            name="Secondary battery",
            name_pt="Bateria Secundária",
            category="Processadores",
            cost=400.0,
            weight=4.0,
            cost_text="=IF(G66<>\"\",400,\"\")",
            weight_text="=IF(G66<>\"\",4,\"\")"
        },
        {
            name="Self-destruct system",
            name_pt="Sistema de Autodestruição",
            category="Processadores",
            cost=nil,
            weight=nil,
            cost_text="=IF(G67<>\"\",IF(DroidSize=\"Small\",24,36)*20,\"\")",
            weight_text="=IF(G67<>\"\",IF(DroidSize=\"Small\",24,36)*0.1,\"\")"
        },
        {
            name="Droid remote control",
            name_pt="Controle Remoto de Droide",
            category="Processadores",
            cost=500.0,
            weight=0.5,
            cost_text="=IF(G68<>\"\",500,\"\")",
            weight_text="=IF(G68<>\"\",0.5,\"\")"
        },
        {
            name="Hidden core",
            name_pt="Núcleo Oculto",
            category="Processadores",
            cost=200.0,
            weight=1.0,
            cost_text="=IF(G69<>\"\",200,\"\")",
            weight_text="=IF(G69<>\"\",1,\"\")"
        },
        {
            name="Personality downloader",
            name_pt="Transferidor de Personalidade",
            category="Processadores",
            cost=nil,
            weight=nil,
            cost_text="5000+",
            weight_text="2 kg+"
        },
        {
            name="Remote starship starter",
            name_pt="Partida Remota de Nave",
            category="Processadores",
            cost=50.0,
            weight=2.0,
            cost_text="=IF(G71<>\"\",50,\"\")",
            weight_text="=IF(G71<>\"\",2,\"\")"
        },
        {
            name="Specialized subprocessor",
            name_pt="Subprocessador Especializado",
            category="Processadores",
            cost=1000.0,
            weight=2.0,
            cost_text="=IF(G72<>\"\",1000,\"\")",
            weight_text="=IF(G72<>\"\",2,\"\")"
        },
        {
            name="Tactician battle computer",
            name_pt="Computador Tático de Batalha",
            category="Processadores",
            cost=5000.0,
            weight=10.0,
            cost_text="=IF(G73<>\"\",5000,\"\")",
            weight_text="=IF(G73<>\"\",10,\"\")"
        },
        {
            name="Improved sensor package",
            name_pt="Pacote de sensores aprimorado",
            category="Sensores",
            cost=200.0,
            weight=2.5,
            cost_text="=IF(G76<>\"\",200,\"\")",
            weight_text="=IF(G76<>\"\",2.5,\"\")"
        },
        {
            name="Darkvision",
            name_pt="Visão no escuro",
            category="Sensores",
            cost=150.0,
            weight=1.5,
            cost_text="=IF(G77<>\"\",150,\"\")",
            weight_text="=IF(G77<>\"\",1.5,\"\")"
        },
        {
            name="Sensor booster",
            name_pt="Amplificador de Sensores",
            category="Sensores",
            cost=200,
            weight=5,
            cost_text="=IF(G78<>\"\",H78,\"\")",
            weight_text="=IF(G78<>\"\",K78,\"\")"
        },
        {
            name="Sensor countermeasure package",
            name_pt="Pacote de Contramedidas de Sensores",
            category="Sensores",
            cost=1000,
            weight=2,
            cost_text="=IF(G79<>\"\",H79,\"\")",
            weight_text="=IF(G79<>\"\",K79,\"\")"
        },
        {
            name="YV sensor package",
            name_pt="Pacote de Sensores YV",
            category="Sensores",
            cost=1000,
            weight=3,
            cost_text="=IF(G80<>\"\",H80,\"\")",
            weight_text="=IF(G80<>\"\",K80,\"\")"
        },
        {
            name="SR",
            name_pt="SR",
            category="Escudos",
            cost=nil,
            weight=nil,
            cost_text="=IF(ISERROR(MATCH(G83,DroidSRList,0)),\"\",INDEX(DroidSRTable,MATCH(G83,DroidSRList,0),2)*DroidCostFactor)",
            weight_text="=IF(ISERROR(MATCH(G83,DroidSRList,0)),\"\",INDEX(DroidSRTable,MATCH(G83,DroidSRList,0),3)*DroidWeightModifier)"
        },
        {
            name="Shield expansion module",
            name_pt="Módulo de Expansão de Escudo",
            category="Escudos",
            cost=nil,
            weight=nil,
            cost_text="=IF(G84<>\"\",DroidShield*50*DroidCostFactor,\"\")",
            weight_text="=IF(G84<>\"\",DroidShield*2*DroidWeightModifier,\"\")"
        },
        {
            name="DC",
            name_pt="CD",
            category="Tradutor",
            cost=nil,
            weight=nil,
            cost_text="=IF(ISERROR(MATCH(G87,DroidTranslatorList,0)),\"\",INDEX(DroidTranslatorTable,MATCH(G87,DroidTranslatorList,0),2))",
            weight_text="=IF(ISERROR(MATCH(G87,DroidTranslatorList,0)),\"\",INDEX(DroidTranslatorTable,MATCH(G87,DroidTranslatorList,0),3)*DroidWeightModifier)"
        }
    },
    shield_generators={
        {
            name="SR 5",
            name_pt="SR 5",
            sr=5,
            cost=2500,
            weight=10,
            size_limit=4
        },
        {
            name="SR 10",
            name_pt="SR 10",
            sr=10,
            cost=5000,
            weight=20,
            size_limit=5
        },
        {
            name="SR 15",
            name_pt="SR 15",
            sr=15,
            cost=7500,
            weight=30,
            size_limit=6
        },
        {
            name="SR 20",
            name_pt="SR 20",
            sr=20,
            cost=10000,
            weight=40,
            size_limit=7
        }
    },
    translator_units={
        {
            name="Translator DC 20",
            name_pt="Tradutor CD 20",
            dc=20,
            cost=200,
            weight=1
        },
        {
            name="Translator DC 15",
            name_pt="Tradutor CD 15",
            dc=15,
            cost=500,
            weight=2
        },
        {
            name="Translator DC 10",
            name_pt="Tradutor CD 10",
            dc=10,
            cost=1000,
            weight=4
        },
        {
            name="Translator DC 5",
            name_pt="Tradutor CD 5",
            dc=5,
            cost=2000,
            weight=8
        }
    }
}
