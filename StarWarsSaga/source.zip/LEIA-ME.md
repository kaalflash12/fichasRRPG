# Star Wars Saga — Firecast 7.3.4

Esta versão aponta o botão ATUALIZAR para o repositório público kaalflash12/fichasRRPG.

## Importar XML RPGmeister 3.5

Na aba Geral, clique em IMPORTAR // DATA e selecione o XML exportado pela ficha RPGmeister 3.5. O conversor reconhece a estrutura antiga e transfere identidade, atributos, classes, perícias, proezas, talentos, poderes da Força, inventário, perfis de ataque e anotações. Itens fora do catálogo são preservados e informados no relatório. O XML original fica preservado nos dados da própria ficha.

O formato RPGmeister 3.5 identifica a estrutura do arquivo; o conversor não transforma regras de D&D 3.5 em regras de Star Wars Saga.

## Atualizar pelo GitHub

O botão ATUALIZAR consulta https://raw.githubusercontent.com/kaalflash12/fichasRRPG/main/update.txt e valida o módulo e a versão interna do RPK antes de solicitar a instalação. Não realiza consultas periódicas nem grava no banco de dados da ficha. A instalação usa a API oficial Plugins.installPlugin, que depende da autorização do Firecast para gerenciar plugins. A validação do canal e do pacote não comprova que essa autorização foi concedida.

## FX

A configuração padrão continua OFF. A escolha posterior do usuário permanece salva. A versão 7.3.4 preserva a implementação de efeitos por componente e as otimizações da 7.3.3.
