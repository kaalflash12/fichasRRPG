return {
    talents={
        {
            description="Uma vez / encontro tão rápido adicionar Sabedoria bônus à defesa da vontade do aliado",
            tree="Consular Jedi",
            name="Sabedoria Consular"
        },
        {
            description="Verificações de persuasão podem ser feitas com Use a Força, e Persuasão é considerada uma habilidade treinada",
            tree="Consular Jedi",
            name="Forçar a Persuasão"
        },
        {
            description="Mova seu inimigo mais um passo para baixo na pista de condição quando tiver sucesso com o Negociador Adept",
            tree="Consular Jedi",
            name="Negociador Mestre"
        },
        {
            description="Faça uma verificação Use a Força contra a Defesa de Vontade de um alvo como uma ação padrão dar a esse inimigo uma -2 Reflexa Pena de defesa contra ataques de todos os seus aliados dentro de 12 quadrados, linha de visão, e que entendem você",
            tree="Consular Jedi",
            name="Adversário Lore"
        },
        {
            description="Sempre que você usa Adversary Lore, o alvo também leva um adicional 1d6 pontos de dano de seus aliados que ganham os benefícios do talento",
            tree="Consular Jedi",
            name="Conhecer a Fraqueza"
        },
        {
            description="Uma vez por turno, como uma ação rápida, remover um efeito que afeta a mente de um único aliado na linha de visão",
            tree="Consular Jedi",
            name="Limpar a Mente"
        },
        {
            description="Outros usuários de força com farseeing dentro de 6 quadrados pode ajudar outro em seu Use a verificação de força para usar poderes e talentos de força baseados em farseeing ou farseeing",
            tree="Consular Jedi",
            name="Visões Coletivas"
        },
        {
            description="Uma vez por rodada, como uma ação rápida, você concede um aliado dentro de 12 quadrados de você (e na sua linha de visão) pontos de sucesso igual a 5 + seu modificador Carisma. Você pega uma pena -5 em todos Use a Força verifica até o início da sua próxima vez.",
            tree="Consular Jedi",
            name="Vitalidade do Consulado"
        },
        {
            description="Sempre que você danificar um alvo com um ataque de sabre de luz bem sucedido, você pode usar o talento Vitalidade do Consular como uma ação livre em vez de uma ação rápida até o início de sua próxima volta.",
            tree="Consular Jedi",
            name="Vitalidade do Consular Melhorada"
        },
        {
            description="Uma vez por turno como rápido gastar Ponto de força para deixar aliado Ajuda Outra como uma reação para ajudá-lo com verificação de habilidade",
            tree="Consular Jedi",
            name="Ajuda aos pedidos"
        },
        {
            description="Ganhe +2 bônus de visão para Defesa de Vontade, e gaste um Ponto da Força como uma ação rápida para dar todos os aliados dentro de 6 quadrados +2 para Defesa de Vontade até o final do encontro",
            tree="Consular Jedi",
            name="Força de Vontade"
        },
        {
            description="Quando você lida com danos a um alvo, fazendo um ataque de sabre leve em sua vez, você pode pedir uma ação rápida antes do fim de sua vez de ativar esse talento. Se você fizer isso, aliados adjacentes ao alvo no momento em que você fez o ataque ganhar um bônus circunstância +2 para melee ataque rola contra esse alvo até o início da sua próxima volta",
            tree="Consular Jedi",
            name="Greves Orientadoras"
        },
        {
            description="Recuperar todos os usos gastos de farseeing uma vez por encontro como uma ação rápida",
            tree="Consular Jedi",
            name="Renovar a Visão"
        },
        {
            description="Sempre que você gasta um ponto de força para devolver um poder de força para sua suíte, você recupera dois poderes de força em vez de um",
            tree="Consular Jedi",
            name="Lembrar"
        },
        {
            description="Gaste uma ação completa para conceder um aliado +5 para uma verificação de habilidades (ou +10 com um ponto de força)",
            tree="Consular Jedi",
            name="Consultora habilidosa"
        },
        {
            description="Faça uma verificação Use a verificação Força para usar farseeing para transferir um ponto de força para um aliado dentro da linha de visão",
            tree="Consular Jedi",
            name="Iniciar o Círculo de Observação"
        },
        {
            description="Faça um uso da força verificar em você ou um aliado dentro de 12 quadrados faltando um ataque contra a defesa da vontade do alvo para ganhar um reroll, mas sofrer uma penalidade cumulativa -5 para usar a força até sua próxima vez",
            tree="Consular Jedi",
            name="Ataque Visionário"
        },
        {
            description="Use a Força para verificar você ou um aliado dentro de 12 quadrados sendo alvo de um ataque contra a Defesa de Vontade do atacante para ganhar um bônus +5 para Defesa de Reflexos, mas sofrer uma penalidade cumulativa -5 para usar a Força até sua próxima vez",
            tree="Consular Jedi",
            name="Defesa Visionária"
        },
        {
            description="Faça uma verificação DC 20 Acrobatics para negar a queda propensa",
            tree="Jedi Guardian",
            name="Recuperação acrobática"
        },
        {
            description="Gaste uma ação completa para conceder a si mesmo e aliados dentro de 6 quadrados +1 para atacar rolos",
            tree="Jedi Guardian",
            name="Meditação de Batalha"
        },
        {
            description="Meditação de batalha é uma ação rápida, estende-se a 12 quadrados e inflige uma penalidade -1 em rolos de ataque inimigo",
            tree="Jedi Guardian",
            name="Meditação de batalha melhorada"
        },
        {
            description="Uma vez por turno, você pode usar uma ação rápida para designar um alvo. Até ao início da próxima volta, o seu movimento não provoca ataques de oportunidade a partir desse alvo, desde que termine o seu movimento adjacente a esse alvo.",
            tree="Jedi Guardian",
            name="Fechar a Manobra"
        },
        {
            description="Quando você gasta com sucesso um Ponto de Força para negar um ataque contra um aliado adjacente com os talentos Block ou Deflect, que o aliado pode mover até 2 quadrados como uma ação livre. Este movimento não provoca um ataque de oportunidade.",
            tree="Jedi Guardian",
            name="Escapar da Capa"
        },
        {
            description="Quando você luta defensivamente você lida +1 morrer em ataques de sabre de luz e ganhar um bônus +2 com Block e Deflect",
            tree="Jedi Guardian",
            name="Acuidade Defensiva"
        },
        {
            description="Pena adicional -5 para vários ataques contra você enquanto luta em melee",
            tree="Jedi Guardian",
            name="Alvo ilusório"
        },
        {
            description="Quando você usa um sabre de luz para causar danos a um alvo, você pode gastar um ponto de força para fazer esse alvo de pés chatos até o fim de sua próxima volta.",
            tree="Jedi Guardian",
            name="Exposição de Greve"
        },
        {
            description="Você pode usar a aplicação Move Light Object de Use a Força como uma reação quando você é atacado por uma granada de qualquer tipo, mas leve uma penalidade -5 para usar a verificação Force até o início da sua próxima volta",
            tree="Jedi Guardian",
            name="Defesa de Granada"
        },
        {
            description="Sempre que você usa um sabre de luz para causar danos a um alvo, esse alvo leva uma pena de -2 em rolos de ataque contra qualquer alvo que não você até o início da sua próxima volta.",
            tree="Jedi Guardian",
            name="Ataque do Guardião"
        },
        {
            description="Os controlos de iniciativa podem ser feitos com a Use the Force, e a Iniciativa é considerada uma habilidade treinada",
            tree="Jedi Guardian",
            name="Forçar a Intuição"
        },
        {
            description="Ao marcar um hit crítico com um sabre de luz, ganhe um ponto de força temporário",
            tree="Jedi Guardian",
            name="Guerreiro Forte"
        },
        {
            description="Quando você faz um ataque bem sucedido de oportunidade contra um oponente em movimento, você termina a ação de movimento do alvo",
            tree="Jedi Guardian",
            name="Manter a Linha"
        },
        {
            description="Você pode ativar este talento como uma ação rápida. Até o início do seu próximo turno, qualquer pessoa que tente movê-lo involuntariamente (como com uma corrida bantha ou o objeto de movimento Forçar o poder) leva uma penalidade -5 para atacar rolos ou verificações de habilidades feitas para usar o efeito que o moveria. Um inimigo só pode tirar o castigo deste talento uma vez por tentativa, independentemente de quantos alvos usaram este talento",
            tree="Jedi Guardian",
            name="Immovível"
        },
        {
            description="Passe uma ação rápida ao terminar o movimento adjacente a um inimigo para se mover com eles até sua velocidade, enquanto ainda beneficia de ataques de oportunidade",
            tree="Jedi Guardian",
            name="Combatente Móvel"
        },
        {
            description="Passe uma ação completa para mover +2 passos ao longo da faixa de condição",
            tree="Jedi Guardian",
            name="Resiliência"
        },
        {
            description="Pode rerolar qualquer Usar a verificação Força feita para evitar ser detectado por outros usuários de Força, mas deve aceitar o resultado da rerolagem mesmo que seja pior",
            tree="Sentinel Jedi",
            name="Limpar a Mente"
        },
        {
            description="Passe um ponto de força como uma ação padrão para conceder uma série de criaturas até o nível de sua classe total ocultação de um oponente se o seu Use a verificação Força bate sua defesa de vontade",
            tree="Sentinel Jedi",
            name="Forçar o Haze"
        },
        {
            description="Sempre que alguém se esconde com o seu uso dos ataques de talentos Foce Haze, você mantém o sigilo total sem ter que fazer outra verificação Use a Força. Só aqueles que não atacam permanecem escondidos.",
            tree="Sentinel Jedi",
            name="Haze Persistente"
        },
        {
            description="Sempre que você usar o talento da Força Haze, aliados escondidos pela neblina podem refazer qualquer verificação de percepção, mantendo o melhor resultado. Além disso, aliados escondidos pelo ganho de neblina +2 em todos os rolos de danos contra inimigos que não sabem deles.",
            tree="Sentinel Jedi",
            name="Olhos Invisíveis"
        },
        {
            description="Use a Força contra a Defesa da Vontade de um alvo como uma ação rápida para fazê-los esquecer sua interação",
            tree="Sentinel Jedi",
            name="Presença de Dampen"
        },
        {
            description="Pode reroll qualquer Use a verificação Força feita para sentir a presença e localização relativa de caracteres com uma pontuação Lado Sombrio, mas deve aceitar o resultado do reroll mesmo que seja pior",
            tree="Sentinel Jedi",
            name="Sentido Lado Escuro"
        },
        {
            description="Deal Carisma bônus extra danos usando poderes de força contra lados escuros",
            tree="Sentinel Jedi",
            name="Bane Lado Escuro"
        },
        {
            description="Dar dano extra igual ao seu modificador Carisma (mínimo +1) contra criaturas com um Lado Sombrio Score",
            tree="Sentinel Jedi",
            name="Scourge Lado Negro"
        },
        {
            description="+5 para todas as pontuações de defesa contra os poderes da Força Lado Negro e qualquer força de um usuário da Força Negra",
            tree="Sentinel Jedi",
            name="Resista ao Lado Negro"
        },
        {
            description="Se você sofrer danos do uso de uma força de força, até o final do encontro você ganha um bônus +2 Força para todas as defesas contra esse poder Força.",
            tree="Sentinel Jedi",
            name="Resistência gradual"
        },
        {
            description="Ganhe +1 para atacar e lidar +1 morrer de danos contra bestas com uma pontuação de lado escuro de 1 ou mais",
            tree="Sentinel Jedi",
            name="Mestre da Grande Caça"
        },
        {
            description="Quando você atinge um alvo com um ataque de sabre de luz, se o alvo não foi atacado desde o final de sua última vez, você lida com +1 morrer de dano.",
            tree="Sentinel Jedi",
            name="Alvos Prime"
        },
        {
            description="Se você tomar dano do uso de um poder de Força, até o final do encontro você lidar com um extra de 2 pontos de dano contra a criatura que usou o poder de Força contra você.",
            tree="Sentinel Jedi",
            name="Reaplicar a Retribuição"
        },
        {
            description="pode usar arredores de sentido para detectar alvos raio 30sq, independentemente de LOS",
            tree="Sentinel Jedi",
            name="Sentir a Força Primal"
        },
        {
            description="Deal 1d6 dano extra para os oponentes de pé plano com poderes de força ou ataques de sabre de luz\n\n(Entrar número de vezes tomadas)",
            tree="Sentinel Jedi",
            name="Ataque Sentinel"
        },
        {
            description="Passe um ponto de força uma vez por encontro ao ser alvo de um poder do lado negro para ativar um poder de força como reação",
            tree="Sentinel Jedi",
            name="Retaliação Escura"
        },
        {
            description="Como uma ação rápida uma vez por encontro, designar um oponente adjacente com uma pontuação Lado Sombrio para negar-lhes seu bônus de Dexterity para Defesa de Reflexos até sua próxima volta",
            tree="Sentinel Jedi",
            name="Gambit de Sentinel"
        },
        {
            description="Se você tem ocultação contra um alvo, você ganha um bônus +2 circunstância em rolos de ataque contra esse alvo.",
            tree="Sentinel Jedi",
            name="Observação do Sentinel"
        },
        {
            description="Leve uma penalidade para o seu jogo de ataque para ganhar o dobro disso como um bônus para sua defesa de vontade",
            tree="Sentinel Jedi",
            name="Resolução de aço"
        },
        {
            description="Faça uma verificação Use a Força como uma reação para negar um ataque melee rolar contra você, ou fornecer-lhe cobertura contra Whirlwind Ataque, com uma penalidade cumulativa de -5 cada vez Block or Deflect foi usado desde sua última vez",
            tree="Combate de sabre de luz",
            name="Bloco"
        },
        {
            description="Uma vez por encontro, ganhar um ataque livre sabre de luz contra um oponente cujo ataque você negou usando Block",
            tree="Combate de sabre de luz",
            name="Riposte"
        },
        {
            description="Use Bloco com luvas de cortose, atacando sabre de luz desativado",
            tree="Combate de sabre de luz",
            name="Bloco de Luva de Cortose"
        },
        {
            description="Faça uma verificação Use a Força como uma reação para negar um rolo de ataque variado contra você, ou fornecer-lhe cobertura contra o autofogo ou Força Relâmpago, com uma penalidade cumulativa de -5 cada vez Block or Deflect tem sido usado desde sua última vez",
            tree="Combate de sabre de luz",
            name="Defletir"
        },
        {
            description="Uma vez por rodada em um uso bem sucedido de Deflect em um único parafuso, faça um ataque variado contra um alvo usando o dano da arma de explosão",
            tree="Combate de sabre de luz",
            name="Redirecionar o Tiro"
        },
        {
            description="Sempre que você redirecionar com sucesso um parafuso de blaster e atingir o seu alvo, o ataque redirecionado negocia + 1 morte de dano.",
            tree="Combate de sabre de luz",
            name="Redirecionar Precisamente"
        },
        {
            description="Ganhe +1 para Defesa de Reflexos como uma ação rápida até sua próxima volta\n\n(Entrar número de vezes tomadas)",
            tree="Combate de sabre de luz",
            name="Defesa do sabre de luz"
        },
        {
            description="Como a ação padrão faz melee ataque com sabre de luz, reduz a velocidade do alvo para 2 quadrados até o final de sua próxima volta",
            tree="Combate de sabre de luz",
            name="Precisão"
        },
        {
            description="Sempre que você empunhar um sabre de luz de uma mão e um shoto ou guarda shoto, você ganha um bônus de competência +2 para ataques feitos com o shoto",
            tree="Combate de sabre de luz",
            name="Foco no Shoto"
        },
        {
            description="Ganhe +2 bônus para rolos de danos com sabres de luz",
            tree="Combate de sabre de luz",
            name="Especialização em armas (iluminadores)"
        },
        {
            description="Um sabre de luz não é mais considerado uma arma lançada improvisada, e pode ser recuperado após um ataque lançado dentro de 6 quadrados com um DC 20 Use a verificação Força",
            tree="Combate de sabre de luz",
            name="Lançar o sabre de luz"
        },
        {
            description="Como uma ação rápida, gaste um ponto de força para fazer as criaturas querer evitar você, fazendo todos os quadrados em um raio de 2 quadrados contar como terreno difícil para seus inimigos",
            tree="Alter",
            name="Aversão"
        },
        {
            description="Excluir uma série de alvos iguais ao seu modificador de Sabedoria (mínimo 1) de poderes de força de efeito cone",
            tree="Alter",
            name="Greve disciplinada"
        },
        {
            description="Ganhe um ponto de força temporário ao rolar um 1 natural em um rolo de ataque ou use a verificação de força",
            tree="Alter",
            name="Forçar o Fluxo"
        },
        {
            description="Passe um ponto de força como uma ação padrão para criar ilusões que parecem reais para aqueles cuja defesa de vontade é excedida por sua verificação Use a força",
            tree="Alter",
            name="Ilusão"
        },
        {
            description="Pode ver ou ouvir como se estivesse no espaço da sua ilusão se humanóide",
            tree="Alter",
            name="Ligação à ilusão"
        },
        {
            description="Você pode usar a habilidade Use a Força no lugar da Decepção para criar uma aparência enganosa",
            tree="Alter",
            name="Mascarada"
        },
        {
            description="1/encontro pode retornar um poder de força que afeta a mente como uma ação rápida sem custar um ponto de força",
            tree="Alter",
            name="Sabão da Influência"
        },
        {
            description="Use o truque mental para convencer um alvo que eles não podem usar a Força",
            tree="Alter",
            name="Suprimir a Força"
        },
        {
            description="Um aliado treinado em Use the Force pode ajudar outro dentro de 12 quadrados e linha de visão como uma reação, mas leva uma penalidade em Use the Force checks",
            tree="Alter",
            name="Ligação"
        },
        {
            description="Livre uso extra da força telecinética em um 20 natural",
            tree="Alter",
            name="Potência Telecinética"
        },
        {
            description="Gaste um ponto de força para ter alvos de Objetos de Movimento maiores que danos na área de grande negócio",
            tree="Alter",
            name="Mover Objeto Massivo"
        },
        {
            description="Retornar um poder de força telecinético para sua suíte como uma ação rápida uma vez por encontro\n\n(Entrar número de vezes tomadas)",
            tree="Alter",
            name="Sabonete telecinético"
        },
        {
            description="Ganhe um poder telecinético livre quando você selecionar mover objeto como um dos poderes de Force Training",
            tree="Alter",
            name="Prodígio telecinético"
        },
        {
            description="Formem uma ligação telepática com outro aliado sensível à força que permite a comunicação instantânea dentro de um quilômetro, e uma vez por encontro o uso de uma força de força de sua suíte de força",
            tree="Alter",
            name="Ligação Telepática"
        },
        {
            description="Ao rolar um 20 natural em um rolo de ataque ou usar a verificação de Força, você pode conceder um aliado dentro de 12 quadrados um ponto de força temporário em vez de recuperar todos os poderes de força gastos",
            tree="Alter",
            name="Influência telepática"
        },
        {
            description="Você pode usar truque mental em criaturas de inteligência 2 ou inferior",
            tree="Controlo",
            name="Truque da Besta"
        },
        {
            description="Sempre que você usar a energia negatória Forçar a energia para negar com sucesso os danos de um ataque de arma de energia, você pode gastar um Ponto de Força como uma reação para ativar imediatamente qualquer Poder de Força atualmente em sua suíte de Força",
            tree="Controlo",
            name="Energia do Canal"
        },
        {
            description="Passe um ponto de força para ganhar DR 10 por 1 minuto como uma ação padrão",
            tree="Controlo",
            name="Redução de Danos 10"
        },
        {
            description="Passe um ponto de força para remover todas as condições debilitantes como uma ação rápida",
            tree="Controlo",
            name="Equilíbrio"
        },
        {
            description="Ganhe mais 1d6 pontos por ponto de força (máximo 10d6) ao usar o segundo vento",
            tree="Controlo",
            name="Forçar a Recuperação"
        },
        {
            description="Mover -1 passo persistente ao longo da pista de condição para escolher um poder de força que pode ser usado um tempo extra em detrimento de qualquer outro poder\n\n(Entrar número de vezes tomadas)",
            tree="Controlo",
            name="Forçar o exercício"
        },
        {
            description="Faça um DC 15 Use a verificação de força para recuperar uma força gasta como uma ação completa",
            tree="Controlo",
            name="Forçar o Foco"
        },
        {
            description="Uma vez por encontro, você pode ativar um talento da Força que requer um ponto de força para usar sem gastar um ponto de força",
            tree="Controlo",
            name="Harmonia de Força"
        },
        {
            description="Ao falhar em negar ou redirecionar com sucesso uma força com repreensão, você pode diminuir o efeito da força um passo",
            tree="Controlo",
            name="Forçar a Supressão"
        },
        {
            description="Passe um ponto de força como uma ação padrão para ficar imune a todos os efeitos que afetam a mente por 1 minuto",
            tree="Controlo",
            name="Vontade indomável"
        },
        {
            description="Está imune aos efeitos que o movem contra a sua vontade",
            tree="Controlo",
            name="Estabilidade telecinética"
        },
        {
            description="Uma vez por turno, como uma reação, ao defender-se contra um poder de força que visa a sua Defesa de Vontade, você pode rolar uma verificação Use a Força e usar o resultado em seu lugar, mas na próxima rodada sua verificação Use a Força é -5",
            tree="Controlo",
            name="A vontade de resistir"
        },
        {
            description="Como uma ação rápida, leve uma penalidade -5 para Defesa de Vontade para ganhar um bônus +2 para atacar até sua próxima rodada",
            tree="Lado Sombrio",
            name="Consumado pela escuridão"
        },
        {
            description="Uma vez por encontro como uma ação rápida, você pode retornar um poder de força com o descritor [lado escuro] para o seu pacote de força sem gastar um ponto de força",
            tree="Lado Sombrio",
            name="Sabão Lado Escuro"
        },
        {
            description="Obtenha treinamento de habilidades ou foco em uma habilidade de um alvo tocado com um teste Use a Força contra sua defesa de vontade ou aprenda informações com um teste de percepção",
            tree="Lado Sombrio",
            name="Drenar o Conhecimento"
        },
        {
            description="Escolha o melhor de dois rolos no bônus morrer por gastar um Ponto da Força para modificar um rolo de ataque, aumentando Lado Sombrio Score em 1",
            tree="Lado Sombrio",
            name="Poder do Lado Negro"
        },
        {
            description="Você e aliados dentro de 6 quadrados ganhar +1 bônus para todas as defesas até o final do encontro como uma ação padrão",
            tree="Lado Sombrio",
            name="Presença Escura"
        },
        {
            description="Ganhe +2 bônus para atacar rolos e rolos de dano para o restante do encontro após a morte (ou redução para 0 pontos de ataque) de um aliado de igual ou maior aliado",
            tree="Lado Sombrio",
            name="Vingança"
        },
        {
            description="Negar mover-se para baixo a pista de condição, aumentando a sua pontuação lado escuro",
            tree="Lado Sombrio",
            name="Preservação Escura"
        },
        {
            description="Use um poder de força de duração padrão ou mover ação como uma ação rápida uma vez por dia",
            tree="Lado Sombrio",
            name="Potência Rápida"
        },
        {
            description="Ao rodar um 20 natural para ativar um poder de força prejudicial, você pode lidar com metade dos danos novamente no início do próximo turno do alvo em vez de reabastecer sua suíte de força",
            tree="Lado Sombrio",
            name="Ira do Lado Negro"
        },
        {
            description="Quando você morre se torna um espírito do lado escuro e pode possuir outros ou entrar em um objeto",
            tree="Lado Sombrio",
            name="Essência de Transferência"
        },
        {
            description="Seu espírito guardião pode lhe dizer as consequências imediatas de suas ações, e você ganha um ponto de força bônus por dia após um descanso de 6 horas que só pode ser usado para melhorar os poderes da Força, ou ativar técnicas e segredos",
            tree="Espírito Guardião",
            name="Espírito Guardião"
        },
        {
            description="1/retrolocamento falhada verificação de habilidade com +2 bônus",
            tree="Espírito Guardião",
            name="Conselhos Cruciais"
        },
        {
            description="Seu espírito guardião aparece para o encontro dentro de 6 quadrados de você, e enquanto ele permanecer dentro de 12 quadrados de você, você recebe +1 em rolos de ataque, +2 em Use as verificações da Força, e +2 Defesa de Vontade; você pode mover o espírito até seis quadrados uma vez por rodada como uma ação Swift",
            tree="Espírito Guardião",
            name="Manifeste o espírito guardião"
        },
        {
            description="Qualquer inimigo dentro de 3 quadrados leva uma penalidade -2 para Defesa de Vontade e atacar rolos contra você",
            tree="Espírito Guardião",
            name="Aparição Distraída"
        },
        {
            description="1/encontro você ganha pontos temporários igual a 10 + 1/2 seu nível heróico",
            tree="Espírito Guardião",
            name="Incentivo vital"
        },
        {
            description="Gaste um ponto de força para ganhar um bônus +2 para todas as defesas até o final do encontro, ou quando você atacar, o que vier primeiro",
            tree="Lado Luminoso",
            name="Em Paz"
        },
        {
            description="Você pode gastar um ponto de força para refazer um ataque contra um alvo com uma pontuação de Lado Sombrio de 1 ou mais e tirar o melhor dos resultados",
            tree="Lado Luminoso",
            name="Ataque Focado"
        },
        {
            description="Quando você rolar um 20 natural contra um alvo com uma pontuação de Lado Sombrio de 1 ou mais, você pode ativar um poder de força com o descritor [Lado Luminoso] imediatamente como uma ação livre",
            tree="Lado Luminoso",
            name="Afinado"
        },
        {
            description="Uma vez por encoutner, como uma ação rápida, você pode retornar qualquer poder de força com o descritor [lado leve] sem gastar um ponto de força",
            tree="Lado Luminoso",
            name="Surto de Luz"
        },
        {
            description="Passe um ponto de força como padrão para ignorar toda a ocultação por 1 minuto",
            tree="Sentido",
            name="Sinta a Força"
        },
        {
            description="Verificações de percepção podem ser feitas com Use a Força, e Percepção é considerada uma habilidade treinada",
            tree="Sentido",
            name="Forçar a Percepção"
        },
        {
            description="Passe um ponto de Força para refazer uma verificação de Iniciativa, mantendo o melhor resultado, recuperando o ponto de Força no caso de um natual 20",
            tree="Sentido",
            name="Previsão"
        },
        {
            description="Faça uma verificação Use a Força contra a Defesa de Vontade de um alvo como uma ação padrão para verificar se é Força Sensível, e quantos poderes de Força e Pontos de Força ele tem",
            tree="Sentido",
            name="Potencial de Força de Medição"
        },
        {
            description="Use um uso do poder de farseeing de sua suíte, e antes do fim de seu próximo atacante força volta para reroll seu rolo de ataque e manter o segundo resultado",
            tree="Sentido",
            name="Moção do Futuro"
        },
        {
            description="Quando você usa Farseeing, você pode escolher atingir um objeto que você segura e olhar para o seu passado até 5 anos por nível",
            tree="Sentido",
            name="Psicometria"
        },
        {
            description="Farseeing pode ser usado para ver o passado ou futuro do alvo ao custo de um ponto de força",
            tree="Sentido",
            name="Visões"
        },
        {
            description="O piloto pode fazer verificações com Use a Força, e Pilot é considerado uma habilidade treinada",
            tree="Sentido",
            name="Forçar Piloto"
        },
        {
            description="Passe um ponto de força para refazer uma verificação Pilot para ativar uma manobra de nave estelar e manter o melhor resultado",
            tree="Sentido",
            name="Forçar Reflexos"
        },
        {
            description="Use o Force substituts Use o Computador para alarde",
            tree="Sentido",
            name="Navegação Instintiva"
        },
        {
            description="Você pode gastar um ponto de força para adicionar seu bônus Carisma ao seu cheque Percepção",
            tree="Sentido",
            name="Consciência aumentada"
        },
        {
            description="Você pode gastar um Ponto de Força para obter visão de baixa luz por 1 minuto ou até o final do encontro, o que for mais longo",
            tree="Sentido",
            name="Sentido de Mudança"
        },
        {
            description="Uma vez por rodada, como uma reação a um inimigo em sua linha de visão se movendo, você pode permitir que um aliado dentro de sua linha de visão para mover-se até sua velocidade como uma ação livre.",
            tree="Antecipação",
            name="Antecipar o Movimento"
        },
        {
            description="Todos os aliados dentro de 12 quadrados de você ganhar um bônus +2 insight em rolos de ataque e rolos de danos para ataques de oportunidade.",
            tree="Antecipação",
            name="Aliados Prevenidos"
        },
        {
            description="Uma vez por turno, como uma ação rápida, destinem uma área quadrada 3×3 dentro de sua linha de visão. Até ao fim da próxima volta, se um alvo se mover para aquela área, você pode permitir que um aliado dentro da sua linha de visão faça um ataque de oportunidade contra esse alvo. O aliado que você escolher deve estar armado com uma arma capaz de fazer ataques de oportunidade, e isso conta para as limitações normais do aliado para os ataques de oportunidade feitos em uma rodada. Pré-requisito: Aliados avisados.",
            tree="Antecipação",
            name="Zona de Fogo Pesado"
        },
        {
            description="Como uma reação, quando um aliado é alvo de um ataque variado, você pode permitir que o aliado cair prona imediatamente (impondo a penalidade normal -2 para um ataque variado contra um alvo propensa ao rolo de ataque disparado) como uma ação livre.",
            tree="Antecipação",
            name="Descer"
        },
        {
            description="Uma vez por rodada, como uma reação, quando um inimigo se move adjacente a você, você pode permitir que um aliado dentro de sua linha de visão faça imediatamente um ataque de carga contra o inimigo desencadeante. O aliado que você escolher deve ser capaz de acusar o inimigo de sua atual praça sob as regras de carga normais. Pré-requisito: Desça.",
            tree="Antecipação",
            name="Ajuda de convocação"
        },
        {
            description="Quando você rolar Iniciativa no início do combate, também rolar uma verificação Decepção, comparando o resultado com a Defesa de Vontade de todos os inimigos na linha de visão. Se sua verificação de decepção for bem sucedida, esse alvo não poderá atacá-lo enquanto este efeito estiver ativo.",
            tree="Colaborador",
            name="Agente Duplo"
        },
        {
            description="Como uma ação padrão, você designa um aliado e faz uma verificação de Persuasão contra a Defesa da Vontade de todos os inimigos na linha de visão. Verificações bem-sucedidas significam que eles não podem atacar o aliado que você designou até o início da sua próxima volta.",
            tree="Colaborador",
            name="Protecção"
        },
        {
            description="Sempre que um inimigo dentro de 12 quadrados de você e em sua linha de visão recebe um insight ou bônus moral de qualquer fonte, você também pode ganhar esse bônus, sujeito a todas as mesmas limitações que o bônus fornecido a esse inimigo.",
            tree="Colaborador",
            name="Táticas inimigas"
        },
        {
            description="Se você está em combate melee com um inimigo adjacente e são o alvo de um ataque variado que perde você, se o ataque é igual ou excede a Defesa Reflexo do inimigo, esse inimigo se torna o novo alvo do ataque, que é resolvido como normal.",
            tree="Colaborador",
            name="Fogo Amigo"
        },
        {
            description="Como uma ação rápida, você pode conceder um bônus inimigo +1 em seu próximo rolo de ataque feito antes do início de sua próxima volta. Além disso, até o início do seu próximo turno, você pode designar um aliado que recebe um bônus +2 em seu próximo rolo de ataque.",
            tree="Colaborador",
            name="Informação da Fonte"
        },
        {
            description="Faça a verificação de persuasão como ação padrão contra a defesa de vontade do alvo. Se tiver sucesso, você impõe uma penalidade -2 a todas as defesas do alvo até o fim da sua volta na rede.",
            tree="Desgraça",
            name="Castigar"
        },
        {
            description="Uma vez por encontro, como uma ação padrão, você concede vantagem tática a todos os aliados dentro da sua linha de visão. Quando um aliado flanqueia um oponente, esse aliado ganha um bônus +4 flanqueando em rolos de ataque melee em vez do bônus normal +2.",
            tree="Desgraça",
            name="Táticas Sujas"
        },
        {
            description="Durante uma rodada surpresa, antes de começar o combate, se você não estiver surpreso, você pode desistir de sua ação padrão para permitir que todos os aliados não surpreendidos dentro da linha de visão para tomar uma ação extra movimento durante a rodada surpresa ou reroll sua verificação Iniciativa.",
            tree="Desgraça",
            name="Emboscada"
        },
        {
            description="Como ação rápida, faça Persuasão verificar contra Will Defesa de todos os oponentes dentro da linha de visão. Se forem bem sucedidos, os alvos não podem atacar-vos se um dos vossos aliados estiver dentro de 6 quadrados de vós.",
            tree="Desgraça",
            name="Lealdade Deslocada"
        },
        {
            description="Use cada uma das seguintes ações uma vez por encontro como uma ação padrão:\n- Segurança Flase\n- Não ameaçador.\n- Alvo complicado.\nVer p. 14 de Escória e Vilões",
            tree="Desgraça",
            name="Duas Faces"
        },
        {
            description="Ganhe +5 bônus para sua defesa de vontade contra verificações de habilidades feitas para ler suas emoções e influenciar sua atitude. Além disso, quando você finge um alvo em combate, esse alvo é de pé plano contra todos os seus ataques até o fim da sua próxima volta.",
            tree="Desgraça",
            name="Ilegível"
        },
        {
            description="Persuasão para mudar a atitude do inimigo para -5 inimigo Will Def até a próxima volta, FP para o fim do enc",
            tree="Exílio",
            name="Bluster Arrogante"
        },
        {
            description="1/enc como reac se tiver sucesso em Know (galatic lore) habilitar 1 aliado w/in 6sq & LOS para reroll falha Int ou verificação de habilidade baseada em Wis (além de Percepção)",
            tree="Exílio",
            name="Orientação Galáctica"
        },
        {
            description="se tiver sucesso em Persuasão para intimidar o inimigo w/in 6sq negar movimento inimigo em vez disso, conceda 1 aliado para usar movimento imediatamente",
            tree="Exílio",
            name="Rant"
        },
        {
            description="1/enc use 1 talento da árvore da inspiração em si mesmo",
            tree="Exílio",
            name="Auto- Confiante"
        },
        {
            description="Ao usar uma arma leve ou sabre de luz com a qual você é proficiente, você pode usar seu modificador Carisma em vez de seu modificador de força em rolos de ataque",
            tree="Esgrima",
            name="Nobre estilo de esgrima"
        },
        {
            description="Metade dos danos causados por um ataque melee contra um oponente para, em vez disso, infligir uma penalidade -5 em ataques feitos contra você até sua próxima vez",
            tree="Esgrima",
            name="Defesa Desmoralizante"
        },
        {
            description="Ao danificar um oponente com um ataque melee, faça uma verificação Deception contra eles para deixá-los plana contra um aliado dentro de seis quadrados até sua próxima vez",
            tree="Esgrima",
            name="Feint líder"
        },
        {
            description="Depois de ser danificado por um inimigo adjacente uma vez por encontro, faça um ataque de melee livre contra eles",
            tree="Esgrima",
            name="Afronto Pessoal"
        },
        {
            description="Dar metade dos danos a um inimigo para trocar de lugar com eles",
            tree="Esgrima",
            name="Ataque de Transposição"
        },
        {
            description="Você pode usar seu bônus Carisma em vez de bônus Sabedoria para Defesa de Vontade",
            tree="Idealogue",
            name="Idealista"
        },
        {
            description="Como uma ação padrão, uma vez por encontro para cada vez tomada, conceder um aliado dentro de 6 quadrados uso de seu modificador de habilidade (exceto para Usar a Força)\n\n(Entrar número de vezes tomadas)",
            tree="Idealogue",
            name="Instrução"
        },
        {
            description="Como uma ação rápida fazer um Knowledge (lore galáctico) verificar contra DC 15 + CL do alvo para aprender dois de: bônus de ataque base, bônus de ataque particular, pontuação de defesa, modificador de habilidade, feito talento ou feito feito feito",
            tree="Idealogue",
            name="Conheça seu inimigo"
        },
        {
            description="Faça uma verificação de Persuasão contra a Defesa da Vontade de um único oponente dentro da linha de visão como uma ação padrão para evitar que eles ataquem você até sua próxima volta",
            tree="Idealogue",
            name="Conhecido Dissidente"
        },
        {
            description="Uma vez por encontro, ao causar danos a um inimigo, conceda a todos os aliados +1 ataque e +1 morrer dano contra o mesmo alvo",
            tree="Idealogue",
            name="Liderar por Exemplo"
        },
        {
            description="Uma vez por turno, como uma ação padrão, você pode designar um aliado e um inimigo que têm linha de efeito entre si. O aliado e o inimigo fazem verificações opostas da Iniciativa, e o vencedor pode fazer um único ataque imediato ou contra o perdedor. Nenhum personagem pode beneficiar deste talento mais de uma vez por rodada.",
            tree="Líder do Jogo",
            name="Agressão Gambit"
        },
        {
            description="Uma vez por turno, como uma ação rápida, você pode designar um aliado e um alvo que não tem cobertura de você. Até ao início do teu próximo tum, o aliado que designas ignora os bónus de cobertura do alvo para a Defesa de Reflexos.\nPré-requisito: Agressão Gambit.",
            tree="Líder do Jogo",
            name="Fogo Directo"
        },
        {
            description="Se você não tem cobertura de um alvo, você ganha um +1 bônus moral para atacar rolos contra esse alvo.",
            tree="Líder do Jogo",
            name="Enfrente o Foe"
        },
        {
            description="Se você não tem cobertura de um alvo que você danifica com um ataque variado, todos os seus aliados ganham um bônus de moral +2 para atacar rolos contra esse alvo e um bônus de circunstância +5 para verificar o contrário Iniciativa contra esse alvo até o início de sua próxima volta.\nPré-requisito: Enfrentar o Foe.",
            tree="Líder do Jogo",
            name="Liderar da Frente"
        },
        {
            description="Se pelo menos um inimigo na sua linha de visão está ciente de você e você não tem cobertura contra esse inimigo, no início do seu tum se você estiver consciente, você ganha um número de pontos de bônus igual a 5 + metade do seu nível. Os danos são subtraídos dos pontos de sucesso bônus primeiro, e quaisquer pontos de sucesso bônus restantes no final do encontro são perdidos. Bônus pontos de sucesso não empilham.\nPré-requisito: Enfrentar o Foe.",
            tree="Líder do Jogo",
            name="A sorte favorece o negrito"
        },
        {
            description="Verificações de persuasão para intimidar são ações padrão, não ações completas",
            tree="Influência",
            name="Presença"
        },
        {
            description="Faça uma verificação de persuasão uma vez por encontro contra a defesa da vontade de um alvo reduzido a menos de metade dos pontos de ataque para impor sua rendição",
            tree="Influência",
            name="Rendição da Demanda"
        },
        {
            description="Uma vez por encontro como uma ação padrão, use Persuasão para intimidar um oponente dentro da linha de visão para permitir-lhes apenas uma ação rápida para sua vez",
            tree="Influência",
            name="Fluster"
        },
        {
            description="Uma vez por encontro como uma reação, faça uma verificação de Persuasão para intimidar um oponente dentro da linha de visão para aplicar uma penalidade -5 ao seu rolo de ataque",
            tree="Influência",
            name="Defesa Intimidante"
        },
        {
            description="Faça uma verificação de Persuasão contra a Defesa da Vontade de um alvo ao lidar com danos maiores do que o limite de danos para impor o voo.",
            tree="Influência",
            name="Resolver a trama"
        },
        {
            description="Os alvos que fogem do Weaken Resolve não param de correr se forem feridos.",
            tree="Influência",
            name="Solução melhorada do Weaken"
        },
        {
            description="Mova um aliado +1 passo ao longo da faixa de condição uma vez por encontro e dar pontos de bônus de hit igual ao seu nível de personagem se ele está abaixo de meio pontos de hit",
            tree="Inspiração",
            name="Alívio de apoio"
        },
        {
            description="Todos os aliados dentro da linha de visão ganham um bônus +1 para atacar rolos e verificações de habilidade até o final do encontro como uma ação padrão",
            tree="Inspiração",
            name="Inspire confiança"
        },
        {
            description="Você pode usar cada uma das seguintes ações uma vez por encontro:\n- Guardião.\n- Represália\n- Para mim!\nVer p.14 de Escória e Vilões.",
            tree="Inspiração",
            name="Amado"
        },
        {
            description="Conceda a um aliado um bônus para danos em seu próximo rolo de ataque igual ao seu nível de personagem ao bater em um oponente com um variado ou ataque melee",
            tree="Inspiração",
            name="Ignite Fervor"
        },
        {
            description="Os oponentes desceram a trilha da condição a partir de ataques feitos por aliados dentro da linha de visão mover um adicional -1 descer a trilha da condição",
            tree="Inspiração",
            name="Inspire o zelo"
        },
        {
            description="Uma vez por encontro como uma ação rápida, conceda aliados dentro da linha de visão +2 Defesa de Vontade",
            tree="Inspiração",
            name="Poder de Vontade"
        },
        {
            description="Como uma ação rápida, um aliado dentro da linha de visão pode fazer uma verificação de habilidade exigindo uma ação padrão como uma ação de movimento em sua próxima volta",
            tree="Inspiração",
            name="Inspire a pressa"
        },
        {
            description="Aliados na linha de visão ganham um bônus +1 para atacar rolos enquanto permanecem na linha de visão, ativados como uma ação rápida uma vez por encontro",
            tree="Liderança",
            name="Líder Nascido"
        },
        {
            description="O bônus de Born Leader aplica-se mesmo que a linha de visão seja interrompida",
            tree="Liderança",
            name="Comando Distante"
        },
        {
            description="Aliados dentro da linha de visão em menos de metade dos pontos de ataque ganham um bônus +2 para Defesa de Reflexos, Defesa de Vontade e rolos de danos, ativados como uma ação rápida uma vez por encontro",
            tree="Liderança",
            name="Rally"
        },
        {
            description="Aliados ganham +5 para Will Defesa contra os efeitos do medo para o resto do encontro, ativados como uma ação rápida",
            tree="Liderança",
            name="Líder Destemido"
        },
        {
            description="Uma vez por encontro, sobre você ou um aliado sendo atacado, conceder um aliado dentro de 6 quadrados um ataque livre contra o inimigo atacando",
            tree="Liderança",
            name="Ataque Reacionário"
        },
        {
            description="Quando um aliado que você pode ver gasta um ponto de força para melhorar um rolo de ataque, o aliado ganha um bônus para o rolo de ponto de força igual ao seu modificador de inteligência. Pré-requisito: Nascido Líder.",
            tree="Liderança",
            name="Sabado Tático"
        },
        {
            description="Você se destaca em liderar outros para a batalha, emitir ordens rápidas, demonstrar um dom para a estratégia, dizimar seus inimigos e impressionar seus colegas. Você pode usar cada uma das seguintes ações uma vez por encontro como uma ação padrão:\n* Segure a linha: Faça um único ataque ou variou contra qualquer alvo dentro do seu alcance. Se o seu ataque chegar, todos os aliados dentro de 6 quadrados de você ganhar um bônus moral +2 para suas pontuações de defesa até o final de sua próxima volta.\n* Liderar o Assalto: Faça uma única batalha ou atacou qualquer alvo dentro do seu alcance. Se o teu ataque chegar. todos os aliados dentro de 6 quadrados de você e dentro de sua linha de visão ganhar um bônus de moral +2 para seus rolos de ataque e rolos de danos até o fim de sua próxima volta.\n* Vire o Maré: Faça um único ataque ou variou contra qualquer alvo dentro do seu alcance. Se você danificar com sucesso o alvo, um número de aliados iguais ao seu modificador Carisma (mínimo 1) pode imediatamente mover-se até metade da sua velocidade como uma ação livre. Pré-requisitos: Nascido Líder, Sabão Tático.",
            tree="Liderança",
            name="Presença Comandante"
        },
        {
            description="Aliados dentro da linha de visão concedem um bônus +1 adicional ao usar ajuda outra até o início de sua próxima volta, ativada como uma ação padrão\n\n(Entrar número de vezes tomadas)",
            tree="Liderança",
            name="Coordenadas"
        },
        {
            description="Desistir de uma ação padrão para conceder um aliado dentro da linha de visão um padrão extra ou mover ação em sua próxima vez",
            tree="Liderança",
            name="Confiança"
        },
        {
            description="Uma vez por turno, como uma ação rápida, você pode designar um aliado dentro de sua linha de visão que pode ouvir e entender você. Até ao início da próxima vez, esse aliado torna-se imune a todos os efeitos que tornam o aliado de pés chatos ou que negam ao aliado um bónus de Dexteridade à sua Defesa Reflexa.",
            tree="Liderança",
            name="Ally inabalável"
        },
        {
            description="Evite pagar taxas de licença em equipamentos inferiores ao seu nível de caráter x 1000 créditos, e reduzir o multiplicador de custos do mercado negro em 1",
            tree="Linhagem",
            name="Ligações"
        },
        {
            description="Uma vez por dia, receber uma verificação de habilidade em 25 + metade do seu nível heróico ao longo de 10 x minutos de verificação de habilidade resultado",
            tree="Linhagem",
            name="Amigos Influentes"
        },
        {
            description="Uma vez por encontro, leve 20 em uma verificação de persuasão sem levar mais tempo do que o habitual",
            tree="Linhagem",
            name="Amigos Poderosos"
        },
        {
            description="Verificações de conhecimento podem ser feitas sem treinamento",
            tree="Linhagem",
            name="Educado"
        },
        {
            description="Treinado em Mecânica. O tempo necessário para instalar novos sistemas num veículo é reduzido em 25%",
            tree="Linhagem",
            name="Engenheiro"
        },
        {
            description="Faça uma verificação de habilidades uma vez por dia como se estivesse treinado em uma habilidade em que não está treinado (exceto Use a Força)\n\n(Entrar número de vezes tomadas)",
            tree="Linhagem",
            name="Habilidade Espontânea"
        },
        {
            description="Ganhe 5000 créditos para cada nível de Nobre cada vez que você ganha um nível",
            tree="Linhagem",
            name="Riqueza"
        },
        {
            description="Ganhas um único seguidor. Escolha o modelo de seguidor agressivo, defensivo ou utilitário para o seu seguidor. Este seguidor ganha uma proeza de armadura de sua escolha e se torna treinado na habilidade de percepção.",
            tree="Protetor Leal",
            name="Inspirar lealdade"
        },
        {
            description="Você pode usar qualquer uma das seguintes ações em sua vez.\n- Guarda-costas\n- Ataque de Desvio\n- A melhor defesa",
            tree="Protetor Leal",
            name="Acções de Protecção"
        },
        {
            description="Como reação a você ser danificado por um ataque ou um poder da Força, um de seus seguidores pode fazer um ataque imediato ou variou contra o alvo que o atacou.",
            tree="Protetor Leal",
            name="Proteção contra punição"
        },
        {
            description="Cada um dos seus seguidores ganha a façanha da dureza.",
            tree="Protetor Leal",
            name="Lealdade Imortal"
        },
        {
            description="Quando adjacentes a duas criaturas ganham ocultação contra alvos não adjacentes.",
            tree="Mestre da Intriga",
            name="Misturar"
        },
        {
            description="Escolha dois talentos que você encontra reqs. Passe o FP para obter acesso 1/turn até o fim da sua próxima volta",
            tree="Mestre da Intriga",
            name="Feito Tudo"
        },
        {
            description="1/enc no início de sua primeira volta dois aliados em LOS e 12 sq mover sua velocidade como reac",
            tree="Mestre da Intriga",
            name="Entrar em posição"
        },
        {
            description="Quando você se move para baixo da trilha da barragem que excede o thresh, próximo ack antes do fim da próxima volta move alvo -1 para baixo se leva a represa",
            tree="Mestre da Intriga",
            name="Planejamento Avançado"
        },
        {
            description="Evite que um inimigo receba bônus de moral e insight para rodada",
            tree="Provocador",
            name="Suspeita Elevada"
        },
        {
            description="Redirecionar um ataque perdido contra um aliado para um inimigo adjacente",
            tree="Provocador",
            name="Amigo ou Foi"
        },
        {
            description="Faça uma verificação de persuasão contra Defesa de Vontade para ordenar um inimigo para atacar outro de seus inimigos",
            tree="Provocador",
            name="Traidor Verdadeiro"
        },
        {
            description="Você usurpar a tentativa de um inimigo para ajudar outro e dar o bônus para um aliado",
            tree="Provocador",
            name="Vantagem Roubada"
        },
        {
            description="Quando seus aliados tomam um Segundo Vento, seus inimigos perdem seu bônus de Dexterity para Defesa de Reflexos",
            tree="Provocador",
            name="Aflição por Discórdia"
        },
        {
            description="Se você gastar FP em rolo de habilidade e falha recuperar FP",
            tree="Desafio de Habilidade",
            name="Garantido Boon"
        },
        {
            description="Quando você tiver sucesso com habilidade no desafio de habilidade, ganhe +2 em diferentes rolos de habilidade no mesmo desafio",
            tree="Desafio de Habilidade",
            name="Habilidade Principal"
        },
        {
            description="Quando você falha no teste de habilidade, o próximo aliado ganha +2 com habilidade diferente",
            tree="Desafio de Habilidade",
            name="Aprenda com erros"
        },
        {
            description="Quando você falhar verificar no desafio de habilidade escolha aliado. Próximo uso da mesma habilidade rolar 2 dados e manter melhor",
            tree="Desafio de Habilidade",
            name="Tente a sua sorte"
        },
        {
            description="Perder bônus de competência em 1 habilidade para rolar 2 dados manter melhor",
            tree="Habilidades Superiores",
            name="Habilidade Assegurada (Acrobacias)"
        },
        {
            description="Perder bônus de competência em 1 habilidade para rolar 2 dados manter melhor",
            tree="Habilidades Superiores",
            name="Habilidade Assegurada (Climb)"
        },
        {
            description="Perder bônus de competência em 1 habilidade para rolar 2 dados manter melhor",
            tree="Habilidades Superiores",
            name="Habilidade Assegurada (Decepção)"
        },
        {
            description="Perder bônus de competência em 1 habilidade para rolar 2 dados manter melhor",
            tree="Habilidades Superiores",
            name="Habilidade Assegurada (Endurance)"
        },
        {
            description="Perder bônus de competência em 1 habilidade para rolar 2 dados manter melhor",
            tree="Habilidades Superiores",
            name="Habilidade Assegurada (Informação de Coleta)"
        },
        {
            description="Perder bônus de competência em 1 habilidade para rolar 2 dados manter melhor",
            tree="Habilidades Superiores",
            name="Habilidade Assegurada (Iniciativa)"
        },
        {
            description="Perder bônus de competência em 1 habilidade para rolar 2 dados manter melhor",
            tree="Habilidades Superiores",
            name="Habilidade Assegurada (Jump)"
        },
        {
            description="Perder bônus de competência em 1 habilidade para rolar 2 dados manter melhor",
            tree="Habilidades Superiores",
            name="Habilidade Assegurada (Conhecimento [Bureacracy])"
        },
        {
            description="Perder bônus de competência em 1 habilidade para rolar 2 dados manter melhor",
            tree="Habilidades Superiores",
            name="Habilidade Assegurada (Conhecimento [Galático])"
        },
        {
            description="Perder bônus de competência em 1 habilidade para rolar 2 dados manter melhor",
            tree="Habilidades Superiores",
            name="Habilidade Assegurada (Conhecimento [Ciências da Vida])"
        },
        {
            description="Perder bônus de competência em 1 habilidade para rolar 2 dados manter melhor",
            tree="Habilidades Superiores",
            name="Habilidade Assegurada (Conhecimento [ciências físicas])"
        },
        {
            description="Perder bônus de competência em 1 habilidade para rolar 2 dados manter melhor",
            tree="Habilidades Superiores",
            name="Habilidade Segura (Conhecimento [Ciências Sociais])"
        },
        {
            description="Perder bônus de competência em 1 habilidade para rolar 2 dados manter melhor",
            tree="Habilidades Superiores",
            name="Habilidade Assegurada (Conhecimento [Tática])"
        },
        {
            description="Perder bônus de competência em 1 habilidade para rolar 2 dados manter melhor",
            tree="Habilidades Superiores",
            name="Conhecimento [Tecnologia]"
        },
        {
            description="Perder bônus de competência em 1 habilidade para rolar 2 dados manter melhor",
            tree="Habilidades Superiores",
            name="Habilidade Assegurada (Mecânica)"
        },
        {
            description="Perder bônus de competência em 1 habilidade para rolar 2 dados manter melhor",
            tree="Habilidades Superiores",
            name="Habilidade Assegurada (Percepção)"
        },
        {
            description="Perder bônus de competência em 1 habilidade para rolar 2 dados manter melhor",
            tree="Habilidades Superiores",
            name="Habilidade Assegurada (Persuasão)"
        },
        {
            description="Perder bônus de competência em 1 habilidade para rolar 2 dados manter melhor",
            tree="Habilidades Superiores",
            name="Habilidade Assegurada (Pilot)"
        },
        {
            description="Perder bônus de competência em 1 habilidade para rolar 2 dados manter melhor",
            tree="Habilidades Superiores",
            name="Habilidade Assegurada (Ride)"
        },
        {
            description="Perder bônus de competência em 1 habilidade para rolar 2 dados manter melhor",
            tree="Habilidades Superiores",
            name="Habilidade Segura (Stealth)"
        },
        {
            description="Perder bônus de competência em 1 habilidade para rolar 2 dados manter melhor",
            tree="Habilidades Superiores",
            name="Habilidade Assegurada (Survival)"
        },
        {
            description="Perder bônus de competência em 1 habilidade para rolar 2 dados manter melhor",
            tree="Habilidades Superiores",
            name="Habilidade Assegurada (Natação)"
        },
        {
            description="Perder bônus de competência em 1 habilidade para rolar 2 dados manter melhor",
            tree="Habilidades Superiores",
            name="Habilidade Assegurada (Tratado de Lesão)"
        },
        {
            description="Perder bônus de competência em 1 habilidade para rolar 2 dados manter melhor",
            tree="Habilidades Superiores",
            name="Habilidade Assegurada (Use Computador)"
        },
        {
            description="Perder bônus de competência em 1 habilidade para rolar 2 dados manter melhor",
            tree="Habilidades Superiores",
            name="Habilidade Assegurada (Use a Força)"
        },
        {
            description="Quando você rolar nat 20 em uma habilidade, escolha habilidades diferentes. Ganhe +5 antes do fim da próxima volta como livre",
            tree="Habilidades Superiores",
            name="Sucesso da habilidade crítica"
        },
        {
            description="Quando você rolar um nat 2-7, trate como 8.",
            tree="Habilidades Superiores",
            name="Habilidade excepcional (Acrobacias)"
        },
        {
            description="Quando você rolar um nat 2-7, trate como 8.",
            tree="Habilidades Superiores",
            name="Habilidade excepcional (Climb)"
        },
        {
            description="Quando você rolar um nat 2-7, trate como 8.",
            tree="Habilidades Superiores",
            name="Habilidade Excepcional (Decepção)"
        },
        {
            description="Quando você rolar um nat 2-7, trate como 8.",
            tree="Habilidades Superiores",
            name="Habilidade Excepcional (Endurance)"
        },
        {
            description="Quando você rolar um nat 2-7, trate como 8.",
            tree="Habilidades Superiores",
            name="Habilidade Excepcional (Recolher informações)"
        },
        {
            description="Quando você rolar um nat 2-7, trate como 8.",
            tree="Habilidades Superiores",
            name="Habilidade Excepcional (Iniciativa)"
        },
        {
            description="Quando você rolar um nat 2-7, trate como 8.",
            tree="Habilidades Superiores",
            name="Habilidade Excepcional (Jump)"
        },
        {
            description="Quando você rolar um nat 2-7, trate como 8.",
            tree="Habilidades Superiores",
            name="Habilidade excepcional"
        },
        {
            description="Quando você rolar um nat 2-7, trate como 8.",
            tree="Habilidades Superiores",
            name="Habilidade Excepcional (Conhecimento [Galático])"
        },
        {
            description="Quando você rolar um nat 2-7, trate como 8.",
            tree="Habilidades Superiores",
            name="Habilidade excepcional (conhecimento [ciências da vida])"
        },
        {
            description="Quando você rolar um nat 2-7, trate como 8.",
            tree="Habilidades Superiores",
            name="Habilidade excepcional (conhecimento [ciências físicas])"
        },
        {
            description="Quando você rolar um nat 2-7, trate como 8.",
            tree="Habilidades Superiores",
            name="Habilidade excepcional (conhecimento [ciências sociais])"
        },
        {
            description="Quando você rolar um nat 2-7, trate como 8.",
            tree="Habilidades Superiores",
            name="Habilidade Excepcional (Conhecimento [Tática])"
        },
        {
            description="Quando você rolar um nat 2-7, trate como 8.",
            tree="Habilidades Superiores",
            name="Conhecimento [Tecnologia]"
        },
        {
            description="Quando você rolar um nat 2-7, trate como 8.",
            tree="Habilidades Superiores",
            name="Habilidade excepcional (Mecânica)"
        },
        {
            description="Quando você rolar um nat 2-7, trate como 8.",
            tree="Habilidades Superiores",
            name="Habilidade Excepcional (Percepção)"
        },
        {
            description="Quando você rolar um nat 2-7, trate como 8.",
            tree="Habilidades Superiores",
            name="Habilidade excepcional (persuasão)"
        },
        {
            description="Quando você rolar um nat 2-7, trate como 8.",
            tree="Habilidades Superiores",
            name="Habilidade Excepcional (Pilot)"
        },
        {
            description="Quando você rolar um nat 2-7, trate como 8.",
            tree="Habilidades Superiores",
            name="Habilidade excepcional (Ride)"
        },
        {
            description="Quando você rolar um nat 2-7, trate como 8.",
            tree="Habilidades Superiores",
            name="Habilidade Excepcional (Stealth)"
        },
        {
            description="Quando você rolar um nat 2-7, trate como 8.",
            tree="Habilidades Superiores",
            name="Habilidade excepcional (sobrevivência)"
        },
        {
            description="Quando você rolar um nat 2-7, trate como 8.",
            tree="Habilidades Superiores",
            name="Habilidade excepcional (Natação)"
        },
        {
            description="Quando você rolar um nat 2-7, trate como 8.",
            tree="Habilidades Superiores",
            name="Habilidade Excepcional (Lesão no Tratamento)"
        },
        {
            description="Quando você rolar um nat 2-7, trate como 8.",
            tree="Habilidades Superiores",
            name="Habilidade Excepcional (Use Computador)"
        },
        {
            description="Quando você rolar um nat 2-7, trate como 8.",
            tree="Habilidades Superiores",
            name="Habilidade Excepcional (Use a Força)"
        },
        {
            description="Reroll FP dados que mostram 1 em uma verificação de habilidade e reroll até que é 2 ou superior",
            tree="Habilidades Superiores",
            name="Boon confiável"
        },
        {
            description="aumentar os dados FP para próximo maior em 1 habilidade (d6 a d8, d8 a d10, d10 a d12)",
            tree="Habilidades Superiores",
            name="Acrobacias"
        },
        {
            description="aumentar os dados FP para próximo maior em 1 habilidade (d6 a d8, d8 a d10, d10 a d12)",
            tree="Habilidades Superiores",
            name="Habilidade Boon (Climb)"
        },
        {
            description="aumentar os dados FP para próximo maior em 1 habilidade (d6 a d8, d8 a d10, d10 a d12)",
            tree="Habilidades Superiores",
            name="Habilidade Boon (Decepção)"
        },
        {
            description="aumentar os dados FP para próximo maior em 1 habilidade (d6 a d8, d8 a d10, d10 a d12)",
            tree="Habilidades Superiores",
            name="Habilidade Boon (Endurance)"
        },
        {
            description="aumentar os dados FP para próximo maior em 1 habilidade (d6 a d8, d8 a d10, d10 a d12)",
            tree="Habilidades Superiores",
            name="Bóon de Habilidade (Informação de Coleta)"
        },
        {
            description="aumentar os dados FP para próximo maior em 1 habilidade (d6 a d8, d8 a d10, d10 a d12)",
            tree="Habilidades Superiores",
            name="Habilidade Boon (Iniciativa)"
        },
        {
            description="aumentar os dados FP para próximo maior em 1 habilidade (d6 a d8, d8 a d10, d10 a d12)",
            tree="Habilidades Superiores",
            name="Habilidade Boon (Jump)"
        },
        {
            description="aumentar os dados FP para próximo maior em 1 habilidade (d6 a d8, d8 a d10, d10 a d12)",
            tree="Habilidades Superiores",
            name="Habilidade Boon (Conhecimento [Bureaucracy])"
        },
        {
            description="aumentar os dados FP para próximo maior em 1 habilidade (d6 a d8, d8 a d10, d10 a d12)",
            tree="Habilidades Superiores",
            name="Habilidade Boon (Conhecimento [Lore galáctico])"
        },
        {
            description="aumentar os dados FP para próximo maior em 1 habilidade (d6 a d8, d8 a d10, d10 a d12)",
            tree="Habilidades Superiores",
            name="Habilidade Boon (Conhecimento [Ciências da Vida])"
        },
        {
            description="aumentar os dados FP para próximo maior em 1 habilidade (d6 a d8, d8 a d10, d10 a d12)",
            tree="Habilidades Superiores",
            name="Habilidade Boon (Conhecimento [ciências físicas])"
        },
        {
            description="aumentar os dados FP para próximo maior em 1 habilidade (d6 a d8, d8 a d10, d10 a d12)",
            tree="Habilidades Superiores",
            name="Habilidade Boon (Conhecimento [Ciências Sociais])"
        },
        {
            description="aumentar os dados FP para próximo maior em 1 habilidade (d6 a d8, d8 a d10, d10 a d12)",
            tree="Habilidades Superiores",
            name="Habilidade Boon (Conhecimento [Tática])"
        },
        {
            description="aumentar os dados FP para próximo maior em 1 habilidade (d6 a d8, d8 a d10, d10 a d12)",
            tree="Habilidades Superiores",
            name="Habilidade Boon (Conhecimento [Tecnologia])"
        },
        {
            description="aumentar os dados FP para próximo maior em 1 habilidade (d6 a d8, d8 a d10, d10 a d12)",
            tree="Habilidades Superiores",
            name="Habilidade Boon (Mecânica)"
        },
        {
            description="aumentar os dados FP para próximo maior em 1 habilidade (d6 a d8, d8 a d10, d10 a d12)",
            tree="Habilidades Superiores",
            name="Habilidade Boon (Percepção)"
        },
        {
            description="aumentar os dados FP para próximo maior em 1 habilidade (d6 a d8, d8 a d10, d10 a d12)",
            tree="Habilidades Superiores",
            name="Habilidade Boon (Persuasão)"
        },
        {
            description="aumentar os dados FP para próximo maior em 1 habilidade (d6 a d8, d8 a d10, d10 a d12)",
            tree="Habilidades Superiores",
            name="Habilidade Boon (Pilot)"
        },
        {
            description="aumentar os dados FP para próximo maior em 1 habilidade (d6 a d8, d8 a d10, d10 a d12)",
            tree="Habilidades Superiores",
            name="Habilidade Boon (Ride)"
        },
        {
            description="aumentar os dados FP para próximo maior em 1 habilidade (d6 a d8, d8 a d10, d10 a d12)",
            tree="Habilidades Superiores",
            name="Habilidade Boon (Stealth)"
        },
        {
            description="aumentar os dados FP para próximo maior em 1 habilidade (d6 a d8, d8 a d10, d10 a d12)",
            tree="Habilidades Superiores",
            name="Habilidade Boon (Survival)"
        },
        {
            description="aumentar os dados FP para próximo maior em 1 habilidade (d6 a d8, d8 a d10, d10 a d12)",
            tree="Habilidades Superiores",
            name="Habilidade Boon (Natação)"
        },
        {
            description="aumentar os dados FP para próximo maior em 1 habilidade (d6 a d8, d8 a d10, d10 a d12)",
            tree="Habilidades Superiores",
            name="Habilidade Boon (Injúria Tratada)"
        },
        {
            description="aumentar os dados FP para próximo maior em 1 habilidade (d6 a d8, d8 a d10, d10 a d12)",
            tree="Habilidades Superiores",
            name="Habilidade Boon (Usar Computador)"
        },
        {
            description="aumentar os dados FP para próximo maior em 1 habilidade (d6 a d8, d8 a d10, d10 a d12)",
            tree="Habilidades Superiores",
            name="Habilidade Boon (Use a Força)"
        },
        {
            description="Quando não conseguir obter resultado min de verificação de 1 habilidade, ganhar FP só utilizável nessa habilidade antes do fim do enc",
            tree="Habilidades Superiores",
            name="Recuperação habilidosa (Acrobacias)"
        },
        {
            description="Quando não conseguir obter resultado min de verificação de 1 habilidade, ganhar FP só utilizável nessa habilidade antes do fim do enc",
            tree="Habilidades Superiores",
            name="Recuperação habilidosa (Climb)"
        },
        {
            description="Quando não conseguir obter resultado min de verificação de 1 habilidade, ganhar FP só utilizável nessa habilidade antes do fim do enc",
            tree="Habilidades Superiores",
            name="Recuperação habilidosa (Decepção)"
        },
        {
            description="Quando não conseguir obter resultado min de verificação de 1 habilidade, ganhar FP só utilizável nessa habilidade antes do fim do enc",
            tree="Habilidades Superiores",
            name="Recuperação habilidosa (Endurance)"
        },
        {
            description="Quando não conseguir obter resultado min de verificação de 1 habilidade, ganhar FP só utilizável nessa habilidade antes do fim do enc",
            tree="Habilidades Superiores",
            name="Recuperação habilidosa (informações de coleta)"
        },
        {
            description="Quando não conseguir obter resultado min de verificação de 1 habilidade, ganhar FP só utilizável nessa habilidade antes do fim do enc",
            tree="Habilidades Superiores",
            name="Recuperação habilidosa (iniciativa)"
        },
        {
            description="Quando não conseguir obter resultado min de verificação de 1 habilidade, ganhar FP só utilizável nessa habilidade antes do fim do enc",
            tree="Habilidades Superiores",
            name="Recuperação habilidosa (Jump)"
        },
        {
            description="Quando não conseguir obter resultado min de verificação de 1 habilidade, ganhar FP só utilizável nessa habilidade antes do fim do enc",
            tree="Habilidades Superiores",
            name="Recuperação habilidosa (Conhecimento [Bureaucracy])"
        },
        {
            description="Quando não conseguir obter resultado min de verificação de 1 habilidade, ganhar FP só utilizável nessa habilidade antes do fim do enc",
            tree="Habilidades Superiores",
            name="Recuperação habilidosa"
        },
        {
            description="Quando não conseguir obter resultado min de verificação de 1 habilidade, ganhar FP só utilizável nessa habilidade antes do fim do enc",
            tree="Habilidades Superiores",
            name="Recuperação habilidosa (Conhecimento [Ciências da vida])"
        },
        {
            description="Quando não conseguir obter resultado min de verificação de 1 habilidade, ganhar FP só utilizável nessa habilidade antes do fim do enc",
            tree="Habilidades Superiores",
            name="Recuperação habilidosa (Conhecimento [ciências físicas])"
        },
        {
            description="Quando não conseguir obter resultado min de verificação de 1 habilidade, ganhar FP só utilizável nessa habilidade antes do fim do enc",
            tree="Habilidades Superiores",
            name="Recuperação habilidosa (Conhecimento [Ciências Sociais])"
        },
        {
            description="Quando não conseguir obter resultado min de verificação de 1 habilidade, ganhar FP só utilizável nessa habilidade antes do fim do enc",
            tree="Habilidades Superiores",
            name="Recuperação habilidosa (Conhecimento [Tática])"
        },
        {
            description="Quando não conseguir obter resultado min de verificação de 1 habilidade, ganhar FP só utilizável nessa habilidade antes do fim do enc",
            tree="Habilidades Superiores",
            name="Recuperação habilidosa (Conhecimento [Tecnologia])"
        },
        {
            description="Quando não conseguir obter resultado min de verificação de 1 habilidade, ganhar FP só utilizável nessa habilidade antes do fim do enc",
            tree="Habilidades Superiores",
            name="Recuperação habilidosa (Mecânica)"
        },
        {
            description="Quando não conseguir obter resultado min de verificação de 1 habilidade, ganhar FP só utilizável nessa habilidade antes do fim do enc",
            tree="Habilidades Superiores",
            name="Recuperação habilidosa (Percepção)"
        },
        {
            description="Quando não conseguir obter resultado min de verificação de 1 habilidade, ganhar FP só utilizável nessa habilidade antes do fim do enc",
            tree="Habilidades Superiores",
            name="Recuperação habilidosa (Persuasão)"
        },
        {
            description="Quando não conseguir obter resultado min de verificação de 1 habilidade, ganhar FP só utilizável nessa habilidade antes do fim do enc",
            tree="Habilidades Superiores",
            name="Recuperação habilidosa (Pilot)"
        },
        {
            description="Quando não conseguir obter resultado min de verificação de 1 habilidade, ganhar FP só utilizável nessa habilidade antes do fim do enc",
            tree="Habilidades Superiores",
            name="Recuperação habilidosa (Ride)"
        },
        {
            description="Quando não conseguir obter resultado min de verificação de 1 habilidade, ganhar FP só utilizável nessa habilidade antes do fim do enc",
            tree="Habilidades Superiores",
            name="Recuperação habilidosa (stealth)"
        },
        {
            description="Quando não conseguir obter resultado min de verificação de 1 habilidade, ganhar FP só utilizável nessa habilidade antes do fim do enc",
            tree="Habilidades Superiores",
            name="Recuperação habilidosa (Survival)"
        },
        {
            description="Quando não conseguir obter resultado min de verificação de 1 habilidade, ganhar FP só utilizável nessa habilidade antes do fim do enc",
            tree="Habilidades Superiores",
            name="Recuperação habilidosa (Natação)"
        },
        {
            description="Quando não conseguir obter resultado min de verificação de 1 habilidade, ganhar FP só utilizável nessa habilidade antes do fim do enc",
            tree="Habilidades Superiores",
            name="Recuperação habilidosa"
        },
        {
            description="Quando não conseguir obter resultado min de verificação de 1 habilidade, ganhar FP só utilizável nessa habilidade antes do fim do enc",
            tree="Habilidades Superiores",
            name="Recuperação habilidosa (Use Computador)"
        },
        {
            description="Quando não conseguir obter resultado min de verificação de 1 habilidade, ganhar FP só utilizável nessa habilidade antes do fim do enc",
            tree="Habilidades Superiores",
            name="Recuperação habilidosa (Use a força)"
        },
        {
            description="Quando você faz uma verificação de engano para fingir (ver página 66 do livro de regras da Saga Edition) contra um inimigo dentro de 6 quadrados de você, você pode rolar duas vezes, mantendo o melhor dos dois resultados. Pré-requisito: Treinado em Enganação.",
            tree="Árvore de Talentos Brigadeiros",
            name="Truque barato"
        },
        {
            description="Quando você faz um ataque como uma ação padrão e atinge com sucesso um inimigo, você pode optar por reduzir os danos que você lida pela metade. Esse alvo é então negado seu bônus de Dexterity para Defesa de Reflexos contra seus ataques até o fim de sua próxima vez. Pré-requisito: Truque barato.",
            tree="Árvore de Talentos Brigadeiros",
            name="Prey Fácil"
        },
        {
            description="Você rapidamente se move sobre o campo de batalha, aproveitando o caos da batalha para ganhar vantagem. Você pode usar cada uma das seguintes ações uma vez por encontro como uma ação padrão:\n* Distracting Injury: Faça um único ataque ou variou contra qualquer inimigo dentro do seu alcance. Se o ataque atingir com sucesso, esse inimigo leva uma penalidade -2 para seus rolos de ataque e rolos de danos até o final do encontro.\n* Faça com que Sangrem: Faça uma única batalha ou ataque contra qualquer criatura viva dentro do seu alcance. Se você lidar com sucesso com danos como resultado do ataque, que o inimigo ganha uma condição persistente que pode ser removido apenas com um sucesso DC 25 Trate Injury check para realizar a cirurgia.\n* Força em Números: Faça uma única batalha ou atacou um inimigo que é adjacente a um ou mais de seus aliados. Se você acertar com sucesso esse inimigo, você ganha um bônus +2 para danos para cada aliado que está adjacente ao alvo. Pré-requisitos: Trick barato, Prey fácil.",
            tree="Árvore de Talentos Brigadeiros",
            name="Combatente Sly"
        },
        {
            description="Durante a primeira ronda de combate, se vai danificar com sucesso um inimigo que ainda não agiu no combate. você pode fazer um ataque imediato como uma ação livre contra um alvo diferente dentro de 6 quadrados do primeiro alvo. Pré-requisito: Truque barato.",
            tree="Árvore de Talentos Brigadeiros",
            name="Ataque Rápido"
        },
        {
            description="Passe um ponto de força para ganhar um bônus +1 para atacar rolos, +1 para todas as defesas, ou +5 para verificação de habilidades para o resto do encontro como uma ação padrão",
            tree="Sorte",
            name="Sorte do Tolo"
        },
        {
            description="Uma vez por encontro, transformar um ataque crítico contra você em um ataque normal.",
            tree="Sorte",
            name="Avert Disaster"
        },
        {
            description="Uma vez por encontro, como reação, você ganha um bônus de sorte +5 para qualquer defesa até o início da próxima vez.",
            tree="Sorte",
            name="Melhor sorte do que morte"
        },
        {
            description="Ganhe uma ação padrão livre ao marcar um hit crítico em um rolo de ataque",
            tree="Sorte",
            name="Favor da sorte"
        },
        {
            description="Ganhe um bônus +2 para cheques Sabedoria para jogos de azar\n\n(Entrar número de vezes tomadas)",
            tree="Sorte",
            name="Jogador"
        },
        {
            description="Rerole uma verificação de habilidade e ter o melhor resultado uma vez por dia\n\n(Entrar número de vezes tomadas)",
            tree="Sorte",
            name="Knack"
        },
        {
            description="Rerole um rolo de ataque e ter o melhor resultado uma vez por dia\n\n(Entrar número de vezes tomadas)",
            tree="Sorte",
            name="Lucky Shot"
        },
        {
            description="Você pode usar cada um dos seguintes uma vez por encontro como uma ação padrão:\n- Inimigo de ilusório\n- Escapar.\n- Faça a sua própria sorte\nVer p.14 de Escória e Vilões",
            tree="Sorte",
            name="Sorte idiota"
        },
        {
            description="Você pode reduzir o disfarce de um inimigo por um passo, mas só lidar com metade dos danos.",
            tree="Sorte",
            name="Tiro Ricochet"
        },
        {
            description="Uma vez por encontro, você pode considerar qualquer único rolo d20 de 16 ou mais para ser um natural 20.",
            tree="Sorte",
            name="Sorte Inexplicável"
        },
        {
            description="Uma vez por encontro, você pode reroll o dano de um ataque e ter o melhor resultado.",
            tree="Sorte",
            name="Improvável Tiro"
        },
        {
            description="Uma vez por encontro como uma reação, negue os danos de um ataque que reduziria você a 0 pontos de ataque",
            tree="Sorte",
            name="Parada da Sorte"
        },
        {
            description="Uma vez por encontro, como uma reação, você se torna imune a todos os efeitos que afetam a mente até o fim da próxima vez. Você pode escolher reter efeitos benéficos.",
            tree="Sorte",
            name="Mente Labryntina"
        },
        {
            description="Uma vez por encontro, aplique uma toxina em uma arma como uma ação padrão para envenenar qualquer inimigo cuja defesa fortitude é menor do que o seu sucesso rolo de ataque. O veneno faz o ataque rolar para danificar o alvo e movê-los pela pista conditon",
            tree="Envenenador de Malkite",
            name="Técnicas de Malkite"
        },
        {
            description="Faça uma verificação do conhecimento (ciências da vida) no tratado de lesão DC de um veneno para mudar o método de entrega de um veneno",
            tree="Envenenador de Malkite",
            name="Modificar o Veneno"
        },
        {
            description="Qualquer alvo envenenado por ti é negado o seu bónus de destreza para a Defesa Reflexa enquanto afligido",
            tree="Envenenador de Malkite",
            name="Entorpecente Veneno"
        },
        {
            description="O tratamento de lesão DC para curar o seu veneno aumenta em 5",
            tree="Envenenador de Malkite",
            name="Veneno Indetectável"
        },
        {
            description="Seus venenos ganham +2 para seus rolos de ataque para vencer a defesa Fortitude do alvo",
            tree="Envenenador de Malkite",
            name="Veneno Vicioso"
        },
        {
            description="Como ação rápida fazer Deception verificar contra um alvo Defesa de Vontade. Se você conseguir, até o início de sua próxima volta, você pode se mover através da área ameaçada do alvo como parte de sua ação de movimento sem provocar um ataque de oportunidade.",
            tree="Desfortuna",
            name="Bebuddle"
        },
        {
            description="Ataques bem sucedidos contra oponentes negaram seu bônus de Dexterity para Defesa de Reflexos movê-los -1 descer a trilha da condição",
            tree="Desfortuna",
            name="Ataque Covarde"
        },
        {
            description="Sempre que você der dano ao oponente negou seu bônus Dex para Defesa de Reflexos, você pode optar por não mover o alvo para baixo da pista de condição e, em vez disso, impor uma penalidade -5 para todos os ataques do seu oponente e danos melee até o final do seu próximo turno.",
            tree="Desfortuna",
            name="Greve Fraca"
        },
        {
            description="Inimigos dentro da linha de visão são negados moral e insight bônus até o início de sua próxima vez",
            tree="Desfortuna",
            name="Disruptivo"
        },
        {
            description="Os oponentes dentro da linha de visão e seis quadrados levam uma penalidade -2 para suas defesas até o início de sua próxima volta, ativada como uma ação padrão",
            tree="Desfortuna",
            name="Caminhe na Linha"
        },
        {
            description="Você pode usar cada uma das seguintes ações uma vez por encontro:\n- Criar Abertura\n- Ataque paralisante\n- Ataque Vicioso\nVer p. 15 de Escória e Vilões",
            tree="Desfortuna",
            name="Estrategista abominável"
        },
        {
            description="Faça uma verificação de persuasão como uma ação padrão contra um alvo dentro de 12 quadrados. Se o cheque vencer a Defesa de Vontade do alvo, o alvo leva uma penalidade -2 para sua velocidade base e deve gastar uma ação rápida para fazer uma ação padrão.",
            tree="Desfortuna",
            name="Hesitar"
        },
        {
            description="Uma vez por encontro como uma ação padrão, faça uma verificação Decepção contra Will defesa de todos os inimigos na linha de visão, em um sucesso, eles têm que passar uma ação rápida, além de uma ação padrão para atacar até o início de sua próxima vez",
            tree="Desfortuna",
            name="Confusão de Semeamento"
        },
        {
            description="Se você falhar em uma verificação de Persuasão para mudar a atitude de um alvo, você pode voltar com sua Decepção",
            tree="Desfortuna",
            name="Sedutor"
        },
        {
            description="Uma vez por encontro como uma ação de movimento você pode apreender um objeto segurado, carregado ou usado em um alvo adjacente, fazendo um ataque Desarmado com um bônus +10",
            tree="Desfortuna",
            name="Apreender objeto"
        },
        {
            description="+1 bônus para atacar rolos até o início de sua próxima volta se você mover pelo menos 2 quadrados antes de atacar e terminar sua jogada em um quadrado diferente do quadrado inicial",
            tree="Desfortuna",
            name="Skirmisher"
        },
        {
            description="Quando você mover pelo menos 2 quadrados antes de seu ataque e terminar sua jogada em um quadrado diferente de onde você começou, você ganha um bônus +1 para todas as suas defesas até o início de sua próxima volta.",
            tree="Desfortuna",
            name="Esquirmisher Melhorado"
        },
        {
            description="Ganhar 1d6 pontos de dano em ataques contra alvos dentro de 6 quadrados negou seu bônus de Dexterity para Defesa de Reflexos\n\n(Entrar número de vezes tomadas)",
            tree="Desfortuna",
            name="Ataque furtivo"
        },
        {
            description="Você pode aproveitar as distrações do seu adversário, não importa quão momentânea ou fugaz. Uma vez por turno, quando você flanqueia um alvo, você pode tratá-lo ou ela como um pé chato para um de seus ataques. Pré-requisito: Ataque furtivo.",
            tree="Desfortuna",
            name="Apunhalador de costas"
        },
        {
            description="Você pode usar o talento Sneak Attack contra um alvo dentro de 12 quadrados, em vez de dentro de 6 quadrados. Pré-requisitos: Ponto Blank Shot feito, Ataque Sneak.",
            tree="Desfortuna",
            name="Melhor ataque furtivo"
        },
        {
            description="Sempre que você iria ganhar o benefício do talento Skirmisher e você bateu com sucesso no seu oponente, você lidar com danos de ataque furtivo, além de danos normais causados pelo ataque.",
            tree="Desfortuna",
            name="Greve súbita"
        },
        {
            description="Uma vez por rodada, como uma ação rápida, você designa um alvo dentro de 12 quadrados e na linha de visão como o alvo deste talento. Até o início de sua vez, você pode fazer com que o alvo tome uma pena -5 em todos os cheques feitos com uma única habilidade.",
            tree="Desfortuna",
            name="Stymie"
        },
        {
            description="Quando um inimigo ou aliado em sua linha de visão gira um 1 natural em um rolo de ataque, você pode fazer um ataque desordenado ou variou contra um único alvo com no alcance.",
            tree="Oportunista",
            name="Abertura vantajosa"
        },
        {
            description="Quando um inimigo ou aliado dentro de 20 quadrados de você é reduzido para 0 pontos de sucesso, você ganha pontos de bônus igual a 5 + metade do seu nível de personagem.",
            tree="Oportunista",
            name="Animar o Caos"
        },
        {
            description="Quando um alvo move um de seus aliados em sua linha de visão para baixo a pista de condição por qualquer meio, você ganha um bônus +2 insight para seus rolos de ataque contra esse alvo até o final de sua próxima volta.",
            tree="Oportunista",
            name="Retribuição"
        },
        {
            description="Quando um inimigo que você tenha danificado é reduzido para 0 pontos de ataque ou movido para o fundo da pista de condição, seu próximo ataque feito antes do fim das ofertas de encontro + 1 morrer de dano.",
            tree="Oportunista",
            name="Vindicação"
        },
        {
            description="Quando danificas um alvo, até ao início da próxima volta, podes mover-te pelo espaço do alvo. Movendo-se através do espaço do alvo ainda pode provocar ataques de oportunidade como normal, e você deve terminar seu movimento em um espaço legal.",
            tree="Oportunista",
            name="Deslizar"
        },
        {
            description="Objetos e veículos com equipamento de júri ganham pontos temporários iguais ao resultado da sua verificação Mecânica",
            tree="Tecnologia Fora da Lei",
            name="Reparações Rápidas"
        },
        {
            description="Use verificações de computador para melhorar o acesso a um sistema de computador pode ser feito com Mecânica, e Use Computador é considerado uma habilidade treinada",
            tree="Tecnologia Fora da Lei",
            name="Fio quente"
        },
        {
            description="Você pode preparar objetos ou veículos que não estejam desativados uma vez por encontro",
            tree="Tecnologia Fora da Lei",
            name="Correcção Rápida"
        },
        {
            description="+1 bônus para atacar rolos e +2 bônus para danificar rolos com armas powered para o restante de um encontro, ativado como uma ação padrão",
            tree="Tecnologia Fora da Lei",
            name="Modificações Personalizadas"
        },
        {
            description="1/enc quando falhar Decepção ou verificação de persuasão adicionar +1d6 + Wis mod para verificar",
            tree="Forasteiro",
            name="Oafish"
        },
        {
            description="1/enc DC 20 Percepção como stan ganho 1 pedaço de informação: 1 Def pontuação de 1 caráter ou veículo em LOS ou identificar o mesmo com hp mais baixo ou mais alto ou em maior ou mais baixo na pista",
            tree="Forasteiro",
            name="Olho de Fora"
        },
        {
            description="Se falhar a Persuasão para mudar de atitude, a atitude não muda e pode tentar mudar de atitude mais uma vez por enc",
            tree="Forasteiro",
            name="Consulta de Forasteiros"
        },
        {
            description="Sempre que você é perdido por um ataque, você ganha um bônus de moral +2 para o seu próximo rolo de ataque antes do fim do seu próximo turno.",
            tree="Imprudência",
            name="Procurar aberturas"
        },
        {
            description="Uma vez por turno, quando um inimigo o danifica com um ataque de oportunidade, você pode fazer um único ataque ou variou ataque contra um alvo em alcance como areação.\nPré-requisito: Encontrar Aberturas.",
            tree="Imprudência",
            name="Risco de recompensa"
        },
        {
            description="Sempre que você faz um ataque de área, cada aliado na área não leva nenhum dano se seu rolo de ataque falhar em superar sua defesa Reflex, e leva metade dos danos se o ataque atingir.",
            tree="Imprudência",
            name="Bater no Deck"
        },
        {
            description="Como uma ação rápida, faça uma verificação de Iniciativa, oposta pela verificação de Iniciativa de um inimigo dentro de sua linha de visão. Se seu resultado de verificação for igual ou superior à verificação do alvo, o alvo é considerado plano contra o próximo ataque que fizer antes do fim da sua vez.Se o resultado de verificação do alvo for maior, você é considerado plano contra o próximo ataque feito pelo alvo antes do início da sua próxima volta.",
            tree="Imprudência",
            name="Trick Step"
        },
        {
            description="Uma vez por tum, como uma ação de movimento, você pode fazer uma verificação Decepção contra a Defesa da Vontade de um inimigo com em 12 quadrados e com na sua linha de visão. Se seu resultado de verificação é igual ou superior à Defesa de Vontade do alvo, o alvo deve mover um número de quadrados igual a metade de sua velocidade, e cada quadrado de movimento deve trazer o doseador de alvo para você (embora o alvo evite perigos e obstades). Se o alvo não puder evitar um perigo (como um poço), pára de se mover no quadrado seguro ne3rest. Este movimento é considerado involuntário e não provoca ataques de oportunidade. Este é um efeito que afeta a mente.\nPré-requisito: Trick Step.",
            tree="Imprudência",
            name="Atrair mais perto"
        },
        {
            description="+5 para verificação Mecânica para manipulação de explosivos e criar granada frag a partir de peças de reposição",
            tree="Revolucionário",
            name="Atirador de Bombas"
        },
        {
            description="quando você bate com ataque e dano excede thresh alvo leva -5 para atingi-lo até o final da sua vez",
            tree="Revolucionário",
            name="Criar um Exemplo"
        },
        {
            description="alvo w/in 12 sq & LOS Persuasão vs Will ou alvo não pode tomar ações do Stan até sua próxima vez",
            tree="Revolucionário",
            name="Retórica revolucionária"
        },
        {
            description="Uma vez por encontro, fazer um ataque de oportunidade contra um oponente dentro de alcance à queima-roupa contra um oponente provocando um ataque de oportunidade contra um aliado",
            tree="Executar e Armar",
            name="Greve oportunista"
        },
        {
            description="Uma vez por encontro, faça um ataque de oportunidade contra um inimigo usando retirar dentro do alcance à queima-roupa",
            tree="Executar e Armar",
            name="Tiro Barato"
        },
        {
            description="Um inimigo que usa retirar-se do seu espaço ameaçado é considerado plano até à sua próxima volta",
            tree="Executar e Armar",
            name="Nenhuma fuga"
        },
        {
            description="Uma vez por encontro, ao danificar um oponente, você pode mover sua velocidade",
            tree="Executar e Armar",
            name="Atacar e Correr"
        },
        {
            description="Uma vez por encontro, ao danificar um oponente, você pode negar-lhes ataques de oportunidade até sua próxima vez",
            tree="Executar e Armar",
            name="Strike Slippery"
        },
        {
            description="Você pode usar Use Computador em vez de Enganar para falsificar documentos eletrônicos",
            tree="Cortador",
            name="Falsificação eletrônica"
        },
        {
            description="Faça uma verificação Use Computer para substituir a defesa de vontade de um computador e torná-lo hostil para qualquer pessoa, exceto você",
            tree="Cortador",
            name="Sabotagem Eletrónica"
        },
        {
            description="Você pode substituir Usar verificação de computador para verificação de mecânica ao desativar um dispositivo computadorizado.",
            tree="Cortador",
            name="Vírus"
        },
        {
            description="Emitir comandos de rotina para um computador é uma ação rápida, não uma ação padrão",
            tree="Cortador",
            name="Gimmick"
        },
        {
            description="Rerole todas as verificações Use o computador para melhorar o acesso para melhorar o acesso em um computador e manter o melhor resultado",
            tree="Cortador",
            name="Mestre Slicer"
        },
        {
            description="Você não precisa de um kit de segurança para desativar um sistema de segurança, e pode falhar por até 10, sem repercussões",
            tree="Cortador",
            name="Cortador de Segurança"
        },
        {
            description="Use Computador pode ser usado para fazer Recolha de informações, desde que uma rede de computador",
            tree="Cortador",
            name="Rastrear"
        },
        {
            description="Você pode tomar 10 em cheques Stealth para esconder itens, mesmo sob pressão, e como uma ação rápida",
            tree="Contrabandista",
            name="Arte de esconder"
        },
        {
            description="Uma vez por dia como uma ação padrão, você pode tomar 20 em um teste de engano para enganar",
            tree="Contrabandista",
            name="Falador Rápido"
        },
        {
            description="Se você desenhar um item escondido e atacar um alvo na mesma rodada, o alvo é de pé plano se eles não notarem. Se você tem o desenho rápido, seu desenho é uma ação rápida",
            tree="Contrabandista",
            name="Armas Escondidas"
        },
        {
            description="Você pode reroll cheques de persuasão para regatear por mercadorias refried, militares ou ilegais e manter o melhor resultado",
            tree="Contrabandista",
            name="Negociações Ilícitas"
        },
        {
            description="Ao falhar em uma verificação de engano para transmitir informações enganosas, você pode iniciar o combate e fazer um único ataque como uma ação livre, com todos os outros combatentes considerados surpresos",
            tree="Contrabandista",
            name="Ataque surpresa"
        },
        {
            description="Adicione seu nível de classe uma vez por dia para um rolo de ataque, verificação de habilidades ou verificação de habilidade enquanto em uma nave estelar",
            tree="Espaçador",
            name="Hipercondutor"
        },
        {
            description="Proficiente com qualquer arma da nave estelar, e não levar nenhuma penalidade em rolos de ataque em ambientes de baixa ou zero gravidade nem sofrer doença espacial",
            tree="Espaçador",
            name="Cão Espacial"
        },
        {
            description="Ganhe +1 bônus para atacar rolos em uma nave estelar",
            tree="Espaçador",
            name="Raider da Nave Estelar"
        },
        {
            description="Ao lado de um obstáculo ou barreira, você ganha um bônus de cobertura +2 para sua Defesa Reflexa.",
            tree="Espaçador",
            name="Lutando em quartos apertados"
        },
        {
            description="Ganhar um ponto de força temporário ao rolar um 20 natural em um rolo de ataque feito a bordo de uma nave estelar",
            tree="Espaçador",
            name="Guerreiro Estelar"
        },
        {
            description="Uma vez por encontro, enquanto em um veículo, você pode mover-se até metade de sua velocidade ou mover o veículo até metade de sua velocidade se o piloto como uma ação rápida.",
            tree="Espaçador",
            name="Faça uma pausa para ele"
        },
        {
            description="Reroll Knowledge (ciências da vida) ou tratar verificações de lesões para usar ou reparar biotecnologia",
            tree="Yuuzhan Vong Biotech",
            name="Biotech Adept"
        },
        {
            description="Deal +1 morre de danos com erros de barbear e bugs thud",
            tree="Yuuzhan Vong Biotech",
            name="Bugbite"
        },
        {
            description="Passe uma ação rápida para ignorar a cobertura com um bug de barbear ou bug de bater",
            tree="Yuuzhan Vong Biotech",
            name="Jogada Curvada"
        },
        {
            description="Sempre que tiver sucesso com as armas Vong e o rolo de ataque exceder a Defesa de Vontade, o alvo é considerado plano até ao fim da próxima volta.",
            tree="Yuuzhan Vong Biotech",
            name="Armas surpreendentes"
        },
        {
            description="Ganhe +10 bônus para cheques Deception and Stealth para ocultar biotech e desenhar armas biotecnológicas como ação rápida e adversário negou o bônus de Dexterity para Defesa de Reflexos",
            tree="Yuuzhan Vong Biotech",
            name="Biotecnologia Veiled"
        },
        {
            description="Durante a sua vez, você pode gastar uma ação rápida para permitir que todos os aliados dentro de 6 quadrados de você e dentro de sua linha de visão para contar o primeiro quadrado de terreno difícil como terreno normal cada vez que eles se movem. Pré-requisito: Treinado em Sobrevivência.",
            tree="Árvore de Talentos de Patrulha Avançada",
            name="Trailblazer"
        },
        {
            description="Você pode usar o modificador de verificação de percepção em vez do modificador de iniciativa ao fazer verificações de iniciativa. Se você tem direito a um check reroll Iniciativa, você pode reroll seu teste Percepção em vez (sujeito às mesmas circunstâncias e limitações). Você é considerado para ser treinado em Iniciativa.",
            tree="Árvore de Talentos de Patrulha Avançada",
            name="Passo Cuidadoso"
        },
        {
            description="No início de uma rodada surpresa em que você não é pego de surpresa, você pode designar um aliado dentro de 6 quadrados de você como capaz de reter o seu bônus Dexterity para Defesa de Reflexos durante a rodada surpresa. Pré-requisito: Passo vigilante.",
            tree="Árvore de Talentos de Patrulha Avançada",
            name="Patrulha Avançada"
        },
        {
            description="Você pode reroll verificação Percepção, mas deve aceitar o resultado do reroll mesmo que pior",
            tree="Consciência",
            name="Sentidos agudos"
        },
        {
            description="Você pode se mover em velocidade normal enquanto usa Sobrevivência para rastrear sem penalidade",
            tree="Consciência",
            name="Rastreador Perito"
        },
        {
            description="Você pode reroll verificações Iniciativa, mas deve aceitar o resultado do reroll mesmo que pior",
            tree="Consciência",
            name="Iniciativa Melhorada"
        },
        {
            description="Uma vez por encontro após a primeira rodada completa, o batedor pode definir aumentar sua Iniciativa atual em +5",
            tree="Consciência",
            name="Reiniciar a Iniciativa"
        },
        {
            description="Você não pode ser pego de pés chatos",
            tree="Consciência",
            name="Estranho Dodge I"
        },
        {
            description="Você não pode ser flanqueado",
            tree="Consciência",
            name="Esquivo estranho II"
        },
        {
            description="Nenhuma penalidade para atacar rolos contra alvos com ocultação",
            tree="Consciência",
            name="Keen Shot"
        },
        {
            description="Uma vez por encontro, como uma ação rápida, você pode ignorar o DR de um alvo dentro de sua linha de visão para o resto de sua vez",
            tree="Consciência",
            name="Ponto Fraco"
        },
        {
            description="Ao beneficiar da cobertura, gaste uma ação padrão para aumentar o valor da cobertura por um passo.",
            tree="Camuflagem",
            name="Hunker Down"
        },
        {
            description="Quando propensa, você pode gastar uma ação rápida para ganhar sigilo até o início de sua próxima volta. Se te levantares ou te mexeres, perdes este benefício.",
            tree="Camuflagem",
            name="Cavar"
        },
        {
            description="Se você iniciar sua vez com total ocultação ou cobertura total de um alvo, durante essa volta você pode fazer uma verificação Stealth como uma ação rápida, oposta pela verificação de percepção do alvo. Se você conseguir, o alvo é considerado plano contra você até o fim da sua vez.",
            tree="Camuflagem",
            name="Assaltante Fantasma"
        },
        {
            description="Você pode reroll cheques Stealth, mas deve aceitar o resultado do reroll mesmo que pior",
            tree="Camuflagem",
            name="Melhor Stealth"
        },
        {
            description="Você pode se mover em sua velocidade normal enquanto usa Stealth para se esconder sem penalidade",
            tree="Camuflagem",
            name="Movimento Oculto"
        },
        {
            description="Uma vez por encontro quando dentro de 2 quadrados de cobertura ou ocultação, você pode mover-se para lá e fazer uma verificação Stealth como uma ação de movimento.",
            tree="Camuflagem",
            name="Esconder na Vista Simples"
        },
        {
            description="Você pode usar cada um dos seguintes uma vez por encontro como uma ação padrão:\n- Ataque cego\n- Ataque Confuso\n- Ataque inesperado\nVer p.16 de Escória e Vilões",
            tree="Camuflagem",
            name="Shadow Striker"
        },
        {
            description="Tratar qualquer ocultação como ocultação total",
            tree="Camuflagem",
            name="Ocultação Total"
        },
        {
            description="Stealth substitui Deception para criar diversão para esconder, +5 se treinado em Deception",
            tree="Espionagem",
            name="Desvanecer"
        },
        {
            description="quando atingido ou perdido por ataque velocidade de movimento como reac & deve terminar adjacente ao aliado, no AoO",
            tree="Espionagem",
            name="Manter Juntos"
        },
        {
            description="Quando você reduzir o inimigo para 0 hp/uncon você & 2 aliados w/in 6 sq & LOS mover spd como reac, no AoO",
            tree="Espionagem",
            name="Escapar Prudente"
        },
        {
            description="quando perdido por variado atk & ter cover/escondimento mover metade spd & fazer verificação Stealth se ainda ocultar",
            tree="Espionagem",
            name="Stealth Reativo"
        },
        {
            description="Percepção 1/enc vs Vontade do alvo dentro de 6 sq & LOS para +2 bônus de habilidade e ataques para enc",
            tree="Espionagem",
            name="Redimensionamento"
        },
        {
            description="Você pode rerolar verificações de persuasão feitas para regatear, mas deve aceitar o resultado do reroll mesmo que pior",
            tree="Fringer",
            name="Barter"
        },
        {
            description="Ganhe um ponto de força temporário ao rolar um 20 natural em uma verificação de habilidade durante um encontro",
            tree="Fringer",
            name="Fringe Savant"
        },
        {
            description="Aumentar a velocidade em 2 quadrados sem armadura ou armadura leve",
            tree="Fringer",
            name="Long Stride"
        },
        {
            description="Como uma ação padrão, sua velocidade aumenta em 2, designar um único oponente e mover-se até a sua velocidade longe deles sem provocar ataques de oportunidade.",
            tree="Fringer",
            name="Fugir"
        },
        {
            description="Use uma ação rápida para reduzir o custo de cada movimento em um espaço diagonal para 1 até o final da sua vez se você estiver usando luz ou sem armadura.",
            tree="Fringer",
            name="Passo lateral"
        },
        {
            description="Você pode usar cada um dos seguintes uma vez por encontro como uma ação padrão.\n- Burst Borrão\n- Agressão súbita\n- Tecendo Stride\nVer p.17 de Escória e Vilões",
            tree="Fringer",
            name="Strider Rápido"
        },
        {
            description="Uma vez por encontro você pode usar uma ação rápida para avançar até a sua velocidade.",
            tree="Fringer",
            name="Surge"
        },
        {
            description="Podes refazer os cheques da Mecânica para o júri-rig, mas tens de aceitar o resultado da reroll mesmo que pior.",
            tree="Fringer",
            name="Jury Rigger"
        },
        {
            description="Sempre que você com sucesso júri-rig um dispositivo ou veículo, ele não se move -5 passos ao longo da trilha de condição no final do encontro, embora ele move -2 passos persistentes para baixo a trilha de condição.",
            tree="Fringer",
            name="Mantenha-o unido"
        },
        {
            description="Uma vez por encontro, force seu oponente a rebobinar um ataque contra você ou seu veículo e tomar o pior resultado",
            tree="Explorador de hiperespaço",
            name="Gambit de espaço profundo"
        },
        {
            description="Use uma ação rápida para conceder a um aliado dentro da linha de visão a capacidade de ignorar terreno difícil em sua próxima volta",
            tree="Explorador de hiperespaço",
            name="Orientação"
        },
        {
            description="Usar a aplicação snipe do Stealth é uma ação rápida",
            tree="Explorador de hiperespaço",
            name="Atacador Oculto"
        },
        {
            description="Substituir a habilidade do piloto para usar Verificações de computador feitas para operar sensores ou astrogatas durante a pilotagem",
            tree="Explorador de hiperespaço",
            name="Hyperspace Savant"
        },
        {
            description="nunca sofrer de circunstâncias desfavoráveis do ambiente w/Stealth, 1/rnd w/Stealth auto ajudar outro 1 aliado",
            tree="Explorador de hiperespaço",
            name="Movimento silencioso"
        },
        {
            description="Trate seu navio como dois tamanhos menores ao usar Stealth como piloto",
            tree="Explorador de hiperespaço",
            name="Sneak do veículo"
        },
        {
            description="1/enc cada w / melee ou variou como stan se bater & represa: 1. alvo perde seu bônus de armadura para Ref Def & é plana de pés, alvo deve gastar stan para ajustar armadura, 2. alvo -2 ark até o fim próxima volta & todas as criaturas etc têm ocultação do alvo, 3. alvo spd -2 até o fim próxima volta",
            tree="Escoteiro Mestre",
            name="Hit Piercing"
        },
        {
            description="sem penalidade ao usar Escalada Acelerada de Escalada",
            tree="Escoteiro Mestre",
            name="Velocímetro"
        },
        {
            description="em surpresa rnd se não surpreso pode tomar swif além de outra ação, se surpreso pode tomar swif",
            tree="Escoteiro Mestre",
            name="Surpreendentemente Rápido"
        },
        {
            description="definir armadilha 3sq largo, DC20 Mechanics & Deception para ocultar, alvo DC10 Acrobatics para evitar, selecione 1 opção: 1. alvo quedas propensas 1d6 represa, 2. auto bater w/mine & 1d20+10 v. adjacente, 3. +2 Decepção & queda prona",
            tree="Escoteiro Mestre",
            name="Tripwire"
        },
        {
            description="1/enc cada um na montagem: 1. se usar montagem como cobertura pode fazer 1 atk, 2. se usar montagem como cobertura ganho cobertura melhorada - se falhar por 10 ou mais ainda obter cobertura, 3. montagem pode fazer atk como swif não stan",
            tree="Scout Móvel",
            name="Monte de batalha"
        },
        {
            description="Reroll Ride",
            tree="Scout Móvel",
            name="Expert Rider"
        },
        {
            description="w / velocímetro pode usar montagem rápida ou desmontar, queda suave, ficar em Saddle & usar montagem como cobertura de passeio",
            tree="Scout Móvel",
            name="Cavaleiro Mecanizado"
        },
        {
            description="DC20 Passeio para negar terreno difícil",
            tree="Scout Móvel",
            name="Orientação do Terreno"
        },
        {
            description="Como uma ação de movimento, você pode fazer com que um de seus seguidores para mover até sua velocidade +2 quadrados.",
            tree="Reconhecimento",
            name="Entrar em posição"
        },
        {
            description="Ganhas um único seguidor. Escolha o modelo de seguidor Y agressivo, defensivo ou uti iluminado para o seu seguidor. Este seguidor ganha o feito de treinamento de habilidades para as habilidades Percepção e Stealth.",
            tree="Reconhecimento",
            name="Líder da equipa de reconhecimento"
        },
        {
            description="Cada um dos seus seguidores ganha o feito Point Blank Shot.",
            tree="Reconhecimento",
            name="Agressão de Combate de Fechar"
        },
        {
            description="Você pode usar qualquer uma das seguintes ações em sua vez.\n- Patrulhamento\n- Grupo Sniping\n- Varrer a área",
            tree="Reconhecimento",
            name="Acções de Reconhecimento"
        },
        {
            description="Você pode reroll Deception verifica para criar uma aparência enganosa e manter o melhor resultado",
            tree="Espião",
            name="Incógnito"
        },
        {
            description="Faça uma verificação de percepção como uma ação completa contra DC 15 ou uma verificação Stealth do alvo para conceder a si mesmo e aliados +2 para atacar rolos até sua próxima vez",
            tree="Espião",
            name="Vigilância"
        },
        {
            description="Ganhe +1 para todas as defesas contra o alvo da Vigilância",
            tree="Espião",
            name="Melhor vigilância"
        },
        {
            description="Uma vez por encontro, como uma ação padrão, tomar 20 em uma verificação de conhecimento treinado ou 10 em uma verificação não treinada, mesmo que as circunstâncias normalmente não permitem que",
            tree="Espião",
            name="Conhecimento íntimo"
        },
        {
            description="Você não deixa nenhum vestígio quando desabilita um dispositivo com Mecânica, e pode falhar até 10 sem repercussões",
            tree="Espião",
            name="Perturbação sem rasto"
        },
        {
            description="Se você tiver sigilo de um alvo, você ganha um bônus de +5 circunstâncias em todos os controles Perception feitos contra esse alvo.",
            tree="Vigilância",
            name="Olhos Ocultos"
        },
        {
            description="Se você fizer um ataque de acusação contra um alvo que não está ciente de você, esse alvo não pode fazer uma verificação de percepção para notá-lo até af ter o ataque é resolvido, mesmo se você se afastar da cobertura ou ocultação.",
            tree="Vigilância",
            name="Procurar e Destruir"
        },
        {
            description="Quando você usa uma ação padrão para procurar ativamente inimigos ocultos, você pode fazer um único ataque ou variou contra qualquer inimigo que você notar com sua verificação Percepção.",
            tree="Vigilância",
            name="Caçar o Caçador"
        },
        {
            description="Como uma ação de movimento, você pode fazer uma verificação de percepção com um DC igual a 10 + o CL de um inimigo em sua linha de visão. Se você tiver sucesso, você e todos os seus aliados ganham um bônus + 1 em rolos de ataque contra esse alvo até o final da próxima vez.",
            tree="Vigilância",
            name="Spotter"
        },
        {
            description="Se você não está surpreso com o início do combate, você pode usar o talento Spotter como uma ação gratuita em sua primeira vez, inclusive durante a rodada surpresa.",
            tree="Vigilância",
            name="Intel avançada"
        },
        {
            description="Você leva metade dos danos de ataques de área que atingiram, nenhum dano de ataques de área que falham",
            tree="Sobrevivente",
            name="Evasão"
        },
        {
            description="Ganhe +5 para uma verificação de força ou verificação de habilidade baseada em força como duas ações rápidas",
            tree="Sobrevivente",
            name="Esforço Extremo"
        },
        {
            description="Você pode correr a cinco vezes sua velocidade",
            tree="Sobrevivente",
            name="Sprint"
        },
        {
            description="Sua velocidade não é reduzida pelo terreno difícil",
            tree="Sobrevivente",
            name="Surefoot"
        },
        {
            description="Uma vez por encontro quando você pegar um segundo vento, você pode fazer um ataque de carga como uma ação gratuita, desde que você pode fazer um ataque de acusação contra um alvo legal no momento em que você pegar um segundo vento.",
            tree="Imprevisível",
            name="Surge Agressivo"
        },
        {
            description="Uma vez por rodada, quando você é danificado por um ataque de área do inimigo, como uma reação que você pode fazer um ataque imediato ou variou contra a fonte do ataque de área, desde que você tenha linha de visão para o atacante eo alvo está com em seu melee ou alcance variado.",
            tree="Imprevisível",
            name="Retroceder"
        },
        {
            description="Uma vez por encontro quando você perde um alvo com uma única batalha ou ataque variado, como uma ação livre você pode mover-se até metade da sua velocidade e fazer um segundo ataque do mesmo tipo contra um alvo diferente. Este movimento não provoca ataques de oportunidade. Se você tem a façanha de Reflexos de Combate, você pode usar este talento várias vezes por encontro igual ao seu bônus de Dexterity (mínimo 1). Você ainda pode usar este talento apenas uma vez por rodada.\nPré-requisito: Blast Back.",
            tree="Imprevisível",
            name="Segunda Greve"
        },
        {
            description="Uma vez por tum quando você está danificado pelo ataque de um inimigo, como uma reac tion você pode mover-se até metade da sua velocidade. Este movimento não provoca ataques de oportunidade.",
            tree="Imprevisível",
            name="Desvanecer"
        },
        {
            description="Uma vez por encontro quando um inimigo faz um ataque de oportunidade contra você, como uma reação você pode automaticamente negar o ataque e imediatamente mover-se até metade da sua velocidade. Este movimento não provoca ataques de oportunidade. Se você tem a façanha de Reflexos de Combate, você pode usar este talento várias vezes por encontro igual ao seu bônus de Dexterity (mínimo 1). Você ainda pode usar este talento apenas uma vez por rodada.\nPré-requisito: desaparecer.",
            tree="Imprevisível",
            name="Swerve"
        },
        {
            description="Quando qualquer inimigo dentro de 24 quadrados recebe um insight ou bônus moral, você ganha os mesmos benefícios",
            tree="Versatilidade",
            name="Adaptar e Sobreviver"
        },
        {
            description="Quando você usaAdapt e Sobreviver, você pode negar a um dos inimigos o bônus",
            tree="Versatilidade",
            name="Adaptação Desbalanceadora"
        },
        {
            description="Passe um ponto de força para adicionar a uma defesa de você ou um aliado até sua próxima vez",
            tree="Versatilidade",
            name="Proteção defensiva"
        },
        {
            description="Uma vez por encontro mova até a sua velocidade como uma reação",
            tree="Versatilidade",
            name="Rápido em seus pés"
        },
        {
            description="Tome uma ação preparada a qualquer momento até o final da rodada atual",
            tree="Versatilidade",
            name="Prontos e dispostos"
        },
        {
            description="Aplique o bônus mais alto de nível heróico ou armadura para sua Defesa Reflexa",
            tree="Especialista em armaduras",
            name="Defesa com Armadura"
        },
        {
            description="Tratar armadura proficiente como se tivesse um máximo de destreza 1 maior",
            tree="Especialista em armaduras",
            name="Mastery Armadura"
        },
        {
            description="Aplique o mais alto nível heróico mais bônus de meia armadura ou bônus de armadura para sua defesa reflexa",
            tree="Especialista em armaduras",
            name="Defesa melhorada da armadura"
        },
        {
            description="Armadura não afeta sua velocidade",
            tree="Especialista em armaduras",
            name="Juggernaut"
        },
        {
            description="Aumente seu bônus de armadura para Defesa de Reflexos e seu bônus de equipamento para Defesa de Fortitude em 1",
            tree="Especialista em armaduras",
            name="Segunda Pele"
        },
        {
            description="Uma vez por encontro, como uma ação rápida, ganhar SR 10 em um escudo pessoal ativo (até o máximo)",
            tree="Especialista em armaduras",
            name="Especialista em escudos"
        },
        {
            description="Se você não está surpreso na primeira rodada de combate em um encontro, você pode tratar a primeira rodada de combate como se fosse a rodada surpresa para fins de talentos e proezas que disparam apenas durante a rodada surpresa. Além disso, durante a rodada surpresa como uma ação gratuita você pode designar esse alvo como seu alvo principal. Você ganha um bônus de moral +2 para atacar rolos contra seu alvo principal até o final do encontro.",
            tree="Ambusher",
            name="Especialista em Emboscada"
        },
        {
            description="Depois de designar um alvo principal, você lida com + 1 morte de danos em ataques contra o alvo principal até o final do encontro.\nPré-requisito: Especialista em Emboscada.",
            tree="Ambusher",
            name="Ambusher Destrutivo"
        },
        {
            description="Se você reduzir seu alvo principal para 0 pontos de ataque, como uma ação livre, você pode designar outro alvo dentro de sua linha de visão como seu novo alvo principal. Este novo alvo continua a ser o seu alvo principal até ao fim do encontro.\nPré-requisito: Especialista em Emboscada.",
            tree="Ambusher",
            name="Continue."
        },
        {
            description="Como uma ação rápida, você pode fazer uma verificação de Iniciativa, oposta à verificação de Iniciativa do seu alvo principal. Se o resultado da verificação for igual ou superior ao resultado da verificação do seu alvo principal, o seu alvo é de pé plano contra todos os ataques que fizer antes do fim da sua vez.\nPré-requisito: Especialista em Emboscada.",
            tree="Ambusher",
            name="Mantê - los Enrolados"
        },
        {
            description="Você ganha um bônus +5 circunstância para Percepção\nverifica o seu alvo principal até ao final do encontro.\nPré-requisito: Especialista em Emboscada.",
            tree="Ambusher",
            name="Ambusher Perceptivo"
        },
        {
            description="Se você e todos os seus aliados rolarem maiores verificações Iniciativa para começar o combate do que todos os seus adversários, você automaticamente ganhar uma rodada surpresa, mesmo que os adversários estão cientes de você quando o combate começa.",
            tree="Ambusher",
            name="Lançar a Armadilha"
        },
        {
            description="Enquanto flanqueado você ganha um bônus +2 em ataques desarmados e rolos de danos.",
            tree="Lutador",
            name="Cantina Brawler"
        },
        {
            description="Durante a surpresa, você e todos os aliados dentro de 6 quadrados ganhar um +1 bônus moral para atacar, e mantê-lo para o encontro em cada adversário danificado na rodada surpresa.",
            tree="Lutador",
            name="Escolha uma luta"
        },
        {
            description="Quando você luta defensivamente, qualquer criatura adjacente que ataca provoca um ataque de oportunidade de você.",
            tree="Lutador",
            name="Contrapunch"
        },
        {
            description="Quando desarmar com sucesso, fazer imediato livre -5 atk w/ arma desarmada ou -10 se não proficiente",
            tree="Lutador",
            name="Desarmar e Acionar"
        },
        {
            description="Ao agarrar, você leva -2 para ataques não -5, alvo leva -5 para todos os ataques",
            tree="Lutador",
            name="Embalador"
        },
        {
            description="+2 para atacar",
            tree="Lutador",
            name="Especialista Grappler"
        },
        {
            description="Escolha um oponente cada rodada para negar seu bônus de força para seus rolos de ataque contra você",
            tree="Lutador",
            name="Desbalanceamento Oposto"
        },
        {
            description="Não tome nenhuma penalidade ao usar a ação de captura",
            tree="Lutador",
            name="Grabber"
        },
        {
            description="Armas ranged podem ser tratadas como um taco, ou como uma arma dupla se montada com uma baioneta",
            tree="Lutador",
            name="Clube de Armas"
        },
        {
            description="Quando você toma uma ação de ataque completo, você pode tratar uma arma variada com uma baioneta como uma arma dupla. Você pode atacar com a baioneta e acertar um alvo com sua arma variada, ignorando as penalidades normais.",
            tree="Lutador",
            name="Mestre Bayonet"
        },
        {
            description="Se você está desarmado, dobre seu bônus de força",
            tree="Lutador",
            name="Hammerblow"
        },
        {
            description="Você não aceita penalidades quando usa armas improvisadas.",
            tree="Lutador",
            name="Fazer Fazer"
        },
        {
            description="Sempre que um aliado dentro de 6 quadrados é reduzido para 0 pontos ou menos você pode mover-se até a sua velocidade para que aliado como uma reação sem provocar ataques de oportunidade.",
            tree="Lutador",
            name="Homem Down"
        },
        {
            description="+1 danos aos ataques de melee",
            tree="Lutador",
            name="Melee Smash"
        },
        {
            description="Uma vez por encontro, adicione metade do seu nível ao dano em vez do +1 de Melee Smash",
            tree="Lutador",
            name="Devastador Melee Smash"
        },
        {
            description="Ao danificando um oponente com um ataque melee com um rolo de ataque excedendo seu limiar de dano, eles movem um passo adicional -1 para baixo da pista de condição",
            tree="Lutador",
            name="Ataque impressionante"
        },
        {
            description="Você pode usar cada um dos seguintes uma vez por encontro como uma ação padrão:\n- Evite o ataque\n- Mente Fortificada\n- Estágio Focado\nVer p. 18 de Escória e Vilões",
            tree="Lutador",
            name="Lutador experiente"
        },
        {
            description="Sempre que você perder com um ataque melee ou o ataque é negado, você ainda lidar com seu bônus Força em danos ao alvo (mínimo 1) ou 2× seu bônus Força se você atacar com uma arma que você está pesando duas mãos.",
            tree="Lutador",
            name="Agressão Incansável"
        },
        {
            description="o modificador de força do alvo como dano (min 1)",
            tree="Lutador",
            name="Dosagem Inversa"
        },
        {
            description="Quando você agarra, o inimigo deve usar uma ação completa para escapar",
            tree="Lutador",
            name="Agarrar Forte"
        },
        {
            description="Quando você danificar um inimigo negou seu bônus de Dexterity para Defesa de Reflexos com uma arma melee, eles não podem fazer ataques de oportunidade até o fim de sua próxima volta.",
            tree="Lutador",
            name="Soco Otário"
        },
        {
            description="1/encontro ganhar um bônus +1 para Persuasão para intimidar por aliado",
            tree="Esquadrão Bruto",
            name="Líder de gangues"
        },
        {
            description="Bata em um alvo adjacente à defesa Reflex e Fortitude do aliado e lidar com +1 morrer de dano e bater propensa",
            tree="Esquadrão Bruto",
            name="Melee Assault"
        },
        {
            description="Bata um alvo ao lado da defesa Reflex e Fortitude do aliado e reduza a velocidade e a defesa Reflex em 2",
            tree="Esquadrão Bruto",
            name="Melee Brute"
        },
        {
            description="1/encontro quando um aliado atinge alvo adjacente fazer ataque como uma reação com +2 bônus",
            tree="Esquadrão Bruto",
            name="Melee Opportunist"
        },
        {
            description="Quando você atinge um inimigo com dois aliados adjacentes, reroll dano e levar o melhor dos resultados",
            tree="Esquadrão Bruto",
            name="Esquadrão Brutalidade"
        },
        {
            description="Sempre que você e dois aliados são adjact ao alvo, o alvo é plano contra você",
            tree="Esquadrão Bruto",
            name="Superioridade do Esquadrão"
        },
        {
            description="Fazer uma verificação DC 15 Conhecimento (táticas) para verificar se os caracteres dentro da linha de visão estão em ou abaixo de metade de seus pontos de sucesso",
            tree="Comando",
            name="Análise de Batalha"
        },
        {
            description="Aliados dentro de seis quadrados ganham +1 Reflexa Defesa até o início de sua próxima volta sempre que você fizer um ataque variado com um rifle ou pistola",
            tree="Comando",
            name="Fogo de cobertura"
        },
        {
            description="Sempre que você tiver o benefício da capa (veja as páginas 157-158 do livro de regras da Saga Edition), você pode gastar duas ações rápidas para tratá-la como capa melhorada até o início da próxima vez. Pré-requisito: Análise de Batalha.",
            tree="Comando",
            name="Posição defensiva"
        },
        {
            description="Explosivos definidos pelo negócio de habilidade Mecânica +2 dados de dano\n\n(Entrar número de vezes tomadas)",
            tree="Comando",
            name="Demolicionista"
        },
        {
            description="Faça uma verificação de Persuasão contra a Defesa de Vontade de todos os oponentes dentro da linha de visão para se tornar o único personagem alvo dentro de seis quadrados até o início da sua próxima volta",
            tree="Comando",
            name="Desenhar Fogo"
        },
        {
            description="Ataques contra um aliado adjacente dano de negócio para você em vez até sua próxima volta, ativado como uma ação rápida",
            tree="Comando",
            name="Caminho do Harm"
        },
        {
            description="Mover +5 passos ao longo da faixa de condição uma vez por dia como uma ação rápida\n\n(Entrar número de vezes tomadas)",
            tree="Comando",
            name="Indomável"
        },
        {
            description="Quando você usa a ajuda outra ação para suprimir um inimigo, esse inimigo leva uma pena -5 em seu próximo ataque em vez da penalidade normal -2. Apenas 1 personagem pode ganhar os benefícios deste talento contra um determinado alvo de cada vez.",
            tree="Comando",
            name="Manter Eles em Bay"
        },
        {
            description="Você pode pegar seu segundo vento uma hora extra por dia",
            tree="Comando",
            name="Duro como pregos"
        },
        {
            description="Pegar um segundo vento como uma reação em vez de uma ação rápida",
            tree="Comando",
            name="Alvo Difícil"
        },
        {
            description="+2 danos aos alvos danificados por um aliado desde sua última vez",
            tree="Mercenário",
            name="Fogo combinado"
        },
        {
            description="+2 danos por aliado que danificou seu alvo desde sua última vez",
            tree="Mercenário",
            name="Trabalho de equipe do Mercenário"
        },
        {
            description="Ao reduzir um inimigo a 0 pontos de ataque com um ataque, faça uma verificação de Persuasão como uma ação livre contra a Defesa da Vontade de todos os alvos dentro de 6 quadrados para infligir uma penalidade -2 para seus rolos de ataque para o resto do encontro",
            tree="Mercenário",
            name="Temido Guerreiro"
        },
        {
            description="Uma vez por encontro, ao lidar com danos a um oponente com uma batalha ou ataque variado, seu limiar de dano é reduzido em 2 para o resto do encontro",
            tree="Mercenário",
            name="Luta Suja"
        },
        {
            description="Ao lidar com danos com um rolo de ataque ou variado que excede o limiar de dano do alvo, você ganha um bônus +2 para danos contra esse alvo para o resto do encontro",
            tree="Mercenário",
            name="Impiedoso"
        },
        {
            description="Ao lidar com danos a um oponente em combate, você ganha +5 para Defesa de Vontade até sua próxima vez",
            tree="Mercenário",
            name="Guerreiro Focado"
        },
        {
            description="Como uma ação rápida converter a penalidade de uma condição para um bônus, em seguida, mova -1 passo ao longo da faixa condição no final de sua próxima volta",
            tree="Mercenário",
            name="Grit Mercenário"
        },
        {
            description="Passe um Ponto de Força como uma ação gratuita na sua vez para dobrar sua velocidade para uma rodada, pelo menos 5 rodadas após sua última utilização",
            tree="Mercenário",
            name="Determinação do Mercenário"
        },
        {
            description="Ativar um jet pack como uma ação livre, e lang sem uma verificação Pilot",
            tree="Salta de Foguete",
            name="Treinamento do Jet Pack"
        },
        {
            description="Use uma carga de jato como lança-chamas",
            tree="Salta de Foguete",
            name="Agressão Ardente"
        },
        {
            description="Aumentar a velocidade da mosca em 2 quadrados usando jet packs",
            tree="Salta de Foguete",
            name="Trajectória Melhorada"
        },
        {
            description="Uma vez por encontro, retire ou mova sua velocidade como uma reação sobre um inimigo que se move adjacente a você",
            tree="Salta de Foguete",
            name="Retirar o Jet Pack"
        },
        {
            description="Sempre que você estiver dentro de 3 quadrados de um aliado, você ganha um bônus + 1 circunstância em todo o melee e rolos de ataque variados.",
            tree="Soldado",
            name="Camaradas de armas"
        },
        {
            description="Quando você danifica um alvo com um ataque confuso ou variado, todos os aliados dentro de 3 quadrados ganhar um bônus +2 em rolos de danos contra esse alvo até o início de sua próxima volta.",
            tree="Soldado",
            name="Segmentação Focada"
        },
        {
            description="Você pode gastar uma ação para ativar esse talento. Até o início de sua próxima volta, se um aliado se mover, você pode imediatamente mover-se até sua velocidade como uma ação de movimento, desde que você termine seu movimento dentro de 3 quadrados desse aliado.",
            tree="Soldado",
            name="Ficar juntos"
        },
        {
            description="Se você é adjacente a pelo menos um aliado, inimigos não ganham nenhum benefício de flanquear você ou quaisquer aliados adjacentes.",
            tree="Soldado",
            name="Cuidado com as costas"
        },
        {
            description="Sempre que você fornecer uma cobertura de 50 pés para um aliado dentro de 3 quadrados, você é considerado para fornecer cobertura melhorada.",
            tree="Soldado",
            name="Phalanx"
        },
        {
            description="Se um inimigo sentir a sua falta com um ataque melee, como uma reação, você pode automaticamente lidar com danos iguais ao seu modificador de força (mínimo 1 ponto de dano) para o seu atacante, se o atacante estiver ao seu alcance.",
            tree="Shockboxer",
            name="Jab de retaliação"
        },
        {
            description="Quando você está desarmado e tomar a luta defensivamente ação, você pode fazer um único ataque desarmado como uma ação livre contra um alvo adjacente. Pré-requisito: Retaliação Jab.",
            tree="Shockboxer",
            name="Jab Defensivo"
        },
        {
            description="Se um inimigo sentir a sua falta com um ataque melee, como uma reação você pode mover-se para 2 quadrados, mas você deve terminar o seu movimento adjacente ao seu atacante.",
            tree="Shockboxer",
            name="Desviar do Nibble"
        },
        {
            description="Quando você atinge um alvo com um ataque desarmado você pode optar por lidar com metade dos danos com o seu ataque. Se o fizeres, o teu inimigo também causa metade de dano em todos os ataques que ele ou ela faz até ao fim do teu próximo turno.",
            tree="Shockboxer",
            name="Picar o Jab"
        },
        {
            description="Quando você lidar com danos de atordoamento a um alvo com um ataque desarmado, após o dano de atordoamento é reduzida para metade, rolar uma morte extra de danos e adicionar que são os danos subtraídos dos pontos de ataque do alvo. Pré-requisito: Stinging Jab.",
            tree="Shockboxer",
            name="Shockboxer impressionante"
        },
        {
            description="Ganhas um único seguidor. Escolha o modelo de seguidor agressivo, defensivo ou utilitu. Este seguidor ganha uma façanha de Proficiência de Armadura de sua escolha e Proficiência de Arma (rifles).",
            tree="Líder de Esquadrão",
            name="Comandante"
        },
        {
            description="Cada um de seus seguidores ganha o feito de ataque coordenado, desde que ele atenda ao pré-requisito. Se seu seguidor mais tarde atender ao pré-requisito para o feito, ele ganha o feito naquele momento.",
            tree="Líder de Esquadrão",
            name="Táticas coordenadas"
        },
        {
            description="Como uma ação completa, você e um de seus seguidores podem fazer um ataque variado contra um alvo (cada um) na linha de visão. Cada um leva uma pena de -5 aos seus rolos de ataque.",
            tree="Líder de Esquadrão",
            name="Fogo à Vontade"
        },
        {
            description="Você pode usar qualquer uma das seguintes ações em sua vez.\n- Barragem de disparo automático\n- Abrir fogo\n- Alvo Pintado",
            tree="Líder de Esquadrão",
            name="Acções por Esquadra"
        },
        {
            description="Você aprendeu uma variedade de maneiras diferentes de tratar lesões de combate no campo. Quando você tiver sucesso em uma bochecha de tratamento de lesão para administrar Primeiros Socorros, a criatura cuidada também move +1 aumentar a trilha da condição. Pré-requisito: Treinado no tratamento de lesões.",
            tree="Veterano",
            name="Remédio de campo de batalha"
        },
        {
            description="Você já viu mais ação em mais lugares do que a maioria das pessoas sabe que existem e pouco na galáxia deixa você agitado. Qualquer personagem usando um efeito de medo em você deve rolar duas vezes, mantendo o resultado mais baixo em quaisquer verificações de habilidade e rolos de ataque. Pré-requisitos: Testado em batalha, treinado em Iniciativa.",
            tree="Veterano",
            name="Viu Tudo"
        },
        {
            description="Quando você pega uma segunda vitória) (ver página 154 do livro de regras do núcleo saga Edition), você move +2 passos na faixa de condição, além de recuperar pontos de sucesso.",
            tree="Veterano",
            name="Testado em batalha"
        },
        {
            description="Pode aproveitar a sua vasta experiência no campo de batalha para atrair os seus camaradas e conduzir os seus inimigos à sua frente. Você pode usar cada uma das seguintes ações uma vez por encontro como uma ação padrão:\n* Defy the Odds: Faça um único ataque ou ataque. Você ganha imediatamente um número de pontos bônus igual à sua pontuação Constituição.\n* Dobrar a dor: Quando você usar o Aid Outra ação para fornecer um aliado dentro de 6 quadrados de você um bônus para o seu rolo de ataque, adicione metade do seu nível de caráter ao rolo de danos do aliado se o ataque for bem sucedido.\n* Agressão Protegida: Faça um único ataque. Você ganha um bônus de dano +2 para sua defesa Reflex contra todos os ataques até o início da próxima vez.\nPré-requisitos: Vi tudo, testado em batalha.",
            tree="Veterano",
            name="Guerreiro Grizzled"
        },
        {
            description="Você sabe por experiência própria que a vitória vai para aqueles dispostos a arriscar. Você pode adicionar seu bônus de Sabedoria (mínimo +1) ao rolo de danos quando você fizer um ataque de carga bem sucedido.\nPré-requisito: Testado em batalha.",
            tree="Veterano",
            name="Imprudente"
        },
        {
            description="Ao fazer um ataque Autofire, você pode segurar com uma arma que não é apenas Autofire.",
            tree="Especialista em armas",
            name="Agressão de disparo automático"
        },
        {
            description="Trate seus oponentes limiar de dano como se fosse 5 pontos mais baixo quando você faz um ataque bem sucedido\n\n(Enter número de vezes tomadas, escolha qual arma na aba Talentos 2)",
            tree="Especialista em armas",
            name="Ataque devastador"
        },
        {
            description="Quando você suprimir com sucesso, o alvo tomar -5 em ataques; -2 em auto-fogo, mesmo que ele falha",
            tree="Especialista em armas",
            name="Incêndio de supressão melhorado"
        },
        {
            description="Trate seus adversários redução de danos como se fosse 5 pontos mais baixo quando você faz um ataque bem sucedido\n\n(Enter número de vezes tomadas, escolha qual arma na aba Talentos 2)",
            tree="Especialista em armas",
            name="Ataque penetrante"
        },
        {
            description="+2 bônus para danos\n\n(Enter número de vezes tomadas, escolha qual arma na aba Talentos 2)",
            tree="Especialista em armas",
            name="Especialização da Arma"
        },
        {
            description="Quando você danificar com sucesso um inimigo com um ataque de espancamento para o qual você tem especialização em armas, você ganha +2 para atacar e danificar com seu próximo ataque.\n\n(Enter número de vezes tomadas, escolha qual arma na aba Talentos 2)",
            tree="Especialista em armas",
            name="Ataque esmagador"
        },
        {
            description="Ignorar o bônus de armadura de um oponente para a defesa ao desarmar, e uma vez por encontro ganhar um bônus +10 em seu rolo de ataque para desarmar\n\n(Enter número de vezes tomadas, escolha qual arma na aba Talentos 2)",
            tree="Especialista em armas",
            name="Ataque de Desarmamento"
        },
        {
            description="Se você acertar com sucesso um inimigo com uma arma piercing para o qual você tem o talento de Especialização de Armas, a velocidade do seu oponente é reduzida em 2 quadrados até o final da sua próxima volta.\n\n(Enter número de vezes tomadas, escolha qual arma na aba Talentos 2)",
            tree="Especialista em armas",
            name="Agressão Impailing"
        },
        {
            description="pode fazer Atk de Opp ao usar arma simples variada ou lançada (nenhuma área atk armas)",
            tree="Guerreiro",
            name="Oportunidade Simples"
        },
        {
            description="quando o inimigo faz atk desarmado/melee pela 2a vez no enc v. você faz Perception como reac para ganhar +1 Ref & Fort Def v. para o resto do enc, pode alternar os alvos não usando por 1 rnd completo",
            tree="Guerreiro",
            name="Consciência do guerreiro"
        },
        {
            description="1/enc ignorar 1 efeito não-Força, talento, habilidade ou habilidade que excede Will Def, se gastar FP ignorar efeito da mente mesmo se Força",
            tree="Guerreiro",
            name="Determinação do Guerreiro"
        },
        {
            description="Passe um ponto de força como uma ação padrão para evitar a detecção de força por uma hora, ou até que você faça uma verificação Use a força",
            tree="Agente de Ossus",
            name="Presença enterrada"
        },
        {
            description="Esconder um alvo adjacente disposto com presença enterrada ou desaparecer\n\n(Entrar número de vezes tomadas)",
            tree="Agente de Ossus",
            name="Ocultar Outro"
        },
        {
            description="Passe um ponto de força como uma ação rápida para usar o modificador Use o modificador de força para fazer um ataque variado",
            tree="Agente de Ossus",
            name="Objetivo Perspicaz"
        },
        {
            description="Faça uma verificação de uso da força como uma ação rápida contra a defesa da vontade de um alvo para obter total ocultação contra eles",
            tree="Agente de Ossus",
            name="Desaparecer"
        },
        {
            description="+5 em verificação de habilidade ou grapple para todos os aliados w / em 6 sq, pode gastar FP para negar um aliado movido contra vontade",
            tree="Monge Aing- Tii",
            name="Aura da Liberdade"
        },
        {
            description="Um aliado w/in 12 sq & LOS que é agarrado etc & liberá-los e pode mover metade spd como reac w/no AofO",
            tree="Monge Aing- Tii",
            name="Liberar"
        },
        {
            description="Um aliado w/in 12 sq & LOS que é agarrado etc & liberá-los e pode mover metade spd como reac w/no AofO",
            tree="Monge Aing- Tii",
            name="Dobrado o domínio do espaço"
        },
        {
            description="Um poder de força já não tem descritor de lado escuro ou claro",
            tree="Monge Aing- Tii",
            name="Muitas Sombras da Força"
        },
        {
            description="Use a Força nega danos ao veículo que você está a bordo, ocorre após DR & SR aplicado",
            tree="Monge Aing- Tii",
            name="Integridade espacial"
        },
        {
            description="Sempre que você subir a faixa de condição, você ganha 5 + seu nível bônus pontos de sucesso",
            tree="Capitão Bando Goro",
            name="Bando Goro Surge"
        },
        {
            description="Sempre que você gastar um ponto de força para aumentar um rolo de ataque, curar o mesmo número que o bônus se o ataque atinge",
            tree="Capitão Bando Goro",
            name="Lutador de Força"
        },
        {
            description="Passe um ponto de força para negar o movimento na pista de condição",
            tree="Capitão Bando Goro",
            name="Resista à Inervação"
        },
        {
            description="Sempre que um inimigo que você tenha danificado neste encontro é reduzido para 0 pontos de ataque, você retorna uma força de força para sua pilha",
            tree="Capitão Bando Goro",
            name="Mestre da Força Vitoriosa"
        },
        {
            description="+10 Percepção para evitar ser surpreendido, gastar FP para agir em rodada surpresa mesmo que surpreso",
            tree="Baran Do Sage",
            name="Sentido de Perigo Melhorado"
        },
        {
            description="adicionar bônus Wis para Ref Def se negado Dex",
            tree="Baran Do Sage",
            name="Conhecimento e Defesa"
        },
        {
            description="com Search Your Feelings pode sentir consequências 1 hora no futuro, gastar FP por 8 horas, DP 24 horas",
            tree="Baran Do Sage",
            name="Horizonte Expandido"
        },
        {
            description="no novo planeta 10 minutos para se aclimatar e no planeta +2 todos Def contra os perigos naturais, spd +1 sq, tempo sentido durante 24 horas como full-round",
            tree="Baran Do Sage",
            name="Atuação Planetária"
        },
        {
            description="1/dia gastar 10 minutos e uma vez mais no dia nega um ataque, desde que não nat 20, se não usar recuperar FP",
            tree="Baran Do Sage",
            name="Meditação Precognitiva"
        },
        {
            description="Quando atacado com sucesso, faça uma verificação Use a Força, se exceder o rolo de ataque, você adiciona seu modificador Carisma à sua Defesa Reflexa",
            tree="Os crentes discípula",
            name="Intuição do crente"
        },
        {
            description="Como uma ação rápida faça um DC 15 Use a verificação de Força para ganhar um bônus +1 para Defesa de Fortitude até o final do encontro ou DC 20 para ganhar um bônus +1 para todas as defesas",
            tree="Os crentes discípula",
            name="Aumentar a Defesa"
        },
        {
            description="Passe um ponto de força para reduzir o número de ações rápidas que você leva para mover +1 passo na faixa de condição por um",
            tree="Os crentes discípula",
            name="Rugosidade"
        },
        {
            description="Como uma ação rápida, faça um DC 15 Use a verificação Força para adicionar o dobro do seu bônus Força para danos melee antes do fim da sua vez",
            tree="Os crentes discípula",
            name="Alto Impacto"
        },
        {
            description="Você ganha um bônus moral +1 para ataques quando dentro de 20 quadrados e linha de visão de um aliado com uma pontuação de lado escuro igual ou maior que a sua própria",
            tree="Os crentes discípula",
            name="Sith Reverence"
        },
        {
            description="escolher 1 sq w/in 12sq & LOS, tratar como origem sq para próxima gama de atk de energia, deve ter LOS ao alvo",
            tree="Corrente em chamas",
            name="Força de Tiro Dirigido"
        },
        {
            description="quando a energia negate v. variou de redirecionamento no inimigo w/in 6sq, UtF v. Fort Def para metade da barragem negada",
            tree="Corrente em chamas",
            name="Negar e redireccionar"
        },
        {
            description="1/rnd como reacesso a aliar a barragem ou a trilha +1 atk next atk (até o máximo +5)",
            tree="Corrente em chamas",
            name="Raiva crescente"
        },
        {
            description="1/rnd como reac para aliar tomar represa ou para baixo trilha UtF v. Will Def para mover alvo -1 trilha, se o inimigo se moveu para o fundo da pista não inconsciente, mas deve fugir por 1 min até que se move para cima trilha",
            tree="Corrente em chamas",
            name="Pânico em ascensão"
        },
        {
            description="Você pode reroll Use as verificações de Força para ativar os poderes de Força se você passar uma ação completa em vez do padrão, mover ou ação rápida para ativá-lo, mas deve aceitar o resultado do reroll",
            tree="Bruxa Dathomiri",
            name="Adept Spellcaster"
        },
        {
            description="Passe um ponto de força para voar em sua velocidade normal, subir a meia velocidade ou descer em velocidade dupla, ativado como uma ação rápida e duradoura até o início de sua próxima volta",
            tree="Bruxa Dathomiri",
            name="Voo"
        },
        {
            description="Você pode usar Use a Força em vez de Persuasão para tentar mudar a atitude de uma criatura desmesticada com uma inteligência de 2 ou menos, e não tomar qualquer penalidade para a criatura não entender sua linguagem",
            tree="Bruxa Dathomiri",
            name="Fera do Charme"
        },
        {
            description="Ao mudar a atitude de um animal para indiferente ou amigável, você pode tratá-lo como domesticado, e como um monte, se for maior do que você e adequado para sentar-se sobre",
            tree="Bruxa Dathomiri",
            name="Monstro de Comando"
        },
        {
            description="Gaste um ponto de força para ganhar o conceito sempre que você mover 3 quadrados",
            tree="Discípulos da Crepúsculo",
            name="Cloak of Shadow"
        },
        {
            description="Conceda a si mesmo um bônus de força +1 para Defesa de Reflexos",
            tree="Discípulos da Crepúsculo",
            name="Armadura Sombra"
        },
        {
            description="Passe um ponto de força para criar sombras ilusórias em torno de um alvo",
            tree="Discípulos da Crepúsculo",
            name="Fantasmo"
        },
        {
            description="Negar bônus de ocultação do oponente para Defesa de Reflexos",
            tree="Discípulos da Crepúsculo",
            name="Revelação"
        },
        {
            description="Obter visão de baixa luz",
            tree="Discípulos da Crepúsculo",
            name="Visão Sombra"
        },
        {
            description="Leve metade do dano do fogo, ou nenhum dano em uma falha",
            tree="Ember de Vahl",
            name="Iniciação de Vahl"
        },
        {
            description="Rebole Farseeing ou Pesquise Seus Sentimentos Use as verificações da Força e obtenha o melhor resultado",
            tree="Ember de Vahl",
            name="Lendo a Chama"
        },
        {
            description="+1 Forçar bônus em rolos de ataque com armas simples",
            tree="Ember de Vahl",
            name="Espada de Vahl"
        },
        {
            description="Arma de coroa em chamas que causam danos de fogo +1d6",
            tree="Ember de Vahl",
            name="Chama de Vahl"
        },
        {
            description="Os danos da Arma de Empoderamento são considerados danos ao fogo",
            tree="Ember de Vahl",
            name="Arma de Vahl"
        },
        {
            description="Passe um ponto de força para transformar sua explosão de força em um ataque de efeito de área com um raio de 2 quadrados",
            tree="Xamã Feluciano",
            name="Detonar"
        },
        {
            description="Ter sucesso automático na telepatia com um alvo disposto, e pode usá-lo como uma ação rápida",
            tree="Xamã Feluciano",
            name="Mente Colmeia"
        },
        {
            description="Passe um ponto de força como uma ação completa para dobrar o DR de uma arma sem energia e torná-lo resistente aos sabres de luz. Dobraste o dano que ganhaste ao gastares um Ponto de Força para adicionares danos à arma.",
            tree="Xamã Feluciano",
            name="Infundir a Arma"
        },
        {
            description="Se você usar a verificação de força para usar a força de explosão excede a defesa de fortaleza do alvo, eles se movem -1 descer a trilha de condição se você aceitar um aumento de 1 para o seu Lado Sombrio Score",
            tree="Xamã Feluciano",
            name="Explosão Doente"
        },
        {
            description="oponente é de pé plano contra o seu próximo ataque com um sabre de luz antes do fim do seu próximo turno",
            tree="Cavaleiro de Ferro",
            name="Duelista Dróide"
        },
        {
            description="pode usar Força Trance e receber transferência vital e ganhar hp adicional = Cha mod (min 1)",
            tree="Cavaleiro de Ferro",
            name="Forçar a reparação"
        },
        {
            description="pode curar dróides com transferência vital",
            tree="Cavaleiro de Ferro",
            name="Dróide de Cura"
        },
        {
            description="tornar-se imune a Sense Force e parecem ser dróides normais até que você use a Força",
            tree="Cavaleiro de Ferro",
            name="Presença da máscara"
        },
        {
            description="ganhar bônus para Will Def = Cha mod (min 1) contra Use a Força até o fim do seu próximo turno",
            tree="Cavaleiro de Ferro",
            name="Mente de Silício"
        },
        {
            description="Uma vez por encontro, faça uma verificação de Persuasão contra a Defesa de Vontade de um alvo para negar-lhes sua ação de movimento na próxima rodada, ou sua ação padrão para um Ponto de Força",
            tree="Jal Shay",
            name="Forçar o Atraso"
        },
        {
            description="Após o sucesso em Força Atraso, conceder um aliado dentro de seis quadrados e linha de visão outra ação padrão para uma ação de movimento",
            tree="Jal Shay",
            name="Intercâmbio de Acções"
        },
        {
            description="Transferir um ponto de força para um item como uma ação completa a ser recuperada como uma ação rápida em um momento posterior",
            tree="Jal Shay",
            name="Item do Imbue"
        },
        {
            description="Passe um ponto de força para ajudar outro aliado dentro de 6 quadrados em uma verificação Use a força como uma reação",
            tree="Jal Shay",
            name="Conhecimento da Força"
        },
        {
            description="Passe um ponto de força como uma ação completa para aumentar o bônus de armadura de sua armadura em +2 e sua máxima Dexeridade em +1",
            tree="Jensaarai Defender",
            name="Armadura Attune"
        },
        {
            description="Proteja você e qualquer coisa sobre sua pessoa de vigilância eletrônica, sensores e comunicações, ativados como uma ação rápida e mantidos como uma ação padrão",
            tree="Jensaarai Defender",
            name="Forçar o Cloak"
        },
        {
            description="Você pode usar Force Cloak em um número de criaturas até o seu nível de caráter (incluindo você)",
            tree="Jensaarai Defender",
            name="Forçar o domínio do manto"
        },
        {
            description="Leve uma penalidade para o seu rolo de ataque para adicionar à Defesa Reflexa de um aliado dentro da linha de visão como uma ação rápida (pênalti máximo / bonus de -5/+5)",
            tree="Jensaarai Defender",
            name="Defesa Ligada"
        },
        {
            description="Faça uma verificação de engano sempre que usar Use a Força para ocultar os efeitos do uso da Força",
            tree="Keetael",
            name="Uso da Força Oculta"
        },
        {
            description="Adicionar +3 (ou +4 se você rolar d8s) quando passar um ponto de força em um ataque variado em vez de rolar um dado",
            tree="Keetael",
            name="Direção de Força"
        },
        {
            description="Adicione o seu rolo Ponto da Força a um ataque melee para melee dano também",
            tree="Keetael",
            name="Forçar o Momento"
        },
        {
            description="Reduza os números de DC pela metade ao usar farseeing para olhar para o passado, e veja tudo dentro de seis quadrados do seu alvo sem gastar um Ponto de Força",
            tree="Keetael",
            name="Visões Passadas"
        },
        {
            description="Uma vez por turno como reação, você pode ganhar um bônus de deflexão +2 para sua defesa reflexa contra qualquer ataque variado. Para usar esse talento, você deve estar usando uma luva de escudo ativo, você deve estar ciente do ataque, e você não deve ser de pé plano.",
            tree="Kilian Ranger",
            name="Defesa da luva de escudo"
        },
        {
            description="Uma vez por rodada como uma reação, você pode negar um ataque variado, fazendo um sucesso Use a verificação Força. O DC da verificação de habilidade é igual ao resultado do rolo de ataque que você deseja negar. Para usar este talento, você deve estar usando uma luva de escudo ativo que você deve estar ciente do ataque, e você não deve ser de pés chatos. Você pode gastar um ponto de força para usar este talento para negar um ataque variado contra um personagem adjacente.\nVocê pode usar Shield Gauntlet Deflection para desviar alguns dos disparos disparados de uma arma variada definida em auto-fogo. Se a verificação Use a Força tiver sucesso. Sofres metade dos danos se o ataque atingir e nenhum dano se o ataque falhar.\nPré-requisito: Defesa de escudos.",
            tree="Kilian Ranger",
            name="Desvio da luva de escudo"
        },
        {
            description="Este talento permite redirecionar um parafuso de blaster desviado ao longo de uma trajetória específica para que ele danifique outra criatura ou objeto em seu caminho. Quando você desviar com sucesso um parafuso de blaster, você pode fazer um ataque imediato variado contra outro alvo dentro de 6 quadrados de você para o qual você tem linha de visão. Se o ataque for bem sucedido, causa danos normais ao alvo.\nSó os parafusos de blaster podem ser redirecionados desta forma. Você não pode usar este talento para redirecionar barragens de armas de fogo automático e outros tipos de projéteis. Para usar esse talento, você deve estar usando uma luva de escudo ativo, você deve estar ciente do ataque, e você não deve ser de pé plano.\nPré-requisitos: Escudo Gauntlet Defesa, Escudo Gauntlet Deflex, base bônus de ataque +5.",
            tree="Kilian Ranger",
            name="Redirecionar a luva de escudo"
        },
        {
            description="Tratas uma lança siang como uma espingarda em vez de uma arma exótica. Além disso, você ganha um bônus +1 para atacar rolos com uma lança siang. Este talento conta como o foco da arma (siang lance) feito com o propósito de satisfazer pré-requisitos. Se você também tem a façanha de Foco de Arma (rifles), o bônus de ataque fornecido por este talento não empilha com o bônus de ataque fornecido por Foco de Arma (rifles).",
            tree="Kilian Ranger",
            name="Siang Lance Mastery"
        },
        {
            description="Você pode gastar um Ponto de Força para capacitar uma lança siang, o que requer uma ação completa. Depois que a lança do siang está empoderada, ela lida com uma morte adicional de dano quando você a empunha. Outros que empunham a arma não ganham o bônus de dano morrer.\nPré-requisito: Siang Lance Mastery, bônus de ataque base +7.",
            tree="Kilian Ranger",
            name="Empoderar Siang Lance"
        },
        {
            description="Ganhas um seguidor de Akk Dog",
            tree="Korunnai Adept",
            name="Akk Dog Master"
        },
        {
            description="Você pode usar as seguintes ações em sua vez\n- Ataque em Concerto\n- Caia na Prey\n- Emparelhado Maul\nVer p.57 do CWCS",
            tree="Korunnai Adept",
            name="Ações de Akk Dog Trainer"
        },
        {
            description="Seu Akk Dog ganha o poderoso feito de carga",
            tree="Korunnai Adept",
            name="Treinamento de Cães Akk"
        },
        {
            description="Seu Akk Dog ganha ataques de oportunidade contra inimigos adjacentes atacando você",
            tree="Korunnai Adept",
            name="Reacção protectora"
        },
        {
            description="Uma vez por encontro ao usar um Ponto de Força de uma forma que lhe daria um ponto de lado escuro, você ganha automaticamente o resultado mais alto possível do rolo de morrer do Ponto de Força",
            tree="O Krath",
            name="Manipulação Lada Negra"
        },
        {
            description="Reduzir a pena para grandes ilusões para metade como uma ação rápida",
            tree="O Krath",
            name="Ilusões Krath"
        },
        {
            description="Uma vez por encontro, tratar os danos de uma arma alquímica Sith como o máximo possível",
            tree="O Krath",
            name="Intuição Krath"
        },
        {
            description="Uma vez por encontro, como uma ação rápida, adicionar 1 morrer de dano ou estender o alcance de uma potência por 6 quadrados, tornando-o um poder do lado escuro",
            tree="O Krath",
            name="Krath Surge"
        },
        {
            description="Faça um DC 15 Use a verificação Força como uma ação rápida para detectar campos eletromagnéticos e de energia dentro de 12 quadrados de você, e tratar SR como 5 pontos mais baixo até sua próxima volta",
            tree="Luka Sene",
            name="Detecção de Campo"
        },
        {
            description="Uma vez por encontro, ganhe um ponto de força para usar com as árvores de talentos Senso ou Luka Sene, farseeing, ou Use a força para sentir força ou pesquisar seus sentimentos",
            tree="Luka Sene",
            name="Luka Sene Master"
        },
        {
            description="Você pode pesquisar como uma ação rápida, e sempre ter sucesso em Sense Surroundings",
            tree="Luka Sene",
            name="Visão de Força Melhorada"
        },
        {
            description="Faça uma verificação Use a Força como uma ação livre contra a defesa de vontade de um alvo dentro de 12 quadrados para ganhar +2 para atacar rolos contra eles, ao custo de um uso de farseeing",
            tree="Luka Sene",
            name="Consulta Rápida"
        },
        {
            description="adicionar Cha mod em vez de Con mod para Fort Def, pode gastar FP para se tornar imune ao veneno, radiação e doença até o fim do enc",
            tree="Matuki Adept",
            name="Controle do Corpo"
        },
        {
            description="quando você rolar uma verificação de iniciativa no início do enc você pode gastar um swif imediatamente, independentemente",
            tree="Matuki Adept",
            name="Cirurgia Física"
        },
        {
            description="quando danificado ganho DR 10 até ao fim da sua próxima volta",
            tree="Matuki Adept",
            name="Macio a Sólido"
        },
        {
            description="+1 Ref Def v. melee se tiver wan-shen na mão e não pés plano",
            tree="Matuki Adept",
            name="Defesa Wan-Shen"
        },
        {
            description="tratar wan-shen como arma Med não Grande, pode Pin & Trip com wan-shen se wan-shen na mão",
            tree="Matuki Adept",
            name="Wan- Shen Kata"
        },
        {
            description="fazer 2 atk com wan-shen cada um contra um alvo diferente se tiver wan-shen na mão",
            tree="Matuki Adept",
            name="Wan-Shen Mastery"
        },
        {
            description="+5 para Defesa de Vontade against Deception, e pode usar a Força para fazer verificações de persuasão para sentir engano e sentir influência",
            tree="Ordem de Shasa",
            name="Consciência Decepção"
        },
        {
            description="+1 ataque com fira",
            tree="Ordem de Shasa",
            name="Maior Foco na Arma (fira)"
        },
        {
            description="Uma vez por encontro, Use a Força contra a Defesa de Vontade de um oponente para movê-los -1 persistente descer a pista de condição e negá-los sua ação padrão no próximo turno",
            tree="Ordem de Shasa",
            name="Chamada do Progenitor"
        },
        {
            description="Adicione seu modificador Carisma a qualquer dano de um poder telecinético como uma ação rápida",
            tree="Ordem de Shasa",
            name="Forma de onda"
        },
        {
            description="se não usar armas (luvas ou luvas) pode usar o Whirlwind Attack até ao início da sua próxima volta",
            tree="Seyugi Dervish",
            name="Cyclone de Seyugi"
        },
        {
            description="pode mover a velocidade após o ataque Whirlwind",
            tree="Seyugi Dervish",
            name="Vento móvel"
        },
        {
            description="+2 Ref Def v. alvo atingido por Whirlwind Ataque até o início da sua próxima volta",
            tree="Seyugi Dervish",
            name="Repelindo o vento"
        },
        {
            description="fazer Whirlwind Ataque no final da carga não melee ataque normal se não usar armas (luvas, etc)",
            tree="Seyugi Dervish",
            name="Tempestade súbita"
        },
        {
            description="pode mover o alvo 1 sq se danificado pelo Whirlwind Ataque, não se agarrado ou travado, sem Atk of Opp",
            tree="Seyugi Dervish",
            name="Tempestade lançada"
        },
        {
            description="+1d6 represa de fogo para qualquer potência de força que afeta um único alvo e pega fogo",
            tree="Shaper de Kro Var",
            name="Combustão"
        },
        {
            description="criar 3x3 sq terreno difícil ao seu redor e você ignora terreno difícil que você cria",
            tree="Shaper de Kro Var",
            name="Fivela terrestre"
        },
        {
            description="UtF para acrobacias e pode reroll UtF se pode reroll Acrobacias, gastar FP para ser um tamanho maior w / grapple",
            tree="Shaper de Kro Var",
            name="Fluididade"
        },
        {
            description="Se usares um Poder de Força que cause danos, podes usar o Bantha Rush contra o alvo como se melee atk",
            tree="Shaper de Kro Var",
            name="Trovãoclap"
        },
        {
            description="ganhar ocultação & +2 Ref Def v. armas lançadas até o fim do encontro",
            tree="Shaper de Kro Var",
            name="Vortex Wind"
        },
        {
            description="Quando visado pelo poder do lado negro, gaste um ponto de força para dar uma penalidade ao seu Use a verificação da força igual à sua pontuação no lado escuro",
            tree="Tyia Adept",
            name="Repelir Discórdia"
        },
        {
            description="Os teus poderes da Força podem causar danos de choque.",
            tree="Tyia Adept",
            name="Conflito de Estímulos"
        },
        {
            description="Passe um ponto de força como uma ação Swift para designar um aliado em 12 quadrados e linha de visão; até o fim de sua próxima volta, se o aliado leva danos, você leva metade em vez",
            tree="Tyia Adept",
            name="Tyia Adept"
        },
        {
            description="Quando um aliado em 12 quadrados e linha de visão leva danos ou move-se para baixo a trilha da condição, outro aliado dentro de 12 quadrados e linha de visão ganha pontos de impacto temporários igual a 5 + seu modificador Carisma",
            tree="Tyia Adept",
            name="Ciclo de Harmonia"
        },
        {
            description="1/torno aliado dentro de 12 quadrados e linha de visão pode tomar um Segundo Vento se eles já não têm",
            tree="Tyia Adept",
            name="Forçar a Estabilização"
        },
        {
            description="Recupere todos os poderes da força em um 20 natural em um ataque desarmado",
            tree="Diretor do Céu",
            name="Ressurgência Marcial"
        },
        {
            description="Fazer a verificação de salto como uma ação gratuita quando você reduziu um oponente para 0 hp",
            tree="Diretor do Céu",
            name="Salto Rebotado"
        },
        {
            description="Faça dois ataques desarmados contra alvos diferentes.",
            tree="Diretor do Céu",
            name="Greve Similatanosa"
        },
        {
            description="Adicionar rolo de ponto de força para danos e ataque se desarmado",
            tree="Diretor do Céu",
            name="Greve telecinética"
        },
        {
            description="Rebole qualquer dado de dano desarmado que tenha um \"1\" como resultado",
            tree="Diretor do Céu",
            name="Ataque Brutal Sem Armados"
        },
        {
            description="Com sucesso Atirar oponente cai propensa em qualquer espaço que você deseja até 3 quadrados além do seu alcance",
            tree="Diretor do Céu",
            name="Lançar Telecinético"
        },
        {
            description="reação ao dano ganhar total ocultação até o final de sua próxima volta e pode tomar 2o Vento se não",
            tree="Adepto Atual Branco",
            name="Montar a Corrente"
        },
        {
            description="até o fim do encontro: só pode usar \"você\" Força Powers & 1/turn recuperar 1 energia gasta w/out FP",
            tree="Adepto Atual Branco",
            name="Renda-se à corrente"
        },
        {
            description="Use a Força substitui Stealth, considerado treinado, se pode reroll Stealth pode reroll Use a Força",
            tree="Adepto Atual Branco",
            name="Adepto Atual Branco"
        },
        {
            description="furtivo de Stealth de dispositivos eletrônicos, use o mesmo rolo para Percepção & Usar Computador",
            tree="Adepto Atual Branco",
            name="Forçar a Imersão"
        },
        {
            description="aplica-se a aliado também, gastar Ponto da Força para todos os aliados adjacentes",
            tree="Adepto Atual Branco",
            name="Imergir outro"
        },
        {
            description="fazer atk área com diskblade v. 3 alvos se todos na faixa PB, fazer 1 rolo de ataque",
            tree="Zeison Sha Guerreiro",
            name="Arco Discblade"
        },
        {
            description="tratar discoblado lançado como pistola para alcance",
            tree="Zeison Sha Guerreiro",
            name="Discblade Distante"
        },
        {
            description="DC 15 Use a Força para recordar o disco",
            tree="Zeison Sha Guerreiro",
            name="Chamar Discblade"
        },
        {
            description="pode retornar Intercept para suite sem gastar Ponto da Força",
            tree="Zeison Sha Guerreiro",
            name="Vigilância Telecinética"
        },
        {
            description="+2 represa de melee com discblade",
            tree="Zeison Sha Guerreiro",
            name="Especialização em armas (discblado)"
        },
        {
            description="Você pode usar Trate Lesão em vez de Persuasão para intimidar ou mudar atitudes",
            tree="Dróide de primeiro grau",
            name="Interrogador"
        },
        {
            description="Como uma ação gratuita, você faz uma verificação DC 15 Conhecimento (ciências da vida) (DC 25 para espécies raras, DC 35 para espécies desconhecidas, ambas determinadas pelo Gamemaster). Se o cheque for bem sucedido, até o final do encontro, sempre que você fizer um ataque bem sucedido ou desarmado que cause danos contra um alvo dessa espécie, seu alvo leva uma -2 penalidades para atacar rolos até o fim de sua próxima vez.\nPré-requisito: Formação em Conhecimento (ciências da vida)",
            tree="Dróide de primeiro grau",
            name="Vulnerabilidade conhecida"
        },
        {
            description="Ao fazer uma verificação de tratamento de lesão para tratar doença, tratar veneno ou tratar radiação, você também pode adicionar seu modificador de inteligência para o seu rolo.\nPré-requisitos: Treinado em Conhecimento (ciências da vida), dróide médico.",
            tree="Dróide de primeiro grau",
            name="Analisador Médico"
        },
        {
            description="Você concede uma criatura pontos duplos para cada ponto acima da DC ao executar primeiros socorros com um medpac",
            tree="Dróide de primeiro grau",
            name="Dróide Médico"
        },
        {
            description="Faça uma verificação DC 15 Trate Lesão como uma ação redonda completa para mover uma criatura adjacente +1 passo ao longo da trilha de condição",
            tree="Dróide de primeiro grau",
            name="Encaixe a Dor"
        },
        {
            description="Você pode adicionar o dobro do seu modificador de inteligência para o seu conhecimento (ciências da vida) ou verificação de habilidades de conhecimento (ciências físicas).\nPré-requisitos: Formação em Conhecimento (ciências da vida) e Conhecimento (ciências físicas).",
            tree="Dróide de primeiro grau",
            name="Analisador de Ciência"
        },
        {
            description="Como uma ação padrão, você pode fazer uma verificação DC 20 tratar lesão. Se a verificação tiver sucesso, você sabe se os cha ratters orgânicos dentro de 6 quadrados e dentro de sua linha de visão estão abaixo de metade de seus pontos de sucesso e em que passo eles estão ao longo da pista de condição.\nPré-requisitos: Treinado em Lesão de Tratamento, dróide médico.",
            tree="Dróide de primeiro grau",
            name="Varredura de Triagem"
        },
        {
            description="Quando você ajuda outro em Mecânica, Piloto ou Computador de Uso, você adiciona +5 em vez de +2",
            tree="Dróide de segundo grau",
            name="Assistente Adept"
        },
        {
            description="Você pode dobrar a quantidade de dados transferidos com o idioma binário em uma única rodada (veja a página 191 do livro de regras da Saga Edition) ao se comunicar com outros dróides com Burst Transfer, e você corta o tempo de informações de acesso ao meio ao fazer verificações de uso do computador para encontrar geral ou específico em formação (ver página 76 do livro de regras do núcleo da Saga Edition)",
            tree="Dróide de segundo grau",
            name="Burst Transfer"
        },
        {
            description="Podes sempre aceitar dez cheques mecânicos.",
            tree="Dróide de segundo grau",
            name="Mecânica Mestre"
        },
        {
            description="Enquanto estiver a bordo de uma nave estelar ou veículo e ligado aos sistemas da nave por ligação scomp, soquete dróide, ou porta de dados básicos, você pode redirecionar energia ou recarregar escudos como duas ações rápidas em vez de três.",
            tree="Dróide de segundo grau",
            name="Ligação do Sistema On-Board"
        },
        {
            description="Suas rotinas eletrônicas rápidas de cálculo de asterrorância permitem que você corte o tempo de cálculo ao meio. Além disso, ao tentar uma verificação Use Computer para Astrogate, você pode fazer o cálculo como uma ação padrão em vez de uma ação completa.\nPré-requisito: Treined in Use Computer.",
            tree="Dróide de segundo grau",
            name="Astrogação Rápida"
        },
        {
            description="Você pode usar cada uma das ações fo llowing uma vez por encontro:\n• Erradicar: Você pode usar Disable ou Apagar Prog carneiro em um computador que é amigo ou útil para você. Com isso é talento, disabrir ou apagar um programa leva 5 minutos e requer um DC 15 Use Computer check (ver página 76 do livro de regras da Saga Edition).\n• Bloqueio: Se você tiver sucesso em uma verificação de computador oposta quando você emitir um comando de rotina para neutralizar as ações de outro programador, você automaticamente bloquear o outro programador fora do sistema. Ele ou ela deve ter sucesso em uma verificação Use Computer contra você para recuperar o acesso ao sistema (ver página 76 do livro de regras da Saga Edition). Resiste à tentativa como reacção.\n• Não rastreável: Como reacção, você automaticamente manter um computador hosti le a partir de t raci ng sua localização se você f ai l a Use Computer check (ver página 76 do livro de regras Saga Edition core) por 10 ou menos.\nPré-requisitos: Quaisquer dois ta emprestados da Árvore de Talentos Slicer (ver página 47 do livro de regras Saga Ed ition). Burst Transfer pode ser um desses talentos.",
            tree="Dróide de segundo grau",
            name="Cortador de Links Scomp"
        },
        {
            description="Uma vez por dia, você pode fazer uma verificação DC 20 Mecânica como três ações rápidas em rodadas sucessivas para conceder um veículo 1d8 pontos de batida mais 1 para cada ponto que você exceder o DC, e movê-lo +1 passo ao longo da pista de condição",
            tree="Dróide de segundo grau",
            name="Mecânica do Veículo"
        },
        {
            description="Quando você usa Persuasão para mudar de atitude, você ajusta-a por um passo adicional",
            tree="Dróide de terceiro grau",
            name="Etiqueta"
        },
        {
            description="Você pode usar ajuda outro para um aliado adjacente como uma ação rápida uma vez por turno",
            tree="Dróide de terceiro grau",
            name="Útil"
        },
        {
            description="Uma vez por encontro, você pode adicionar seu bônus de Sabedoria a um cheque de Persuasão, além do bônus de Carisma.",
            tree="Dróide de terceiro grau",
            name="Nuanced"
        },
        {
            description="Aumenta a sua persuasão aplicando dados obtidos através da observação. Sempre que você falharia em uma verificação de Persuasão, você pode rolar uma verificação de Percepção como uma ação gratuita, com um DC igual ao DC da verificação de Persuasão. Se você tiver sucesso, adicione +5 ao resultado original da verificação de Persuasão.",
            tree="Dróide de terceiro grau",
            name="Observador"
        },
        {
            description="Você automaticamente tem sucesso em ajudar outro para verificação de Decepção, Conhecimento e Persuasão",
            tree="Dróide de terceiro grau",
            name="Protocolo"
        },
        {
            description="Você pode usar cada uma das seguintes ações uma vez por encontro:\n• Suporte de combate: Como uma ação padrão, você automaticamente ajuda outro no rolo de ataque de um dróide mentiroso, desde que você seja capaz de usar o auxílio outra ação para ajudar esse aliado. Se você também tem Foco de Arma com esta arma, você aumenta o bônus fornecido pela ajuda outra ação de +2 para +3.\n• Diretor: Como uma ação padrão, você automaticamente ajudar outro dróide com uma habilidade que você está treinando. Se você também tem Skill Focus na habilidade, você aumenta a ajuda outro bônus de +2 para +5.\n• Ação instantânea: Como uma ação rápida, você concede a um aliado uma ação rápida que ele pode usar imediatamente como uma ação livre.\nPré-requisitos: Observador, qualquer talento da Influência, Inspiração ou Liderança Talento Árvores (ver páginas 43 - 44 do livro de regras da Saga Edition).",
            tree="Dróide de terceiro grau",
            name="Supervisionar o Dróide"
        },
        {
            description="Quando um de seus aliados está tentando usar a habilidade de Persuasão para mudar a atitude de uma criatura que não entende seu aliado, você adiciona +2 aos resultados da verificação de Persuasão do aliado se você realizar a tradução.\nPré-requisito: Treinado em Persuasão.",
            tree="Dróide de terceiro grau",
            name="Talkdroid"
        },
        {
            description="Uma vez por dia, você pode se reparar como uma ação completa em vez de mais de uma hora",
            tree="Dróide de 4o Grau",
            name="Reparações de Combate"
        },
        {
            description="Adicionas o dobro do teu bónus de força aos rolos de danos ao usar uma arma só com uma mão.",
            tree="Dróide de 4o Grau",
            name="Droid Smash"
        },
        {
            description="Uma vez por encontro, como uma reação, você pode reduzir o dano de um único ataque que visa sua Defesa Reflexa em uma quantidade igual à sua Defesa Fortitude.\nPré-requisitos: Equipado com armadura média ou melhor, proficiente com essa armadura.",
            tree="Dróide de 4o Grau",
            name="Apenas um arranhão"
        },
        {
            description="Uma vez por encontro, como uma ação rápida, designar um alvo inimigo dentro da linha de visão como um alvo adquirido. Você ganha um bônus de +1 circunstância para atacar rolos e rolos de danos para todos os ataques contra esse alvo até o final do encontro, desde que o alvo permanece dentro da sua linha de visão.",
            tree="Dróide de 4o Grau",
            name="Aquisição do Alvo"
        },
        {
            description="Trava-se no alvo designado pelo talento de aquisição do alvo. Se o alvo deixar a sua linha de visão, você automaticamente readquirir o bloqueio do alvo como uma reação se o alvo voltar com a sua linha de visão. Você também ganha um bônus +5 para sua habilidade de percepção ao se opor às verificações Stealth do alvo.\nPré-requisito: Aquisição do alvo.",
            tree="Dróide de 4o Grau",
            name="Bloqueio do Alvo"
        },
        {
            description="Você pode tomar duas ações rápidas consecutivas para conceder a si mesmo +2 para atacar e danificar rolos em alvos em linha de visão dentro do intervalo em branco",
            tree="Dróide de 4o Grau",
            name="Pacote de destino"
        },
        {
            description="Uma vez por encontro, como uma ação livre, você pode aumentar os danos causados por uma de suas armas em 1 ou 2 dados de dano em troca de mover -1 passo na pista condição para cada morrer aumentado. A arma deve ser montada permanentemente em seu chassis, e deve usar sua fonte de alimentação interna. As armas de mão, tais como espingardas, não se qualificam para este talento.",
            tree="Dróide de 4o Grau",
            name="Surge o Poder das Armas"
        },
        {
            description="+5 bônus para verificação de habilidade baseada em força, e dobrar sua capacidade de transporte",
            tree="Dróide de quinto grau",
            name="Cargo Hauler"
        },
        {
            description="A primeira vez durante um encontro que você seria movido para o fundo da pista de condição por qualquer efeito, você em vez parar no passo -10. Além disso, se um único ataque faz com que você mova vários passos para baixo da pista de condição, você pode gastar um ponto de força como uma reação para apenas mover -1 descer a pista de condição.",
            tree="Dróide de quinto grau",
            name="Durável"
        },
        {
            description="+5 bônus à defesa de fortaleza contra riscos ambientais",
            tree="Dróide de quinto grau",
            name="Protegido ambientalmente"
        },
        {
            description="Podes dobrar o teu bónus da Força para os teus rolos de danos desarmados.\nPré-requisito: Tamanho médio ou maior.",
            tree="Dróide de quinto grau",
            name="Atuadores pesados"
        },
        {
            description="Você é considerado proficiente com armas lançadas improvisadas (veja página 150 do livro de regras da Saga Edition) ao fazer um ataque variado jogando um objeto. Objetos até uma categoria de tamanho maior do que você pode ser jogado até um número de quadrados iguais a 2× seu bônus de força (mínimo 1 quadrado). Além disso, você adiciona seu bônus de Força a qualquer dano causado.",
            tree="Dróide de quinto grau",
            name="Carregar o Lançador"
        },
        {
            description="Você pode agir como um gerador de energia, e pode recarregar escudos ou redirecionar energia em um veículo ou nave estelar como apenas duas ações rápidas",
            tree="Dróide de quinto grau",
            name="Fonte de alimentação"
        },
        {
            description="Selecione uma habilidade em que você é treinado. Uma vez por encontro, você pode executar qualquer aplicação dessa habilidade como uma ação mais rápida do que o normal, mas como pelo menos uma ação rápida (por exemplo, uma ação completa torna-se uma ação padrão, uma ação padrão torna-se uma ação movimento, uma ação movimento torna-se uma ação rápida). As tarefas que exigem mais de uma rodada não podem ser otimizadas com esse talento.",
            tree="Dróide de quinto grau",
            name="Otimização da Tarefa"
        },
        {
            description="Sempre que você usar o movimento completo em seu veículo, você ganha um bônus +2 para a Defesa Reflexa da nave.",
            tree="Execução de Bloqueio",
            name="Saída"
        },
        {
            description="Se você é o piloto de um veículo, veículos menores recebem uma penalidade -10 em seus cheques Pilot para engajá-lo em uma luta de cães.",
            tree="Execução de Bloqueio",
            name="Perfurar"
        },
        {
            description="Quando você é o piloto de um veículo colossal ou menor, armas de navio capital que tomar uma -20 penalidade em rolos de ataque críticos em um 20 natural apenas se a batida normalmente teria atingido o seu veículo.",
            tree="Execução de Bloqueio",
            name="Alvo Pequeno"
        },
        {
            description="Você pode se mover para dentro ou através de um espaço ocupado por uma nave Colossal (Frigate) ou maior sem causar uma colisão, e pode ocupar o mesmo espaço se sua nave for Colossal ou menor.",
            tree="Execução de Bloqueio",
            name="Veja isto"
        },
        {
            description="Se você ocupar o mesmo espaço que um veículo maior que o seu, você ganha um bônus de cobertura +5 dele.",
            tree="Execução de Bloqueio",
            name="Fechar a Capa"
        },
        {
            description="Faça uma verificação piloto oposta como uma ação rápida para ficar no ponto cego de um alvo para ganhar +2 bônus para atacar e infligir uma penalidade -2 para ataques contra você",
            tree="Piloto Especialista",
            name="Ponto Cego"
        },
        {
            description="Quando o ramming levar dano como se o seu navio é 2 tamanhos menor, navio rammed é dano normal",
            tree="Piloto Especialista",
            name="Clip"
        },
        {
            description="Faça uma verificação piloto contra o rolo de ataque total de um golpe crítico marcado contra você para evitar levar duplo dano",
            tree="Piloto Especialista",
            name="Fechar Raspa"
        },
        {
            description="Pilotos inimigos em uma luta de cães com você recebem uma penalidade -10 para atacar rolos contra você quando você tiver sucesso na verificação piloto oposto",
            tree="Piloto Especialista",
            name="Elusivo Dogfighter"
        },
        {
            description="Você pode tomar 10 em verificações Pilot para aumentar a velocidade do seu veículo, e movimento total move você cinco vezes a velocidade do seu veículo",
            tree="Piloto Especialista",
            name="Aceleração total"
        },
        {
            description="Você não precisa se mover em linha reta em uma corrida de ataque",
            tree="Piloto Especialista",
            name="Execução de Ataque Melhorada"
        },
        {
            description="Luta defensivamente = +5 Ref Def & -2 atk ou +10 Ref Def & -5 atk",
            tree="Piloto Especialista",
            name="Mestre Defender"
        },
        {
            description="Você pode voltar a se opor aos cheques Pilot para iniciar uma luta de cães e manter o melhor resultado",
            tree="Piloto Especialista",
            name="Perseguição Incansável"
        },
        {
            description="Todos os aliados dentro de 6 quadrados de um veículo que você piloto pode rerolar uma verificação piloto, mantendo o melhor resultado.",
            tree="Piloto Especialista",
            name="Piloto Renovado"
        },
        {
            description="1/enc quando sua nave sofre danos, Piloto vs navio aliado adjacente Ref Def para deslocar danos para aliado",
            tree="Piloto Especialista",
            name="Dano de shunt"
        },
        {
            description="Pode sempre levar 10 em verificações piloto e ganhar um +2 para atacar rolos com um tipo de veículo\n\n(Entrar número de vezes tomadas, escolher qual veículo à direita)",
            tree="Piloto Especialista",
            name="Foco do Veículo"
        },
        {
            description="O seu veículo leva metade dos danos causados por ataques de área que atingiram, nenhum dano causado por ataques de área que falham.",
            tree="Piloto Especialista",
            name="Evasão veicular"
        },
        {
            description="Ao lutar defensivamente como o piloto de um veículo, você pode usar o combate veicular para negar um hit adicional por rodada",
            tree="Piloto Especialista",
            name="Juke"
        },
        {
            description="Faça um teste piloto DC 15 como uma ação rápida para dar a um caça estelar aliado ou aerovelocidade dentro de 2 quadrados um bônus +5 para os controles piloto relacionados à luta de cães",
            tree="Piloto Especialista",
            name="Wingman"
        },
        {
            description="+1 bônus em rolos de ataque feitos usando armas de veículo",
            tree="Gunner",
            name="Expert Gunner"
        },
        {
            description="Não leve nenhuma penalidade para atacar rolos em lutas de cães, mesmo que você não é o piloto",
            tree="Gunner",
            name="Gunner de luta de cães"
        },
        {
            description="Em um veículo inimigo deixando seu quadrado ou um quadrado adjacente, você faz um único ataque contra esse veículo como um ataque de oportunidade",
            tree="Gunner",
            name="Ativador Rápido"
        },
        {
            description="Uma vez por ataque de encontro simultaneamente com um aliado para tratar o ataque como um golpe para determinar danos antes SR e DR são aplicados",
            tree="Gunner",
            name="Fogo Sincronizado"
        },
        {
            description="Depois de causar danos a um veículo que exceda o seu limiar de danos, o veículo desloca-se um passo adicional -1 para baixo da pista de condição",
            tree="Gunner",
            name="Sistema atingido"
        },
        {
            description="Desactivar um dos sistemas de uma nave ao fazê-lo mover-se para baixo da pista de condição",
            tree="Gunner",
            name="Bater paralisante"
        },
        {
            description="Reduzir a categoria de alcance para um alvo por um ao usar armas de veículo",
            tree="Gunner",
            name="Grande Tiro"
        },
        {
            description="Designe um alvo como uma ação rápida para fornecer um bônus +5 para atacar rolos para membros do seu esquadrão em uma corrida de ataque",
            tree="Líder de Esquadrão",
            name="Iniciar a Execução de Ataque"
        },
        {
            description="Uma vez por encontro mover todos os veículos em seu esquadrão +1 passo ao longo da pista condição como uma ação padrão",
            tree="Líder de Esquadrão",
            name="Reagrupar"
        },
        {
            description="Partir os benefícios de um piloto especialista ou talento Gunner que você possui para todos os membros do seu esquadrão uma vez por encontro como uma ação padrão",
            tree="Líder de Esquadrão",
            name="Manobras de Esquadrão"
        },
        {
            description="Uma vez por encontro, ao usar uma manobra de nave estelar, você concede a todos os membros do seu esquadrão a capacidade de usar a mesma manobra no seu próximo turno.",
            tree="Líder de Esquadrão",
            name="Tática de Esquadrão"
        },
        {
            description="Quando você usa o auxílio outra ação para ajudar um aliado de ataque rolar com uma arma de veículo, se o ataque atinge, ele lida +1 morrer de dano. Qualquer aliado só pode beneficiar deste talento uma vez por rolo de ataque, independentemente de quantos aliados com esta ajuda talento no ataque.",
            tree="Wingman",
            name="Concentrar todo o fogo"
        },
        {
            description="Como uma reação, você pode usar o feito de combate veicular para negar um ataque contra um veículo adjacente de tamanho colossal ou menor que é pilotado por um aliado. Se você pode usar o Vehicular Combat mais de uma vez por rodada. cada uso para negar um ataque conta para o seu limite de usos por rodada.\nPré-requisito: Piloto de escolta.",
            tree="Wingman",
            name="Piloto de Acompanhante"
        },
        {
            description="Quando um veículo que você está pilotando é adjacente a um veículo de tamanho colossal ou menor que é pilotado por um aliado, tanto você e seu aliado ganhar um bônus circunstância +5 para Pilot verificações para evitar ser puxado para uma luta de cães como um ataque de oportunidade.",
            tree="Wingman",
            name="Executar a Interferência"
        },
        {
            description="Quando um veículo de tamanho colossal ou menor que é pilotado por um aliado é danificado por um ataque, uma vez por rodada como uma reação você pode fazer um ataque de arma veículo com uma penalidade -5 contra o atacante do seu aliado.\nPré-requisito: Piloto de escolta.",
            tree="Wingman",
            name="Retribuição do Wingman"
        },
        {
            description="Quando um veículo que você está pilotando é adjacente a um veículo de tamanho colossal ou menor que é pilotado por um aliado, ambos os veículos ganham um bônus +10 para seus limiares de danos.",
            tree="Wingman",
            name="Perder a Perseguição"
        },
        {
            description="Quando um ataque bem sucedido faz com que um oponente se mova -1 passo ao longo da pista de condição, esse oponente imediatamente leva um dano adicional +1d6.",
            tree="Assassino",
            name="Artes Assassinas I"
        },
        {
            description="Sempre que você bateu com sucesso em um oponente que você marcou, sua confusão e ataques variados lidar com um dano adicional +1d6.",
            tree="Assassino",
            name="Artes Assassinas II"
        },
        {
            description="Como uma ação de movimento, você pode mover 1 quadrado sem provocar um ataque de oportunidade.",
            tree="Assassino",
            name="Deslocar"
        },
        {
            description="Qualquer oponente que você está flanqueando é considerado de pé plano e é negado seu bônus de Dexterity para Defesa de Reflexos contra você.",
            tree="Assassino",
            name="Posicionamento vantajoso"
        },
        {
            description="Uma vez por encontro como uma ação padrão, você pode fazer um ataque contra um alvo e, em seguida, mover a sua velocidade para longe desse alvo sem provocar ataques de oportunidade.",
            tree="Assassino",
            name="Obter alguma distância"
        },
        {
            description="Quando você faz um ataque variado contra um alvo que não está à queima roupa, você adiciona metade do seu nível de classe ao seu rolo de danos.",
            tree="Assassino",
            name="Assassino furtivo"
        },
        {
            description="Uma vez por encontro, quando você faz um ataque variado contra um alvo que não está à queima-roupa, você pode ignorar o bônus de armadura do seu alvo para Defesa de Reflexos.",
            tree="Assassino",
            name="Atirador"
        },
        {
            description="Ao tomar apenas uma única ação rápida, você pode mirar em um alvo que não está dentro do alcance em branco.",
            tree="Assassino",
            name="Mestre Sniping"
        },
        {
            description="Quando você reduz um alvo para 0 pontos de ataque ou para o fundo da pista condição, todos os adversários dentro da linha de visão de você e do alvo tomar um -2 em rolos de ataque até o início de sua próxima volta.",
            tree="GenoHaradan",
            name="Repercussões Mortais"
        },
        {
            description="Uma vez por turno, quando você danificar um alvo com sucesso com um ataque fora da área, faça uma verificação imediata de Persuasão contra a defesa de vontade do alvo. Se tiver sucesso, você determina o que o alvo faz com sua ação rápida no seu próximo turno.",
            tree="GenoHaradan",
            name="Golpe Manipulador"
        },
        {
            description="Sempre que você usar com sucesso o talento Manipulating Strike, você determina o que o alvo faz com a sua ação movimento na próxima vez.",
            tree="GenoHaradan",
            name="Greve de manipulação melhorada"
        },
        {
            description="Como uma ação padrão, você pode fazer uma verificação de Persuasão contra a Defesa de Vontade de um alvo dentro de 12 quadrados. Se for bem-sucedido, você move o alvo até metade de sua velocidade para você através da rota mais segura e você pode fazer um ataque imediato variado ou melee.",
            tree="GenoHaradan",
            name="Puxando as Cordas"
        },
        {
            description="DC para localizar pessoa específica com Recolher Informações é -10 e quantidade de suborno e tempo são metade",
            tree="Caçador de recompensas",
            name="Detective."
        },
        {
            description="aplicar inimigo familiar para o 2o alvo, passar um único full-rnd observando se pode ver ambos",
            tree="Caçador de recompensas",
            name="Inimigos familiares"
        },
        {
            description="aplicar inimigo familiar ao seu Fort & Will Def",
            tree="Caçador de recompensas",
            name="Situação Familiar"
        },
        {
            description="",
            tree="Caçador de recompensas",
            name="Marca de Caçador"
        },
        {
            description="Você ganha um bônus em rolos de danos contra um oponente designado uma vez por encontro como uma ação gratuita",
            tree="Caçador de recompensas",
            name="Alvo do Caçador"
        },
        {
            description="Como uma ação padrão, faça uma verificação de persuasão contra Defesa de Vontade do alvo do seu caçador. Se você igualá-lo ou vencê-lo, o oponente leva uma penalidade -5 para Defesa de Vontade, desde que você tenha linha de visão.",
            tree="Caçador de recompensas",
            name="Dread"
        },
        {
            description="Uma vez por turno, sempre que o alvo do seu caçador tentar retirar-se, você pode fazer um ataque de oportunidade contra o oponente.",
            tree="Caçador de recompensas",
            name="Não há para onde correr"
        },
        {
            description="O oponente que você designou com o alvo de Hunter não pode movê-lo ao longo da trilha condição",
            tree="Caçador de recompensas",
            name="Incansável"
        },
        {
            description="Quando você danificar o alvo do caçador, todos os aliados ganham um bônus de +2 em seu próximo ataque contra eles até o início de sua próxima vez.",
            tree="Caçador de recompensas",
            name="Marca"
        },
        {
            description="+1 para Força e Vontade Defesa contra Personagens Sensíveis à Força, e lidar com +1 morre de danos contra eles",
            tree="Caçador de recompensas",
            name="Caçador Jedi"
        },
        {
            description="Você pode reroll verificações de persuasão feitas para intimidar e manter o melhor resultado",
            tree="Caçador de recompensas",
            name="Notório"
        },
        {
            description="Os oponentes dentro de 6 quadrados de um nível igual ou inferior recebem uma penalidade -1 em ataques contra você",
            tree="Caçador de recompensas",
            name="Temível"
        },
        {
            description="Você pode reroll cheques Persuasão feitas para regatear o preço de uma recompensa e manter o melhor resultado",
            tree="Caçador de recompensas",
            name="Negociador Impiedoso"
        },
        {
            description="Você pode reroll e reunir verificações de informação para localizar um indivíduo específico, mas deve manter o resultado do reroll",
            tree="Caçador de recompensas",
            name="Nenhum lugar para esconder"
        },
        {
            description="w / sucesso grab pode ligar o alvo a você ou objeto adjacente, você & alvo -2 Ref Def enquanto juntos",
            tree="Caçador de recompensas",
            name="Algemas Rápidas"
        },
        {
            description="Ganhe um bônus de moral +2 em verificações de habilidades opostas enquanto estiver na posse de uma arma de assinatura, armadura, veículo, nave estelar ou outro item. Este bônus aumenta em 1 para cada item de assinatura adicional.\n\n(Entrar número de vezes tomadas)",
            tree="Caçador de recompensas",
            name="Rubrica da assinatura"
        },
        {
            description="Você é especialmente difícil de detectar na Força",
            tree="Forçar o Caçador",
            name="Forçar em Branco"
        },
        {
            description="Quando um inimigo sente sua falta com um sabre de luz, mova 2 quadrados como uma reação",
            tree="Forçar o Caçador",
            name="Evasão de sabre de luz"
        },
        {
            description="Aumentar a dificuldade de Defletir tentativas contra seus tiros em +5",
            tree="Forçar o Caçador",
            name="Fogo de Precisão"
        },
        {
            description="Se você resistir com sucesso a um poder de força que afeta a mente, você está imune a ele pelo resto do encontro",
            tree="Forçar o Caçador",
            name="Mente de aço"
        },
        {
            description="Você adiciona seu nível de classe à sua defesa de vontade contra truque mental",
            tree="Forçar o Caçador",
            name="De Vontade Forte"
        },
        {
            description="Sempre que você é alvo de um poder de força que o move você só move metade da distância",
            tree="Forçar o Caçador",
            name="Resistência telequenética"
        },
        {
            description="Uma vez por dia, você gasta 10 minutos realizando rituais para melhorar sua conexão com a Força. Gasta quantos pontos de força quiseres. Durante o dia, você pode reroll Percepção, Stealth e rolos de ataque, mas levar o novo resultado até pontos de força gastos.",
            tree="Gand Findsman",
            name="Cerimônias do Localizador"
        },
        {
            description="Quando você fizer uma verificação de percepção para evitar surpresa, jogue dois dados e mantenha o melhor resultado.",
            tree="Gand Findsman",
            name="Previsão do Achado"
        },
        {
            description="Sempre que um aliado dentro de 10 quadrados rola um natural 1 ou 20, até o final da próxima vez, você ganha um bônus +2 insight para seu próximo rolo de ataque ou sua Defesa Reflexa.",
            tree="Gand Findsman",
            name="Presságio"
        },
        {
            description="Uma vez por encontro, quando uma criatura inimiga se move dentro de 6 quadrados de você, você pode fazer um ataque descontrolado ou variou contra o alvo como uma reação ao seu movimento.",
            tree="Gand Findsman",
            name="Visões- Alvo"
        },
        {
            description="Uma vez por encontro, como uma reação ao ataque de um inimigo, você pode avançar até a sua velocidade.",
            tree="Gand Findsman",
            name="Consciência temporal"
        },
        {
            description="Quando você fintar com sucesso em combate, você pode imediatamente mover-se para metade da sua velocidade",
            tree="Trapaça",
            name="Distração Curiosamente"
        },
        {
            description="Como uma ação padrão, você pode fazer uma verificação Decepção contra Will Defesa de qualquer alvo dentro da linha de visão que possa ouvir, ver e entender você. Se bem sucedido, o próximo ataque feito por um de seus aliados contra esse alvo oferece 2 dados de dano extra",
            tree="Trapaça",
            name="Daming Deception"
        },
        {
            description="Uma vez por encontro como uma reação você pode fazer uma verificação Decepção para substituir a pontuação Defesa de seu aliado por seu cheque",
            tree="Trapaça",
            name="Gritar Distraindo"
        },
        {
            description="Como uma ação rápida, você pode fazer uma verificação de engano contra um inimigo dentro de 6 quadrados e linha de visão contra sua defesa de vontade para dar-lhe uma -5 penalidade para todos os ataques feitos contra você até o início de sua próxima volta",
            tree="Trapaça",
            name="Inócuo"
        },
        {
            description="Enquanto você ocupa um sqare adjacente a outra criatura, você pode usar uma ação rápida para ganhar um bônus de cobertura +2 para Defesa de Reflexos até o início de sua próxima volta ou até que você não esteja mais adjacente, o que vier primeiro",
            tree="Trapaça",
            name="Capa Macia Melhorada"
        },
        {
            description="Sempre que você é atacado em combate e adjacente a uma criatura diferente de seu atacante, você pode mover 1 quadrado como uma reação que provoca. O atacante bate na criatura adjacente.",
            tree="Trapaça",
            name="Trecherous"
        },
        {
            description="Rebole qualquer habilidade baseada em Sabedoria, Inteligência ou Carisma (exceto Use a Força) uma vez por encontro",
            tree="Poder Corporativo",
            name="Condução Competitiva"
        },
        {
            description="Você e um número de aliados iguais ao seu modificador Carisma ganham Quick Draw para o encontro se você não estiver surpreso",
            tree="Poder Corporativo",
            name="Contorno Competitivo"
        },
        {
            description="Como uma ação padrão, faça uma verificação de Persuasão contra a Defesa de Vontade de todos os alvos em um cone 6-quadrado para negar-lhes uma ação rápida ou qualquer ação completa",
            tree="Poder Corporativo",
            name="Impor Hesitação"
        },
        {
            description="Impor Hesitação cobre um cone de 12 quadrados, e uma vez por encontro os alvos são negados sua ação padrão",
            tree="Poder Corporativo",
            name="Impor Confusão"
        },
        {
            description="Uma vez por encontro, faça uma verificação de Persuasão contra a Defesa de Vontade de um alvo dentro da linha de visão para impedi-los de atacá-lo, ou retirar-se se você exceder por 5, ou juntar-se a você se exceder por 10",
            tree="Poder Corporativo",
            name="Clout corporativo"
        },
        {
            description="Uma vez por encontro, negue um rolo de ataque ou verificação de habilidade contra você que visa sua defesa de vontade",
            tree="Poder Corporativo",
            name="Resolução voluntária"
        },
        {
            description="Inimigos que o atacam levam uma penalidade -2 para Defesa de Vontade até sua próxima vez",
            tree="Poder Corporativo",
            name="Decisão errada"
        },
        {
            description="Os oponentes de nível igual ou inferior a você tomar -1 para atacar rolos, verificações de habilidade opostas e Use as verificações de força para ativar poderes de força contra você",
            tree="Infâmia",
            name="Inspire o medo"
        },
        {
            description="Uma vez por encontro, designe um lacaio como uma ação livre para espalhar o medo entre seus inimigos. Em qualquer ponto antes do fim do encontro, você pode ativar esta capacidade de forçar todos os inimigos adjacentes ao minion para mover 1 quadrado para longe (não povoke).",
            tree="Infâmia",
            name="Assustador"
        },
        {
            description="Oponentes de nível igual ou inferior a você tomar -2 para atacar rolos, verificações de habilidade opostas e Use as verificações de força para ativar poderes de força contra você",
            tree="Infâmia",
            name="Inspire o medo II"
        },
        {
            description="Uma vez por encontro como uma reação a um de seus asseclas sendo movido para baixo a trilha da condição, você pode reduzir o número de passos em 1, e o alvo ganha pontos de sucesso iguais ao seu nível heróico.",
            tree="Infâmia",
            name="Medo"
        },
        {
            description="Oponentes de nível igual ou inferior a você tomar -5 para atacar rolos, verificações de habilidades opostas e Use as verificações de Força para ativar poderes de força contra você",
            tree="Infâmia",
            name="Inspire o Medo III"
        },
        {
            description="Como uma ação padrão, faça uma verificação de persuasão contra a defesa de vontade de um alvo. Se bem sucedido, na próxima volta do alvo, eles devem usar sua ação de movimento para se afastar de você. Se não puder, a penalidade do Medo Inspirado duplica até o início da próxima volta.",
            tree="Infâmia",
            name="Terrificante"
        },
        {
            description="Os seus lacaios podem refazer os controlos de persuasão feitos para intimidar, mas devem manter o resultado do reroll",
            tree="Infâmia",
            name="Notoriedade Partilhada"
        },
        {
            description="Qualquer oponente que seja reduzido a meio ponto ou menos dentro de 6 quadrados de você leva uma penalidade -2 em todos os rolos de ataque e verificações de habilidade para a duração do encontro.",
            tree="Infâmia",
            name="Reputação Insavory"
        },
        {
            description="Você ganha um minion não-heroico de três quartos de seu nível de caráter, arredondado para baixo.\n\n(Entrar número de vezes tomadas)",
            tree="Mastermind",
            name="Atrair o Minion"
        },
        {
            description="Sempre que você está adjacente a um minion, você ganha um bônus de cobertura +2 para sua defesa Reflex",
            tree="Mastermind",
            name="Abrigo"
        },
        {
            description="Sempre que um de seus servos é morto, ele ou ela é substituído por outro lacaio do mesmo nível. Esta substituição ocorre 24 horas depois.",
            tree="Mastermind",
            name="Riqueza dos Aliados"
        },
        {
            description="Sempre que você está adjacente a um minion ganho com o talento Attract Minion, uma vez por turno como uma reação a ser atacado, você pode redirecionar o ataque contra o minion.",
            tree="Mastermind",
            name="Guarda-costas I"
        },
        {
            description="Quando você redireciona um ataque para um minion usando o talento Bodyguard I, que a pontuação de defesa relevante do minion ganha um bônus igual a metade do seu nível de classe.",
            tree="Mastermind",
            name="Guarda-costas II"
        },
        {
            description="Quando você redireciona um ataque para um minion usando o talento Bodyguard I, esse minion pode fazer um ataque imediato ou variou ataque contra o seu atacante. Além disso, o bônus fornecido pelo Bodyguard II aumenta para o seu nível de classe.",
            tree="Mastermind",
            name="Guarda-costas III"
        },
        {
            description="1/enc mova sua velocidade quando você falhar em um ataque, habilidade ou verificação oposta",
            tree="Mastermind",
            name="Plano de contingência"
        },
        {
            description="Conceda a um aliado a oportunidade de mover sua velocidade normal imediatamente, ativada como uma ação rápida",
            tree="Mastermind",
            name="Impel Ally I"
        },
        {
            description="Dar a um aliado a chance de tomar uma ação ou movimento padrão imediatamente, ativado como uma ação rápida",
            tree="Mastermind",
            name="Impel Ally II"
        },
        {
            description="Uma vez por encontro você pode gastar três ações rápidas em turnos consecutivos para conceder a um aliado a capacidade de tomar uma ação padrão e uma ação de movimento. O aliado deve agir imediatamente na sua vez quando a ação rápida final é gasta.",
            tree="Mastermind",
            name="Impel Ally III"
        },
        {
            description="Uma vez por encontro, você pode gastar três ações rápidas em voltas consecutivas para aumentar a velocidade de todos os aliados dentro da linha de visão por 2. A velocidade dura até o início da próxima volta após a terceira ação rápida ser gasta.",
            tree="Mastermind",
            name="Urgência"
        },
        {
            description="Quando um aliado usa uma ação concedida a ele ou ela por você, o aliado pode refazer qualquer ataque ou verificação feita durante essa ação, tomando o melhor resultado.",
            tree="Mastermind",
            name="Ordens de Mestre"
        },
        {
            description="Como uma ação padrão, designe um alvo para ser objeto da ira de seus aliados. Enquanto seus aliados têm linha de visão e você está consciente, eles ganham um bônus de moral +2 em rolos de ataque e verificações de habilidades feitas contra o alvo.",
            tree="Mastermind",
            name="Inspire a ira"
        },
        {
            description="Gastar duas ações rápidas para selecionar dois aliados. Cada aliado pode mover 2 quadrados como uma reação sem provocar ataques de oportunidade.",
            tree="Mastermind",
            name="Superioridade Tática"
        },
        {
            description="Gastar duas ações rápidas para conceder todos os aliados na linha de visão e 6 quadrados de você para usar a ação retirada como uma ação rápida. Isto dura até ao início da próxima volta",
            tree="Mastermind",
            name="Retirada Tática"
        },
        {
            description="Como uma ação rápida, você pode fazer uma verificação DC 15 Conhecimento (táticas). Se bem sucedido, todos os aliados dróides capazes de ouvir e entender você ganha os benefícios da façanha Double Attack para um grupo de armas até o fim de sua próxima volta.",
            tree="Comandante Dróide",
            name="Ataque automatizado"
        },
        {
            description="Como uma ação padrão, você pode transmitir informações táticas para todos os aliados dróides que podem ouvi-lo e compreendê-lo, concedendo-lhes um bônus igual ao seu modificador de inteligência para uma de suas defesas (sua escolha) até o início de sua próxima vez.",
            tree="Comandante Dróide",
            name="Defesa Dróide"
        },
        {
            description="Como uma ação rápida uma vez por turno, você pode designar um único aliado dróide dentro de sua linha de visão. Esse aliado dróide ganha pontos bônus iguais a 10 + seu nível de classe.",
            tree="Comandante Dróide",
            name="Droid Mettle"
        },
        {
            description="Você empurra os limites dos dróides sob seu comando. Você pode gastar uma ação rápida uma vez por turno para permitir que cada um de seus aliados trabalhados em rede (veja o recurso de classe Mente Rededa abaixo) para mover imediatamente até a sua velocidade.",
            tree="Comandante Dróide",
            name="Tropas overclockadas"
        },
        {
            description="Quando você usa uma habilidade que concede a um aliado dróide um bônus moral ou insight, aumente o valor desse bônus em 1.",
            tree="Comandante Dróide",
            name="Comandos Reforçados"
        },
        {
            description="Se você ou qualquer um de seus aliados dróides tem linha de visão para e está ciente de um alvo, todos os aliados dróides que podem ouvir e entender você também é considerado ter linha de visão (mas não necessariamente linha de efeito) para esse alvo.",
            tree="Comandante Dróide",
            name="Sensores expandidos"
        },
        {
            description="Como uma ação rápida uma vez por turno, você pode conceder um aliado dróide dentro de sua linha de visão um bônus de competência em seu próximo rolo de ataque feito antes do início de sua próxima volta igual a metade de seu nível de classe.",
            tree="Comandante Dróide",
            name="Inspirar a Competência"
        },
        {
            description="Como uma ação rápida uma vez por turno, você pode conceder a todos os aliados dróides dentro de sua linha de visão a capacidade de tomar a ação Recuperar como duas ações rápidas (em vez de três ações rápidas) até o início de sua próxima volta.",
            tree="Comandante Dróide",
            name="Manter o Foco"
        },
        {
            description="Como uma ação padrão, você permite que um dróide que pode ouvir e entender você para fazer uma Decepção, Mecânica, Persuasão, Piloto, Passeio, Tratar Lesão, ou Usar Computador verificar imediatamente como uma ação livre. O dróide pode substituir seu modificador de pontuação de habilidade relevante para esse check com seu modificador Intelligence.",
            tree="Substituir",
            name="Acção Dirigida"
        },
        {
            description="Como uma ação completa, você permite que um dróide que pode ouvir e entender você para tomar a ação de ataque completo. O dróide pode substituir seu modificador de pontuação de habilidade relevante para qualquer rolo de ataque que ele faz com seu modificador de inteligência. Pré-requisitos: Ação Dirigida, Movimento Dirigido e Ataque Remoto.",
            tree="Substituir",
            name="Controlo total"
        },
        {
            description="Como uma ação de movimento, você permite que um dróide que pode ouvir e entender você para mover-se até sua velocidade. O dróide pode fazer verificações Acrobatics, Escalar, Saltar, Stealth ou Swim durante este movimento, e pode substituir seu próprio modificador de pontuação de habilidade relevante para esse check com seu modificador Intelligence.",
            tree="Substituir",
            name="Movimento Dirigido"
        },
        {
            description="Como uma ação padrão, você permite que um dróide que pode ouvi-lo e compreendê-lo para fazer um ataque ou variar. O dróide pode substituir seu modificador de pontuação de habilidade relevante para seu rolo de ataque por seu modificador de inteligência.",
            tree="Substituir",
            name="Ataque Remoto"
        },
        {
            description="Aumente o alcance crítico de armas pesadas em 1",
            tree="Mestre Crítico",
            name="Alcance crítico estendido (armas pesadas)"
        },
        {
            description="Aumente a gama crítica de rifles em 1",
            tree="Mestre Crítico",
            name="Intervalo Crítico Estendido (rifles)"
        },
        {
            description="alcance de hematócrito da arma estendido por 1",
            tree="Mestre Crítico",
            name="Alcance crítico estendido (armas simples)"
        },
        {
            description="Ao marcar um golpe crítico, faça um ataque extra contra um único alvo dentro do alcance\n\n(Entrar número de vezes tomadas)",
            tree="Mestre Crítico",
            name="Ataque Flurry"
        },
        {
            description="Ao marcar um golpe crítico contra um alvo até dois tamanhos maiores do que você, você pode movê-los um quadrado em qualquer direção",
            tree="Mestre Crítico",
            name="Knockback"
        },
        {
            description="Ao marcar um ataque crítico com um ataque descontrolado ou variado, você inflige uma penalidade -2 para a defesa reflexa do alvo até que eles recuperem pontos de ataque completos",
            tree="Mestre Crítico",
            name="Reduzir a Defesa"
        },
        {
            description="Ao marcar um hit crítico com um melee ou ataque variado, você metade da velocidade do seu alvo até que eles recuperar pontos de hit completo",
            tree="Mestre Crítico",
            name="Reduzir a Mobilidade"
        },
        {
            description="Ao marcar um ataque crítico com um choque ou ataque variado, você imobiliza seu alvo para sua próxima volta",
            tree="Mestre Crítico",
            name="Negar a jogada"
        },
        {
            description="Uma vez por encontro, mova sua velocidade como uma ação livre antes de qualquer outra ação em sua vez",
            tree="Guerreiro Mandaloriano",
            name="Avanço Mandaloriano"
        },
        {
            description="Uma vez por encontro, ao fazer mais de um ataque em uma rodada, adicione um dano morre a cada sucesso\n\n(Entrar número de vezes tomadas, selecionar arma à direita)",
            tree="Guerreiro Mandaloriano",
            name="Ferocidade Mandaloriana"
        },
        {
            description="Uma vez por encontro, ao reduzir os pontos de um adversário para 0, ganhe +5 para o seu próximo ataque durante o mesmo encontro",
            tree="Guerreiro Mandaloriano",
            name="Glória Mandaloriana"
        },
        {
            description="Adicione seu bônus de defesa de fortaleza da armadura ao seu Elite Trooper DR, que não é ignorado pelos sabres de luz dado que você está usando materiais resistentes ao sabre de luz",
            tree="Guerreiro Mandaloriano",
            name="Mandaloriano blindado"
        },
        {
            description="Lidar com uma morte extra de danos com ataques desarmados",
            tree="Mestre de Teräs Käsi",
            name="Teräs Käsi Basics"
        },
        {
            description="Ignorar completamente o DR se o seu ataque desarmado exceder o DR",
            tree="Mestre de Teräs Käsi",
            name="Ignorar a Redução de Danos"
        },
        {
            description="Tome uma ação de ataque desarmada como uma ação padrão",
            tree="Mestre de Teräs Käsi",
            name="Teräs Käsi Mastery"
        },
        {
            description="Como uma reação enquanto luta defensivamente, negue ataques melee chegando com um rolo de ataque desarmado oposto, com um acumulado -2 para todos os rolos de ataque feitos desde o início de sua última vez",
            tree="Mestre de Teräs Käsi",
            name="Parry Desarmado"
        },
        {
            description="Após o sucesso em Desarmado Parry, imediatamente fazer um ataque desarmado como uma reação contra o atacante",
            tree="Mestre de Teräs Käsi",
            name="Contra- Ataque Desarmado"
        },
        {
            description="Quando você fizer um ataque com uma arma do grupo escolhido e o rolo de ataque exceder a Defesa Reflexa do alvo em 5 ou mais, você lida com +1 morte de dano com o ataque.\n\n(Tempos de entrada)",
            tree="Especialista em Melee",
            name="Golpe Acurado"
        },
        {
            description="Sempre que você ocupa o mesmo quadrado que o seu alvo ou são adjacentes ao seu alvo, você ganha um +1 bônus circunstância para seus rolos de ataque contra esse alvo.",
            tree="Especialista em Melee",
            name="Lutador de Quarters Próximos"
        },
        {
            description="Uma vez por encontro, quando você faz um ataque insolente, você pode ignorar qualquer bônus de armadura ou equipamento concedido pela armadura do seu alvo.",
            tree="Especialista em Melee",
            name="Ignorar armadura"
        },
        {
            description="Quando você danificar um oponente com um ataque melee que move o alvo para baixo a pista condição, o alvo não pode tomar qualquer ação que exija uma ação padrão ou full-round no seu próximo turno.",
            tree="Especialista em Melee",
            name="Greve impressionante melhorada"
        },
        {
            description="Rodas a arma à tua volta num borrão, criando um círculo de morte à tua volta. Qualquer alvo inimigo que começa a sua vez adjacente a você leva dano igual ao seu bônus de Força. Deve estar a usar uma arma para usar este talento.",
            tree="Especialista em Melee",
            name="Morte de Contorno"
        },
        {
            description="Uma vez por turno tomar alguns ou todos os danos contra um aliado adjacente",
            tree="Protecção",
            name="Sacrifício do guarda-costas"
        },
        {
            description="1/ encontro como reacção mova- se até à sua velocidade e cause danos em vez de um aliado",
            tree="Protecção",
            name="Salva-vidas"
        },
        {
            description="Permitir que um aliado entre 6 quadrados para mover para o seu lado como uma ação de movimento",
            tree="Protecção",
            name="Fora do caminho do dano"
        },
        {
            description="Sempre que sofrer danos por um aliado, o seu limiar de danos é 5 mais elevado.",
            tree="Protecção",
            name="Aceite o golpe"
        },
        {
            description="Sempre que você sofre danos por um aliado, você ganha DR igual ao seu nível até o final da sua próxima volta",
            tree="Protecção",
            name="Role com ele"
        },
        {
            description="Aliado designado trata sua proximidade como capa macia",
            tree="Protecção",
            name="Ward"
        },
        {
            description="Bónus de cobertura de Ward para Defesa de Reflexos é aumentado em metade do seu bônus armadura",
            tree="Protecção",
            name="Guarda blindado"
        },
        {
            description="Cada rodada que você começa adjacente à sua ala você ganha seu nível de caráter em pontos de bônus",
            tree="Protecção",
            name="Entrada da Guarda"
        },
        {
            description="Uma vez por encontro, você pode optar por lidar com +1 morrer de dano com uma única granada ou outro explosivo.",
            tree="Comando Republicano",
            name="Rendimento Superior"
        },
        {
            description="Você pode recuperar uma célula de energia armazenada e recarregar sua arma como uma única ação rápida.",
            tree="Comando Republicano",
            name="Recarregar rapidamente"
        },
        {
            description="Sempre que você começa sua vez adjacente a um aliado, você ganha um número de pontos de bônus iguais ao seu nível heróico.",
            tree="Comando Republicano",
            name="Ombro para ombro"
        },
        {
            description="Se você estiver dentro de 10 quadrados de um aliado, você pode adicionar +2 à sua DR.",
            tree="Comando Republicano",
            name="Dosagem em Números"
        },
        {
            description="Se você usar uma arma variada como amelee arma (como com o talento Gun Club), você ganha um bônus +2 para melee ataque rola com essa arma.",
            tree="Comando Republicano",
            name="Mudança de Arma"
        },
        {
            description="Como uma ação de movimento, você pode habilitar cada membro do seu esquadrão a mover imediatamente dois quadrados. Este movimento não provoca um ataque de oportunidade. Pré-requisito: Carisma 13.",
            tree="Líder de Esquadrão",
            name="Recuar"
        },
        {
            description="Como uma ação de movimento, você dá a todos os membros do esquadrão um bônus de moral +2 para sua Defesa Reflex até o fim de sua próxima vez, desde que eles estejam dentro de 6 quadrados de outro membro do esquadrão. Pré-requisitos: Carisma 13.",
            tree="Líder de Esquadrão",
            name="Formar para cima"
        },
        {
            description="Como uma ação de movimento, você dá a todos os membros do pelotão +2 bônus de moral para rolos de danos até o final de sua próxima vez. Pré-requisito: Carisma 13.",
            tree="Líder de Esquadrão",
            name="Avanço total"
        },
        {
            description="Uma vez por encontro, como uma ação padrão. Você move todos os membros do seu esquadrão +1 passo na pista condição. Pré-requisito: Carisma 13.",
            tree="Líder de Esquadrão",
            name="Segure firme"
        },
        {
            description="Como uma ação de movimento. Você dá a todos os membros do pelotão um bônus de moral +2 para a Percepção cheques até o final da sua próxima vez. Pré-requisito: Carisma 13.",
            tree="Líder de Esquadrão",
            name="Procurar e Destruir"
        },
        {
            description="Autofire e Burst As penalidades de ataque são reduzidas para -2, e autofire preparado não tem penalidade para o seu rolo de ataque",
            tree="Mestre de Armas",
            name="Explosão controlada"
        },
        {
            description="Uma vez por encontro. ao fazer um ataque de autogiro, você pode tratar o ataque como um cone de 6 quadrados. Fazer este ataque consome 20 tiros do pacote de energia da arma. Pré-requisitos: Bônus de ataque base +12, Burst controlado.",
            tree="Mestre de Armas",
            name="Agressão feroz"
        },
        {
            description="Você é proficiente com qualquer arma exótica.",
            tree="Mestre de Armas",
            name="Mestre em Armas Exóticas"
        },
        {
            description="ameaçar todos os quadrados w/in 2sq raio w/arma ranged elegível para Atk of Opp",
            tree="Mestre de Armas",
            name="Ameaça Prolongada"
        },
        {
            description="+1 bônus para atacar rolos\n\n(Enter número de vezes tomadas, escolha qual arma na aba Talentos 2)",
            tree="Mestre de Armas",
            name="Maior Foco na Arma"
        },
        {
            description="Trate seus oponentes limiar de dano como se fosse 10 pontos mais baixo quando você faz um ataque bem sucedido\n\n(Enter número de vezes tomadas, escolha qual arma na aba Talentos 2)",
            tree="Mestre de Armas",
            name="Ataque devastador"
        },
        {
            description="Trate seus adversários redução de danos como se fosse 10 pontos mais baixo quando você faz um ataque bem sucedido\n\n(Enter número de vezes tomadas, escolha qual arma na aba Talentos 2)",
            tree="Mestre de Armas",
            name="Ataque de Penetração Maior"
        },
        {
            description="+2 bônus para danos\n\n(Enter número de vezes tomadas, escolha qual arma na aba Talentos 2)",
            tree="Mestre de Armas",
            name="Especialização da Arma Maior"
        },
        {
            description="Reduza a penalidade aos rolos de ataque ao fazer múltiplos ataques com armas pesadas em 2\n\n(Entrar número de vezes tomadas)",
            tree="Mestre de Armas",
            name="Proficiência de múltiplos ataques (armas pesadas)"
        },
        {
            description="Reduzir penalização para rolos de ataque ao fazer vários ataques com rifles em 2\n\n(Entrar número de vezes tomadas)",
            tree="Mestre de Armas",
            name="Proficiência de múltiplos ataques (rifles)"
        },
        {
            description="reduzir a penalidade de Atk em 2",
            tree="Mestre de Armas",
            name="Proficiência de múltiplos ataques (armas simples)"
        },
        {
            description="lançar 2 armas no mesmo inimigo ou alvo sq w/uma mão, atks separados -10 & armas devem ser semelhantes, intervalo = 8sq",
            tree="Mestre de Armas",
            name="Dois por um lançamento"
        },
        {
            description="Prepare uma arma de fogo automático com uma única ação rápida",
            tree="Execução",
            name="Braçagem da Capa"
        },
        {
            description="Seu veículo leva metade do dano quando você bateu com sucesso outro veículo, e que o veículo é imobilizado para uma rodada",
            tree="Execução",
            name="Acidente intencional"
        },
        {
            description="Ganhe +1 para atacar e lidar +1 morrer de danos com armas de choque",
            tree="Execução",
            name="Táticas não letais"
        },
        {
            description="Você pode rerolar verificações Endurance e manter o melhor resultado ao correr, e pode não correr em linha reta",
            tree="Execução",
            name="Perseguição"
        },
        {
            description="Caracteres indiferentes são amigáveis para você sem verificação necessária",
            tree="Execução",
            name="Oficial Respeitado"
        },
        {
            description="Quando você move um alvo para baixo da pista de condição com um ataque, sua velocidade é reduzida para metade até que tenha removido todas as condições",
            tree="Execução",
            name="Diminuindo o Stun"
        },
        {
            description="Ao lidar com danos no final de uma carga, seu alvo é derrubado propenso",
            tree="Execução",
            name="Derrubar"
        },
        {
            description="monte compartilha um link empático, quando você monta seu monte tem seu Ref & Will Def, você ganha sentidos",
            tree="Beastwarden",
            name="Montagem Ligada"
        },
        {
            description="Use a Força v. Will Def da besta indiferente ou melhor para executar uma tarefa menor dentro de 30 sq, veja J18",
            tree="Beastwarden",
            name="Entreat Beast"
        },
        {
            description="mudar besta hostil para indiferente automaticamente",
            tree="Beastwarden",
            name="Presença calmante"
        },
        {
            description="1/turn mente toque de besta indiferente ou melhor w/in 12 sq & LOS, Percepção da besta & LOS é seu",
            tree="Beastwarden",
            name="Senso selvagem"
        },
        {
            description="Passe um ponto de força como uma ação gratuita para lidar com 1d6 por nível de classe danos extras a um alvo negou seu bônus de Dexterity para Defesa de Reflexos ou ser flanqueado",
            tree="Devotee Lado Escuro",
            name="Agressão do Canal"
        },
        {
            description="Passe um ponto de força como uma ação rápida para ganhar um bônus +2 para melee ataque e rolos de danos para uma série de rodadas iguais a 5 + seu modífero Constituição, em seguida, mova -1 passo ao longo da pista condição",
            tree="Devotee Lado Escuro",
            name="Raiva de Canal"
        },
        {
            description="Você pode rerolar Use as verificações da Força para ativar poderes do lado escuro da Força, mas deve manter o resultado da rerolagem, e não pode mais usar poderes do lado claro da Força",
            tree="Devotee Lado Escuro",
            name="Abrace o Lado Negro"
        },
        {
            description="Ao marcar um hit crítico, você pode gastar um ponto de força para reduzir para metade a velocidade dos alvos até totalmente curado",
            tree="Devotee Lado Escuro",
            name="Greve paralisante"
        },
        {
            description="+2 em uma defesa contra poderes de luz",
            tree="Devotee Lado Escuro",
            name="Talismã Lado Negro"
        },
        {
            description="+2 em todas as defesas contra os poderes de luz",
            tree="Devotee Lado Escuro",
            name="Talismã Lado Negro Maior"
        },
        {
            description="Você pode reroll Use as verificações da Força para ativar um determinado Poder de Força gastando um Ponto de Força e mantendo o melhor resultado\n\n(Entrar número de vezes tomadas)",
            tree="Forçar o Adepto",
            name="Forçar o Adepto de Potência"
        },
        {
            description="Trate as verificações de lesão podem ser feitas com Use a Força, e Trate a lesão é considerado uma habilidade treinada, e você pode administrar primeiros socorros, tratar doenças, tratar veneno e tratar radiação sem um kit médico ou medpac",
            tree="Forçar o Adepto",
            name="Tratamento de Força"
        },
        {
            description="Você é imune a doenças, veneno e radiação",
            tree="Forçar o Adepto",
            name="Corpo Fortificado"
        },
        {
            description="quando pesquisar com sucesso seus sentimentos ganhar FP e usar antes do fim do enc, se usar w / ganho desfavorável Lado Sombrio Point, se usar & ganhar Lado Sombrio Point ganhar 2 pontos",
            tree="Forçar o Adepto",
            name="Instrumento da Força"
        },
        {
            description="DC30 UtF para 1 benefício como decidido pelo GM: 1. Força de volta, 2. 1 FP para uso antes do fim do enc, 3. +1 uso de Força-relacionado talento ou façanha, 4. rolo +1 morrer w / força verificação & selecionar mais alto morrer laminado",
            tree="Forçar o Adepto",
            name="Ligação Mística"
        },
        {
            description="Gaste um ponto de força para ganhar um bônus +1 para atacar rolos com uma arma melee, ativado como uma ação completa",
            tree="Forçar Item",
            name="Arma Atual"
        },
        {
            description="Gaste um ponto de força para ganhar uma morte +1 de dano com uma arma, ativada como uma ação completa",
            tree="Forçar Item",
            name="Empoderar a Arma"
        },
        {
            description="Você pode lançar uma arma simples ou avançada como uma ação padrão, que pode tornar-se incorporado no alvo se ele lida com danos perfurantes ou cortantes",
            tree="Forçar Item",
            name="Forçar o lançamento"
        },
        {
            description="Faça uma verificação Use a Força como uma reação para negar um ataque melee rolar contra você, ou fornecer-lhe cobertura contra Whirlwind Ataque, com uma penalidade cumulativa de -5 cada vez que Primitive Block tem sido usado desde sua última vez",
            tree="Forçar Item",
            name="Bloco Primitivo"
        },
        {
            description="Gaste um ponto de força para ganhar um bônus +1 para uma de suas defesas enquanto usa ou carrega um talismã, ativado como uma ação completa",
            tree="Forçar Item",
            name="Forçar Talismã"
        },
        {
            description="Quando você cria um talismã Force, você pode selecionar um único poder Force de sua suíte Force. Sempre que você estiver usando este talismã e ativar o poder de Força selecionado, você pode gastar um Ponto de Força para recuperar imediatamente esse poder gasto.",
            tree="Forçar Item",
            name="Talismã de Força Focado"
        },
        {
            description="Como o Talismã de Força Focada (ver acima), exceto que um Ponto de Força gasto para recuperar imediatamente o poder selecionado não conta contra a restrição \"um por tum\" em gastar Pontos de Força.",
            tree="Forçar Item",
            name="Talismã de maior concentração"
        },
        {
            description="Seu talismã de força oferece um bônus +1 para todas as suas defesas",
            tree="Forçar Item",
            name="Talismã de Maior Força"
        },
        {
            description="Ao lidar com danos a um alvo com um poder de força, faça uma verificação de persuasão para intimidar como uma ação livre",
            tree="Inquisidor Imperial",
            name="Forçar o Interrogatório"
        },
        {
            description="Verificações de persuasão para intimidar podem ser feitas contra todos os alvos dentro de um cone 6-quadrado",
            tree="Inquisidor Imperial",
            name="Inimigos Cower"
        },
        {
            description="Passe um ponto de força para fazer uma verificação Use a força contra a defesa de vontade de todas as criaturas dentro de 6 quadrados para infligir uma penalidade -2 para atacar rolos e verificações de habilidade para o resto do encontro",
            tree="Inquisidor Imperial",
            name="Presença inquietante"
        },
        {
            description="Ganhe +1 para atacar rolos e lidar com +1 morrer de danos contra alvos com Sensibilidade à Força",
            tree="Inquisidor Imperial",
            name="Inquisição"
        },
        {
            description="Mover -1 descer a pista para ganhar 1 ponto de força até o fim da sua vez",
            tree="Místico",
            name="Vitalidade do Canal"
        },
        {
            description="Efeitos que afetam a mente devem ser enrolados duas vezes contra você tendo o resultado mais baixo",
            tree="Místico",
            name="Mente Fechada"
        },
        {
            description="Quando você gasta um Ponto de Força para ativar uma técnica ou segredo você ganha hp igual a 10 + seu nível de classe",
            tree="Místico",
            name="Técnica Esotérica"
        },
        {
            description="Quando você ganha um nível você recebe pontos de força bônus iguais a um número de Talentos de força (6 máx)",
            tree="Místico",
            name="Mística Mestria"
        },
        {
            description="+5 bônus em verificações de habilidades feitas para executar um Regime de Força",
            tree="Místico",
            name="Domínio do Regime"
        },
        {
            description="Ao tocar uma criatura com uma inteligência de 3 ou mais, você pode fazer uma verificação Use a Força versus sua Defesa de Vontade para usar Recolher informações em um alvo relutante",
            tree="Telepata",
            name="Sonda Mental"
        },
        {
            description="Você pode se comunicar em frases completas e pensamentos completos, sem mudar de assunto",
            tree="Telepata",
            name="Telepatia Perfeita"
        },
        {
            description="Você ganha um bônus para o seu Will Defefense igual ao seu nível de classe",
            tree="Telepata",
            name="Cidadela Psíquica"
        },
        {
            description="Quando você é alvo de poderes que afetam a mente, seu oponente automaticamente leva 1d6 danos",
            tree="Telepata",
            name="Defesas psíquicas"
        },
        {
            description="",
            tree="Telepata",
            name="Intrusor Telepático"
        },
        {
            description="Ao lidar com danos que excedem o limiar de dano de um oponente, lidar com uma morte adicional de danos\n\n(Entrar número de vezes tomadas, selecionar arma à direita)",
            tree="Combate Gladiatorial",
            name="Ataque brutal"
        },
        {
            description="Se um ataque que causa danos a um alvo também exceder a sua Defesa de Vontade, eles levam uma penalidade -2 para a Defesa Reflexa até sua próxima vez",
            tree="Combate Gladiatorial",
            name="Ataque Distrativo"
        },
        {
            description="Quaisquer feitos ou talentos que afetem qualquer arma exótica afetam todas as armas exóticas",
            tree="Combate Gladiatorial",
            name="Mestre em Armas Exóticas"
        },
        {
            description="Reduza a penalidade aos rolos de ataque ao fazer vários ataques com armas exóticas em 2\n\n(Entrar número de vezes tomadas)",
            tree="Combate Gladiatorial",
            name="Proficiência de múltiplos ataques (armas exóticas)"
        },
        {
            description="Se você bater com um ataque de oportunidade, o movimento do alvo termina instantaneamente",
            tree="Combate Gladiatorial",
            name="Bloquear greve"
        },
        {
            description="Como uma ação rápida, provocar todos os inimigos dentro da linha de visão e 12 quadrados para dar-lhes uma penalidade -2 para atacar rolos contra qualquer alvo diferente de você",
            tree="Combate Gladiatorial",
            name="Vendetta pessoal"
        },
        {
            description="Um alvo de Personal Vendetta recebe uma penalidade -5 ao atacar alvos diferentes de você",
            tree="Combate Gladiatorial",
            name="Chamar"
        },
        {
            description="Uma vez por encontro, reduza o número de passos que você é derrubado pela trilha de condição por um",
            tree="Combate Gladiatorial",
            name="Imparável"
        },
        {
            description="Quando você exceder o limiar de um inimigo com rifle, empurre o alvo 1 quadrado de distância",
            tree="Carbineer",
            name="Retorno"
        },
        {
            description="Ponto em branco de qualquer rifle que você usa é 5 quadrados maior",
            tree="Carbineer",
            name="Fechar contato"
        },
        {
            description="Ao usar a ajuda outra ação para suprimir um inimigo (veja a página 151 do livro de regras do núcleo da saga Edition), o inimigo, em vez disso, leva uma penalidade -5 para todos os rolos de ataque até o fim de sua próxima volta. Pré-requisito: Cuidado Tiroteio.",
            tree="Carbineer",
            name="Mantenha - os honestos"
        },
        {
            description="Característica confiável da classe Sidearm aplica-se aos rifles",
            tree="Carbineer",
            name="Velho Fiel"
        },
        {
            description="+2 bônus em ataques de oportunidade com rifles",
            tree="Carbineer",
            name="Fogo de oportunidade"
        },
        {
            description="Tratar rifles como se fossem precisos",
            tree="Carbineer",
            name="Mestre do rifle"
        },
        {
            description="Sempre use uma espingarda para fazer ataques de oportunidade",
            tree="Carbineer",
            name="Atire do quadril"
        },
        {
            description="Você não provoca quando aponta com uma espingarda",
            tree="Carbineer",
            name="Snap Shot"
        },
        {
            description="Você ignora as penalidades em seus rolos de ataque quando um alvo tem ocultação ou total ocultação.",
            tree="Gunslinger",
            name="Tiro Cego"
        },
        {
            description="Dar dano depois de usar o objetivo para um ataque variado move o alvo -1 descer a trilha da condição",
            tree="Gunslinger",
            name="Tiro Debilitante"
        },
        {
            description="Vencer a Defesa de Vontade de um alvo com um cheque de Decepção nega ao alvo o seu bónus de Dexterity para Defesa de Reflexos contra os seus ataques até ao seu próximo turno, activado como duas acções rápidas",
            tree="Gunslinger",
            name="Tiro Enganador"
        },
        {
            description="Você pode fazer um único ataque em uma rodada surpresa, mesmo que surpreso e sua pistola está guardada",
            tree="Gunslinger",
            name="Desenho Rápido Melhorado"
        },
        {
            description="Bater em um alvo depois de usar o objetivo para um ataque variado bate o alvo propensa, além de causar danos",
            tree="Gunslinger",
            name="Derrubar o Tiro"
        },
        {
            description="Reduza a penalidade aos rolos de ataque ao fazer vários ataques com pistolas em 2\n\n(Entrar número de vezes tomadas)",
            tree="Gunslinger",
            name="Proficiência de múltiplos ataques (pistols)"
        },
        {
            description="Imediatamente após fazer um ataque completo onde você ataca com duas pistolas, mova sua velocidade como uma ação livre",
            tree="Gunslinger",
            name="Ataque móvel (pistols)"
        },
        {
            description="1/enc para cada: 1. 1 atk thresh do alvo é metade, 2. 1 atk como se visado, 3. +4 Ref Def para 1 volta e fazer 1 atk",
            tree="Gunslinger",
            name="Duelista de Pistola"
        },
        {
            description="Você pode desarmar usando um ataque variado",
            tree="Gunslinger",
            name="Desarmar Ranged"
        },
        {
            description="Se você estiver com 6 quadrados de um alvo e armado com uma pistola ou rifle, você pode agir como através de você ocupou o quadrado mais próximo adjacente ao alvo para efeitos de determinação de flanqueamento.",
            tree="Gunslinger",
            name="Flank Ranged"
        },
        {
            description="longe de perseguir alvo executar ou usar 2 swif & fazer single -5 atk como parte do movimento, FP para evitar -5",
            tree="Gunslinger",
            name="Retirar o Fogo"
        },
        {
            description="1/enc make single variou atk w/arma manual como swif não stan, não pode usar restante para atk",
            tree="Gunslinger",
            name="Tiro Rápido"
        },
        {
            description="Você não leva nenhuma penalidade em seu rolo de ataque ao usar Rapid Shot",
            tree="Gunslinger",
            name="Trigger Work"
        },
        {
            description="Uma vez por encontro como uma ação redonda quando você está empunhando duas pistolas, você pode mover-se até o dobro de sua velocidade e fazer um ataque variado com cada pistola.",
            tree="Pistoleiro",
            name="Dash e Blast"
        },
        {
            description="Sempre que você está flanqueado por dois ou mais oponentes e está empunhando duas pistolas, você pode fazer uma ação de ataque completo como uma ação padrão. Isto é desde que você alvo adversários que flanqueiam você e atacar pelo menos dois alvos.",
            tree="Pistoleiro",
            name="Fogo de Flanking"
        },
        {
            description="Se empunhar duas pistolas e apenas fizer um único ataque variado com uma delas, mesmo que você falhar, você lida com danos iguais a metade do seu nível heróico para o alvo.",
            tree="Pistoleiro",
            name="Tiro Garantido"
        },
        {
            description="Ao empunhar duas pistolas, como uma ação padrão, você pode fazer um ataque de auto-fogo com uma das pistolas como se a arma fosse ajustada para auto-fogo, mesmo que não tenha modo de auto-fogo.",
            tree="Pistoleiro",
            name="Hailfire"
        },
        {
            description="Ao empunhar duas pistolas, você ganha um bônus de +2 para os rolos de danos ao usar o feito Rapid Shot.",
            tree="Pistoleiro",
            name="Tiro Duplo"
        },
        {
            description="Ao usar a ação de mira, você ganha o benefício do feito Point Blank Shot contra seu alvo, independentemente da categoria de alcance. Pré-requisito: Fato de tiro distante.",
            tree="Árvore de Talentos Sharpshooter",
            name="Tiro de Precisão"
        },
        {
            description="Uma vez por rodada, você pode gastar uma única ação rápida para designar um único inimigo que não está dentro do alcance à queima-roupa. Quando você fizer um rolo de ataque variado bem sucedido que causa danos contra o inimigo designado, adicione seu bônus de Dexterity (mínimo +1) ao rolo de dano. Este efeito dura até que o alvo esteja inconsciente, morto ou deixe a sua linha de visão. Só pode ter um inimigo designado desta forma. Pré-requisitos: Precision Shot. base bônus de ataque +10.",
            tree="Árvore de Talentos Sharpshooter",
            name="Desenhar uma Bead"
        },
        {
            description="Uma vez por encontro. Você pode designar um único alvo que você tenha apontado e que não esteja dentro do alcance à queima-roupa. Ao fazer um movimento de ataque variado contra esse alvo, o alvo é negado seu bônus de Dexterity para Defesa de Reflexos ao determinar o efeito do seu ataque. Pré-requisitos: Desenhe uma Bead, Tiro de Precisão, façanha de atirador.",
            tree="Árvore de Talentos Sharpshooter",
            name="Boilho"
        },
        {
            description="Você pode manter seu alvo preocupado sobre de onde o próximo tiro está vindo em vez de tentar fugir. Quando você lida com danos a um inimigo que você tem apontado, a velocidade do alvo é reduzida para 2 quadrados, e o alvo não pode tomar uma ação de movimento duplo ou usar a ação de execução até o final de sua próxima volta. Este é um efeito impressionante. Pré-requisito: Tiro de Precisão.",
            tree="Árvore de Talentos Sharpshooter",
            name="Pinning Shot"
        },
        {
            description="Quando você faz um ataque bem sucedido variado contra um inimigo que você tem apontado e o ataque causa danos, o alvo não pode usar uma ação padrão para fazer um ataque rolar em seu próximo turno. Isto conta como um efeito impressionante. Pré-requisitos: Pinning Shot, Precision Shot.",
            tree="Árvore de Talentos Sharpshooter",
            name="Tiro de Harrying"
        },
        {
            description="1/encontro gastar um ponto de força para adicionar bônus armadura para você limiar de dano",
            tree="Armadura de Cavaleiro",
            name="Aumento blindado I"
        },
        {
            description="Sempre que você usar a ampliação blindada eu ganho DR = para 2× armadura Fortitude bônus",
            tree="Armadura de Cavaleiro",
            name="Aumento blindado II"
        },
        {
            description="Ganhe +2 bônus ao fazer um ataque melee desarmado contra um ataque sabre de luz",
            tree="Armadura de Cavaleiro",
            name="Defesa da cortose"
        },
        {
            description="Faça um ataque imediato de oportunidade quando você se esquivar com seu desafio de cortose",
            tree="Armadura de Cavaleiro",
            name="Retaliação da cortose"
        },
        {
            description="Sempre que um aliado dentro de 12 quadrados atinge com um ataque de sabre de luz, ganhar um +1 bônus moral para todas as defesas até a próxima volta",
            tree="Resolução de Cavaleiros",
            name="Moral de Cavaleiro"
        },
        {
            description="Quando um aliado dentro de 12 quadrados tem sucesso com um ataque de sabre de luz, ganhar +1 morrer de dano em seu próximo ataque de sabre de luz antes do fim de sua próxima volta",
            tree="Resolução de Cavaleiros",
            name="Força do Império"
        },
        {
            description="Quando um aliado dentro de 12 quadrados atinge com um ataque de sabre de luz, você ganha 3 × nível de classe em pontos de bônus até o final de sua próxima volta",
            tree="Resolução de Cavaleiros",
            name="Juramento de dever"
        },
        {
            description="Você pode usar o Block ou Defletir talento para negar um ataque feito contra um aliado adjacente",
            tree="Resolução de Cavaleiros",
            name="Praetoria Ishu"
        },
        {
            description="Deal +1 morre de dano com um sabre de luz em duas mãos se você mover 1 quadrado antes",
            tree="Resolução de Cavaleiros",
            name="Praetoria Vonil"
        },
        {
            description="Ao procurar um item do mercado negro, você não precisa fazer uma verificação de informações para localizar um mercado negro; você automaticamente tem sucesso.",
            tree="Contratos públicos",
            name="Comprador de Mercado Negro"
        },
        {
            description="Sempre que você compra bens através do mercado negro, você pode obter itens que foram modificados com o feito Tech Specialist (veja página 21 de Naves Estelares da Galáxia) sem aumentar o valor base dos itens.\nPré-requisito: Comprador do Mercado Negro.",
            tree="Contratos públicos",
            name="Apenas o melhor"
        },
        {
            description="Certifica-te sempre que os teus aliados têm o melhor equipamento disponível. Sempre que você compra armas, armaduras ou outros equipamentos (quer legalmente ou através do mercado negro), todas as engrenagens que você compra tem 50% mais pontos de ataque do que o normal e tem 5 mais DR do que o normal. Além disso, sempre que um de seus aliados faz uma verificação Mecânica sobre um objeto que você comprou, que aliado ganha um bônus de equipamento +2 para o cheque.",
            tree="Contratos públicos",
            name="Kit Excelente"
        },
        {
            description="Você tem um talento para encontrar as peças de reposição de melhor qualidade para equipamentos quebrados. Sempre que você usa a aplicação Reparar da habilidade Mecânica, você restaura um ponto de sucesso extra 1d8 com uma verificação Mecânica bem sucedida, além do que você normalmente restauraria.\nSe você usar a ajuda outra ação para ajudar um aliado com reparos, que aliado também repara um ponto de sucesso adicional adicionar com uma verificação Mecânica bem sucedida. Qualquer aliado só pode beneficiar deste talento uma vez por verificação Mecânica, independentemente de quantos aliados com esta ajuda talento no cheque.",
            tree="Contratos públicos",
            name="Exatamente o que é necessário"
        },
        {
            description="Uma vez por dia, quando um aliado faz uma verificação de habilidade não treinada. como uma reação você pode conceder que aliado um bônus de equipamento +5 para a verificação, e o aliado é considerado treinado nessa habilidade com a finalidade de usar somente aplicações treinadas da habilidade. Você não pode usar este talento para permitir que um aliado faça uma verificação sem treinamento Use a verificação Força.",
            tree="Contratos públicos",
            name="A engrenagem certa para o trabalho"
        },
        {
            description="Uma vez por encontro, você pode usar este talento em um dróide inimigo adjacente que foi reduzido para 0 pontos de ataque ou movido para o fundo da pista condição, mas não destruído. Como uma ação padrão, faça uma verificação Mecânica contra a Defesa de Vontade do dróide. Se o seu resultado é igual ou superior à Defesa da Vontade do dróide, o dróide move +2 passos na pista de condição, recupera 1d8 pontos de ataque, e torna-se seu aliado, e sua atitude para com você imediatamente muda para amigável. O druida luta do seu lado até o fim do encontro, no momento em que é destruído.",
            tree="Improvisador",
            name="Capturar o Droid"
        },
        {
            description="Você pode usar a aplicação Jury-Rig da habilidade Mecânica como uma ação padrão em vez de como uma ação completa. Além disso, você não é obrigado a fazer uma verificação de habilidade para com sucesso júri-rig um dispositivo ou veículo, eo dispositivo ou veículo move +3 passos na pista condição em vez de +2.",
            tree="Improvisador",
            name="Melhor Jury-Rig"
        },
        {
            description="Você pode criar uma peça temporária de quase qualquer tipo de equipamento a partir das peças de reposição que você tem ao redor. Para isso, você deve fazer uma verificação DC 25 Mecânica e passar uma hora construindo o dispositivo. O objeto pode ter um valor máximo de 200 créditos x seu nível de classe. não pode ter uma disponibilidade de rara ou ilegal, e não pode ser única. O dispositivo que você cria deve ser algo que você estaria razoavelmente familiarizado, e depois de 24 horas o objeto é destruído. Você pode usar este talento uma vez por dia.",
            tree="Improvisador",
            name="Dispositivo improvisado"
        },
        {
            description="Sempre que você cria uma granada com o talento do Dispositivo Improvisado, a granada fornece um dado adicional de dano quando usada.\nPré-requisito: Dispositivo improvisado.",
            tree="Improvisador",
            name="Bang Maior"
        },
        {
            description="Sempre que criar um dispositivo com o talento do Dispositivo Improvisado, pode aplicar uma modificação concedida pelo especialista técnico (ver página 21 das Naves Estelares da Galáxia) ao dispositivo. Esta personalização não afeta o valor do item que está sendo criado.\nPré-requisitos: Dispositivo Improvisado, Proeza Especialista em Tecnologia.",
            tree="Improvisador",
            name="Modelo Personalizado"
        },
        {
            description="Adicione seu nível de classe à Defesa de Vontade ao ser reprogramado",
            tree="Autonomia",
            name="Eletrônica defensiva"
        },
        {
            description="DR 10 contra danos iónicos",
            tree="Autonomia",
            name="Resistência ao Íon"
        },
        {
            description="Se você é movido para o fundo da pista de condição por outra maneira do que tomar danos maiores do que seu limiar de dano, mova +1 passo ao longo da pista de condição após ser desativado por 2 rodadas",
            tree="Autonomia",
            name="Repor suavemente"
        },
        {
            description="Você não sofre nenhuma penalidade para reprogramar ou modificar-se",
            tree="Autonomia",
            name="Especialista em modificações"
        },
        {
            description="Você canaliza o seu pico de energia para um impulso para o seu sistema de locomoção. Quando você iniciar um pico de energia, você pode usar um dos seguintes bônus com seu sistema de locomoção instalado: Pular +4 quadrados (caminhando ou locomoção rodada), ou aumentar a altura pairando em 4 quadrados (caminhando locomoção). Você pode usar este talento para um número de rodadas iguais a metade do seu nível (redondo para baixo). No final de um impulso de energia, você move -1 passo persistente na pista de condição. As penalidades impostas por esta condição persistem até que você receba reparos (usando a aplicação Repair Droid da habilidade Mecânica). Você pode usar Power Surge e Power Boost ao mesmo tempo, mas você deve mover -2 passos persistentes na pista de condição. Pré-requisito: Recrutamento de Energia.",
            tree="Autonomia",
            name="Aumentar o Poder"
        },
        {
            description="Ganhe 1 ponto de ataque adicional por ponto que você excede o DC para se reparar",
            tree="Autonomia",
            name="Auto- Reparar"
        },
        {
            description="Você pode usar sua capacidade de contornar inibidores comportamentais para quebrar temporariamente a programação de um dróide com o qual você tem um link de dados. Faça uma verificação Use Computer oposta pela defesa de vontade do dróide. Quebrar a programação do dróide substitui seus inibidores comportamentais por várias rodadas iguais ao seu bônus de inteligência.\nPré-requisito: Treinado em Computador de Uso.",
            tree="Elite Droid",
            name="Programa de quebra"
        },
        {
            description="Você entende as sutilezas e limitações do seu processador heurístico. Você pode refazer qualquer verificação de habilidade não treinada (exceto Use a Força), mantendo o segundo resultado, mesmo que seja pior. Uma vez por encontro, você pode gastar um Ponto da Força para refazer qualquer verificação de habilidade (treinada ou não treinada), levando o melhor resultado.\nPré-requisito: Sabedoria 15.",
            tree="Elite Droid",
            name="Mestre Heurístico"
        },
        {
            description="Uma vez por encontro você pode usar cada uma das seguintes ações:\n• Script de ataque: Você pode usar um feito ou um talento que modifica seu rolo de ataque como uma ação a menos (por exemplo, uma ação completa torna-se uma ação padrão, uma ação rd standa torna-se uma ação movimento, uma ação movimento torna-se uma ação rápida, uma ação rápida torna-se uma ação livre).\n• Roteiro de Defesa: Você pode aplicar r bônus Espírito Independente uma segunda vez durante um único encontro.\n• Script de habilidades: Enquanto em combate, você pode aplicar um bônus igual a metade de seu nível de classe para qualquer habilidade sing le que requer uma ação padrão ou menos para usar. Você deve ser treinado na habilidade.\nPré-requisito: Bônus de ataque base +5.",
            tree="Elite Droid",
            name="Rotinas Programadas"
        },
        {
            description="Você tem sub-rotinas avançadas que o tornam mais resistente ao efeito de danos. Uma vez por encontro, como reação, você pode aumentar seu limiar de dano com um bônus igual ao seu nível Droid Independente.",
            tree="Elite Droid",
            name="Ultra Resiliente"
        },
        {
            description="Você pode usar seu modificador de persuasão em vez de usar o computador para usar verificações de habilidade do computador",
            tree="Dróide Especializado",
            name="Língua do Computador"
        },
        {
            description="Você pode rebobinar qualquer opção Use verificação do computador e manter o melhor resultado",
            tree="Dróide Especializado",
            name="Mestre do Computador"
        },
        {
            description="Você pode tomar 10 em qualquer verificação de habilidade baseada em Dexterity, mesmo quando ameaçado ou de outra forma não permitido",
            tree="Dróide Especializado",
            name="Manipulação aprimorada"
        },
        {
            description="Como uma ação rápida, você ganha um bônus +5 para Intelligence and Wisdom based skill checks, e um bônus +1 para rolos de ataque variados, para um número de rodadas iguais a metade do seu nível, em que ponto você cair -1 etapas para baixo a pista de condição",
            tree="Dróide Especializado",
            name="Processador Hotwired"
        },
        {
            description="Você pode usar cada uma das seguintes ações uma vez por encontro.\n• Apenas Outro Dróide: Você é hábil em usar Stealth para passar furtivamente por inimigos incautos ao se mover à vista de todos. Você pode usar a aplicação Sneak da habilidade Stealth quando à vista de um inimigo, se o inimigo não tem razão para duvidar que você é apenas outro dróide. Você é considerado treinado em Stealth para esta ação.\n• Apenas um Dróide Normal: Você pode reroll Deception verifica para aparência enganosa para fazer observadores acreditar que você está realizando uma função padrão ao tentar fazer algo atípico para o seu modelo ou função dróide. Você pode manter qualquer resultado.",
            tree="Dróide Especializado",
            name="Apenas um Dróide"
        },
        {
            description="Como uma ação rápida, você ganha um +1 bônus para rolos de ataque melee, lidar +1 morrer de dano, e aumentar a sua velocidade em 2 quadrados, para um número de rodadas iguais a metade do seu nível, em que ponto você cair -1 passos para baixo da pista condição",
            tree="Dróide Especializado",
            name="Surge o Poder"
        },
        {
            description="Quando você reprogramar a si mesmo, você pode ganhar um bônus Habilidade Foco façanha em troca de uma habilidade treinada",
            tree="Dróide Especializado",
            name="Conversão de Habilidade"
        },
        {
            description="Você pode fazer uma ação rápida como uma reação depois de falhar em uma verificação Deception ou uma verificação Stealth.\nPré-requisitos: Quaisquer dois talentos da árvore de talentos Autonomia.",
            tree="Dróide Especializado",
            name="Dróide Rápida"
        },
        {
            description="Sua contagem de iniciativa não é alterada ao desencadear uma ação preparada",
            tree="Infiltração",
            name="Sempre Pronto"
        },
        {
            description="Uma vez por rodada, você pode refazer um ataque usando uma arma oculta como uma ação rápida, mas deve ter o segundo resultado",
            tree="Infiltração",
            name="Especialista em armas ocultas"
        },
        {
            description="Como uma ação rápida, você pode designar um alvo inconsciente dentro de 12 quadrados para negá-los Percepção verifica para notá-lo até sua próxima vez",
            tree="Infiltração",
            name="Abordagem Assustadora"
        },
        {
            description="Gastar duas ações rápidas consecutivas ao lidar com danos de atordoamento para um alvo para movê-los um passo extra para baixo da pista de condição",
            tree="Infiltração",
            name="Definir para o Stun"
        },
        {
            description="Se você danificar um oponente inconsciente, ele não pode falar ou fazer barulhos até sua próxima volta",
            tree="Infiltração",
            name="Derrubamento Silencioso"
        },
        {
            description="Você pode usar o modificador Recolher informações para fazer verificações de conhecimento (lore galáctico)",
            tree="Bothan Spynet",
            name="Agente Spynet"
        },
        {
            description="Faça uma verificação DC 20 Recolha de informações para comprar armas padrão, equipamentos e transporte a meio preço, ou variações exóticas e restritas para 75% do preço",
            tree="Bothan Spynet",
            name="Recursos Bothan"
        },
        {
            description="Faça uma verificação do Conhecimento (saber galáctico) como uma ação rápida contra uma DC de 15 + a CL do alvo para ganhar um bônus +2 para uma pontuação de defesa",
            tree="Bothan Spynet",
            name="O conhecimento é vida"
        },
        {
            description="Faça uma verificação de conhecimento (sabor galáctico) como uma ação rápida contra uma DC de 15 + a CL do alvo para aumentar o seu alcance crítico contra esse alvo em 1",
            tree="Bothan Spynet",
            name="O conhecimento é poder"
        },
        {
            description="Faça uma verificação de Conhecimento (saber galáctico) como uma ação rápida contra uma DC de 15 + a CL do alvo para ganhar um bônus +2 para um ataque rola contra eles",
            tree="Bothan Spynet",
            name="Conhecimento é Força"
        },
        {
            description="Faça uma verificação do conhecimento (lore galáctica) como uma ação rápida contra uma DC de 15 + a CL do alvo para aprender seu nível, classes, pontuações de habilidade, bem como números de Pontos de Força e Destino",
            tree="Bothan Spynet",
            name="Seis Perguntas"
        },
        {
            description="Passe um ponto de força para relegar um ataque crítico contra você para lidar com danos normais",
            tree="Duelista",
            name="Forçar a Fortificação"
        },
        {
            description="+1 bônus para rolos de ataque melee",
            tree="Duelista",
            name="Foco na Arma Maior (sabres de luz)"
        },
        {
            description="+2 bônus para rolos de danos melee",
            tree="Duelista",
            name="Especialização em armas maiores (sabres de luz)"
        },
        {
            description="Seu rolo de ataque lança sabre de luz é comparado à defesa reflexa de todos os alvos em uma linha 6-quadrado",
            tree="Duelista",
            name="Melhor lançamento de sabre de luz"
        },
        {
            description="Alvos danificados com seu sabre de luz jogado mover a meia velocidade até sua próxima volta",
            tree="Duelista",
            name="Mestria do sabre de luz lançada"
        },
        {
            description="Uma vez por turno, após o sucesso em um Redirect Shot, o Deflector que desencadeou não conta para a penalidade cumulativa de Deflection",
            tree="Duelista",
            name="Redirecionamento Melhorado"
        },
        {
            description="Após o sucesso em um Riposte, o bloco que desencadeou não conta para a pena cumulativa de Block",
            tree="Duelista",
            name="Riposte Melhorado"
        },
        {
            description="1/ encontro como uma ação rápida, devolva um poder de força com o descritor [lightsaber] de volta para o seu pacote Force\n\n(Entrar número de vezes tomadas)",
            tree="Duelista",
            name="Sabre de luz Savant"
        },
        {
            description="Reduza a penalidade aos rolos de ataque ao fazer vários ataques com sabres de luz em 2\n\n(Entrar número de vezes tomadas)",
            tree="Duelista",
            name="Proficiência de múltiplos ataques (iluminadores)"
        },
        {
            description="Desmembrar um alvo, lidar com metade dos danos e movê-los -1 descer a trilha da condição, quando você de outra forma matá-los",
            tree="Duelista",
            name="Greve de Separação"
        },
        {
            description="Você pode tratar um sabre de luz de uma mão como uma arma leve se você também está empunhando um Shoto (sabre de luz curto), e além disso, se você tem o talento Lightsaber Defesa você pode ativá-lo como uma ação livre em vez de um rápido",
            tree="Duelista",
            name="Shoto Master"
        },
        {
            description="Como uma ação padrão, você pode devolver um poder de força gasto para a suíte Força de qualquer aliado dentro de 6 quadrados de você e na sua linha de visão. O poder da Força deve ter sido gasto pelo aliado que designaste.",
            tree="Arquivista Jedi",
            name="Directo"
        },
        {
            description="Você pode ajudar outro nas verificações de conhecimento de qualquer aliado dentro de 6 quadrados de você como uma reação para o conhecimento de habilidades em que você é treinado.",
            tree="Arquivista Jedi",
            name="Conhecimento Impart"
        },
        {
            description="Você pode fazer uma verificação Use a Força no lugar de uma verificação de conhecimento para qualquer habilidade de conhecimento em que você não é treinado. Você é considerado treinado nessa habilidade de conhecimento para fins de usar este talento.",
            tree="Arquivista Jedi",
            name="Por Dentro da Força"
        },
        {
            description="Quando você usa o talento do conselheiro hábil, o aliado que você ajuda ganha um ponto de força temporário no final de sua próxima volta. Se o Ponto de Força não for gasto antes do fim do encontro, ele se perde.",
            tree="Arquivista Jedi",
            name="Conselheiro Mestre"
        },
        {
            description="Como uma ação rápida, você pode rerall uma verificação de conhecimento e manter o melhor dos dois resultados. Isso pode ser usado com qualquer habilidade de conhecimento em que você é treinado.",
            tree="Arquivista Jedi",
            name="Conhecimento Científico"
        },
        {
            description="Chamar e acender um sabre de luz que você construiu como uma ação livre se na linha de visão",
            tree="Artesão Jedi",
            name="Chamar Arma"
        },
        {
            description="Adicionar um acessório extra, reroll um dado de dano se auto-construído, mentor outro edifício (-5 seu DC)",
            tree="Artesão Jedi",
            name="Masterwork Lightsaber"
        },
        {
            description="+2 Bloquear e defletir com um sabre de luz que você construiu",
            tree="Artesão Jedi",
            name="Especialista em sabre de luz"
        },
        {
            description="Se você gastar um ponto de força em um ataque de sabre de luz que você construiu, você também pode adicionar essa quantidade para danos",
            tree="Artesão Jedi",
            name="Atuação Perfeita"
        },
        {
            description="Passe 1 minuto removendo um acessório e adicionando outro em um sabre de luz que você construiu",
            tree="Artesão Jedi",
            name="Modificação Rápida"
        },
        {
            description="Meditação de batalha oferece um bônus +2 em vez de um +1",
            tree="Mestre de Batalha Jedi",
            name="Comandante de Batalha Jedi"
        },
        {
            description="Como uma ação rápida, aliados afetados pelo seu ganho de Meditação de Batalha +2 para Defesa de Reflexos, e você ganha um bônus +1 para Bloquear ou defletir para cada aliado adjacente sabre de luz",
            tree="Mestre de Batalha Jedi",
            name="Círculo Defensivo"
        },
        {
            description="Aliados reduzidos a 0 pontos de ataque enquanto influenciados pela sua Meditação de Batalha podem tomar o Segundo Vento imediatamente se você gastar um Ponto de Força",
            tree="Mestre de Batalha Jedi",
            name="Forçar a Reviver"
        },
        {
            description="Uma vez por encontro, ao fazer uma cobrança, você não toma qualquer penalidade cumulativa para tentativas de bloco, e pode adicionar o bônus de cobrança para Riposte",
            tree="Mestre de Batalha Jedi",
            name="Taxa de corte"
        },
        {
            description="Imediatamente depois de fazer um ataque completo onde você ataca com dois sabres de luz ou duas extremidades de um sabre de luz de duas lâminas, mova sua velocidade como uma ação livre",
            tree="Mestre de Batalha Jedi",
            name="Ataque Móvel (Iluminadores)"
        },
        {
            description="Ao curar alguém thraugh transferência vital, a quantidade de danos curados aumenta em 1 ponto por seu nível de classe.",
            tree="Curador Jedi",
            name="Aumentar a cura"
        },
        {
            description="Ao curar alguém através de transferência vital, a quantidade de danos curados aumenta em 2 pontos por seu nível dass.",
            tree="Curador Jedi",
            name="Melhor aumento da cura"
        },
        {
            description="Ao usar transferência vital para curar alguém, você pode mover o alvo + 1 passo na pista condição em vez de cicatrizar danos. Ao fazê-lo, você move -1 passo na pista condição em troca.",
            tree="Curador Jedi",
            name="Soothe"
        },
        {
            description="Adicione o seu resultado do Ponto de Força a um aliado em 12 sq com um modificador Use o Modificador de Força inferior ao seu",
            tree="Instrutor Jedi",
            name="Aprendiz Boon"
        },
        {
            description="1/turn conceder o uso de Segredo da Força para aliado em 12 sq & treinado em Use a Força",
            tree="Instrutor Jedi",
            name="Compartilhar o Segredo da Força"
        },
        {
            description="1/turn conceder o uso de Técnica da Força para aliado em 12 sq e treinado em Use a Força, não FP Recuperação",
            tree="Instrutor Jedi",
            name="Compartilhar a técnica da força"
        },
        {
            description="1/dia concessão de uso de Lightsaber Combate ou Formulários, Duelista até o final do enc se w/em 12 sq para aliados = 1/2 cl",
            tree="Instrutor Jedi",
            name="Compartilhar Talento"
        },
        {
            description="Passe um poder em suite e dê a aliado treinado em Use a Força e dentro de 12 quadrados e linha de visão; perdido se não usado até o final do encontro",
            tree="Instrutor Jedi",
            name="Potência de Transferência"
        },
        {
            description="Você pode usar o poder longínquo num local em vez de uma criatura individual, perscrutando o passado do local para ver os eventos que ocorreram ali. Ao contrário do uso normal do poder farseeing, você está realmente olhando para o passado do local (em um momento que você designar), e você deve estar em pé no local que está sendo visto. O alvo DC para o seu Uso a verificação Força é 20, +1 para cada dia no passado que você tenta rabiscar. Quando você olha para o passado, você só precisa especificar uma hora em um número de dias, como você pode sentir tremores na Força que focam suas visões em eventos significativos naquele dia",
            tree="Investigador Jedi",
            name="Ecos na Força"
        },
        {
            description="Como uma ação rápida, você designa uma única criatura alvo como o foco de suas atenções. Você ganha um bônus +2 para sua velocidade a qualquer momento que você gastar uma ação de movimento para mover, desde que você termine seu movimento adjacente ao alvo. Você retém o bônus (e não pode usar esse talento novamente) até que seu alvo se renda, seja reduzido a 0 pontos de acerto, ou se mova para o fundo da pista condição, ou até que o encontro termine",
            tree="Investigador Jedi",
            name="Quarry Jedi"
        },
        {
            description="Sempre que você tem pelo menos um poder de farseeing não gasto em sua suíte, você pode gastar esse poder de farseeing para recuperar qualquer outro poder de força como uma ação rápida",
            tree="Investigador Jedi",
            name="Preparados para o Perigo"
        },
        {
            description="Sempre que alguém fizer uma verificação de habilidade de Decepção ou Persuasão contra sua Defesa de Vontade, você pode fazer uma verificação Use a Força, substituindo sua Defesa de Vontade com o resultado da verificação Use a Força se for maior",
            tree="Investigador Jedi",
            name="Decepção de Sentido"
        },
        {
            description="Sempre que você é o alvo de um poder de força de talento que afeta a mente, você pode gastar um ponto de força como uma reação para negar os efeitos desse poder de força ou talento (sem verificação de habilidade necessária)",
            tree="Investigador Jedi",
            name="Julgamento desnudado"
        },
        {
            description="-5 penalização para reunir informações para encontrá-lo",
            tree="Refugiados Jedi",
            name="Cubra Suas Faixas"
        },
        {
            description="Rerole qualquer oposição Use as verificações da Força para ocultar sua presença",
            tree="Refugiados Jedi",
            name="Difícil de sentir"
        },
        {
            description="Você só pode ser detectado a partir de um intervalo de 10 km",
            tree="Refugiados Jedi",
            name="Forçar Veil"
        },
        {
            description="Uma vez por uso de sessão de jogo; Adquira equipamentos ou fundos, obter informações, receber atenção médica ou casa segura segura.",
            tree="Refugiados Jedi",
            name="Rede Jedi"
        },
        {
            description="Você pode parecer ter um Lado Sombrio Score o mesmo que sua pontuação Sabedoria quando sentido através da Força\n\nDecepção é uma habilidade de classe",
            tree="Sombra Jedi",
            name="Decepção Escura"
        },
        {
            description="Você pode usar uma força de lado escuro uma vez por encontro sem aumentar sua pontuação de lado escuro",
            tree="Sombra Jedi",
            name="Mancha do Lado Negro"
        },
        {
            description="Sentinel Strike lida com danos d8",
            tree="Sombra Jedi",
            name="Greve Sentinel melhorada"
        },
        {
            description="O Gambit do Sentinel pode ser usado novamente várias vezes igual a metade do seu nível de classe",
            tree="Sombra Jedi",
            name="Gambit Sentinel Melhorado"
        },
        {
            description="Você pode escolher o melhor de dois rolos para repreender poderes do lado negro",
            tree="Sombra Jedi",
            name="Rebuke the Dark"
        },
        {
            description="Aliados dentro de 12 quadrados podem rerolar seus controles de Iniciativa no início do combate, e um número igual ao Modificador de Sabedoria não ficam surpresos se você não estiver",
            tree="Jedi Watchman",
            name="Forçar o Aviso"
        },
        {
            description="Você e seus aliados podem tomar uma ação extra na rodada surpresa",
            tree="Jedi Watchman",
            name="Avanço do Vigia"
        },
        {
            description="Você pode desenhar, acender e atacar com um sabre de luz na rodada surpresa, mesmo se você estiver surpreso, ou desenhar e acender um sabre de luz como uma ação livre em sua vez",
            tree="Jedi Watchman",
            name="Desenho rápido melhorado (iluminadores)"
        },
        {
            description="Como uma ação rápida, conceda a um aliado um bônus +1 para Defesa de Reflexos desde que você permaneça adjacente",
            tree="Jedi Watchman",
            name="Vigilância"
        },
        {
            description="Você pode bloquear ou defletir ataques contra um aliado adjacente sem gastar um Ponto de Força",
            tree="Jedi Watchman",
            name="Estância de Abrigo"
        },
        {
            description="Sempre que você usar o poder de ataque de batalha, você ganha o bônus do poder em rolos de ataque em seu primeiro ataque melee feito cada rodada até o final do encontro. Se não atacar numa ronda, este efeito termina",
            tree="Mestre da Arma Jedi",
            name="Combater Trance"
        },
        {
            description="Você não leva nenhuma penalidade em rolos de ataque com armas improvisadas",
            tree="Mestre da Arma Jedi",
            name="Mestre da Arma Improvisado"
        },
        {
            description="Como uma ação padrão, sempre que você está empunhando duas armas (ou uma arma dupla), você pode fazer um ataque com cada arma (ou cada extremidade de uma arma dupla). Cada ataque deve ser contra um alvo diferente.",
            tree="Mestre da Arma Jedi",
            name="Estilo de arma dupla"
        },
        {
            description="Sempre que você usa o talento estilo de arma gêmea, você pode mover 2 quadrados entre cada ataque. Este movimento não provoca ataque de oportunidade",
            tree="Mestre da Arma Jedi",
            name="Mestre em Armas Gêmeas"
        },
        {
            description="Sempre que você está empunhando um shoto e usar com sucesso o talento Block para negar um ataque melee, o atacante não pode fazer mais ataque melee até o início de sua próxima vez ou até que você não está mais adjacente a ele",
            tree="Mestre da Arma Jedi",
            name="Shoto Pin"
        },
        {
            description="Aplique seu bônus Dexterity em rolos de danos com um sabre de luz em vez de seu bônus de força",
            tree="Formas de sabre de luz",
            name="Ataru"
        },
        {
            description="Depois de ser dele por um ataque melee, gastar um ponto de força para fazer um ataque imediato contra o oponente",
            tree="Formas de sabre de luz",
            name="Djem So"
        },
        {
            description="Você pode refazer o primeiro rolo de ataque de cada rodada contra um inimigo, designado por gastar um Ponto de Força como uma ação rápida, e manter o melhor resultado",
            tree="Formas de sabre de luz",
            name="Juyo"
        },
        {
            description="Você marca um hit crítico com um sabre de luz em 19 ou 20 naturais, desde que você bater.",
            tree="Formas de sabre de luz",
            name="Vaapad"
        },
        {
            description="Wielding um único sabre de luz uma mão aumenta seu bônus Lightsaber Defesa em 2 (máximo +5)",
            tree="Formas de sabre de luz",
            name="Makashi"
        },
        {
            description="+1 bônus para Defesa de Reflexos e Defesa de Vontade enquanto empunha um sabre de luz",
            tree="Formas de sabre de luz",
            name="Niman"
        },
        {
            description="Dobre o bônus para sua Defesa Reflexa da Lightsaber Defense enquanto empunha dois sabres de luz",
            tree="Formas de sabre de luz",
            name="Jar'Kai"
        },
        {
            description="+5 bônus para rolo de ataque variado para redirecionar um parafuso de blaster desviado",
            tree="Formas de sabre de luz",
            name="Shien"
        },
        {
            description="A sanção cumulativa para usos sucessivos em bloco ou em deflexão é reduzida para -2",
            tree="Formas de sabre de luz",
            name="Shii- Cho"
        },
        {
            description="Você pode levar 10 em cheques de acrobacias para cair mesmo quando distraído ou ameaçado, e cair através de um quadrado ameaçado ou ocupado conta como 1 quadrado",
            tree="Formas de sabre de luz",
            name="Sokan"
        },
        {
            description="Você pode reroll Use as verificações Force para bloquear ou defletir e manter o melhor resultado",
            tree="Formas de sabre de luz",
            name="Soresu"
        },
        {
            description="Faça uma verificação de engano para fingir em combate como duas ações rápidas",
            tree="Formas de sabre de luz",
            name="Trakata"
        },
        {
            description="Ao fazer um ataque desarmado, você estende seu alcance de ameaça crítica por 1 (por exemplo. 19-20 em vez de 20). No entanto, qualquer coisa que não seja um 20 natural não é considerado um hit automático; se você rolar qualquer coisa além de um 20 natural e ainda errar o alvo, você não marcar um hit crítico. Pré-requisito: Bônus de ataque base +10.",
            tree="Formas de Artes Marciais",
            name="Especialização em Echani"
        },
        {
            description="Quando você danifica uma criatura ou dróide com um ataque desarmado, o alvo leva uma penalidade ao seu próximo rolo de ataque igual ao seu bônus de Força.",
            tree="Formas de Artes Marciais",
            name="Hijkata Especialização"
        },
        {
            description="Uma vez por turno. Quando você danificar uma criatura ou dróide com um ataque desarmado, você pode fazer um ataque para desarmar como uma ação rápida. Além disso, você não leva a penalidade -5 para o seu rolo de ataque se o alvo está empunhando uma arma com mais de uma mão.",
            tree="Formas de Artes Marciais",
            name="K'tara Expertise"
        },
        {
            description="Qualquer inimigo que comece sua volta adjacente a você leva danos iguais ao seu modificador de Força (ponto mínimo 1) se você for capaz de fazer um ataque de oportunidade contra eles. Você pode usar este talento enquanto usa apenas armadura leve sem armadura.",
            tree="Formas de Artes Marciais",
            name="K'thri Especialização"
        },
        {
            description="Quando você pegar com sucesso um inimigo, ele ou ela deve fazer uma verificação de garra oposta para se livrar de sua captura. Se você está iniciando um grapple, você pode reroll sua verificação grapple. No entanto. Você deve aceitar o segundo resultado, mesmo que seja pior. Você pode usar este talento apenas usando armadura leve ou sem armadura.",
            tree="Formas de Artes Marciais",
            name="Stava Expertise"
        },
        {
            description="Uma vez por turno, quando você danificar uma criatura ou dróide com um ataque desarmado, compare seu rolo de ataque com o limiar de dano do alvo. Se o seu rolo de ataque for igual ou superior ao limiar do alvo, o alvo é movido -1 passo na pista de condição, independentemente do resultado de dano do seu ataque.",
            tree="Formas de Artes Marciais",
            name="Especialização em Tae-Jitsu"
        },
        {
            description="Uma vez por turno, quando você danificar uma criatura ou dróide com um ataque desarmado, você pode fazer um ataque contra a defesa de fortaleza do alvo como uma ação livre. Se esse ataque for bem sucedido, o alvo só pode tomar uma única ação rápida no seu próximo turno. Você pode usar este talento apenas usando armadura leve ou sem armadura.",
            tree="Formas de Artes Marciais",
            name="Wrruushi Expertise"
        },
        {
            description="Quando você faz vários ataques desarmados como uma ação de ataque completo (veja a página 154 do livro de regras da Saga Edition), você reduz a pena para o seu rolo de ataque em 2. Podes aguentar este talento várias vezes. Cada vez que você tomar este talento, você reduz a penalidade para seus rolos de ataque por um adicional 2.",
            tree="Mestre Desarmado",
            name="Flurry de golpes"
        },
        {
            description="Se você danificar com um ataque desarmado de uma criatura ou dróide que tem redução de danos, você reduz o valor dessa redução de danos por um até o final do encontro. Ataques cumulativos contra o mesmo alvo não empilham.",
            tree="Mestre Desarmado",
            name="Greve Endurecida"
        },
        {
            description="Quando você marcar um ataque crítico em um ataque desarmado, você pode fazer um ataque desarmado imediato (além de outros efeitos de um ataque crítico) contra um único alvo ao alcance. Você pode usar este talento apenas Uma vez por turno e apenas enquanto usar armadura leve em nenhuma armadura.",
            tree="Mestre Desarmado",
            name="Ataque de punição"
        },
        {
            description="Você pode realizar um golpe de graça como uma ação de movimento, e quando você conseguir, todos os aliados dentro da linha de visão ganhar um bônus moral +2 em rolos de ataque durante a duração do encontro.",
            tree="Pirataria",
            name="Sanguinário"
        },
        {
            description="Uma vez por encontro, como uma ação rápida, aliados dentro de 6 quadrados de vocês curam danos iguais ao seu nível heróico.",
            tree="Pirataria",
            name="Lute até a morte"
        },
        {
            description="Todos os adversários dentro de 6 quadrados de você tomar -1 penalidade em todos os ataques.",
            tree="Pirataria",
            name="Reputação Selvagem"
        },
        {
            description="Uma vez por rodada, quando um de seus aliados em 6 quadrados danifica um inimigo, você concede a todos os aliados dentro da linha de visão um bônus igual a metade de seu nível de classe para danificar até o fim de sua próxima volta.",
            tree="Pirataria",
            name="Frenzy do Raider"
        },
        {
            description="Como uma ação padrão, você pode fazer uma verificação de Decepção ou Persuasão contra cada inimigo dentro da linha de visão. Se o cheque for bem sucedido contra a Defesa de Vontade, esse inimigo deve retirar-se em sua próxima ação ou tomar uma penalidade -1 para atacar para o encontro.",
            tree="Pirataria",
            name="Surge o Raider"
        },
        {
            description="Sempre que você ou qualquer um de seus aliados dentro de 6 quadrados de você reduz um alvo para 0 pontos de sucesso, você pode optar por tratar esse oponente como se eles tinham sido reduzidos a 0 por danos de atordoamento.",
            tree="Pirataria",
            name="Leve - os vivos"
        },
        {
            description="Você pode usar trajes espaciais blindados como se você tivesse Proficiência Armadura (pesado)",
            tree="Privado",
            name="Espaçador blindado"
        },
        {
            description="Você ganha um corsário não heróico de três quartos de seu nível de classe para acompanhá-lo\n\n(Entrar número de vezes tomadas)",
            tree="Privado",
            name="Atrair o Privado"
        },
        {
            description="Você pode fazer um ataque livre com uma pistola sempre que você faz um único ataque com uma arma avançada melee",
            tree="Privado",
            name="Blaster e Blade I"
        },
        {
            description="Você pode tratar uma arma avançada como duas mãos quando empunhar com uma pistola.",
            tree="Privado",
            name="Blaster e Blader II"
        },
        {
            description="Você pode fazer um ataque completo com uma pistola e avançada arma de melee como uma ação padrão",
            tree="Privado",
            name="Blaster e Blader III"
        },
        {
            description="Você ignora a cobertura, mas não a cobertura melhorada, quando a bordo de uma nave estelar ou estação espacial",
            tree="Privado",
            name="Boarder"
        },
        {
            description="Você ganha +1 para atacar rolos e lidar +1 morrer dano ao usar armas iônicas",
            tree="Privado",
            name="Ion Mastery"
        },
        {
            description="Reduza a penalidade aos rolos de ataque ao fazer múltiplos ataques com armas melee avançadas em 2\n\n(Entrar número de vezes tomadas)",
            tree="Privado",
            name="Proficiência de múltiplos ataques (armas melee avançadas)"
        },
        {
            description="Ao lidar com danos suficientes para destruir um veículo com armamento de veículo, você pode em vez de lidar com metade do dano, movê-lo -1 descer a pista condição e desativar seus motores subluz e hiperdrive",
            tree="Privado",
            name="Preservar o Tiro"
        },
        {
            description="Você pode usar Treat Injury para reviver um alvo que morreu dentro de um número de rodadas iguais a metade do seu nível heróico",
            tree="Medicina Avançada",
            name="Trá-los de volta"
        },
        {
            description="Aliados automaticamente têm sucesso em ajudar outras tentativas para você tratar lesões",
            tree="Medicina Avançada",
            name="Equipa de Emergência"
        },
        {
            description="Você pode usar o tratamento de lesão para realizar primeiros socorros em um alvo mais uma vez por dia",
            tree="Medicina Avançada",
            name="Primeiros Socorros Extra"
        },
        {
            description="Faça uma verificação DC 20 tratar lesão para dar um alvo adjacente um segundo vento imediato",
            tree="Medicina Avançada",
            name="Milagre Médico"
        },
        {
            description="Pode utilizar o Treat Injury para realizar primeiros socorros, tratar doenças e tratar venenos sem um kit médico, desde que sejam adequados substitutos",
            tree="Medicina Avançada",
            name="Cura Natural"
        },
        {
            description="Você pode reroll qualquer verificação de lesão de tratamento e manter o melhor resultado",
            tree="Medicina Avançada",
            name="Mantendo - se sob pressão"
        },
        {
            description="Você pode usar o tratamento de lesão para executar primeiros socorros como uma ação padrão",
            tree="Medicina Avançada",
            name="Médico de Battlefield"
        },
        {
            description="O seu paciente não sofre danos, nem morre, por não ter sido verificado.",
            tree="Medicina Avançada",
            name="Segunda chance"
        },
        {
            description="+5 aos ataques de oportunidade com armas proficientes",
            tree="Duelista Melee",
            name="Greve de vantagem"
        },
        {
            description="Fingir como duas ações rápidas contra um oponente você ameaça ao invés de uma ação padrão",
            tree="Duelista Melee",
            name="Truques Sujos"
        },
        {
            description="Faça um único ataque grátis com sua segunda arma de luz sempre que fazer um único ataque",
            tree="Duelista Melee",
            name="Farinha de arma dupla I"
        },
        {
            description="Faça um ataque completo com duas armas leves como uma ação padrão em vez de uma ação completa",
            tree="Duelista Melee",
            name="Farinha de arma dupla II"
        },
        {
            description="Você pode adicionar seu bônus Dexterity em vez de seu bônus Força para rolos de danos com uma arma leve",
            tree="Duelista Melee",
            name="Mestre da Elegância"
        },
        {
            description="Uma vez por encontro, como uma ação livre, fazer um ataque com uma arma leve após uma finta bem sucedida",
            tree="Duelista Melee",
            name="De Nenhum Lugar"
        },
        {
            description="Você pode mover sua velocidade como uma ação livre ao fazer um ataque completo com uma única arma leve",
            tree="Duelista Melee",
            name="Farinha de arma única I"
        },
        {
            description="Faça um ataque completo com uma única arma leve como uma ação padrão em vez de uma ação completa",
            tree="Duelista Melee",
            name="Farinha de arma única II"
        },
        {
            description="Quando disparas ou atiras uma arma com um raio de explosão ou de salpico num alvo com cobertura, ignoras essa cobertura.",
            tree="Engenheiro Militar",
            name="Capa de Violação"
        },
        {
            description="Você ignora o limiar de danos de portas e paredes ao usar minas e explosivos fixos (não granada).",
            tree="Engenheiro Militar",
            name="Violação de Explosivos"
        },
        {
            description="Quando você usa uma mina, você pode escolher ter o raio de explosão tornar-se terreno difícil depois que o explosivo detonou. Alternativamente, você pode ter o negócio explosivo sem danos e, em vez disso, transformar terreno difícil em terreno normal.",
            tree="Engenheiro Militar",
            name="Explosivo preparado"
        },
        {
            description="Como uma ação rápida designar um veículo dentro de sua linha de visão cujo piloto pode ouvi-lo e entendê-lo; o piloto ignora terreno difícil e ganha um bônus +5 em todas as verificações piloto feitas para evitar perigos e colisões até o início de sua próxima volta.",
            tree="Engenheiro Militar",
            name="Resolver problemas"
        },
        {
            description="Você pode usar a aplicação Reparar da habilidade Mecânica para reparar um dróide ou objeto como uma ação padrão. Você pode ganhar os benefícios deste talento apenas uma vez por dia por dróide, objeto ou veículo reparado.",
            tree="Engenheiro Militar",
            name="Reparos em Voo"
        },
        {
            description="Quando você repara um dróide, você repara 1 ponto de ataque adicional para cada ponto pelo qual sua verificação Mecânica bate a base DC de 20.",
            tree="Engenheiro Militar",
            name="Droid Expert"
        },
        {
            description="Quando você cria uma arma criada em campo (de acordo com o recurso de classe), você pode escolher uma modificação de arma do feito Tech Specialist (ver página 21 de Naves Estelares da Galáxia) para se aplicar à arma criada no momento da criação.",
            tree="Engenheiro Militar",
            name="Modificações Rápidas"
        },
        {
            description="Como uma ação rápida, você pode sabotar qualquer objeto ou arma alimentado por uma célula de energia para que ela se torne uma granada.",
            tree="Engenheiro Militar",
            name="Dispositivo Sabotagem"
        },
        {
            description="Como uma ação padrão, você pode aumentar a velocidade de um dróide adjacente ou veículo que você ocupa por 1 quadrado (aplicado a qualquer método de locomoção) até o fim de sua próxima volta.",
            tree="Engenheiro Militar",
            name="Tech Savant"
        },
        {
            description="Como uma ação padrão, você pode fazer uma verificação DC 15 Mecânica para conceder um veículo que você ocupa um número de pontos bônus igual a 5 × seu nível de classe.",
            tree="Engenheiro Militar",
            name="Boost Veicular"
        },
        {
            description="Permita que um aliado em 12 quadrados rerole uma verificação de engano ou furtivo, mas mantenha o segundo resultado",
            tree="Oficial Fugitivo",
            name="Truque Disciplinado"
        },
        {
            description="Sempre que você rolar uma verificação de percepção, todos os aliados em 6 quadrados fazer o mesmo e você tomar o mais alto",
            tree="Oficial Fugitivo",
            name="Percepção do Grupo"
        },
        {
            description="Meta-se até seu modificador Carisma em aliados e conceda-lhes uma ação de retirada gratuita",
            tree="Oficial Fugitivo",
            name="Retirada apressada"
        },
        {
            description="Ao fazer Hasty Withdrawl, um aliado pode fazer um cheque Stealth grátis",
            tree="Oficial Fugitivo",
            name="Retirada furtiva"
        },
        {
            description="Sempre que um aliado em 12 quadrados tem sua defesa de vontade alvo por uma habilidade, o inimigo deve reroll e tomar o resultado mais baixo",
            tree="Oficial Fugitivo",
            name="Subordanatos de Stalwart"
        },
        {
            description="Remova o efeito que afeta a mente ou o medo do aliado e conceda 10 pontos bônus de nível de classe",
            tree="Oficial Fugitivo",
            name="Fique na luta"
        },
        {
            description="Faça uma verificação DC 15 Knowledge (tática) como uma ação de movimento para fornecer a você e aliados +1d6 pontos de dano a um alvo designado com cada melee bem sucedido ou ataque variado até o início da sua próxima volta",
            tree="Táticas Militares",
            name="Táticas de assalto"
        },
        {
            description="Quando você usa o talento de táticas de assalto em um inimigo, o alvo leva uma pena cumulativa -1 para a Defesa Reflexa cada vez que é danificado por um de seus aliados (máximo -5). Esta pena se aplica até o fim da próxima vez.",
            tree="Táticas Militares",
            name="Explora a Fraqueza"
        },
        {
            description="depois de surpresa rnd tomar sua vez antes aliados, mas deve compartilhar talento (qualidade especial, Comando, Liderança ou Táticas Militares), próximo rnd voltar ao lugar normal em ordem Init",
            tree="Táticas Militares",
            name="Prerogativa do Comandante"
        },
        {
            description="Faça uma verificação DC 15 Knowledge (táctica) como uma ação de movimento para fornecer a você e aliados um bônus +1 para atacar rolos contra adversários flanqueados ou Defesa de Reflexos contra ataques de oportunidade até o início da sua próxima virada",
            tree="Táticas Militares",
            name="Tácticas de implantação"
        },
        {
            description="Faça uma verificação de conhecimento DC 15 (tácticas) como uma ação de movimento para fornecer a você e aliados um bônus de cobertura +10 para Defesa de Reflexos desde a capa disponível até o início da próxima vez",
            tree="Táticas Militares",
            name="Táticas de Campo"
        },
        {
            description="Faça uma verificação DC 15 Conhecimento (táticas) como uma ação padrão para negar inimigos dentro da linha de visão qualquer competência, insight ou moral bônus para atacar rolos e qualquer burla para Defesa de Reflexos até o início de sua próxima vez",
            tree="Táticas Militares",
            name="Desvio de manobra"
        },
        {
            description="Você pode levar metade ou todos os danos causados a um aliado adjacente de um único ataque, e vice-versa",
            tree="Táticas Militares",
            name="Um para a equipa"
        },
        {
            description="Como uma ação rápida, uma vez por encontro, você pode conceder pontos de bônus igual a 5 + metade do seu nível de caráter para todos os aliados dentro de 20 quadrados de você e na sua linha de visão.",
            tree="Táticas Militares",
            name="Grande Líder"
        },
        {
            description="depois de usar a partilha de talentos Conhecimento (táctica) como livre para substituir DC de quaisquer talentos desta árvore",
            tree="Táticas Militares",
            name="Táticas Irregulares"
        },
        {
            description="Como uma ação rápida, você pode levar uma penalidade -2 para uma defesa para ganhar um bônus +1 para outra defesa até o início de sua próxima vez",
            tree="Táticas Militares",
            name="Mudar a Defesa I"
        },
        {
            description="Como uma ação rápida, você pode levar uma penalidade -5 para uma defesa para ganhar um bônus +2 para outra defesa até o início de sua próxima volta",
            tree="Táticas Militares",
            name="Mudar a Defesa II"
        },
        {
            description="Como uma ação rápida, você pode levar uma penalidade -5 para duas defesas para ganhar um bônus +5 para a outra defesa até o início de sua próxima volta",
            tree="Táticas Militares",
            name="Mudança de Defesa III"
        },
        {
            description="As táticas de assalto, de implantação e tática de campo podem ser usadas como ações rápidas",
            tree="Táticas Militares",
            name="Contorno Tático"
        },
        {
            description="Uma vez por dia, você pode adicionar metade do seu nível de classe oficial a todas as suas defesas para uma rodada. Tem de declarar que está a usar este talento no início da sua vez. Os benefícios duram até ao início da próxima volta.",
            tree="Táticas Militares",
            name="Defesa Incensível"
        },
        {
            description="Como uma ação completa conceder um número de veículos iguais ao seu nível de classe dentro de sua linha de visão a capacidade de mover sua velocidade imediatamente",
            tree="Oficial Naval",
            name="Implantação da frota"
        },
        {
            description="Designar um único veículo como uma ação padrão e ter sucesso em uma verificação DC 15 Conhecimento (táticas) para conceder a todos os artilheiros aliados dentro da linha de visão uma morte adicional de danos com ataques variados",
            tree="Oficial Naval",
            name="Tácticas da Frota"
        },
        {
            description="Uma vez por encontro como uma ação rápida conceder ao piloto de qualquer veículo dentro da linha de visão uma ação de movimento imediato",
            tree="Oficial Naval",
            name="É uma armadilha!"
        },
        {
            description="Navios capitais sob seu comando calculam Defesa de Reflexos como se tivesse melhorado a defesa da armadura, com artilheiros ganhando metade de seu nível heróico ou seu nível heróico para danificar e o nível de qualidade da tripulação genérica aumenta em um",
            tree="Oficial Naval",
            name="Comandante Lendário"
        },
        {
            description="Uma vez por encontro, faça uma verificação de Persuasão contra Defesa de Vontade para lidar com metade dos danos ao alvo e movê-lo -1 passo na pista de condição, e o alvo torna-se seu aliado e amigável. Se o alvo for de um nível mais alto do que você, ele ganha um bônus +5 para sua defesa de vontade.",
            tree="Recrutador Rebelde",
            name="Inimigo de Recrutamento"
        },
        {
            description="Sempre que você usar com sucesso Recruit Inemy em um alvo, você e todos os aliados dentro da linha de visão ganhar um bônus moral +2 para atacar rolos até o final do encontro.\nPré-requisito: Inimigo de Recrutamento.",
            tree="Recrutador Rebelde",
            name="Números Bolsados"
        },
        {
            description="Sempre que você usar com sucesso Recruit Enemy em um alvo, se esse alvo for reduzido para 0 pontos de acerto ou movido para o fundo da faixa de condição, como uma reação você pode conceder a si mesmo e todos os aliados dentro da linha de visão um número de pontos de acerto bônus iguais a 10 + seu nível de classe. Os danos são subtraídos dos pontos de sucesso bônus primeiro, e quaisquer pontos de sucesso bônus restantes no final do encontro são perdidos. Bônus pontos de sucesso não empilham. Nenhum ponto de acerto de bônus pode ser concedido se você ou um aliado reduzir o alvo para 0 pontos de acerto ou movê-lo para o fundo da faixa de condição.\nPré-requisito: Inimigo de Recrutamento.",
            tree="Recrutador Rebelde",
            name="Nobre Sacrifício"
        },
        {
            description="Você pode usar seu talento Recruit Inemy sempre que você ou um aliado iria lidar com danos suficientes para matar um alvo, em vez de apenas quando você faz.\nPré-requisito: Inimigo de Recrutamento.",
            tree="Recrutador Rebelde",
            name="Recrutamento da Equipa"
        },
        {
            description="Uma vez por encontro, como uma reação, você pode adicionar metade do seu nível de classe para a pontuação de defesa de sua escolha",
            tree="Foragido",
            name="Sentidos Preternacionais"
        },
        {
            description="Uma vez por rodada, sempre que um aliado danificar com sucesso um oponente, você pode tomar uma ação rápida como uma reação",
            tree="Foragido",
            name="Aproveitar o momento"
        },
        {
            description="Sempre que você usaria o momento, você pode esquecer a ação rápida para ser capaz de apontar como uma única ação rápida em seu próximo turno",
            tree="Foragido",
            name="Procurar uma Abertura"
        },
        {
            description="Uma vez por encontro, sempre que você usaria o momento, você pode esquecer a ação extra rápida para fazer um ataque imediato contra o oponente danificado, seu dano contando como uma parte do ataque do seu aliado para superar DR e limiar de dano",
            tree="Foragido",
            name="Duplo para cima"
        },
        {
            description="Uma vez por encontro sempre que um oponente causar danos a você, você pode mover 1 quadrado como uma reação sem provocar",
            tree="Foragido",
            name="Instintos estranhos"
        },
        {
            description="Uma vez por encontro, sempre que você usar Instintos Incensíveis, você pode esquecer o movimento extra e, em vez disso, aumentar sua Defesa Reflexa em 5 até o fim de sua próxima volta",
            tree="Foragido",
            name="Defesa oportunista"
        },
        {
            description="Como uma ação padrão, você pode fazer um ataque não-área contra um oponente dentro do alcance. Se ele bater, você lida com metade do seu dano normal, mas seu oponente perde sua próxima ação de movimento",
            tree="Foragido",
            name="Emaranhar"
        },
        {
            description="Uma vez por encontro, sempre que você usar Instintos Incensíveis, você pode renunciar ao movimento para fazer um ataque imediato contra o oponente. Se o seu ataque é melee, golpes e danos, você e seu oponente mudar de lugar",
            tree="Foragido",
            name="Ataque confuso"
        },
        {
            description="Se você está adjacente a um objeto que pode fornecer cobertura de um alvo, você pode apontar para esse alvo como uma ação de movimento.",
            tree="Identificador de caminhos",
            name="Bunker Blaster"
        },
        {
            description="Como uma ação rápida, você pode designar um único aliado dentro de sua linha de visão que tem cobertura de um ou mais inimigos. Esse aliado é considerado, em vez disso, para ter melhor cobertura contra esses inimigos até o início da sua próxima volta, enquanto o aliado ainda tem cobertura.\nEscort Fighter: Você pode gastar uma ação rápida para designar um aliado adjacente. Até ao início da próxima vez. Se te mexeres. que aliado também pode mover o mesmo número de quadrados, desde que o aliado termina o seu movimento adjacente a você. Você não pode mover uma distância maior do que a velocidade do aliado.",
            tree="Identificador de caminhos",
            name="Melhorar a Capa"
        },
        {
            description="Você pode gastar uma ação rápida para designar um aliado adjacente. Até ao início da próxima vez. Se te mexeres. que aliado também pode mover o mesmo número de quadrados, desde que o aliado termina o seu movimento adjacente a você. Você não pode mover uma distância maior do que a velocidade do aliado.",
            tree="Identificador de caminhos",
            name="Lutador de Escolta"
        },
        {
            description="Uma vez por turno, você pode gastar uma ação de movimento para permitir que um aliado dentro da linha de visão para mover até sua velocidade como uma reação. Se um alvo fizer um ataque de oportunidade contra o aliado durante o seu movimento. Você pode fazer um ataque de oportunidade contra esse alvo.\nPré-requisito: Lutador de Escolta.",
            tree="Identificador de caminhos",
            name="Passagem Segura"
        },
        {
            description="Como uma ação padrão, você pode identificar uma zona segura, dentro da qual seus aliados ganham certas vantagens. Você designa uma área quadrada 4 por 4 da área de combate como uma zona segura; pelo menos 1 quadrado da zona segura deve ser o quadrado que você atualmente ocupa. Cada aliado que iniciar a sua vez dentro da zona segura ganha um bônus de +2 circunstâncias para sua defesa de fortaleza e defesa de vontade até o início do próximo turno do beco. A zona segura dura até o fim do encontro, e você só pode ter uma zona segura em vigor de cada vez. Você pode criar uma nova zona segura como uma ação padrão, descartando a antiga zona segura e substituindo-a pela nova, mas nenhum quadrado da antiga zona segura pode se sobrepor a qualquer quadrado da nova zona segura. Você não pode criar uma zona segura em um espaço que se sobrepõe à zona segura de outro pathfinder.",
            tree="Identificador de caminhos",
            name="Zona Segura"
        },
        {
            description="Todos os inimigos tratam sua zona segura como terreno difícil.\nPré-requisito: Zona Segura.",
            tree="Identificador de caminhos",
            name="Medidas de defesa"
        },
        {
            description="Qualquer aliado que iniciar a sua vez dentro da sua zona segura e, em seguida, sai da zona ganha um bônus +2 para atacar rolos antes do fim da vez do aliado, desde que o aliado não está dentro da sua zona segura quando o ataque é feito.\nPré-requisito: Zona Segura.",
            tree="Identificador de caminhos",
            name="Ponto de Lançamento"
        },
        {
            description="Inimigos que disparam na sua zona segura, são penalizados para atacar rolos.\nPré-requisito: Zona Segura.",
            tree="Identificador de caminhos",
            name="Defesas Obscurecedoras"
        },
        {
            description="Você pode descartar sua zona segura como uma ação rápida, terminando seus efeitos atuais. Qualquer aliado no espaço que sua zona segura estava ocupando ganha um bônus +2 à velocidade deles até o início de sua próxima volta. Quando você usa este talento, você não pode criar uma nova zona segura até o início de sua próxima vez.\nPré-requisito: Zona Segura.",
            tree="Identificador de caminhos",
            name="Relocalizar"
        },
        {
            description="Qualquer aliado que pegar um segundo vento enquanto estiver dentro da sua zona segura recupera um número de pontos de impacto adicionais iguais ao seu nível de classe.\nPré-requisito: Zona Segura.",
            tree="Identificador de caminhos",
            name="Zona de Recuperação"
        },
        {
            description="Faça uma verificação DC 20 Mecânica como uma ação completa para desativar todos os equipamentos eletrônicos de um tipo específico (exceto dróide, veículo ou arma) dentro de 12 quadrados para o resto do encontro",
            tree="Sabotagem",
            name="Jammer de Dispositivo"
        },
        {
            description="Faça uma verificação Mecânica como uma ação completa contra a Defesa da Vontade de qualquer dróide que venha dentro de 6 quadrados de você para o resto do encontro para permitir que eles tomem apenas ações rápidas",
            tree="Sabotagem",
            name="Droid Jammer"
        },
        {
            description="Você pode colocar uma mina como uma ação padrão",
            tree="Sabotagem",
            name="Mine Mastery"
        },
        {
            description="Você pode definir um detonador como uma ação rápida, e seus explosivos nunca detonar enquanto você está colocando-os",
            tree="Sabotagem",
            name="Demolicionista habilidoso"
        },
        {
            description="Escolha mudar uma explosão para uma linha duas vezes o raio ou um cone três vezes o raio da explosão original",
            tree="Sabotagem",
            name="Explosão Formada"
        },
        {
            description="Aumentar o raio de explosão de uma explosão em 1 quadrado",
            tree="Sabotagem",
            name="Explosão Extrema"
        },
        {
            description="Criar uma torre uma vez por encontro como uma ação padrão, que dispara em um alvo que você designa uma vez por rodada enquanto adjacente",
            tree="Torreta",
            name="Blaster Turret I"
        },
        {
            description="Sua torre é mais poderosa, e pode ser controlada em uma gama de 12 quadrados",
            tree="Torreta",
            name="Blaster Turret II"
        },
        {
            description="Sua torre pode disparar duas vezes por rodada, e ganha DR 5",
            tree="Torreta",
            name="Blaster Turret III"
        },
        {
            description="A sua torre pode causar danos iónicos.",
            tree="Torreta",
            name="Torre de Íon"
        },
        {
            description="A tua torre pode causar danos de choque.",
            tree="Torreta",
            name="Torre de choque"
        },
        {
            description="A tua torre explode num raio de 2 quadrados quando atinge 0 pontos, a menos que a desatives.",
            tree="Torreta",
            name="Autodestruição da torreta"
        },
        {
            description="1/encontro dar criatura disposta 10 pontos de bônus por rodada",
            tree="Implante",
            name="Implante de adrenalina"
        },
        {
            description="1/ encontro dar criatura disposta +1 equipamento bônus para atacar rolos",
            tree="Implante",
            name="Implante de Precisão"
        },
        {
            description="1/ encontro dar +5 bônus de equipamento para limiar de dano à criatura disposta",
            tree="Implante",
            name="Implante de resiliência"
        },
        {
            description="1/encontro aumentar a velocidade de base do alvo em 2",
            tree="Implante",
            name="Implantação de Velocidade"
        },
        {
            description="1/conteúdo conceder +1 morrer de dano melee à criatura disposta",
            tree="Implante",
            name="Implante de força"
        },
        {
            description="Tome 10 quando instalar biotecnologia e a meio custo e tempo",
            tree="Shaper",
            name="Domínio da biotecnologia"
        },
        {
            description="Rebole qualquer verificação de lesão de tratamento para reparar ou modificar biotecnologia",
            tree="Shaper",
            name="Perito Shaper"
        },
        {
            description="Você pode consertar temporariamente um item de biotecnologia como uma ação padrão",
            tree="Shaper",
            name="Medição Expediente"
        },
        {
            description="Quando você conserta temporariamente um dispositivo biotecnológico, ele sobe 4 passos e apenas 3 degraus para baixo no final do encontro.",
            tree="Shaper",
            name="Mestre Mender"
        },
        {
            description="Quando utiliza Biotech Surgery, o ataque biotecnológico contra o doente é reduzido para metade",
            tree="Shaper",
            name="Implante habilidoso"
        },
        {
            description="Um único oponente danificado por uma força de seu poder leva 2d6 danos no início de sua próxima volta",
            tree="Sith",
            name="Aflição"
        },
        {
            description="Uma vez por encontro, ao danificar um oponente sensível à força, você recupera uma força gasta e eles perdem um ponto de força",
            tree="Sith",
            name="Força de drenagem"
        },
        {
            description="Passe um ponto de força como uma ação padrão para fazer um rolo de ataque contra a defesa de fortaleza ou um alvo dentro de 6 quadrados, lidando 1d6 pontos de dano por nível de classe e curando-se uma quantidade equivalente em um hit",
            tree="Sith",
            name="Cura Escura"
        },
        {
            description="Seu alvo de cura escura pode estar dentro de 12 quadrados, e você faz metade do dano e curar mesmo em um ataque fracassado",
            tree="Sith",
            name="Melhor cura escura"
        },
        {
            description="Passe um ponto de força uma vez por encontro para fazer uma verificação Use a força contra a defesa de fortaleza de três alvos dentro de 12 quadrados para lidar 1d6 danos por nível de classe e curar metade dessa quantidade, ou metade se você falhar",
            tree="Sith",
            name="Campo de Cura Escura"
        },
        {
            description="+1 bônus para atacar rolos contra Jedi",
            tree="Sith",
            name="Scourge Escuro"
        },
        {
            description="Você pode rerolar Use as verificações da Força para ativar os poderes da Força do Lado Negro, mas deve manter o resultado da rerolagem",
            tree="Sith",
            name="Adepto Lado Escuro"
        },
        {
            description="Você pode rerolar Use as verificações da Força para ativar as forças do lado negro e manter o melhor resultado gastando um Ponto de Força",
            tree="Sith",
            name="Mestre Lado Negro"
        },
        {
            description="Você pode criar um Talismã Sith para aumentar seus poderes de Força, ou imbuir uma arma com o modelo de arma alquímica Sith",
            tree="Sith",
            name="Sith Alquimia"
        },
        {
            description="Verificações de engano podem ser feitas com Use a Força, e Decepção é considerada uma habilidade treinada",
            tree="Sith",
            name="Forçar a Decepção"
        },
        {
            description="Ganhe um sabre de luz da árvore de talentos Jedi Knight Lightsaber Forms\n\n(Entrar número de vezes tomadas)",
            tree="Sith",
            name="Forma Roubada"
        },
        {
            description="Ao marcar um hit crítico com um sabre de luz, gaste um ponto de força para mover o alvo -2 passos ao longo da pista de condição",
            tree="Sith",
            name="Greve Má"
        },
        {
            description="Podes usar o teu domínio da alquimia Sith para criar abominações mutantes. Você deve ter acesso a uma criatura voluntária (ou inconsciente) à qual você irá aplicar o modelo de Abominação Sith ou o modelo Chrysalis Beast. Você também precisa de um laboratório médico equipado para o processo, o que requer um número de dias iguais ao CL modificado da criatura. Você deve gastar um Ponto de Força na conclusão do processo para completar a transformação. Uma criatura que você sofreu mutação é considerada uma criatura domesticada, mas apenas para você (a menos que já fosse uma criatura domesticada antes de sua mutação)",
            tree="Sith Alquimia",
            name="Causar a Mutação"
        },
        {
            description="Você pode modificar um objeto com a alquimia Sith para que ele ganhe um traço específico. Você só pode realizar uma modificação de cada vez. Salvo indicação em contrário, não pode conceder mais de uma prestação a um único objecto e não pode aplicar a mesma prestação mais de uma vez. Você deve gastar um Ponto de Força e dedicar 1 hora de trabalho ininterrupto para aplicar uma característica ao objeto relevante, e quando você faz isso, você aumenta sua Pontuação de Lado Negro em 1",
            tree="Sith Alquimia",
            name="Especialista em Alquimia Sith"
        },
        {
            description="Como uma ação padrão, você pode realizar pequenas alterações alquímicas a uma arma melee que você empunha. Para o resto do encontro, você ganha um bônus de equipamento +2 em rolos de ataque com essa arma. Além disso, uma vez antes do final do encontro, você pode sacrificar este bônus como uma ação gratuita para ganhar um bônus de equipamento +5 em um único rolo de dano que você faz com essa arma",
            tree="Sith Alquimia",
            name="Alquimia Rápida"
        },
        {
            description="1/ encontro todos os aliados mover +2 sobe a pista de condição, mas sofrer -2 para ataques e habilidades para rodadas de nível de caráter",
            tree="Comandante Sith",
            name="Focar o Terror"
        },
        {
            description="1/encontro conceder todos os aliados ataque imediato em -5 pena",
            tree="Comandante Sith",
            name="Medidas desesperadas"
        },
        {
            description="1/encontro conceder todos os aliados +1 bônus em rolos de ataque, mas -2 em Defesa Reflexa",
            tree="Comandante Sith",
            name="Incite a raiva"
        },
        {
            description="1/encontro todos os aliados em 1/2 pontos de sucesso ganhar pontos de bônus de sucesso igual ao seu nível de caráter",
            tree="Comandante Sith",
            name="Poder do Ódio"
        },
        {
            description="Ao procurar ativamente por inimigos ocultos, você pode fazer uma verificação de percepção como uma ação rápida em vez de uma ação padrão",
            tree="Vanguarda",
            name="Visão Melhorada"
        },
        {
            description="Se você e pelo menos um outro aliado têm linha de visão para e estão cientes de um alvo, você e aliados que podem ouvir e entender que você pode voltar a rolar um ataque variou contra esse alvo, aceitando o segundo resultado, mesmo que seja pior. Você e seus aliados só podem ganhar o benefício deste talento uma vez por encontro",
            tree="Vanguarda",
            name="Triangular"
        },
        {
            description="Sempre que você danificar um alvo com um ataque não-área variou, você pode designar um aliado dentro de sua linha de visão como uma ação rápida. O seu alvo é considerado de pés chatos contra o primeiro ataque do aliado feito antes do início da sua próxima volta.",
            tree="Vanguarda",
            name="Marcar o Alvo"
        },
        {
            description="Quando um oponente usa a ação de mira para negar sua capa, você pode fazer uma verificação Stealth oposta pela verificação Iniciativa do atacante. Se tiver sucesso, você retém seu bônus de cobertura.",
            tree="Vanguarda",
            name="Maximizar a Capa"
        },
        {
            description="Sempre que você tem cobertura contra um alvo, você ganha DR igual ao seu classievei contra esse alvo até o início do seu próximo turno, desde que você ainda tem cobertura do alvo no momento em que o ataque é feito.",
            tree="Vanguarda",
            name="Capa Impenetrável"
        },
        {
            description="Se o seu alvo não o conhece, os seus ataques são mais do que 1 morte por danos contra esse alvo.",
            tree="Vanguarda",
            name="Ataque Invisível"
        },
        {
            description="Sempre que você danificar um alvo com um ataque variado, você pode designar um aliado dentro de sua linha de visão como uma ação rápida. O aliado que você designar ignora a redução de danos do alvo e o SR (se houver) até o início da próxima volta.",
            tree="Vanguarda",
            name="Amenizar o Alvo"
        },
        {
            description="Sempre que você danificar um alvo que não está ciente de você com um ataque de área, esse alvo é considerado de pé plano até o início de sua próxima volta.",
            tree="Vanguarda",
            name="Choque de conchas"
        },
        {
            description="walker",
            tree="",
            name="Velocidade do ar"
        },
        {
            description="simples",
            tree="",
            name="melee avançado"
        }
    }
}
