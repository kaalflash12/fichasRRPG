local M={}

M.skills={
["Acrobatics"]="Acrobacia",["Climb"]="Escalar",["Deception"]="Enganação",["Endurance"]="Resistência",
["Gather Information"]="Obter Informações",["Initiative"]="Iniciativa",["Jump"]="Saltar",
["Knowledge (Bureaucracy)"]="Conhecimento (Burocracia)",["Knowledge (Galactic Lore)"]="Conhecimento (História Galáctica)",
["Knowledge (Life Sciences)"]="Conhecimento (Ciências da Vida)",["Knowledge (Physical Sciences)"]="Conhecimento (Ciências Físicas)",
["Knowledge (Social Sciences)"]="Conhecimento (Ciências Sociais)",["Knowledge (Tactics)"]="Conhecimento (Táticas)",
["Knowledge (Technology)"]="Conhecimento (Tecnologia)",["Mechanics"]="Mecânica",["Perception"]="Percepção",
["Persuasion"]="Persuasão",["Pilot"]="Pilotar",["Ride"]="Cavalgar",["Stealth"]="Furtividade",
["Survival"]="Sobrevivência",["Swim"]="Natação",["Treat Injury"]="Tratar Ferimentos",
["Use Computer"]="Usar Computador",["Use the Force"]="Usar a Força"
}

M.groups={
["advanced melee"]="Armas Corpo a Corpo Avançadas",["advanced melee weapons"]="Armas Corpo a Corpo Avançadas",
["heavy"]="Armas Pesadas",["heavy weapons"]="Armas Pesadas",
["lightsabers"]="Sabres de Luz",["lightsaber"]="Sabres de Luz",
["pistols"]="Pistolas",["pistol"]="Pistolas",["rifles"]="Rifles",["rifle"]="Rifles",
["simple"]="Armas Simples",["simple weapons"]="Armas Simples",["improvised"]="Armas Improvisadas",
["Advanced Melee Weapons"]="Armas Corpo a Corpo Avançadas",["Heavy Weapons"]="Armas Pesadas",
["Lightsabers"]="Sabres de Luz",["Pistols"]="Pistolas",["Rifles"]="Rifles",["Simple Weapons"]="Armas Simples"
}

M.exact={
["Human"]="Humano",["Droid"]="Droide",["Beast"]="Fera",["Noble"]="Nobre",["Scoundrel"]="Malandro",
["Scout"]="Batedor",["Soldier"]="Soldado",["Nonheroic"]="Não Heroico",
["Force Sensitivity"]="Sensibilidade à Força",["Force Training"]="Treinamento na Força",
["Point Blank Shot"]="Tiro à Queima-Roupa",["Dastardly Strike"]="Ataque Covarde",
["Skill Focus"]="Foco em Perícia",["Skill Training"]="Treinamento em Perícia",
["Weapon Focus"]="Foco em Arma",["Weapon Proficiency"]="Proficiência com Arma",
["Exotic Weapon Proficiency"]="Proficiência com Arma Exótica",["Move Object"]="Mover Objeto",
["Accelerated Strike"]="Ataque Acelerado",["Acrobatic Ally"]="Aliado Acrobático",["Acrobatic Dodge"]="Esquiva Acrobática",
["Acrobatic Strike"]="Ataque Acrobático",["Adaptable Talent"]="Talento Adaptável",["Advantageous Attack"]="Ataque Vantajoso",
["Advantageous Cover"]="Cobertura Vantajosa",["Aiming Accuracy"]="Precisão ao Mirar",["Angled Throw"]="Arremesso Angular",
["Anointed Hunter"]="Caçador Consagrado",["Artillery Shot"]="Tiro de Artilharia",["Assault"]="Assalto",
["Assured Attack"]="Ataque Seguro",["Attack Combo (Fire and Strike)"]="Combo de Ataque (Disparo e Golpe)",
["Attack Combo (Melee)"]="Combo de Ataque (Corpo a Corpo)",["Attack Combo (Ranged)"]="Combo de Ataque (À Distância)",
["Autofire Assault"]="Assalto com Fogo Automático",["Autofire Sweep"]="Varredura com Fogo Automático",
["Bad Feeling"]="Mau Pressentimento",["Bantha Herder"]="Condutor de Banthas",["Bantha Rush"]="Investida de Bantha",
["Battering Attack"]="Ataque Demolidor",["Biotech Specialist"]="Especialista em Biotecnologia",
["Biotech Surgery"]="Cirurgia Biotecnológica",["Blaster Barrage"]="Barragem de Blaster",["Bone Crusher"]="Esmagador de Ossos",
["Brilliant Defense"]="Defesa Brilhante",["Brink of Death"]="À Beira da Morte",["Burst Fire"]="Rajada",
["Burst of Speed"]="Explosão de Velocidade",["Careful Shot"]="Tiro Cuidadoso",["Channel Rage"]="Canalizar Fúria",
["Charging Fire"]="Disparo em Investida",["Cleave"]="Trespassar",["Close Combat Escape"]="Escape de Combate Corpo a Corpo",
["Collateral Damage"]="Dano Colateral",["Combat Reflexes"]="Reflexos de Combate",["Combat Trickery"]="Truques de Combate",
["Conditioning"]="Condicionamento",["Controlled Rage"]="Fúria Controlada",["Coordinated Attack"]="Ataque Coordenado",
["Coordinated Barrage"]="Barragem Coordenada",["Cornered"]="Encurralado",["Critical Strike"]="Golpe Crítico",
["Crossfire"]="Fogo Cruzado",["Crush"]="Esmagar",["Cunning Attack"]="Ataque Astuto",["Cut the Red Tape"]="Cortar a Burocracia",
["Cybernetic Surgery"]="Cirurgia Cibernética",["Damage Conversion"]="Conversão de Dano",["Deadeye"]="Olho Mortal",
["Deadly Sniper"]="Atirador Letal",["Deceptive Drop"]="Queda Enganosa",["Deft Charge"]="Investida Ágil",
["Demoralizing Strike"]="Golpe Desmoralizante",["Desperate Gambit"]="Gambito Desesperado",["Destructive Force"]="Força Destrutiva",
["Disabler"]="Incapacitar",["Distracting Droid"]="Droide Distrativo",["Disturbing Presence"]="Presença Perturbadora",
["Dive for Cover"]="Mergulho para Cobertura",["Dodge"]="Esquiva",["Double Attack"]="Ataque Duplo",
["Dreadful Countenance"]="Semblante Terrível",["Dreadful Rage"]="Fúria Terrível",["Droid Focus"]="Foco em Droide",
["Droid Hunter"]="Caçador de Droides",["Droid Shield Mastery"]="Domínio de Escudos de Droide",["Droidcraft"]="Engenharia de Droides",
["Dual Weapon Mastery I"]="Domínio de Duas Armas I",["Dual Weapon Mastery II"]="Domínio de Duas Armas II",
["Dual Weapon Mastery III"]="Domínio de Duas Armas III",["Duck and Cover"]="Abaixar e Procurar Cobertura",
["Echani Training"]="Treinamento Echani",["Elder's Knowledge"]="Conhecimento dos Anciãos",["Erratic Target"]="Alvo Errático",
["Experienced Medic"]="Médico Experiente",["Expert Briber"]="Subornador Especialista",["Expert Droid Repair"]="Reparo Especializado de Droides",
["Extra Rage"]="Fúria Extra",["Extra Second Wind"]="Segundo Fôlego Extra",["Far Shot"]="Tiro Distante",
["Fast Surge"]="Surto Rápido",["Fatal Hit"]="Golpe Fatal",["Feat of Strength"]="Proeza de Força",
["Fight Through Pain"]="Lutar Através da Dor",["Flash and Clear"]="Ofuscar e Limpar",["Fleet-Footed"]="Pés Ligeiros",
["Flood of Fire"]="Chuva de Disparos",["Flurry"]="Rajada de Golpes",["Focused Rage"]="Fúria Focada",
["Follow Through"]="Prosseguir o Golpe",["Force Boon"]="Dádiva da Força",["Force of Personality"]="Força de Personalidade",
["Force Readiness"]="Prontidão da Força",["Force Regimen Mastery"]="Domínio de Regimes da Força",
["Block"]="Bloquear",["Deflect"]="Defletir",["Redirect Shot"]="Redirecionar Disparo",["Lightsaber Defense"]="Defesa com Sabre de Luz",
["Lightsaber Throw"]="Arremesso de Sabre de Luz",["Battle Meditation"]="Meditação de Batalha",
["Force Persuasion"]="Persuasão pela Força",["Master Negotiator"]="Negociador Mestre",["Defensive Acuity"]="Acuidade Defensiva",
["Elusive Target"]="Alvo Esquivo",["Hold the Line"]="Manter a Linha",["Mobile Combatant"]="Combatente Móvel",
["Dark Side Sense"]="Sentir o Lado Sombrio",["Dark Side Bane"]="Flagelo do Lado Sombrio",["Dark Side Scourge"]="Açoite do Lado Sombrio",
["Sense Primal Force"]="Sentir a Força Primal",["Sentinel Strike"]="Golpe da Sentinela",["Dark Retaliation"]="Retaliação Sombria",
["Sentinel's Gambit"]="Gambito da Sentinela",["Sentinel's Observation"]="Observação da Sentinela",
["Influence Savant"]="Especialista em Influência",["Telekinetic Savant"]="Especialista em Telecinese",
["Telekinetic Prodigy"]="Prodígio Telecinético",["Telepathic Link"]="Ligação Telepática",["Telepathic Influence"]="Influência Telepática"
}
function M.name(x)
    if x==nil then return "" end
    local original=tostring(x.name or "")
    return M.cleanPt(tostring(M.exact[original] or x.name_pt or original))
end

function M.names(list)
    local r={}
    for _,x in ipairs(list or {}) do
        local original=tostring(x.name or "")
        if original~="" and original~="None" then r[#r+1]=M.name(x) end
    end
    return r
end

function M.values(list)
    local r={}
    for _,x in ipairs(list or {}) do
        local original=tostring(x.name or "")
        if original~="" and original~="None" then r[#r+1]=original end
    end
    return r
end

function M.field(x,key)
    if x==nil then return "" end
    local original=tostring(x[key] or "")
    if key=="group" then
        local g=M.groups[original] or M.groups[string.lower(original)]
        if g~=nil then return g end
    end
    if key=="type" then
        if original=="M" then return "Corpo a Corpo" end
        if original=="R" then return "À Distância" end
    end
    if key=="range" then
        local low=string.lower(original)
        if low=="melee" then return "Corpo a Corpo" end
        if low=="ranged" then return "À Distância" end
        if low=="thrown" then return "Arremesso" end
    end
    local p=x[key.."_pt"]
    if p~=nil and tostring(p)~="" then return M.cleanPt(p) end
    return M.cleanPt(x[key] or "")
end

function M.list(x,key)
    if x==nil then return {} end
    local p=x[key.."_pt"]
    if type(p)=="table" then return p end
    return x[key] or {}
end
local function findByName(list,name)
    for _,x in ipairs(list or {}) do if tostring(x.name or "")==tostring(name or "") then return x end end
    return nil
end

function M.option(value,catalog)
    local s=tostring(value or "")
    if M.skills[s] then return M.skills[s] end
    if M.groups[s] then return M.groups[s] end
    if M.groups[string.lower(s)] then return M.groups[string.lower(s)] end
    if M.exact[s] then return M.exact[s] end
    local w=catalog and findByName(catalog.weapons,s) or nil
    if w then return M.name(w) end
    return s
end

function M.optionItems(list,catalog)
    local r={}
    for i,v in ipairs(list or {}) do r[i]=M.option(v,catalog) end
    return r
end

function M.featName(name,catalog)
    local s=tostring(name or "")
    if M.exact[s] then return M.exact[s] end
    local base,opt=string.match(s,"^(.-) %((.-)%)$")
    if base~=nil then
        local basePt=M.exact[base] or base
        return basePt.." ("..M.option(opt,catalog)..")"
    end
    if catalog and catalog.feats then
        local x=findByName(catalog.feats,s)
        if x then return M.name(x) end
    end
    return s
end

function M.cleanPt(value)
    local s=tostring(value or "")
    local r={
      {"pontuações de habilidade","valores de atributo"},{"pontuação de habilidade","valor de atributo"},
      {"escores de habilidade","valores de atributo"},{"escore de habilidade","valor de atributo"},
      {"escores de capacidade","valores de atributo"},{"pontuações de capacidade","valores de atributo"},
      {"escore de capacidade","valor de atributo"},{"pontuação de capacidade","valor de atributo"},
      {"ability scores","valores de atributo"},{"ability score","valor de atributo"},
      {"skill checks","testes de perícia"},{"skill check","teste de perícia"},
      {"ability checks","testes de atributo"},{"ability check","teste de atributo"},
      {"attack rolls","jogadas de ataque"},{"attack roll","jogada de ataque"},
      {"rerolls","novas rolagens"},{"reroll","nova rolagem"},
      {"dróides","droides"},{"dróide","droide"},
      {"pista de condição","trilha de condição"},{"condition track","trilha de condição"},
      {"Damage Threshold","Limiar de Dano"},{"damage threshold","Limiar de Dano"},
      {"Damage Reduction","Redução de Dano"},{"damage reduction","Redução de Dano"},
      {"Reflex Defense","Defesa de Reflexos"},{"reflex defense","Defesa de Reflexos"},
      {"Fortitude Defense","Defesa de Fortitude"},{"fortitude defense","Defesa de Fortitude"},
      {"Will Defense","Defesa de Vontade"},{"will defense","Defesa de Vontade"},
      {"Defesa reflexa","Defesa de Reflexos"},{"Defesa Reflexa","Defesa de Reflexos"},
      {"Defesa de fortitude","Defesa de Fortitude"},{"Defesa de vontade","Defesa de Vontade"},
      {"Force Points","Pontos da Força"},{"Force Point","Ponto da Força"},
      {"Destiny Points","Pontos de Destino"},{"Destiny Point","Ponto de Destino"},
      {"Dark Side Score","Pontuação do Lado Sombrio"},
      {"Second Wind","Segundo Fôlego"},{"second wind","segundo fôlego"},
      {"Hit Points","Pontos de Vida"},{"hit points","pontos de vida"},
      {"Standard Action","Ação Padrão"},{"standard action","ação padrão"},
      {"Move Action","Ação de Movimento"},{"move action","ação de movimento"},
      {"Swift Action","Ação Rápida"},{"swift action","ação rápida"},
      {"Full-Round Action","Ação de Rodada Completa"},{"full-round action","ação de rodada completa"},
      {"Free Action","Ação Livre"},{"free action","ação livre"},
      {"Attack of Opportunity","Ataque de Oportunidade"},{"attack of opportunity","ataque de oportunidade"},
      {"attacks of opportunity","ataques de oportunidade"},
      {"cover bonus","bônus de cobertura"},{"%f[%a]Cover%f[%A]","Cobertura"},{"%f[%a]cover%f[%A]","cobertura"},
      {"%f[%a]Concealment%f[%A]","Ocultação"},{"%f[%a]concealment%f[%A]","ocultação"},
      {"trained skill","perícia treinada"},{"untrained skill","perícia não treinada"},
      {"Weapon Proficiency","Proficiência com Arma"},{"Skill Focus","Foco em Perícia"},
      {"Skill Training","Treinamento em Perícia"},{"Force Sensitivity","Sensibilidade à Força"},
      {"Force Training","Treinamento na Força"},
      {"Use the Force","Usar a Força"},{"Use Computer","Usar Computador"},{"Treat Injury","Tratar Ferimentos"},
      {"Gather Information","Obter Informações"},{"Point Blank Shot","Tiro à Queima-Roupa"},
      {"Lesão de Tratamento","Tratar Ferimentos"},{"Tratar lesões","Tratar Ferimentos"},{"tratar lesões","Tratar Ferimentos"},
      {"Perseverança","Resistência"},{"Enganar","Enganação"},{"Recolha de Informações","Obter Informações"},{"Recolha informações","Obter Informações"},
      {"recolha informações","Obter Informações"},{"saber galáctico","História Galáctica"},{"Lore Galáctico","História Galáctica"},
      {"pontos de ataque","Pontos de Vida"},{"Pontos de ataque","Pontos de Vida"},{"1 morte de dano","1 dado de dano"},{"morte de dano","dado de dano"},
      {"bônus de circunstâncias","bônus de circunstância"},{"cheques","testes"},{"cheque","teste"},
      {"verificações","testes"},{"verificação","teste"},{"Passeio","Cavalgar"},{"Nade","Natação"},
      {"furtivo","Furtividade"},{"furtar","Furtividade"},
      {"habilidades","perícias"},{"habilidade","perícia"},
      {" DC "," CD "},{" DC."," CD."},{" DC,"," CD,"},{"DC ","CD "},
      {"lightsabers","sabres de luz"},{"lightsaber","sabre de luz"},
      {"melee attack","ataque corpo a corpo"},{"ranged attack","ataque à distância"},
      {"melee weapon","arma corpo a corpo"},{"ranged weapon","arma à distância"},
      {"critical hit","acerto crítico"},{"%f[%a]critical%f[%A]","crítico"},
      {"damage roll","rolagem de dano"},{"%f[%a]damage%f[%A]","dano"},
      {"%f[%a]prerequisite%f[%A]","pré-requisito"},{"%f[%a]Prerequisite%f[%A]","Pré-requisito"},
      {"%f[%a]benefit%f[%A]","benefício"},{"%f[%a]Benefit%f[%A]","Benefício"},
      {"%f[%a]special%f[%A]","especial"},{"%f[%a]Special%f[%A]","Especial"}
    }
    for _,x in ipairs(r) do s=string.gsub(s,x[1],x[2]) end
    return s
end

return M
