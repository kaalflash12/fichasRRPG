return {
    force_powers={
        {
            name="Ballistakinesis",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic="Telecinético"
        },
        {
            name="Ataque de Batalha",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Cego",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic="Telecinético"
        },
        {
            name="Cloak",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Combustão",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Convecção",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Corrupção",
            light_side="",
            dark_side="Lado Sombrio",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Crucitário",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Criocinese",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Raiva Escura",
            light_side="",
            dark_side="Lado Sombrio",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Transferência Escura",
            light_side="",
            dark_side="Lado Sombrio",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Detonar",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic="Telecinético"
        },
        {
            name="Drenar Energia",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Resistência à energia",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Iluminar",
            light_side="",
            dark_side="",
            mind_affecting="Afeta a Mente",
            telekinetic=""
        },
        {
            name="Farseeing",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Medo",
            light_side="",
            dark_side="Lado Sombrio",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Dobrar o Espaço",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Forçar Explosão",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Forçar a Desarmar",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic="Telecinético"
        },
        {
            name="Forçar o Aperto",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic="Telecinético"
        },
        {
            name="Forçar a Luz",
            light_side="Lado Luminoso",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Forçar o relâmpago",
            light_side="",
            dark_side="Lado Sombrio",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Forçar o Grito",
            light_side="",
            dark_side="Lado Sombrio",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Escudo de força",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic="Telecinético"
        },
        {
            name="Forçar o Slam",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic="Telecinético"
        },
        {
            name="Forçar Tempestade",
            light_side="",
            dark_side="Lado Sombrio",
            mind_affecting="",
            telekinetic="Telecinético"
        },
        {
            name="Força Tempestade (JATM)",
            light_side="",
            dark_side="Lado Sombrio",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Forçar o Stun",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Forçar o Impulso",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic="Telecinético"
        },
        {
            name="Forçar a Faixa",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Forçar o vento",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic="Telecinético"
        },
        {
            name="Ódio",
            light_side="",
            dark_side="Lado Sombrio",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Inertia",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Inspirar",
            light_side="Lado Luminoso",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Intercepto",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic="Telecinético"
        },
        {
            name="Ionizar",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Combate cinético",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic="Telecinético"
        },
        {
            name="Levitate",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic="Telecinético"
        },
        {
            name="Explosão de raios",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Malacia",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Passeio da Memória",
            light_side="",
            dark_side="Lado Sombrio",
            mind_affecting="Afeta a Mente",
            telekinetic=""
        },
        {
            name="Mente Shard",
            light_side="",
            dark_side="",
            mind_affecting="Afeta a Mente",
            telekinetic=""
        },
        {
            name="Trick Mental",
            light_side="",
            dark_side="",
            mind_affecting="Afeta a Mente",
            telekinetic=""
        },
        {
            name="Morichro",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Mover Objeto",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic="Telecinético"
        },
        {
            name="Negar a Energia",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Obscuro",
            light_side="",
            dark_side="",
            mind_affecting="Afeta a Mente",
            telekinetic=""
        },
        {
            name="Fase",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Surge da Planta",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Presciência",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Rebuke",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Rend",
            light_side="",
            dark_side="Lado Sombrio",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Repulsa",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Resista à força",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Força de Separação",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Ponto de Shatter",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Devagar",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic="Telecinético"
        },
        {
            name="Stagger",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic="Telecinético"
        },
        {
            name="Surge",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Tecnologia",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Bomba de Pensamento",
            light_side="",
            dark_side="",
            mind_affecting="Afeta a Mente",
            telekinetic=""
        },
        {
            name="Valor",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Transferência Vital",
            light_side="Lado Luminoso",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Ferida",
            light_side="",
            dark_side="Lado Sombrio",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Formas de sabre de luz",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Greve Assegurada",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Barreira de Lâminas",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Círculo de Abrigo",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Oportunidade Contenciosa",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Desvio do Slash",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Desarmando o Slash",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Desenhar mais perto",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic="Telecinético"
        },
        {
            name="Avalanche Caindo",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Riposte Fluído",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Swoop Hawk-Bat",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Defesa de Alto Terreno",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Makashi Riposte",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Passe a lâmina",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Empurrando Slash",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic="Telecinético"
        },
        {
            name="Vento de vento ascendente",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Sabre Enxame",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Sarlacc Sweep",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Deflexão Shien",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Flank Swift",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Agressão Temperada",
            light_side="",
            dark_side="Lado Sombrio",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Greve Gêmea",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Bloco de Equilíbrio",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Carga Livre",
            light_side="",
            dark_side="",
            mind_affecting="",
            telekinetic=""
        },
        {
            name="Ferocidade de Vornskr",
            light_side="",
            dark_side="Lado Sombrio",
            mind_affecting="",
            telekinetic=""
        }
    },
    force_techniques={
        {
            name="Transferência Vital Avançado"
        },
        {
            name="Curar a Doença"
        },
        {
            name="Destoxificar o Veneno"
        },
        {
            name="Dominar a Mente"
        },
        {
            name="Cego Estendido"
        },
        {
            name="Desarme de Força Estendido"
        },
        {
            name="Aperto de força estendido"
        },
        {
            name="Impulso de Força Estendido"
        },
        {
            name="Objeto de movimento estendido"
        },
        {
            name="Recuperação de pontos de força"
        },
        {
            name="Forçar o domínio do poder"
        },
        {
            name="Melhor Ballistakinesis"
        },
        {
            name="Ataque de batalha melhorado"
        },
        {
            name="Cloak Melhorado"
        },
        {
            name="Convecção Melhorada"
        },
        {
            name="Crucificado Melhor"
        },
        {
            name="Criocinese melhorada"
        },
        {
            name="Maior Raiva Escura"
        },
        {
            name="Transferência escura melhorada"
        },
        {
            name="Detonar Melhor"
        },
        {
            name="Melhor resistência energética"
        },
        {
            name="Iluminar Melhor"
        },
        {
            name="Espaço de dobra melhorado"
        },
        {
            name="Desarmamento da Força Melhorada"
        },
        {
            name="Aperto de força melhorado"
        },
        {
            name="Luz de força melhorada"
        },
        {
            name="Relâmpago de Força Melhorado"
        },
        {
            name="Escudo de força melhorado"
        },
        {
            name="Slam de Força Melhorada"
        },
        {
            name="Tempestade de Força Melhorada"
        },
        {
            name="Tempestade de Força Melhorada (JATM)"
        },
        {
            name="Força aprimorada"
        },
        {
            name="Impulso de Força Melhorado"
        },
        {
            name="Força de Trance Melhorada"
        },
        {
            name="Ionizar Melhor"
        },
        {
            name="Melhor combate cinético"
        },
        {
            name="Melhor Levitate"
        },
        {
            name="Explosão de raios melhorada"
        },
        {
            name="Malacia Melhorada"
        },
        {
            name="Trick Mental Melhorado"
        },
        {
            name="Objeto de luz de movimento melhorado"
        },
        {
            name="Obscuro Melhorado"
        },
        {
            name="Fase Melhorada"
        },
        {
            name="Surge de Planta Melhorada"
        },
        {
            name="Rebuke melhorado"
        },
        {
            name="Renda Melhorada"
        },
        {
            name="Repulsão Melhorada"
        },
        {
            name="Força de resistência melhorada"
        },
        {
            name="Força de Sentido Melhorada"
        },
        {
            name="Entornos de Sentido Melhor"
        },
        {
            name="Melhor Shatterpoint"
        },
        {
            name="Melhor Stagger"
        },
        {
            name="Tecnologia melhorada"
        },
        {
            name="Telepatia Melhorada"
        },
        {
            name="Bomba de pensamento melhorada"
        },
        {
            name="Valor Melhorado"
        },
        {
            name="Transferência vital melhorada"
        },
        {
            name="Absorção da Língua"
        }
    },
    force_secrets={
        {
            name="Poder Corrompido"
        },
        {
            name="Poder Debilitante"
        },
        {
            name="Poder Devastador"
        },
        {
            name="Poder Distante"
        },
        {
            name="Potência Aumentada"
        },
        {
            name="Aumentar a Potência"
        },
        {
            name="Holocron Loremaster"
        },
        {
            name="Poder Ligado"
        },
        {
            name="Mentor"
        },
        {
            name="Potência Multialvo"
        },
        {
            name="Poder Puro"
        },
        {
            name="Aumentar a Potência"
        },
        {
            name="Potência remota"
        },
        {
            name="Potência Formada"
        },
        {
            name="Potência Incondicional"
        }
    }
}
