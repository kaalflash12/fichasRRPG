return {
    feats={
        {
            prerequisites="Dodge, Combate Veicular",
            category="Acções Especiais",
            description="Ganhe +2 para defesa de veículos colossais ou menores, e ataques de projéteis que perdem seu veículo por 5 ou mais autodestruição",
            name="Algumas manobras"
        },
        {
            prerequisites="BAB +6",
            category="Opções de Att",
            description="Uma vez por encontro, tomar uma ação de ataque completo com armas proficientes como uma ação padrão",
            name="Greve acelerada"
        },
        {
            prerequisites="Dex 13, Str 13, treinado na habilidade Acrobacias",
            category="",
            description="Levante ou jogue um aliado do seu tamanho ou smal ler até 2 uares quadrados.",
            name="Aliado acrobático"
        },
        {
            prerequisites="Dex 13, Dodge, Mobilidade, Skill Focus (Acrobatics), treinado na habilidade Acrobatics",
            category="",
            description="Quando um ataque melee mi sses você, mover-se em um squa re adjacente sem provocar um ataque de oportunidade.",
            name="Dodge acrobático"
        },
        {
            prerequisites="Treinado em Acrobacias",
            category="Opções de Att",
            description="Ganhe +2 bônus no próximo ataque contra o oponente você cair passado",
            name="Ataque acrobático"
        },
        {
            prerequisites="",
            category="",
            description="Ganhar acesso a um talento adicional.",
            name="Talento adaptável"
        },
        {
            prerequisites="BAB +1",
            category="Acções Especiais",
            description="Adicionar nível heroico completo aos danos contra alvos que ainda não agiram em combate",
            name="Ataque de vantagem"
        },
        {
            prerequisites="Treinado em Stealth",
            category="",
            description="Não leve nenhum dano de ataques de área enquanto na cobertura",
            name="Capa de Vantagem"
        },
        {
            prerequisites="Droid, Point Blank Shot, preciso tiro, proficiente com arma",
            category="",
            description="Depois de apontar como uma ação completa, ganhar +5 no próximo ataque de arma.",
            name="Apontando Precisão"
        },
        {
            prerequisites="Dex 13",
            category="",
            description="Você pode ignorar cobertura e cobertura melhorada ao lançar uma granada se o seu rolo de ataque exceder uma defesa reflexa de 15",
            name="Lançar Ângulo"
        },
        {
            prerequisites="Espécies nelvaanianas",
            category="Acções Especiais",
            description="Mova 2 ou mais quadrados e ganhe um bônus +1 em ataques com armas lançadas até o final da sua vez.",
            name="Caçador Ungido"
        },
        {
            prerequisites="Proficiência da armadura (média)",
            category="",
            description="Sem penalidade em ataques e sem penalidade de verificação de armaduras enquanto usa armadura pesada",
            name="Proficiência da armadura (pesada)"
        },
        {
            prerequisites="",
            category="",
            description="Nenhuma penalidade em ataques e nenhuma penalidade de verificação de armadura enquanto usa armadura leve",
            name="Proficiência da armadura (luz)"
        },
        {
            prerequisites="Proficiência da armadura (luz)",
            category="",
            description="Sem penalidade em ataques e nenhuma penalidade de verificação de armadura enquanto usa armadura média",
            name="Proficiência da armadura (média)"
        },
        {
            prerequisites="Proficiente com arma usada",
            category="",
            description="Aumentas a eficácia dos teus ataques de armas.",
            name="Tiro de Artilharia"
        },
        {
            prerequisites="Dominância de duplo ataque ou arma dupla, BAB +6",
            category="Opções de Att",
            description="Você pode usar o Ataque Duplo como uma ação padrão ao custo de um Ponto de Força",
            name="Agressão"
        },
        {
            prerequisites="",
            category="Opções de Att",
            description="Rebole o menor dano morre ao fazer um ataque bem sucedido",
            name="Ataque Garantido"
        },
        {
            prerequisites="Combo de ataque (Melee), Combo de ataque (Ranged), BAB +9",
            category="Acções Especiais",
            description="Lidar +1 morrer de dano em melee, desarmado, ou variou ataques até o fim de sua próxima vez depois de bater um inimigo com dois melee consecutiva, desarmado, ou variou ataques.",
            name="Ataque Combo (Fogo e Ataque)"
        },
        {
            prerequisites="Bónus de ataque base +3",
            category="Acções Especiais",
            description="Denuncie +1 morrer de danos em melee ou ataques desarmados até o fim da sua próxima vez depois de atingir um inimigo com dois ataques melee consecutivos ou desarmados.",
            name="Combo de Ataque (Melee)"
        },
        {
            prerequisites="Bónus de ataque base +3",
            category="Acções Especiais",
            description="Deal +1 morre de danos em ataques variados até o final de sua próxima volta depois de atingir um inimigo com dois ataques consecutivos.",
            name="Combo de ataque (em fila)"
        },
        {
            prerequisites="Foco na Arma (arma escolhida)",
            category="Acções Especiais",
            description="Diminuir a penalidade no ataque de auto-fogo e infligir danos extras ao manter fogo nos mesmos quadrados em rodadas consecutivas.",
            name="Agressão de disparo automático"
        },
        {
            prerequisites="Foco na Arma (arma escolhida)",
            category="Acções Especiais",
            description="Varrer uma área ampla ao usar o modo de disparo automático.",
            name="Autofire Sweep"
        },
        {
            prerequisites="",
            category="",
            description="Você pode sempre se mover na rodada surpresa",
            name="Sentimento Ruim"
        },
        {
            prerequisites="Proficiente com arma usada, bônus de ataque base +1",
            category="Opções de Att",
            description="Mova um alvo danificado pelo seu ataque.",
            name="Bantha Herder"
        },
        {
            prerequisites="Str 13, BAB + 1",
            category="Opções de Att",
            description="Empurre o adversário 1 quadrado depois de fazer um ataque melee bem sucedido",
            name="Bantha Rush"
        },
        {
            prerequisites="Bantha Rush, Viagem",
            category="",
            description="Derrube um alvo quando usar Bantha Rush.",
            name="Ataque Batting"
        },
        {
            prerequisites="Treinado em Mecânica",
            category="",
            description="Faça modificações personalizadas na biotecnologia Yuuzhan Vong.",
            name="Especialista em biotecnologia"
        },
        {
            prerequisites="Treinado na habilidade de tratar lesões",
            category="",
            description="Instale uma prótese biotecnológica num ser vivo.",
            name="Cirurgia Biotécnica"
        },
        {
            prerequisites="Ataque coordenado",
            category="",
            description="Se você lidar com danos com um ataque de auto-fogo, seus aliados ganhar um bônus +2 para auto-fogo ataques contra o mesmo alvo",
            name="Barragem Blaster"
        },
        {
            prerequisites="Esmagar, Pino",
            category="",
            description="Mova o oponente danificado -1 passo na pista de condição.",
            name="Crusher de ossos"
        },
        {
            prerequisites="Int 13",
            category="",
            description="Adicione seu bônus de Inteligência à sua Defesa Reflexa como reação.",
            name="Defesa Brilhante"
        },
        {
            prerequisites="",
            category="",
            description="Ataques que matariam seu inimigo reduz-los a pontos de O em vez disso.",
            name="Brinque da morte"
        },
        {
            prerequisites="Proficiência da arma (pesada)",
            category="Opções de Att",
            description="Pegue uma penalidade -5 em um ataque de auto-fogo para ganhar +2 danos de dados",
            name="Explodir o Fogo"
        },
        {
            prerequisites="Treinado na habilidade de perseverança",
            category="Velocidade",
            description="Mover a velocidade duas vezes como uma ação de movimento",
            name="Explosão de Velocidade"
        },
        {
            prerequisites="Ponto em branco, BAB +2",
            category="Opções de Att",
            description="Se você mirar, ganhe +1 bônus no rolo de ataque",
            name="Tiro Cuidadoso"
        },
        {
            prerequisites="Traço da espécie da raiva",
            category="",
            description="Em vez de furioso, ganhar +5 para Defesa de Vontade.",
            name="Raiva de Canal"
        },
        {
            prerequisites="BAB +4",
            category="Opções de Att",
            description="Fazer ataque variado no final de uma carga",
            name="Carregar Fogo"
        },
        {
            prerequisites="Ataque de Energia",
            category="Opções de Att",
            description="Ataque extra melee depois de derrubar o alvo",
            name="Cleave"
        },
        {
            prerequisites="Treinado na habilidade acrobática",
            category="Opções de Att",
            description="Escapar agarrar e atacar",
            name="Fechar a Fuga de Combate"
        },
        {
            prerequisites="Tiro rápido, BAB +6",
            category="Opções de Att",
            description="Ganhe um ataque extra ao atingir o primeiro alvo",
            name="Danos colaterais"
        },
        {
            prerequisites="",
            category="Acções Especiais",
            description="Ganhe ataques adicionais de oportunidade",
            name="Reflexos de Combate"
        },
        {
            prerequisites="Treinado na habilidade de decepção",
            category="",
            description="Gastar duas ações rápidas para fazer Deception verificar para fazer inimigo pé chato.",
            name="Trapaça de Combate"
        },
        {
            prerequisites="Str 13, Con 13",
            category="",
            description="Rebole todas as verificações de habilidades baseadas em Força ou Constituição e adicione bônus de Força à Defesa de Fortitude para uma volta por encontro",
            name="Condicionamento"
        },
        {
            prerequisites="Raiva",
            category="Acções Especiais",
            description="Você pode entrar em raiva como uma ação rápida, e terminar uma rodada depois de declarar que terminou",
            name="Raiva controlada"
        },
        {
            prerequisites="BAB +2",
            category="Acções Especiais",
            description="Sucesso automático com ajuda a outra ação na faixa em branco",
            name="Ataque coordenado"
        },
        {
            prerequisites="Ataque coordenado, BAB +5",
            category="",
            description="Permita que um aliado cause mais danos quando ajudar o ataque dele.",
            name="Barragem coordenada"
        },
        {
            prerequisites="",
            category="",
            description="Quando incapaz de retirar, +2 em ataques",
            name="Encurralado"
        },
        {
            prerequisites="BAB +9, Foco da Arma",
            category="Acções Especiais",
            description="Faça duas ações rápidas consecutivas para aumentar o alcance crítico do seu próximo ataque por 1",
            name="Ataque crítico"
        },
        {
            prerequisites="Ponto em branco tiro, preciso tiro, BAB +6",
            category="",
            description="Se você errar contra um alvo com tampa macia, uma vez por rodada você pode imediatamente fazer um rolo de ataque contra o alvo que fornece a tampa macia.",
            name="Fogo cruzado"
        },
        {
            prerequisites="Pin",
            category="Opções de Att",
            description="Dar dano desarmado ou garra a um oponente preso",
            name="Esmagar"
        },
        {
            prerequisites="",
            category="Opções de Att",
            description="+2 para atacar rolos contra inimigos de pés chatos",
            name="Ataque Acusado"
        },
        {
            prerequisites="Treinado em Conhecimento (burocracia)",
            category="",
            description="Use conhecimento (burocracia) no lugar de reunir informações.",
            name="Cortar a Fita Vermelha"
        },
        {
            prerequisites="Treinado no tratamento da lesão",
            category="",
            description="Instalar uma prótese cibernética em um ser vivo",
            name="Cirurgia cibernética"
        },
        {
            prerequisites="Dróide, Dex 13",
            category="",
            description="Leve danos adicionais no ponto de ataque em vez de mover-se para baixo da pista de condição.",
            name="Conversão de Danos"
        },
        {
            prerequisites="Tiro preciso, BAB +4",
            category="Opções de Att",
            description="Se você mirar, causar danos extras",
            name="Deadeye"
        },
        {
            prerequisites="Atirador, treinado na habilidade Stealth, BAB +9",
            category="Opções de Att",
            description="Quando você faz um ataque variado contra um alvo que não sabe de você, você recebe +2 bônus em seu rolo de ataque e lidar +1 morrer de dano no primeiro ataque cada turno",
            name="Atirador mortal"
        },
        {
            prerequisites="Treinado na habilidade de Iniciativa",
            category="",
            description="Alvos de pés chatos derrubados propensas em rodada surpresa",
            name="Queda Enganadora"
        },
        {
            prerequisites="",
            category="",
            description="Tome ações rápidas, reações e ações livres depois de cobrar antes de sua volta terminar.",
            name="Carga Deft"
        },
        {
            prerequisites="Cha 13",
            category="",
            description="Faça uma verificação de intimidação quando você lidar com danos com um ataque de oportunidade.",
            name="Greve Desmoralizante"
        },
        {
            prerequisites="",
            category="Acções Especiais",
            description="Reroll perdeu o ataque levando uma penalidade para Defesa de Reflexos",
            name="Gambito Desesperado"
        },
        {
            prerequisites="- Não.",
            category="",
            description="Dar danos aos alvos adjacentes quando você danificar objetos e veículos.",
            name="Força Destrutiva"
        },
        {
            prerequisites="Proficiente com arma usada",
            category="",
            description="Ganhe benefícios ao usar certas armas iônicas.",
            name="Desabilitador"
        },
        {
            prerequisites="Droide",
            category="",
            description="Tentar negar inimigos dentro de 6 quadrados sua próxima ação de movimento, com a chance de fazer inimigos de pé plano.",
            name="Distraindo o Dróide"
        },
        {
            prerequisites="Treinado no engano",
            category="",
            description="Faça uma verificação de engano para passar pela área ameaçada sem provocar ataque de oportunidade.",
            name="Presença perturbadora"
        },
        {
            prerequisites="Treinado no Salto",
            category="",
            description="Saltar para se esconder é uma reacção.",
            name="Mergulhar para a Capa"
        },
        {
            prerequisites="Dex 13",
            category="Defesas",
            description="Ganhe um bônus de desvio +1 para Defesa de Reflexos contra um alvo selecionado",
            name="Dodge"
        },
        {
            prerequisites="BAB +6, proficiente com arma",
            category="Opções de Att",
            description="Fazer um ataque extra durante o ataque completo, -5 penalidade para todos os ataques",
            name="Ataque duplo"
        },
        {
            prerequisites="BAB +6, proficiente com arma",
            category="Opções de Att",
            description="Fazer um ataque extra durante o ataque completo, -5 penalidade para todos os ataques",
            name="Ataque duplo"
        },
        {
            prerequisites="BAB +6, proficiente com arma",
            category="Opções de Att",
            description="Fazer um ataque extra durante o ataque completo, -5 penalidade para todos os ataques",
            name="Ataque duplo"
        },
        {
            prerequisites="BAB +6, proficiente com arma",
            category="Opções de Att",
            description="Fazer um ataque extra durante o ataque completo, -5 penalidade para todos os ataques",
            name="Ataque duplo"
        },
        {
            prerequisites="BAB +6, proficiente com arma",
            category="Opções de Att",
            description="Fazer um ataque extra durante o ataque completo, -5 penalidade para todos os ataques",
            name="Ataque duplo"
        },
        {
            prerequisites="BAB +6, proficiente com arma",
            category="Opções de Att",
            description="Fazer um ataque extra durante o ataque completo, -5 penalidade para todos os ataques",
            name="Ataque duplo"
        },
        {
            prerequisites="BAB +6, proficiente com arma",
            category="Opções de Att",
            description="Fazer um ataque extra durante o ataque completo, -5 penalidade para todos os ataques",
            name="Ataque duplo"
        },
        {
            prerequisites="BAB +6, proficiente com arma",
            category="Opções de Att",
            description="Fazer um ataque extra durante o ataque completo, -5 penalidade para todos os ataques",
            name="Ataque duplo"
        },
        {
            prerequisites="Cha 13, membro da tradição Sith",
            category="",
            description="Rerolar Use as verificações de Força e Persuasão para ativar os efeitos do medo",
            name="Terrível Semblante"
        },
        {
            prerequisites="Capacidade de Rage, BAB +1",
            category="Opções de Att",
            description="Bônus de raiva para ataques e danos aumenta para +4",
            name="Terrível Raiva"
        },
        {
            prerequisites="Treinado em mecânica e computador de uso",
            category="",
            description="+1 bônus para certas habilidades e defesas ao lidar com uma classe selecionada de dróide.",
            name="Foco Dróide"
        },
        {
            prerequisites="Treinado em mecânica e computador de uso",
            category="",
            description="+1 bônus para certas habilidades e defesas ao lidar com uma classe selecionada de dróide.",
            name="Foco Dróide"
        },
        {
            prerequisites="Treinado em mecânica e computador de uso",
            category="",
            description="+1 bônus para certas habilidades e defesas ao lidar com uma classe selecionada de dróide.",
            name="Foco Dróide"
        },
        {
            prerequisites="Treinado em mecânica e computador de uso",
            category="",
            description="+1 bônus para certas habilidades e defesas ao lidar com uma classe selecionada de dróide.",
            name="Foco Dróide"
        },
        {
            prerequisites="Treinado em mecânica e computador de uso",
            category="",
            description="+1 bônus para certas habilidades e defesas ao lidar com uma classe selecionada de dróide.",
            name="Foco Dróide"
        },
        {
            prerequisites="Proficiente com arma usada",
            category="Opções de Att",
            description="Dar +2 danos aos inimigos dróides, ou +4 quando usar uma arma iônica.",
            name="Droid Hunter"
        },
        {
            prerequisites="Dróide, equipado com gerador de escudos",
            category="",
            description="Restaurar automaticamente escudos em duas ações rápidas.",
            name="Mastery de escudo dróide"
        },
        {
            prerequisites="Treinado em Mecânica",
            category="",
            description="Reparar um dróide em 10 minutos em vez de 1 hora",
            name="Droidcraft"
        },
        {
            prerequisites="Dex 13, BAB +1",
            category="Opções de Att",
            description="Pegue uma penalidade -5 em ataques ao atacar com duas armas ou ambas as extremidades de uma arma dupla",
            name="Mestre de Armas Duplas I"
        },
        {
            prerequisites="Dex 15, BAB +6, domínio da arma dupla I",
            category="Opções de Att",
            description="Pegue uma penalidade -2 em ataques ao atacar com duas armas ou ambas as extremidades de uma arma dupla",
            name="Domínio de armas duplas II"
        },
        {
            prerequisites="Dex 17, BAB +11, Domínio de Armas Duplas II",
            category="Opções de Att",
            description="Tome uma penalidade sem ataques ao atacar com duas armas ou ambas as extremidades de uma arma dupla",
            name="Domínio de armas duplas III"
        },
        {
            prerequisites="Treinado na habilidade furtiva",
            category="Acções Especiais",
            description="Você mergulha para cobertura quando você evita ataques de área",
            name="Pato e Cobertura"
        },
        {
            prerequisites="Dex 13, Artes Marciais I",
            category="",
            description="Bónus de dupla força para danos. Uma vez por encontro ao lidar com danos desarmados, faça um ataque desarmado contra a defesa de Fortitude para derrubar o oponente propenso",
            name="Formação Echani"
        },
        {
            prerequisites="Habilidade (Conhecimento [ciências sociais]) ou (Conhecimento [saber galáctico])",
            category="",
            description="Substitua uma verificação de competências de Conhecimento (ciências sociais) ou de conhecimentos galácticos para uma verificação de competências relacionada com a Sabedoria.",
            name="Conhecimento do Ancião"
        },
        {
            prerequisites="Dróide, equipado com locomoção pairando ou voando, Dex 13, Dodge",
            category="",
            description="Reduza a velocidade em até 2 quadrados para aumentar o bônus de desvio em até 2 quadrados.",
            name="Alvo Errático"
        },
        {
            prerequisites="BAB +1, escolha uma arma",
            category="",
            description="Enganei uma arma exótica sem pena",
            name="Proficiência com Arma Exótica"
        },
        {
            prerequisites="BAB +1, escolha uma arma",
            category="",
            description="Enganei uma arma exótica sem pena",
            name="Proficiência com Arma Exótica"
        },
        {
            prerequisites="Treinado no tratamento da lesão",
            category="",
            description="Faça cirurgia em múltiplas criaturas simultaneamente.",
            name="Médico experiente"
        },
        {
            prerequisites="Cha 13",
            category="",
            description="Reduza o tempo e o custo das tentativas de suborno.",
            name="Suborno Perito"
        },
        {
            prerequisites="Treinado em Mecânica",
            category="",
            description="Reparar múltiplos dróides simultaneamente",
            name="Reparar Droid Especialista"
        },
        {
            prerequisites="Capacidade de Ira",
            category="",
            description="Raiva uma hora adicional por dia\n\n(Entrar número de vezes tomadas)",
            name="Raiva Extra"
        },
        {
            prerequisites="Treinado em perseverança",
            category="",
            description="Ganhe um segundo vento adicional por dia\n\n(Entrar número de vezes tomadas)",
            name="Vento extra segundo"
        },
        {
            prerequisites="Tiro à Queima-Roupa",
            category="Opções de Att",
            description="Penas de alcance para ataques de curto, médio e longo alcance são reduzidas",
            name="De longe"
        },
        {
            prerequisites="",
            category="",
            description="Pegue o segundo vento como uma ação livre em sua vez.",
            name="Surge Rápido"
        },
        {
            prerequisites="Str 13, Dex 13",
            category="",
            description="Você automaticamente mata um inimigo que reduz para 0 pontos de ataque, e você pode executar um golpe de graça como uma ação padrão",
            name="Atingido Fatal"
        },
        {
            prerequisites="Str 15",
            category="",
            description="Tome 10 ou 20 em uma verificação de força ou verificação de habilidade relacionada por encontro",
            name="Pena de Força"
        },
        {
            prerequisites="- Não.",
            category="",
            description="Use sua defesa de vontade para determinar seu limite de danos.",
            name="Lute pela dor"
        },
        {
            prerequisites="",
            category="",
            description="Ganhe dissimulação contra um alvo que você danificar com uma explosão ou arma de respingo.",
            name="Flash e Limpar"
        },
        {
            prerequisites="Bônus de ataque base +1",
            category="",
            description="Ao carregar, transforme qualquer rolo de ataque natural de 17+ em um ataque crítico.",
            name="Fleche"
        },
        {
            prerequisites="Ataque em Execução",
            category="Velocidade",
            description="+2 velocidade ao fazer um ataque em execução",
            name="Footed Fleet"
        },
        {
            prerequisites="Proficiente com arma usada",
            category="Opções de Att",
            description="Ignore os bônus de desvio e deflexão dos inimigos para a Defesa de Reflexos ao fazer ataques de área com uma arma ativada em fogo automático.",
            name="Inundação de fogo"
        },
        {
            prerequisites="Dex 13",
            category="Opções de Att",
            description="Leve -5 penalidade para Defesa de Reflexos para ganhar +2 bônus para rolos de ataque melee",
            name="Flurry"
        },
        {
            prerequisites="Raiva controlada",
            category="",
            description="Você pode usar todas as habilidades durante uma raiva",
            name="Raiva Focada"
        },
        {
            prerequisites="",
            category="Opções de Att",
            description="Mova-se imediatamente até à sua velocidade depois de reduzir um inimigo para 0 pontos de ataque",
            name="Seguir"
        },
        {
            prerequisites="Força Sensível",
            category="",
            description="Ganhe três pontos de força adicionais em cada nível",
            name="Forçar o Boon"
        },
        {
            prerequisites="Carisma 13",
            category="",
            description="Use a Sabedoria ou Carisma para determinar a Defesa da Vontade.",
            name="Força de Personalidade"
        },
        {
            prerequisites="",
            category="",
            description="Pode gastar Pontos de Força como uma ação gratuita, mesmo que não seja a sua vez",
            name="Forçar a Prontidão"
        },
        {
            prerequisites="Força sensível, treinada em usar a força",
            category="",
            description="Aprenda vários Regimes de Força iguais a 1 + seu modificador Wis (mínimo 1)\n\n(Entrar número de vezes tomadas)",
            name="Domínio do Regime de Força"
        },
        {
            prerequisites="Não é um dróide",
            category="",
            description="Você pode fazer Use as verificações da Força e ter acesso aos talentos da Força",
            name="Sensibilidade à Força"
        },
        {
            prerequisites="Força sensível, treinada em usar a força",
            category="",
            description="Aprenda uma série de poderes de força iguais a 1 + seu modificador Wis (mínimo 1)\n\n(Entrar número de vezes tomadas)",
            name="Treinamento na Força"
        },
        {
            prerequisites="Proficiente com arma usada, bônus de ataque base +1",
            category="",
            description="Mova um alvo danificado pelo ataque de granada.",
            name="Explosão Forte"
        },
        {
            prerequisites="Sensibilidade à Força, Treinamento à Força",
            category="",
            description="Recupere um Poder de força quando pegar um segundo vento.",
            name="Recuperação Forçada"
        },
        {
            prerequisites="Constituição 13",
            category="",
            description="Ganhe pontos de bônus quando você recuperar.",
            name="Fortificando Recuperação"
        },
        {
            prerequisites="Treinado na habilidade de reunir informações",
            category="",
            description="Reduza o multiplicador de custos do mercado negro para objetos licenciados e restritos em 1",
            name="Amigos em lugares baixos"
        },
        {
            prerequisites="Str 13, Cleave, Power Attack, bônus de ataque base +4",
            category="",
            description="Quando você usa a façanha clive, cada inimigo dentro de 6 quadrados e linha de sig ht leva uma penalidade para Reflexa Defesa, verificações de habilidades e rolos de ataque contra você.",
            name="Cleave Assustador"
        },
        {
            prerequisites="",
            category="",
            description="Você não mover para baixo a trilha condição a primeira vez que um ataque excede o seu limiar de dano, e você ganha acesso à árvore de talentos Brawler.",
            name="Treinamento Militar da Aliança Galáctica"
        },
        {
            prerequisites="",
            category="",
            description="Faça a Mecânica e use as verificações do computador mais rápidas que o normal uma vez por encontro",
            name="Cabeça de engrenagem"
        },
        {
            prerequisites="Dex 13",
            category="",
            description="Como uma reação, faça um ataque de agarrar ou agarrar após uma pega falha ou ataque de agarrar feito contra yo u.",
            name="Retirar"
        },
        {
            prerequisites="Proficiente com armadura usada",
            category="",
            description="Aplique o bônus do equipamento da sua armadura na sua defesa de vontade.",
            name="Treinamento do Grande Exército da República"
        },
        {
            prerequisites="",
            category="Opções de Att",
            description="Ganhe um bônus +5 para resistir aos ataques de grapple e grapple.",
            name="Resistência à Grapple"
        },
        {
            prerequisites="Tiro à Queima-Roupa",
            category="",
            description="Ataca dois alvos na linha de visão directa, causando metade dos danos a cada um.",
            name="Tiro de Graz"
        },
        {
            prerequisites="Cleave, BAB +4",
            category="Opções de Att",
            description="Sem limite para clivar ataques cada rodada",
            name="Grande Cleave"
        },
        {
            prerequisites="BAB +1",
            category="Opções de Att",
            description="Refazer um ataque feito com uma arma de veículo.",
            name="Especialista em artilharia"
        },
        {
            prerequisites="Trip, Arma Foco em arma selecionada, Proficiência de Arma em arma selecionada, bônus de ataque base +8",
            category="",
            description="Derrube um inimigo propensa após um ataque bem sucedido de oportunidade, imediatamente termina as ações rema ining do alvo quando também excedendo seu limiar de dano.",
            name="Alto"
        },
        {
            prerequisites="Especialista em Tecnologia",
            category="",
            description="Trocar um traço por outro traço",
            name="Modificação Rápida"
        },
        {
            prerequisites="Foco na Arma (armas pesadas), Proficiência na Arma (armas pesadas)",
            category="",
            description="Adicionar 1 ponto de dano para cada 5 pontos rolados acima da meta Refl ex Defense, além de benefícios adicionais quando você exceder o limite de dano do alvo.",
            name="Heavy Hitter"
        },
        {
            prerequisites="Traço da espécie de mudança de forma",
            category="",
            description="Verificação de decepção para afastar o oponente",
            name="Visagem Hidious"
        },
        {
            prerequisites="Ataque furtivo, tiro rápido ou ataque rápido",
            category="",
            description="Reduza a velocidade do alvo em vez de causar danos adicionais.",
            name="Greve Hobbling"
        },
        {
            prerequisites="Treinado na habilidade mecânica",
            category="",
            description="Atrasar os danos causados a um veículo até ao final da ronda.",
            name="Mantenham-se juntos"
        },
        {
            prerequisites="Treinado na habilidade de usar o computador",
            category="",
            description="Corte todo o tempo de cálculo e use as penalidades do computador pela metade ao fazer a verificação do uso do computador para a astração no emaranhado do hiperespaço. Reduzir o tempo de mapeamento do hiperespaço pela metade.",
            name="Hiperblazer"
        },
        {
            prerequisites="",
            category="",
            description="Negar um efeito que afecte a mente por encontro.",
            name="Treinamento Militar Imperial"
        },
        {
            prerequisites="Traço da espécie de mudança de forma",
            category="",
            description="Mudança de forma para representar uma pessoa específica",
            name="Personagem"
        },
        {
            prerequisites="Con 13",
            category="Acções Especiais",
            description="Mexe-te quando apanhares um segundo vento",
            name="Movimento Impetuoso"
        },
        {
            prerequisites="Deve possuir um implante cibernético",
            category="",
            description="Você não é movido para baixo a trilha condição um passo extra pelo seu implante",
            name="Treinamento de Implantes"
        },
        {
            prerequisites="Str 15, Bantha Rush, BAB +1",
            category="Opções de Att",
            description="Você pode mover seu oponente um número de quadrados de 2 para metade do seu modificador de força",
            name="Melhor corrida Bantha"
        },
        {
            prerequisites="Mobilidade",
            category="Opções de Att",
            description="Você pode carregar sem se mover em linha reta",
            name="Carga Melhorada"
        },
        {
            prerequisites="",
            category="",
            description="O limiar de danos aumenta em 5\n\n(Entrar número de vezes tomadas)",
            name="Limiar de Danos Melhor"
        },
        {
            prerequisites="",
            category="",
            description="Ganhe +1 bônus para todas as defesas",
            name="Defesas Melhoradas"
        },
        {
            prerequisites="Defesa de Melee",
            category="Opções de Att",
            description="Ganhe +5 bônus em ataques melee para desarmar um oponente",
            name="Desarmamento Melhorado"
        },
        {
            prerequisites="Reflexos de Combate, Enganações Oportunísticas",
            category="",
            description="Ataque de sacrifício de oportunidade para reduzir a defesa reflexa do alvo em 5.",
            name="Melhor truque oportunista"
        },
        {
            prerequisites="Ataque Rápido",
            category="Opções de Att",
            description="Leve -5 para atacar para ganhar +2 dados de danos com uma arma leve ou sabre de luz",
            name="Greve rápida melhorada"
        },
        {
            prerequisites="Dex 15, Skill Focus (Decepção), treinado nas habilidades de Decepção e Stealth",
            category="",
            description="Use o Deception para ajudar o seu cheque Stealth a usar o Slealth de Mão; use Stealth para desenhar e palmar uma arma si multaneamente.",
            name="Aperfeiçoamento de mão"
        },
        {
            prerequisites="Proficiência da arma (armas simples)",
            category="",
            description="Tratar armas simples improvisadas, lidar +1d 6 pontos de dano.",
            name="Mestrado em Armas Improvisadas"
        },
        {
            prerequisites="",
            category="Acções Especiais",
            description="Retirar mais rápido quando danificado",
            name="Voo impulsivo"
        },
        {
            prerequisites="Condicionamento",
            category="",
            description="Aumentar as velocidades de escalada e nadar e saltar distância por 2 quadrados e não perder bônus de Dexterity para Defesa de Reflexos ao subir",
            name="Aumento da agilidade"
        },
        {
            prerequisites="Treinado em Percepção",
            category="",
            description="Você pode usar seu modificador de percepção para fazer Gather Information checks, e pode fazer Gather Information checks com circunstâncias favoráveis em metade do tempo",
            name="Infor"
        },
        {
            prerequisites="Proficiente em arma usada, personagem vivo (não um dróide)",
            category="",
            description="Passe um ponto de força para refazer um ataque e ter o melhor resultado.",
            name="Ataque Instintivo"
        },
        {
            prerequisites="Caracter vivo (não é um dróide)",
            category="",
            description="Passe um ponto de força para aumentar todas as defesas em 2 por 1 rodada.",
            name="Defesa Instintiva"
        },
        {
            prerequisites="Treinado na habilidade de persuasão",
            category="",
            description="Quando você intimida com sucesso, o inimigo leva -5 para verificação de habilidades e -2 para ataques para uma rodada.",
            name="Intimidador"
        },
        {
            prerequisites="Cha 13",
            category="",
            description="Adicione seu bônus Carisma à sua defesa de vontade como uma reação.",
            name="Personalidade indomável"
        },
        {
            prerequisites="Dróide com Str 13, ou ciborgue com Con 13",
            category="",
            description="Mova-se apenas -1 passo na pista de condição quando dano iônico exceder o limiar de dano.",
            name="Ion Shielding"
        },
        {
            prerequisites="",
            category="",
            description="Ganhe um ponto de força temporário quando alvo de um aliado do poder ou talento de força.",
            name="Familiaridade Jedi"
        },
        {
            prerequisites="Lightning Draw, treinado na habilidade Stealth",
            category="Opções de Att",
            description="Ataque de oportunidade com arma escondida para maior efeito",
            name="Truque de faca"
        },
        {
            prerequisites="Dex 13, Str 13, Multi- Grab",
            category="Opções de Att",
            description="Você pode bater cabeças de dois oponentes juntos depois de um sucesso multi-garra.",
            name="Knock Heads"
        },
        {
            prerequisites="",
            category="",
            description="Os dróides aliados beneficiam de seus efeitos benéficos que afetam a mente.",
            name="Líder dos Dróides"
        },
        {
            prerequisites="Desenho Rápido",
            category="Opções de Att",
            description="Desenhar e disparar como uma ação padrão",
            name="Desenho de Raios"
        },
        {
            prerequisites="Int 13",
            category="",
            description="Ganhe idiomas bônus iguais a 1 + seu modificador Int (mínimo 1)\n\n(Entrar número de vezes tomadas)",
            name="Linguista"
        },
        {
            prerequisites="Droide",
            category="Acções Especiais",
            description="Uma vez por encontro como reação, ganhe um bônus de moral +2 para uma pontuação de defesa até sua próxima vez",
            name="Atualização lógica: autodefesa"
        },
        {
            prerequisites="Dróide, equipado com processador básico",
            category="",
            description="Troque uma habilidade treinada por uma habilidade não treinada na mosca.",
            name="Atualização Lógica: Troca de Habilidade"
        },
        {
            prerequisites="Dróide, BAB +4",
            category="Acções Especiais",
            description="Uma vez por encontro, use ajuda outra ação para conceder um aliado +5 para atacar",
            name="Atualização Lógica: Táctico"
        },
        {
            prerequisites="",
            category="Opções de Att",
            description="Quando você usa um sabre de luz ou sabre de luz de mão longa você pode tratá-lo como uma arma dupla",
            name="Ataque de Long Haft"
        },
        {
            prerequisites="Carregar Fogo",
            category="Opções de Att",
            description="Ganhe um bônus +2 para o ataque variado e Defesa de Vontade ao usar o Fogo de Carga",
            name="Formação Mandaloriana"
        },
        {
            prerequisites="",
            category="",
            description="Intimidar seus inimigos quando carregar, impedindo personagens adjacentes de fazer ataques de oportunidade e negar o seu alvo seu bônus Dexterity.",
            name="Carga Maniacal"
        },
        {
            prerequisites="",
            category="",
            description="Aumentar os danos de ataques desarmados por um dado passo; ganhar +1 bônus de desvio para Defesa de Reflexos",
            name="Artes marciais I"
        },
        {
            prerequisites="Artes Marciais I, BAB +3",
            category="",
            description="Aumentar os danos de ataques desarmados por um dado passo; ganhar +1 bônus de desvio para Defesa de Reflexos",
            name="Artes marciais II"
        },
        {
            prerequisites="Artes Marciais II, BAB +6",
            category="",
            description="Aumentar os danos de ataques desarmados por um dado passo; ganhar +1 bônus de desvio para Defesa de Reflexos",
            name="Artes marciais III"
        },
        {
            prerequisites="Treinado no engano, Cha 13",
            category="",
            description="Ganhe +5 para criar uma aparência enganosa ou um documento forjado e reduzir a penalidade por correr.",
            name="Mestre do disfarce"
        },
        {
            prerequisites="Ponto em branco tiro, preciso tiro, base ataque bônus +4",
            category="",
            description="Ganhe bônus de cobertura igual ao bônus de cobertura do oponente.",
            name="Escudo de Carne"
        },
        {
            prerequisites="Droid, Artes Marciais I, bônus de ataque base +1",
            category="",
            description="Dê a um inimigo uma penalidade -5 em rolos de ataque e rolos de dano para um round depois de atingi-lo em combate desarmado.",
            name="Artes Marciais Mecânicas"
        },
        {
            prerequisites="Int 13",
            category="Opções de Att",
            description="Bônus de ataque comercial em ataques de melee para um bônus de desvio para Defesa de Reflexos",
            name="Defesa de Melee"
        },
        {
            prerequisites="Con 13, traço de espécie shapeshift, treinado em habilidade de decepção",
            category="",
            description="Mudar o seu tamanho",
            name="Metamorfo"
        },
        {
            prerequisites="Str 13",
            category="Opções de Att",
            description="Gastar duas ações rápidas para lidar com danos extras em melee",
            name="Forte balanço"
        },
        {
            prerequisites="Str 13",
            category="Opções de Att",
            description="Adicione sua Força, bem como seu bônus de Dexterity para atacar rolos com armas lançadas, e aumentar cada categoria de alcance por seu modificador de Força",
            name="Lançar Poderoso"
        },
        {
            prerequisites="Treinado em Acrobacias",
            category="",
            description="Conceda um bónus aos cheques de habilidade dos aliados com a Acrobacias.",
            name="Especialista em Missão (Acrobacias)"
        },
        {
            prerequisites="Treinado em Escalada",
            category="",
            description="Conceda um bónus aos cheques de habilidade não treinados dos aliados com a Escalada.",
            name="Especialista em Missão (Climb)"
        },
        {
            prerequisites="Treinado no engano",
            category="",
            description="Conceda um bónus às verificações de habilidades sem treino dos aliados com o Deception.",
            name="Especialista em Missão (Decepção)"
        },
        {
            prerequisites="Treinado em perseverança",
            category="",
            description="Conceda um bónus aos cheques de habilidade não treinados dos aliados com a Endurance.",
            name="Especialista em Missão (Endurance)"
        },
        {
            prerequisites="Treinados na coleta de informações",
            category="",
            description="Conceda bônus para os cheques de habilidade destreinados dos aliados com Recolher informações.",
            name="Especialista em Missão (Recolher informações)"
        },
        {
            prerequisites="Formação em Iniciativa",
            category="",
            description="Conceda um bónus às verificações de habilidades destreinadas dos aliados com a Iniciativa.",
            name="Especialista em Missão (Iniciativa)"
        },
        {
            prerequisites="Treinado no Salto",
            category="",
            description="Conceda um bónus aos cheques de habilidade não treinados dos aliados com o Jump.",
            name="Especialista em Missão (Jump)"
        },
        {
            prerequisites="Treinado em Conhecimento (Bureaucracy)",
            category="",
            description="Conceda bônus às verificações de habilidades não treinadas dos aliados com o Conhecimento (Bureaucracy).",
            name="Especialista em Missão (Conhecimento (Bureaucracy))"
        },
        {
            prerequisites="Treinado em Conhecimento (Lore Galáctico)",
            category="",
            description="Conceda bônus às verificações de habilidades não treinadas dos aliados com o Knowledge (Galatic Lore).",
            name="Especialista em Missão (Conhecimento (Galático))"
        },
        {
            prerequisites="Treinado em Conhecimento (Ciências da Vida)",
            category="",
            description="Conceda um bônus para os controles de habilidade não treinados dos aliados com o Conhecimento (Ciências da Vida).",
            name="Especialista em Missão (Conhecimento (Ciências da Vida))"
        },
        {
            prerequisites="Formação em Ciências Físicas",
            category="",
            description="Conceda bônus às verificações de habilidades não treinadas dos aliados com o Conhecimento (ciências físicas).",
            name="Especialista em Missão (Conhecimento (ciências físicas))"
        },
        {
            prerequisites="Formação em Ciências Sociais",
            category="",
            description="Conceda bônus aos controles de habilidades não treinados dos aliados com o Conhecimento (Social Sciences).",
            name="Especialista em Missão (Conhecimento (Ciências Sociais))"
        },
        {
            prerequisites="Treinado em Conhecimento (Tática)",
            category="",
            description="Conceda bônus às verificações de habilidades não treinadas dos aliados com o Conhecimento (Tática).",
            name="Especialista em Missão (Conhecimento (Tática))"
        },
        {
            prerequisites="Treinado em Conhecimento (Tecnologia)",
            category="",
            description="Conceda bônus às verificações de habilidades não treinadas dos aliados com Conhecimento (Tecnologia).",
            name="Especialista em Missão (Conhecimento (Tecnologia))"
        },
        {
            prerequisites="Treinado em Mecânica",
            category="",
            description="Conceda um bónus aos cheques de habilidade destreinados dos aliados com a Mecânica.",
            name="Especialista em Missão (Mecânica)"
        },
        {
            prerequisites="Treinado em Percepção",
            category="",
            description="Conceda um bónus às verificações de habilidades sem treino dos aliados com a Percepção.",
            name="Especialista em Missão (Percepção)"
        },
        {
            prerequisites="Treinado em Persuasão",
            category="",
            description="Conceda um bónus aos cheques de habilidade não treinados dos aliados com a Persuasão.",
            name="Especialista em Missão (Persuasão)"
        },
        {
            prerequisites="Treinado em Piloto",
            category="",
            description="Conceda um bónus às verificações de habilidade destreinadas dos aliados com o Pilot.",
            name="Especialista em Missão (Pilot)"
        },
        {
            prerequisites="Treinado em passeio",
            category="",
            description="Conceda um bónus aos cheques de habilidade não treinados dos aliados com o Ride.",
            name="Especialista em Missão (Ride)"
        },
        {
            prerequisites="Treinado em Stealth",
            category="",
            description="Conceda um bónus aos cheques de habilidade não treinados dos aliados com o Stealth.",
            name="Especialista em Missão (Stealth)"
        },
        {
            prerequisites="Treinado na Sobrevivência",
            category="",
            description="Conceda um bónus às verificações de habilidades destreinadas dos aliados com a Sobrevivência.",
            name="Especialista em Missão (Survival)"
        },
        {
            prerequisites="Treinado em natação",
            category="",
            description="Conceda um bónus aos cheques de habilidade não treinados dos aliados com o Swim.",
            name="Especialista em Missão (Natação)"
        },
        {
            prerequisites="Treinado no tratamento da lesão",
            category="",
            description="Conceda bônus para os cheques de habilidades não treinados dos aliados com o tratamento de lesão.",
            name="Especialista em Missão (Tratado de Lesão)"
        },
        {
            prerequisites="Treinado em computador de uso",
            category="",
            description="Conceda um bónus às verificações de habilidades não treinadas dos aliados com o Use Computer.",
            name="Especialista em Missão (Use Computador)"
        },
        {
            prerequisites="Treinado em usar a força",
            category="",
            description="Conceda um bónus às verificações de habilidades destreinadas dos aliados com o Use a Força.",
            name="Especialista em Missão (Use a Força)"
        },
        {
            prerequisites="Dodge",
            category="",
            description="Ganhe +5 Dodge bônus para Reflex Defesa contra alguns ataques de oportunidade",
            name="Mobilidade"
        },
        {
            prerequisites="Treinado em Piloto ou Passeio",
            category="Opções de Att",
            description="Ganhe uma morte de danos em ataques melee montados se seu monte ou veículo moveu sua velocidade",
            name="Greve momentânea"
        },
        {
            prerequisites="Treinado na habilidade Ride",
            category="",
            description="Aumentar a velocidade e evitar ataques ao montar.",
            name="Combate montado"
        },
        {
            prerequisites="Treinado em Piloto ou Passeio",
            category="Acções Especiais",
            description="Redirecionar ataques bem sucedidos contra você para bater em seu monte ou veículo em vez de uma vez por encontro",
            name="Defesa Montada"
        },
        {
            prerequisites="Dodge",
            category="",
            description="Ganhe um bônus para Defesa de Reflexos quando permanecer móvel.",
            name="Alvo em Movimento"
        },
        {
            prerequisites="Dex 13",
            category="Opções de Att",
            description="Você pode pegar dois oponentes como uma ação padrão.",
            name="Multi- Grab"
        },
        {
            prerequisites="Droid, Int 13, proficiente com arma",
            category="",
            description="Você pode espalhar sua ação de mira em várias rodadas consecutivas.",
            name="Multi-Targeting"
        },
        {
            prerequisites="Cha 13",
            category="",
            description="Você lidera uma organização de uma escala igual a metade de seu nível heróico mais seu bônus Carisma, com um +10 para sua pontuação de organização",
            name="Líder Natural"
        },
        {
            prerequisites="Treinado em perseverança",
            category="",
            description="Faça uma verificação de resistência para evitar cair para 0 pontos de ataque.",
            name="Nunca Renda"
        },
        {
            prerequisites="Membro da subespécie Nikto",
            category="",
            description="Reroll Survival verifica no ambiente nativo.",
            name="Sobrevivência de Nikto"
        },
        {
            prerequisites="- Não.",
            category="",
            description="Ganhe um bônus para sua pontuação de classificação e privilégio.",
            name="Treinamento Oficial de Candidatura"
        },
        {
            prerequisites="Reflexos de Combate",
            category="Acções Especiais",
            description="Sacrifício ataque de oportunidade para mover a meia velocidade",
            name="Retirada oportunista"
        },
        {
            prerequisites="- Não.",
            category="",
            description="Ganhar um bônus para ataques de oportunidade com armas variadas.",
            name="Atirador oportunista"
        },
        {
            prerequisites="Reflexos de Combate, Ataque furtivo",
            category="",
            description="Sacrifício ataque de oportunidade para reduzir a defesa reflexa do alvo em 2.",
            name="Truque oportunista"
        },
        {
            prerequisites="",
            category="Opções de Att",
            description="Qualquer tentativa de negar seu ataque leva uma pena -5 no rolo de ataque ou verificação de habilidade.",
            name="Ataque esmagador"
        },
        {
            prerequisites="Pontuação do lado escuro 1+",
            category="",
            description="Adicione metade do seu Lado Sombrio Score para usar as verificações da Força para resistir à detecção.",
            name="Pall do Lado Negro"
        },
        {
            prerequisites="BAB +1",
            category="Opções de Att",
            description="O adversário agarrado está preso por 1 rodada, não pode se mover, e perde seu bônus de Dexterity para Defesa de Reflexos",
            name="Pin"
        },
        {
            prerequisites="Dróide, equipado com garra ou apêndice de mão, bônus de ataque base +1, Pin, Esmagar",
            category="",
            description="Manter Faça a proeza e faça verificações posteriores como uma ação rápida. Aplicar Crush em cada verificação.",
            name="Pincer"
        },
        {
            prerequisites="Droid, Mirando precisão, Ponto em branco tiro, preciso tiro, proficiente com arma",
            category="",
            description="Mover alvo -1 passo na pista de condição quando você bater com Mirar precisão.",
            name="Precisão do Pinpoint"
        },
        {
            prerequisites="Proficiente com arma usada",
            category="",
            description="Ganhe benefícios ao usar certas pistolas.",
            name="Pistoleiro"
        },
        {
            prerequisites="",
            category="Opções de Att",
            description="+1 bônus em ataques variados e danos contra inimigos em branco",
            name="Tiro à Queima-Roupa"
        },
        {
            prerequisites="Con 13",
            category="",
            description="Ganhe +5 para defesa de fortaleza contra veneno, e só leva metade dos danos de venenos",
            name="Resistência Venenosa"
        },
        {
            prerequisites="Str 13",
            category="Opções de Att",
            description="Bónus de ataque comercial para danos em ataques melee (até seu bônus de ataque base)",
            name="Ataque de Energia"
        },
        {
            prerequisites="",
            category="Opções de Att",
            description="Bônus de ataque comercial para danos em ataques variados (até seu bônus de ataque base)",
            name="Explosão de Energia"
        },
        {
            prerequisites="Médio ou superior, BAB+1",
            category="Opções de Att",
            description="Ganhe +2 bônus em seu rolo de ataque ao carregar e lidar com danos extras",
            name="Carga poderosa"
        },
        {
            prerequisites="Raiva",
            category="Opções de Att",
            description="+4 para verificação de força e verificação de habilidade baseada em força enquanto ranger",
            name="Raiva poderosa"
        },
        {
            prerequisites="Tiro à Queima-Roupa",
            category="Opções de Att",
            description="No -5 penalidade por atirar em mimlee",
            name="Tiro preciso"
        },
        {
            prerequisites="Informações 13",
            category="",
            description="Use Dexterity ou Inteligência para determinar a Defesa Reflexa.",
            name="Defesa preditiva"
        },
        {
            prerequisites="Tiro à Queima-Roupa",
            category="Opções de Att",
            description="Ganhe um bônus para atacar rolos quando nenhum de seus aliados estão perto do alvo.",
            name="Tiro Prime"
        },
        {
            prerequisites="BAB +1",
            category="Acções Especiais",
            description="Desenhar a arma como uma ação rápida",
            name="Desenho Rápido"
        },
        {
            prerequisites="",
            category="Acções Especiais",
            description="Uma vez por encontro, tomar 10 em qualquer verificação de habilidade treinada quando apressado, ou tomar 20 em metade do tempo",
            name="Habilidade Rápida"
        },
        {
            prerequisites="Str 15, Crush, Pin, bônus de ataque base +1",
            category="Opções de Att",
            description="Mover um inimigo -1 descer a pista de condição ao usar o feito de esmagamento",
            name="Rancor Crush"
        },
        {
            prerequisites="Dosagem 13",
            category="",
            description="Use a força ou a constituição para determinar a defesa da fortaleza.",
            name="Dosagem Resiliente"
        },
        {
            prerequisites="Dex 15, Desenho Rápido, Foco de Arma (arma escolhida)",
            category="Opções de Att",
            description="Você pode fazer um único ataque variado como uma reação a um ataque variado contra você que falha.",
            name="Devolver Fogo"
        },
        {
            prerequisites="Proficiente com arma usada",
            category="Opções de Att",
            description="Insectos de barbear jogados e bugs thud voltar para sua mão imediatamente.",
            name="Devolvendo Erro"
        },
        {
            prerequisites="",
            category="Opções de Att",
            description="Reagir duas vezes ao mesmo gatilho uma vez por encontro",
            name="Reacção Rápida"
        },
        {
            prerequisites="BAB + 1, proficiente com arma",
            category="Opções de Att",
            description="Pegue uma penalidade -2 em um rolo de ataque variado para lidar +1 morrer de dano",
            name="Tiro Rápido"
        },
        {
            prerequisites="BAB +1, proficiente com arma",
            category="Opções de Att",
            description="Pegue uma penalidade -2 em um rolo de ataque para lidar +1 morrer de dano",
            name="Ataque Rápido"
        },
        {
            prerequisites="",
            category="",
            description="Conceda um bônus adicional +2 a um personagem que você está ajudando com a ajuda de outro",
            name="Rapport"
        },
        {
            prerequisites="Ataque em Execução",
            category="",
            description="Ganhe um bônus de esquiva para Defesa de Reflexos ao usar Running Attack.",
            name="Treinamento Militar Rebelde"
        },
        {
            prerequisites="Treinado em Conhecimento",
            category="",
            description="Você pode rerolar um cheque para uma habilidade de conhecimento com a qual você é treinado uma vez por dia e manter o melhor resultado",
            name="Lembrar"
        },
        {
            prerequisites="",
            category="",
            description="Mova a faixa de condição quando você pegar um segundo vento.",
            name="Recuperando o Surge"
        },
        {
            prerequisites="",
            category="",
            description="Ganhe uso extra de um talento ou façanha 1/encontro.",
            name="Sucesso recorrente"
        },
        {
            prerequisites="Ataque duplo",
            category="Opções de Att",
            description="Sempre que você perder um alvo com arma proficiente, ganhe um bônus de competência +2 em seu próximo ataque contra esse alvo até o fim de sua próxima volta",
            name="Ataque Incansável"
        },
        {
            prerequisites="Ataque duplo",
            category="Opções de Att",
            description="Sempre que você perder um alvo com arma proficiente, ganhe um bônus de competência +2 em seu próximo ataque contra esse alvo até o fim de sua próxima volta",
            name="Ataque Incansável"
        },
        {
            prerequisites="Ataque duplo",
            category="Opções de Att",
            description="Sempre que você perder um alvo com arma proficiente, ganhe um bônus de competência +2 em seu próximo ataque contra esse alvo até o fim de sua próxima volta",
            name="Ataque Incansável"
        },
        {
            prerequisites="Ataque duplo",
            category="Opções de Att",
            description="Sempre que você perder um alvo com arma proficiente, ganhe um bônus de competência +2 em seu próximo ataque contra esse alvo até o fim de sua próxima volta",
            name="Ataque Incansável"
        },
        {
            prerequisites="Ataque duplo",
            category="Opções de Att",
            description="Sempre que você perder um alvo com arma proficiente, ganhe um bônus de competência +2 em seu próximo ataque contra esse alvo até o fim de sua próxima volta",
            name="Ataque Incansável"
        },
        {
            prerequisites="Ataque duplo",
            category="Opções de Att",
            description="Sempre que você perder um alvo com arma proficiente, ganhe um bônus de competência +2 em seu próximo ataque contra esse alvo até o fim de sua próxima volta",
            name="Ataque Incansável"
        },
        {
            prerequisites="Ataque duplo",
            category="Opções de Att",
            description="Sempre que você perder um alvo com arma proficiente, ganhe um bônus de competência +2 em seu próximo ataque contra esse alvo até o fim de sua próxima volta",
            name="Ataque Incansável"
        },
        {
            prerequisites="Ataque duplo",
            category="Opções de Att",
            description="Sempre que você perder um alvo com arma proficiente, ganhe um bônus de competência +2 em seu próximo ataque contra esse alvo até o fim de sua próxima volta",
            name="Ataque Incansável"
        },
        {
            prerequisites="",
            category="",
            description="Uma vez por encontro ganhar DR 10 contra um ataque vindo de onde você tem cobertura",
            name="República Treinamento Militar"
        },
        {
            prerequisites="Bônus de ataque base +1",
            category="",
            description="Ganhe +2 ou +5 para Will Defesa quando você lutar defensivamente.",
            name="Estância de resolução"
        },
        {
            prerequisites="Treinado na habilidade de perseverança",
            category="",
            description="Ganhe ação rápida bônus quando você pegar seu segundo vento",
            name="Resseguro"
        },
        {
            prerequisites="Proficiente com arma usada",
            category="",
            description="Ganhe benefícios ao usar certas espingardas.",
            name="Riflemaster"
        },
        {
            prerequisites="Treinado em escalada ou salto",
            category="",
            description="Melhore suas chances de sucesso com os cheques Escalar ou Saltar.",
            name="Tomador de Riscos"
        },
        {
            prerequisites="Dex 13",
            category="Velocidade",
            description="Mover antes e depois de fazer um ataque",
            name="Ataque em Execução"
        },
        {
            prerequisites="",
            category="",
            description="Mover adversários -1 passo na pista condição quando você entregar um golpe de graça.",
            name="Greve Sádica"
        },
        {
            prerequisites="Ataque duplo",
            category="Opções de Att",
            description="Se você acertar seu alvo com o primeiro ataque de um ataque completo, então você lidar +1 morrer de danos um para o outro ataque bem sucedido",
            name="Ataque Selvagem"
        },
        {
            prerequisites="Ataque duplo",
            category="Opções de Att",
            description="Se você acertar seu alvo com o primeiro ataque de um ataque completo, então você lidar +1 morrer de danos um para o outro ataque bem sucedido",
            name="Ataque Selvagem"
        },
        {
            prerequisites="Ataque duplo",
            category="Opções de Att",
            description="Se você acertar seu alvo com o primeiro ataque de um ataque completo, então você lidar +1 morrer de danos um para o outro ataque bem sucedido",
            name="Ataque Selvagem"
        },
        {
            prerequisites="Ataque duplo",
            category="Opções de Att",
            description="Se você acertar seu alvo com o primeiro ataque de um ataque completo, então você lidar +1 morrer de danos um para o outro ataque bem sucedido",
            name="Ataque Selvagem"
        },
        {
            prerequisites="Ataque duplo",
            category="Opções de Att",
            description="Se você acertar seu alvo com o primeiro ataque de um ataque completo, então você lidar +1 morrer de danos um para o outro ataque bem sucedido",
            name="Ataque Selvagem"
        },
        {
            prerequisites="Ataque duplo",
            category="Opções de Att",
            description="Se você acertar seu alvo com o primeiro ataque de um ataque completo, então você lidar +1 morrer de danos um para o outro ataque bem sucedido",
            name="Ataque Selvagem"
        },
        {
            prerequisites="Ataque duplo",
            category="Opções de Att",
            description="Se você acertar seu alvo com o primeiro ataque de um ataque completo, então você lidar +1 morrer de danos um para o outro ataque bem sucedido",
            name="Ataque Selvagem"
        },
        {
            prerequisites="Ataque duplo",
            category="Opções de Att",
            description="Se você acertar seu alvo com o primeiro ataque de um ataque completo, então você lidar +1 morrer de danos um para o outro ataque bem sucedido",
            name="Ataque Selvagem"
        },
        {
            prerequisites="",
            category="",
            description="Faça uma verificação de percepção para recuperar 30 x o valor do seu resultado em matérias-primas de um veículo ou objeto para uso na construção de um objeto com a aplicação de objeto de construção da Mecânica",
            name="Escavador"
        },
        {
            prerequisites="Dróide ou ciborgue com hardware associado",
            category="",
            description="Compartilhe dados do sensor instantaneamente com um aliado.",
            name="Ligação do sensor"
        },
        {
            prerequisites="",
            category="",
            description="Ganhe um bônus +1 em um rolo de ataque enquanto adjacente a um aliado.",
            name="Treinamento Militar Separatista"
        },
        {
            prerequisites="Con 13, treinada em perseverança",
            category="",
            description="Passe duas ações rápidas para mover +1 passo ao longo da faixa de condição",
            name="Abaná-lo"
        },
        {
            prerequisites="Dróide ou ciborgue com ligação scomp ou ligação de dados diretos semelhantes com o veículo, treinado em Mecânica",
            category="",
            description="Veículo comercial SR por danos causados.",
            name="Surge o Escudo"
        },
        {
            prerequisites="Especialista em Tecnologia",
            category="",
            description="Instalar dois traços",
            name="Dispositivo de Assinatura"
        },
        {
            prerequisites="Treinado em Persuasão",
            category="",
            description="Intimidar uma criatura ou mudar sua atitude como uma ação padrão.",
            name="Língua prateada"
        },
        {
            prerequisites="",
            category="",
            description="Uma vez por encontro ao reduzir um oponente para 0 pontos de ataque ou dano de negócio superior ao limiar de dano, todos os inimigos dentro de seis quadrados levam um -2 para defesas até sua próxima vez",
            name="Treinamento militar Sith"
        },
        {
            prerequisites="",
            category="",
            description="Falhas catastróficas em um desafio de habilidade ocorrem menos frequentemente e com resultados mais leves.",
            name="Desafio de Habilidade: Evitação Catastrófica"
        },
        {
            prerequisites="",
            category="",
            description="Rebole uma terceira verificação de habilidade falhada durante um desafio mal sk e tomar o melhor resultado.",
            name="Desafio de Habilidade: Último Resort"
        },
        {
            prerequisites="",
            category="",
            description="Tratar um desafio de habilidade como se tivesse o efeito de recuperação.",
            name="Desafio de Habilidade: Recuperação"
        },
        {
            prerequisites="",
            category="",
            description="Ganhe +5 bônus de competência em verificações de habilidades com uma habilidade treinada\n\n(Entrar número de vezes tomadas)",
            name="Foco em Perícia"
        },
        {
            prerequisites="",
            category="",
            description="Você se torna treinado em uma habilidade de classe\n\n(Entrar número de vezes tomadas)",
            name="Treinamento em Perícia"
        },
        {
            prerequisites="Dróide pequeno ou maior, equipado com pelo menos dois apêndices adequados, Str 13",
            category="Opções de Att",
            description="Bónus de força tripla para dar errados neste ataque especial.",
            name="Slammer"
        },
        {
            prerequisites="Dodge",
            category="Acções Especiais",
            description="Desvie dois alvos, retire a toda a velocidade.",
            name="Manobra Deslizante"
        },
        {
            prerequisites="Proficiente com arma usada",
            category="",
            description="Ganhe benefícios com certos lançadores e armas esportivas.",
            name="Caçador de esportes"
        },
        {
            prerequisites="",
            category="Opções de Att",
            description="Ao usar uma arma configurada em fogo automático, você pode reduzir a área para 1 quadrado.",
            name="Spray Shot"
        },
        {
            prerequisites="Tiro preciso, BAB +4",
            category="Opções de Att",
            description="Você ignora a capa suave quando faz um ataque variado",
            name="Atirador"
        },
        {
            prerequisites="",
            category="Opções de Att",
            description="Leve -5 penalidade para Defesa de Reflexos até sua próxima volta para ganhar um +2 para variar ataque",
            name="Tiro de Atirador"
        },
        {
            prerequisites="Talento de ataque furtivo ou tiro rápido ou ataque rápido",
            category="Opções de Att",
            description="Esqueça danos extras para empurrar para trás adversário",
            name="Ataque de Agressão"
        },
        {
            prerequisites="Proficiente com arma usada, bônus de ataque base +1",
            category="",
            description="Imponha penalidades aos controles de habilidade inimigos com um ataque bem sucedido.",
            name="Ataque de Agressão (GAW)"
        },
        {
            prerequisites="",
            category="",
            description="Quando se sofre danos, aliados próximos atacam o agressor.",
            name="Fique Alto"
        },
        {
            prerequisites="Especialista em tecnologia, treinada em mecânica",
            category="",
            description="Você é treinado para projetar (e redesenhar) naves estelares",
            name="Desenhador de Naves Estelares"
        },
        {
            prerequisites="Combate veicular, treinado em piloto",
            category="",
            description="Aprenda uma série de manobras de nave estelar iguais a 1 + seu modificador Wis (minumum 1)\n\n(Entrar número de vezes tomadas)",
            name="Táticas da Nave Estelar"
        },
        {
            prerequisites="Treinado na habilidade de perseverança",
            category="Acções Especiais",
            description="Mova 1 descer a pista de condição para reduzir os danos",
            name="Fica acordado"
        },
        {
            prerequisites="Tiro Cuidadoso",
            category="",
            description="Negar o bónus da Dexterity ao Defesa de Reflexos quando estás inclinado e a apontar.",
            name="Posição de estabilização"
        },
        {
            prerequisites="Ataque em Execução",
            category="Opções de Att",
            description="Você pode atacar uma linha de quatro quadrados com um ataque de auto-fogo, ou todos os quadrados que você voar sobre com um jetpack",
            name="Estreito"
        },
        {
            prerequisites="",
            category="",
            description="Roll d8s em vez de d6s quando você gasta um ponto de força",
            name="Forte na Força"
        },
        {
            prerequisites="Especialista em Tecnologia, Int 17, Nível 9",
            category="",
            description="Instalar atualizações superiores de equipamentos",
            name="Tecnologia Superior"
        },
        {
            prerequisites="Str 13, Burst Fire, Proficiência da Arma (pesada)",
            category="Opções de Att",
            description="Alvos mais baixos do que você deve terminar sua próxima vez em cobertura se você usar ajuda outro para impor uma penalidade em um rolo de ataque e exceder sua defesa de vontade",
            name="Fogo de Supressão"
        },
        {
            prerequisites="Treinado no tratamento da lesão",
            category="",
            description="Você pode realizar a cirurgia em 10 minutos em vez de 1 hora",
            name="Perícia cirúrgica"
        },
        {
            prerequisites="Ataque coordenado",
            category="Opções de Att",
            description="+1 para rolos de ataque melee para cada aliado adjacente",
            name="Enxame"
        },
        {
            prerequisites="Reflexos de Combate",
            category="Acções Especiais",
            description="Fazer um ataque de oportunidade e mover 1 quadrado",
            name="Vantagem Tática"
        },
        {
            prerequisites="Táticas da Nave Estelar, Combate Veicular",
            category="Acções Especiais",
            description="Você recupera todas as manobras de nave estelar no final de qualquer rodada você rolar um 20 natural em um rolo de ataque",
            name="Génio Tático"
        },
        {
            prerequisites="Arma Proficiência na arma selecionada, bônus de ataque base +5",
            category="",
            description="Distribua mais 5 pontos de dano contra um alvo dentro de um ataque de área bem-sucedido.",
            name="Área-alvo"
        },
        {
            prerequisites="Treinado em Mecânica",
            category="",
            description="Você pode fazer modificações personalizadas na armadura, armas, veículos, dróides e dispositivos",
            name="Especialista em Tecnologia"
        },
        {
            prerequisites="Viagem",
            category="Opções de Att",
            description="Jogue um oponente amarrado até 1 quadrado além de seu alcance e dano de negócio",
            name="Lançar"
        },
        {
            prerequisites="Dróide pequeno ou maior, equipado com pelo menos dois apêndices com ferramentas",
            category="",
            description="Ganhe +2 para atacar rolos e rolos de dano com apêndices de não-arma em troca de -2 penalidade para Defesa de Reflexos.",
            name="Ferramenta Frenzy"
        },
        {
            prerequisites="",
            category="",
            description="Ganhe +1 ponto de sucesso por nível de caracteres",
            name="Dureza"
        },
        {
            prerequisites="Treinado na habilidade Ride",
            category="",
            description="Ao usar a ação de carga montada, ataque inimigos entre você e seu alvo.",
            name="Atravessar"
        },
        {
            prerequisites="",
            category="Acções Especiais",
            description="Quando você tem cobertura contra os ataques de um inimigo variado, ganhar um bônus + 1 em rolos de ataque contra esse inimigo.",
            name="Guerreiro da Trench"
        },
        {
            prerequisites="BAB +1",
            category="Opções de Att",
            description="Trip um adversário que você lutou, batendo-o propensa",
            name="Viagem"
        },
        {
            prerequisites="BAB +9, Ataque Duplo",
            category="Opções de Att",
            description="Fazer segundo ataque extra durante o ataque completo, penalidade adicional -5 para todos os ataques",
            name="Ataque triplo"
        },
        {
            prerequisites="BAB +9, Ataque Duplo",
            category="Opções de Att",
            description="Fazer segundo ataque extra durante o ataque completo, penalidade adicional -5 para todos os ataques",
            name="Ataque triplo"
        },
        {
            prerequisites="BAB +9, Ataque Duplo",
            category="Opções de Att",
            description="Fazer segundo ataque extra durante o ataque completo, penalidade adicional -5 para todos os ataques",
            name="Ataque triplo"
        },
        {
            prerequisites="BAB +9, Ataque Duplo",
            category="Opções de Att",
            description="Fazer segundo ataque extra durante o ataque completo, penalidade adicional -5 para todos os ataques",
            name="Ataque triplo"
        },
        {
            prerequisites="BAB +9, Ataque Duplo",
            category="Opções de Att",
            description="Fazer segundo ataque extra durante o ataque completo, penalidade adicional -5 para todos os ataques",
            name="Ataque triplo"
        },
        {
            prerequisites="BAB +9, Ataque Duplo",
            category="Opções de Att",
            description="Fazer segundo ataque extra durante o ataque completo, penalidade adicional -5 para todos os ataques",
            name="Ataque triplo"
        },
        {
            prerequisites="BAB +9, Ataque Duplo",
            category="Opções de Att",
            description="Fazer segundo ataque extra durante o ataque completo, penalidade adicional -5 para todos os ataques",
            name="Ataque triplo"
        },
        {
            prerequisites="BAB +9, Ataque Duplo",
            category="Opções de Att",
            description="Fazer segundo ataque extra durante o ataque completo, penalidade adicional -5 para todos os ataques",
            name="Ataque triplo"
        },
        {
            prerequisites="BAB +8, escolha uma arma",
            category="",
            description="Dar triplo dano em um hit crítico",
            name="Crítica Tripla"
        },
        {
            prerequisites="BAB +8, escolha uma arma",
            category="",
            description="Dar triplo dano em um hit crítico",
            name="Crítica Tripla"
        },
        {
            prerequisites="",
            category="Acções Especiais",
            description="Adicione seu bônus de ataque base para o DC acrobacias para cair através de seus quadrados ameaçados",
            name="Defesa do Tumble"
        },
        {
            prerequisites="Dróide, equipado com locomoção pairando, voando, rodando ou rastreando, Dex 13",
            category="",
            description="Retirar limpando quadrados ameaçados em até 2 quadrados de movimento, mova sua velocidade ao usar a ação de retirada. Retirar como reacção gastando um Ponto de Força.",
            name="Virar e queimar"
        },
        {
            prerequisites="Destino",
            category="Opções de Att",
            description="Você pode usar habilidades Livres",
            name="Isenção"
        },
        {
            prerequisites="Vento extra segundo",
            category="",
            description="Apanhar mais de um segundo de vento em um encontro.",
            name="Combatente Imparável"
        },
        {
            prerequisites="",
            category="Opções de Att",
            description="Ganhe um bônus +5 para Defesa de Fortitude e Defesa de Vontade contra qualquer efeito que exija uma verificação Use a Força.",
            name="Força Imparável"
        },
        {
            prerequisites="BAB +2",
            category="",
            description="Sempre que forem alvo de um efeito de medo ou de um efeito que não vos afecte a mente, ganham um Ponto de Força temporário que dura até ao fim do vosso próximo turno. Se você negar o efeito continget de alguma forma, você não ganhar o benefício deste feito",
            name="Resolver por Resposta"
        },
        {
            prerequisites="Treinado em Percepção",
            category="",
            description="Ganhe um bônus +5 para Defesa de Vontade contra Deception e Persuasão cheques.",
            name="Resolver Inquebrável"
        },
        {
            prerequisites="Especialista em Tecnologia, formado em Mecânica",
            category="",
            description="Recarregar escudos ou redirecionar energia em um veículo mais rápido do que o normal.",
            name="Especialização em Sistemas Vechicle"
        },
        {
            prerequisites="Treinado em Piloto",
            category="Acções Especiais",
            description="Negar um ataque por round contra o veículo que você está pilotando",
            name="Combate Veicular"
        },
        {
            prerequisites="Treinado em Piloto",
            category="",
            description="Uma vez por dia, ganhar pontos de bônus para um veículo que você pilotar.",
            name="Surge Veicular"
        },
        {
            prerequisites="Vento extra segundo",
            category="",
            description="Pegue um segundo vento mesmo quando não em ou abaixo dos pontos de impacto.",
            name="Surge Vitalidade"
        },
        {
            prerequisites="",
            category="Acções Especiais",
            description="Ganhe um bônus +2 para Defesa de Fortitude e Defesa de Vontade enquanto luta defensivamente.",
            name="Defensor cauteloso"
        },
        {
            prerequisites="BAB +1",
            category="",
            description="Use o modificador Dex em vez do modificador Str em rolos de ataque com armas leves e sabres de luz",
            name="Finesse da Arma"
        },
        {
            prerequisites="Escolha uma arma",
            category="",
            description="+1 bônus em rolos de ataque com arma selecionada",
            name="Foco em Arma"
        },
        {
            prerequisites="Escolha uma arma",
            category="",
            description="+1 bônus em rolos de ataque com arma selecionada",
            name="Foco em Arma"
        },
        {
            prerequisites="",
            category="",
            description="Ignorar -5 penalidade em rolos de ataque com armas de um tipo particular",
            name="Proficiência com Arma"
        },
        {
            prerequisites="",
            category="",
            description="Ignorar -5 penalidade em rolos de ataque com armas de um tipo particular",
            name="Proficiência com Arma"
        },
        {
            prerequisites="",
            category="",
            description="Ignorar -5 penalidade em rolos de ataque com armas de um tipo particular",
            name="Proficiência com Arma"
        },
        {
            prerequisites="",
            category="",
            description="Ignorar -5 penalidade em rolos de ataque com armas de um tipo particular",
            name="Proficiência com Arma"
        },
        {
            prerequisites="",
            category="",
            description="Ignorar -5 penalidade em rolos de ataque com armas de um tipo particular",
            name="Proficiência com Arma"
        },
        {
            prerequisites="",
            category="",
            description="Ignorar -5 penalidade em rolos de ataque com armas de um tipo particular",
            name="Proficiência com Arma"
        },
        {
            prerequisites="Dex 13, Int 13, Melee Defense, BAB +4",
            category="Opções de Att",
            description="Faça um ataque contra cada oponente ao alcance",
            name="Ataque de vento"
        },
        {
            prerequisites="Ataque Rápido",
            category="Opções de Att",
            description="Ganhar ataque extra em um segundo alvo ao danificar o primeiro alvo",
            name="Greve Má"
        },
        {
            prerequisites="Treinado na habilidade de sobrevivência",
            category="",
            description="Use a habilidade de sobrevivência básica como se você tem um medpac para tratar verificações de lesões.",
            name="Primeiros socorros da natureza"
        },
        {
            prerequisites="BAB +5",
            category="Opções de Att",
            description="Opositores adjacentes não podem retirar-se das praças que você ameaça",
            name="Greve de retirada"
        },
        {
            prerequisites="BAB +5",
            category="Opções de Att",
            description="Opositores adjacentes não podem retirar-se das praças que você ameaça",
            name="Greve de retirada"
        },
        {
            prerequisites="BAB +5",
            category="Opções de Att",
            description="Opositores adjacentes não podem retirar-se das praças que você ameaça",
            name="Greve de retirada"
        },
        {
            prerequisites="BAB +5",
            category="Opções de Att",
            description="Opositores adjacentes não podem retirar-se das praças que você ameaça",
            name="Greve de retirada"
        },
        {
            prerequisites="BAB +5",
            category="Opções de Att",
            description="Opositores adjacentes não podem retirar-se das praças que você ameaça",
            name="Greve de retirada"
        },
        {
            prerequisites="Str 13",
            category="",
            description="Armas de duas mãos numa só mão.",
            name="Wookiee Grip"
        },
        {
            prerequisites="Ponto Tiro em branco",
            category="Opções de Att",
            description="Ganhe um bônus +1 no seu rolo de ataque e negocie +1 danos ao fazer um ataque variado contra um alvo adjacente ou um alvo em seu espaço de luta.",
            name="Intervalo Zero"
        },
        {
            prerequisites="Pré-requisitos",
            category="",
            description="Designação das mercadorias",
            name="Espécie Feat"
        },
        {
            prerequisites="Ewok",
            category="",
            description="Conceda um bónus às defesas de fortaleza dos aliados através da forragem.",
            name="Amplo Forrageamento"
        },
        {
            prerequisites="Cereã",
            category="",
            description="Os inimigos devem rolar duas vezes, mantendo o resultado inferior, sobre os efeitos que afetam a mente.",
            name="Mente binária"
        },
        {
            prerequisites="Bothan",
            category="",
            description="Ganhe um bônus para Defesa de Vontade quando um inimigo não superar sua vontade de ferro.",
            name="Bothan Will"
        },
        {
            prerequisites="Wookiee",
            category="",
            description="Ganhar um bônus para rolos de danos quando você gastar um ponto de força em um ataque Bowcaster.",
            name="Marksman Bowcaster"
        },
        {
            prerequisites="Quarren",
            category="",
            description="Lidar com danos com garras afiadas em ataques desarmados.",
            name="Subespécies com fecho"
        },
        {
            prerequisites="Bothan",
            category="",
            description="Ganhe um ponto de força quando você aprender informações secretas com sucesso.",
            name="Sucesso confiante"
        },
        {
            prerequisites="Sullustano",
            category="",
            description="Imponha uma penalidade aos cheques Stealth feitos perto de você.",
            name="Morador das Trevas"
        },
        {
            prerequisites="Quarren",
            category="",
            description="Ganhar formiga da visão escura ignorar a ocultação da escuridão.",
            name="Visão Profunda"
        },
        {
            prerequisites="Itoriano",
            category="",
            description="Lidar com mais danos com seus ataques de fole.",
            name="Devastador Bellow"
        },
        {
            prerequisites="Sullustano",
            category="",
            description="Ganhe um bônus para verificar habilidades em alvos cuja atitude você melhorou.",
            name="Encantamento Desarmador"
        },
        {
            prerequisites="Mon Calamari",
            category="",
            description="Ganhe um bônus para sua velocidade de natação.",
            name="Nadador Rápido"
        },
        {
            prerequisites="Duros",
            category="",
            description="Rerole os controlos do piloto, mantendo sempre o melhor resultado.",
            name="Piloto sem falhas"
        },
        {
            prerequisites="Ewok",
            category="",
            description="Rerole cheques Stealth, sempre mantendo o melhor resultado.",
            name="Perseguidor Florestal"
        },
        {
            prerequisites="Rodian",
            category="",
            description="Reduzir o multiplicador de custos de itens comprados no mercado negro.",
            name="Benefícios da franja"
        },
        {
            prerequisites="Gungan",
            category="",
            description="Aumentar o tipo de dado ao adicionar aos ataques com um atlatl ou cesta.",
            name="Mestre de Armas Gungan"
        },
        {
            prerequisites="Rodian",
            category="",
            description="Reroll Perception verifica, mantendo sempre o melhor resultado.",
            name="Instintos de Caçador"
        },
        {
            prerequisites="Twi'lek",
            category="",
            description="Aumente o tipo de dado ao adicionar uma verificação de Decepção.",
            name="Mentiroso imperceptível"
        },
        {
            prerequisites="Zabrak",
            category="",
            description="Reduzir um bônus de defesa, mas aumentar outro.",
            name="Resiliência Inata"
        },
        {
            prerequisites="Gamorreano",
            category="",
            description="Ganhe um bônus para a Defesa de Fortitude quando um inimigo não o afetar.",
            name="Resistência aumentada"
        },
        {
            prerequisites="Zabrak",
            category="",
            description="Ganhe um ponto de força temporário quando seu reroll de percepção for menor.",
            name="Percepção Instintiva"
        },
        {
            prerequisites="Twi'lek, Sensibilidade à Força",
            category="",
            description="Ganhar poderes de força extra quando fizeres a façanha de treino da Força.",
            name="Património Jedi"
        },
        {
            prerequisites="Kel Dor",
            category="",
            description="Ganhe um bônus para danificar rolos contra aqueles que prejudicam seus aliados.",
            name="Justice Seeker"
        },
        {
            prerequisites="Ewok",
            category="",
            description="Aumente o alcance de sua capacidade de cheiro para 20 quadrados.",
            name="Perfume Keen"
        },
        {
            prerequisites="Bothan",
            category="",
            description="Após uma verificação de Persuasão bem sucedida, ganhe um bônus para futuras verificações de Persuasão.",
            name="Influência duradoura"
        },
        {
            prerequisites="Rodian",
            category="",
            description="Aumentar o tipo de dado quando adicionar a uma verificação de sobrevivência.",
            name="Rastreador Mestre"
        },
        {
            prerequisites="Cereã",
            category="",
            description="Use Sabedoria em vez de Inteligência para verificação de habilidades baseada em Inteligência.",
            name="Mente de Razão"
        },
        {
            prerequisites="Mon Calamari",
            category="",
            description="Redirecionar a energia mais rapidamente e sem o risco de falha.",
            name="Mon Calamari Shipwright"
        },
        {
            prerequisites="Itoriano",
            category="",
            description="Aumentar o tipo de dado quando adicionar a um teste de Conhecimento (ciências da vida).",
            name="Especialista em Natureza"
        },
        {
            prerequisites="Cereã",
            category="",
            description="Reinicie os controlos da Iniciativa, mantendo sempre o melhor resultado.",
            name="Intuição Perfeita"
        },
        {
            prerequisites="Gungan",
            category="",
            description="Rerole verificações de natação, sempre mantendo o melhor resultado.",
            name="Nadador perfeito"
        },
        {
            prerequisites="Trandoshan",
            category="",
            description="Ganhe pontos bônus sempre que derrubar um inimigo.",
            name="Guerreiro Impiedoso"
        },
        {
            prerequisites="Gamorreano",
            category="",
            description="Lidar +1 morrer de danos com armas simples.",
            name="Guerreiro Primitivo"
        },
        {
            prerequisites="Gamorreano",
            category="",
            description="Recuperar rapidamente depois de ser movido para baixo a trilha de condição por danos.",
            name="Retorno Rápido"
        },
        {
            prerequisites="Kel Dor",
            category="",
            description="Detecta inimigos escondidos dentro de 10 quadrados de ti.",
            name="Leia os Ventos"
        },
        {
            prerequisites="Trandoshan",
            category="",
            description="Recupere mais pontos de ataque (mas mais lentamente) quando você pegar um segundo vento.",
            name="Cura regenerativa"
        },
        {
            prerequisites="Wookiee",
            category="",
            description="Ganhe pontos adicionais ao pegar um segundo vento.",
            name="Vitalidade Ressurgente"
        },
        {
            prerequisites="Kel Dor",
            category="",
            description="Ganhar um bônus para a defesa de fortaleza contra os perigos atmosféricos.",
            name="Scion de Dorin"
        },
        {
            prerequisites="Mon Calamari",
            category="",
            description="Aumentar o tipo de dado ao adicionar a uma verificação de percepção.",
            name="Sentidos afiados"
        },
        {
            prerequisites="Quarren",
            category="",
            description="Suprimir oponentes insight e moral bônus para Defesa de Vontade.",
            name="Negociador astuto"
        },
        {
            prerequisites="Duros",
            category="",
            description="Ganhar um ponto de força temporário quando você rolar um 20 natural em uma verificação Pilot.",
            name="Surge do espaçador"
        },
        {
            prerequisites="Itoriano",
            category="",
            description="Use a sua capacidade de fole sem se mover para baixo da trilha de condição.",
            name="Forte Bellow"
        },
        {
            prerequisites="Sullustano",
            category="",
            description="Ganhe uma velocidade de subida de 4 quadrados.",
            name="Escalador Claro"
        },
        {
            prerequisites="Twi'lek",
            category="",
            description="Faça verificações de sobrevivência para resistir ao calor extremo e frio.",
            name="Sobrevivente de Ryloth"
        },
        {
            prerequisites="Trandoshan",
            category="",
            description="Ganhe um bônus de +2 espécies para sua defesa de fortaleza.",
            name="Pele Espessa"
        },
        {
            prerequisites="Zabrak",
            category="",
            description="Imponha uma penalidade para verificação de habilidades para efeitos que afetam a mente que visam você.",
            name="Foco Inflexível"
        },
        {
            prerequisites="Duros",
            category="",
            description="Ganhe um bônus para usar verificações de computador feitas para astrogata",
            name="Espaçador Veterano"
        },
        {
            prerequisites="Gungan",
            category="",
            description="Ganhe um bônus para Defesa de Vontade ao usar um atlatl ou uma cesta.",
            name="Herança do Guerreiro"
        },
        {
            prerequisites="Wookiee",
            category="",
            description="Ganhar pontos de vitória bônus quando furioso.",
            name="Raiva de Wroshyr"
        },
        {
            prerequisites="Pré-requisitos",
            category="",
            description="Designação das mercadorias",
            name="Artes Marciais Feats"
        },
        {
            prerequisites="Dexterity 13, Artes Marciais I",
            category="",
            description="Bônus de dupla força para danos desarmados; bater alvo propenso.",
            name="Formação Echani"
        },
        {
            prerequisites="Reflexos de Combate, Artes Marciais I",
            category="",
            description="Fazer contra-ataque; impor penalidades aos ataques inimigos.",
            name="Formação Hijkata"
        },
        {
            prerequisites="Artes Marciais I, treinada em Stealth",
            category="",
            description="Dar danos extras contra o inimigo de pés chatos; tornar o alvo mudo.",
            name="Treinamento de K'tara"
        },
        {
            prerequisites="Mestrado em dupla arma I, Artes Marciais I",
            category="",
            description="Fazer ataques desarmados rápidos; lidar com metade dos danos em erros.",
            name="Treinamento K'thri"
        },
        {
            prerequisites="Artes Marciais I, Executando Ataque",
            category="",
            description="Agarre e agarre como uma criatura maior; agarre após carregar.",
            name="Treinamento Stava"
        },
        {
            prerequisites="Dodge, Artes Marciais I, treinado em Iniciativa",
            category="",
            description="Dar mais danos em hits críticos; use Dodge contra inimigos.",
            name="Treinamento Tae-Jitsu"
        },
        {
            prerequisites="Força 13, Artes Marciais I",
            category="",
            description="Trate o limiar de danos do alvo como mais baixo.",
            name="Teräs Käsi Formação"
        },
        {
            prerequisites="Constituição 13, Artes Marciais I, Wookiee",
            category="",
            description="Ganhar pontos de bônus em ataques desarmados; negar bônus de equipamento alvo.",
            name="Formação Wrruushi"
        },
        {
            prerequisites="Pré-requisitos",
            category="",
            description="Designação das mercadorias",
            name="Equipe Feat"
        },
        {
            prerequisites="Treinado em natação",
            category="",
            description="Ganhe bônus para cheques Swim quando perto aliados.",
            name="Especialistas aquáticos"
        },
        {
            prerequisites="Treinado em Escalada",
            category="",
            description="Ganhe bônus para escalar cheques quando perto de aliados.",
            name="Especialistas em Ascensão"
        },
        {
            prerequisites="Treinado em Stealth",
            category="",
            description="Ganhe bônus para cheques Stealth quando perto de aliados.",
            name="Agentes Secretos"
        },
        {
            prerequisites="Treinado no tratamento da lesão",
            category="",
            description="Ganhe bônus para tratar verificações de lesões quando perto de aliados.",
            name="Equipe Médica"
        },
        {
            prerequisites="Treinado em passeio",
            category="",
            description="Ganhe bônus para Ride cheques quando perto de aliados.",
            name="Regimento montado"
        },
        {
            prerequisites="Treinado em Acrobacias",
            category="",
            description="Ganhe bônus para cheques Acrobatics quando perto de aliados.",
            name="Equipe Nimble"
        },
        {
            prerequisites="Treinado em computador de uso",
            category="",
            description="Ganhe bônus para usar verificações de computador quando perto de aliados.",
            name="Equipa de Cortadores"
        },
        {
            prerequisites="Treinado em Mecânica",
            category="",
            description="Ganhe bônus para cheques Mecânicos quando perto aliados.",
            name="Peritos técnicos"
        },
        {
            prerequisites="Treinado em perseverança",
            category="",
            description="Ganhe bônus para verificar Endurance quando perto de aliados.",
            name="Esquadrão Incansável"
        },
        {
            prerequisites="Treinado no Salto",
            category="",
            description="Ganhe bônus para saltar cheques brilham perto de aliados.",
            name="Abordagem sem obstáculos"
        },
        {
            prerequisites="Treinado em Piloto",
            category="",
            description="Ganhe bônus para a Pilot verifica quando perto de aliados.",
            name="Esquadrão Unificado"
        },
        {
            prerequisites="Treinado em Percepção",
            category="",
            description="Ganhe bônus para verificar Percepção quando perto de aliados.",
            name="Sentinelas Cuidadosos"
        },
        {
            prerequisites="Treinado na Sobrevivência",
            category="",
            description="Ganhar bônus para Survival verifica quando próximos aliados.",
            name="Especialistas em Wilderness"
        }
    }
}
