local M={}
local NDB=require("ndb.lua")
local CAT=require("swse_catalog_pt.lua")
local I18N=require("swse_i18n.lua")
local EQUIP=require("swse_inventory_equip.lua")

local function n(v,d) local x=tonumber(v); if x==nil then return d or 0 end; return x end
local function b(v)
    local s=string.lower(tostring(v or ""))
    return s=="true" or s=="1" or s=="yes" or s=="sim"
end
local function decode(v)
    local s=tostring(v or "")
    s=s:gsub("&#(%d+);",function(x)
        local k=tonumber(x)
        if k and k>=0 and k<=0x10ffff and not (k>=0xd800 and k<=0xdfff) then return utf8.char(k) end
        return "&#"..x..";"
    end)
    s=s:gsub("&quot;",'"'):gsub("&apos;","'"):gsub("&lt;","<"):gsub("&gt;",">"):gsub("&amp;","&")
    return s
end
local function strip(s) return tostring(s or ""):gsub("^%s+",""):gsub("%s+$","") end
local function key(v)
    local s=string.lower(decode(v))
    local map={{"á","a"},{"à","a"},{"â","a"},{"ã","a"},{"ä","a"},{"é","e"},{"è","e"},{"ê","e"},{"ë","e"},
               {"í","i"},{"ì","i"},{"î","i"},{"ï","i"},{"ó","o"},{"ò","o"},{"ô","o"},{"õ","o"},{"ö","o"},
               {"ú","u"},{"ù","u"},{"û","u"},{"ü","u"},{"ç","c"}}
    for _,x in ipairs(map) do s=s:gsub(x[1],x[2]) end
    s=s:gsub("—"," "):gsub("–"," "):gsub("%-"," ")
    s=s:gsub("[%(%){%}%[%],%.:;_/\\]"," ")
    s=s:gsub("%s+"," ")
    return strip(s)
end
local function head(xml)
    return tostring(xml or ""):match("<database%s+(.-)>")
end
local function attr(attrs,name)
    if attrs==nil then return "" end
    local s=tostring(attrs)
    local v=s:match("^"..tostring(name)..'="(.-)"')
    if v==nil then v=s:match("%s"..tostring(name)..'="(.-)"') end
    return decode(v or "")
end
local function section(xml,tag)
    return tostring(xml or ""):match("<"..tag.."[^>]*>(.-)</"..tag..">")
end
local function richBackgroundText(xml)
    local sec=section(xml,"background")
    if sec==nil then return "" end
    local best=""
    for raw in sec:gmatch('text="(.-)"') do
        local v=decode(raw)
        if #v>#best then best=v end
    end
    return best
end
local function itemAttrs(xml,tag)
    local out={}
    local sec=section(xml,tag)
    if sec==nil then return out end
    for a in sec:gmatch("<item%s*([^>]*)>") do out[#out+1]=a end
    return out
end
local function ensureList(root,field)
    local list=root[field]
    if not NDB.isNodeObject(list) then
        root[field]=nil
        list=NDB.createChildNode(root,field)
    end
    return list
end
local function clearList(root,field)
    local list=root[field]
    if NDB.isNodeObject(list) then
        local nodes=NDB.getChildNodes(list)
        for i=#nodes,1,-1 do pcall(function() NDB.deleteNode(nodes[i]) end) end
    end
    return ensureList(root,field)
end
local function newRecord(list)
    local names={};local children=NDB.getChildNodes(list)
    for _,child in ipairs(children) do names[NDB.getNodeName(child)]=true end
    local index=#children+1
    while names["item"..index] do index=index+1 end
    return NDB.createChildNode(list,"item"..index)
end
local LEGACY_ALIASES={
    ["short sword"]="Sword, short",
    ["basic datapad"]="Datapad, basic",
    ["utility belt"]="Utility Belt (Standard)",
    ["utility belt standard"]="Utility Belt (Standard)"
}
local function namesFor(x)
    local t={tostring(x.name or ""),tostring(x.display or ""),tostring(x.name_pt or "")}
    if type(I18N.name)=="function" then t[#t+1]=I18N.name(x) end
    return t
end
local function findLoose(list,label)
    local raw=strip(label)
    local alias=LEGACY_ALIASES[key(raw)]
    if alias~=nil then raw=alias end
    local wanted=key(raw)
    if wanted=="" then return nil end
    for _,x in ipairs(list or {}) do
        for _,nm in ipairs(namesFor(x)) do
            if key(nm)==wanted then return x end
        end
    end
    return nil
end
local function sourceText(attrs)
    local page=attr(attrs,"paginaHabilidade")
    local book=attr(attrs,"livroHabilidade")
    if page=="" or key(page)=="nao registrada" then return book end
    if book~="" then return book.." — "..page end
    return page
end
local function reportNew()
    return {feats=0,talents=0,skills=0,powers=0,weapons=0,equipment=0,attacks=0,languages=0,unresolved={}}
end
local function unresolved(r,kind,name)
    r.unresolved[#r.unresolved+1]=tostring(kind)..": "..tostring(name)
end

local function speciesBonusCounts(s)
    local trained,feats=0,0
    local seenT,seenF=false,false
    for _,v in ipairs((s and s.special) or {}) do
        local z=key(v)
        if not seenT and z:find("bonus trained skill",1,true) then trained=trained+1; seenT=true end
        if not seenF and z:find("bonus feat",1,true) then feats=feats+1; seenF=true end
    end
    return trained,feats
end
local function applySpecies(root,label)
    local s=findLoose(CAT.species,label)
    if s==nil then
        root.raca=tostring(label or "")
        root.racaId=""
        return false
    end
    root.racaId=tostring(s.name or "")
    root.raca=tostring(s.name or "")
    local a=s.ability_mods or {}
    root.speciesFor=n(a[1]); root.speciesDes=n(a[2]); root.speciesCon=n(a[3])
    root.speciesInt=n(a[4]); root.speciesSab=n(a[5]); root.speciesCar=n(a[6])
    local d=s.defense_bonus or {}
    root.speciesRef=n(d.ref); root.speciesFort=n(d.fort); root.speciesWill=n(d.will); root.speciesDR=n(d.dr)
    root.isDroid=false; root.lowLightVision=false
    local ids={}
    for _,v in ipairs(s.special or {}) do
        local raw=tostring(v or ""); local z=key(raw); ids[#ids+1]=raw
        if z=="droid traits" then root.isDroid=true end
        if z=="low light vision" then root.lowLightVision=true end
    end
    root.noConstitution=root.isDroid
    root.sizeCode=string.lower(tostring(s.size or "m"))
    root.baseSpeedSquares=n(s.speed)
    root.deslTerrestre=tostring(root.baseSpeedSquares).." q / "..tostring(root.baseSpeedSquares*1.5).." m"
    root.idiomasBase=table.concat(I18N.list(s,"languages") or {},", ")
    root.speciesTraits=table.concat(I18N.list(s,"special") or {},", ")
    root.speciesDescription=I18N.field(s,"description")
    root.speciesClassSkillIds=table.concat(s.class_skills or {},"|")
    root.speciesClassSkills=table.concat(I18N.list(s,"class_skills") or {},", ")
    root.speciesTraitIds=table.concat(ids,"|")
    root.bonusTrainedSkills,root.bonusFeatSlots=speciesBonusCounts(s)
    return true
end

local function addClasses(root,text,fallback,report)
    local list=clearList(root,"classLevels")
    local made=0
    local function addOne(name,count)
        local c=findLoose(CAT.classes,name)
        if c==nil then unresolved(report,"Classe",name); return end
        count=math.max(1,math.floor(n(count,1)))
        for _=1,count do
            made=made+1
            local node=newRecord(list)
            node.levelIndex=made; node.className=c.name; node.classNamePt=I18N.name(c)
            node.hitDie=n(c.hp); node.hitDieText="d"..tostring(c.hp or 0)
            node.babRate=n(c.bab_rate); node.babText=tostring(c.bab_rate or 0)
            node.forcePointsBase=n(c.force_points)
            local d=c.defense or {}
            node.refBonus=n(d.ref); node.fortBonus=n(d.fort); node.willBonus=n(d.will)
            node.trainedSkillsBase=n(c.trained_skills_base)
            node.hpGain=0; node.source=tostring(c.source or ""); node.startingCreditUnit=n(c.starting_credits)
        end
    end
    local raw=tostring(text or "")
    for part in raw:gmatch("[^/]+") do
        local nm,cnt=part:match("^%s*(.-)%s+(%d+)%s*$")
        if nm~=nil then addOne(nm,cnt) end
    end
    if made==0 and raw~="" then
        local nm=raw:gsub("%s+%d+%s*$","")
        addOne(strip(nm),fallback)
    end
    root.classRevision=n(root.classRevision)+1
    return made
end

local OPTION_BASES={
    ["weapon proficiency"]=true,["exotic weapon proficiency"]=true,["weapon focus"]=true,
    ["double attack"]=true,["triple attack"]=true,["triple critical"]=true,
    ["skill training"]=true,["skill focus"]=true,["superior tech"]=true
}
local OPTION_GROUPS={"Pistols","Rifles","Simple Weapons","Advanced Melee Weapons","Heavy Weapons","Lightsabers"}
local function canonicalOption(v)
    local raw=strip(v)
    local k=key(raw)
    for _,x in ipairs(OPTION_GROUPS) do
        if key(x)==k or key(I18N.groups[x] or "")==k then return x end
    end
    for en,pt in pairs(I18N.skills or {}) do
        if key(en)==k or key(pt)==k then return en end
    end
    local w=findLoose(CAT.weapons,raw); if w then return w.name end
    return raw
end
local function featureResolve(list,raw)
    local x=findLoose(list,raw)
    if x then return x,"" end
    local base,opt=raw:match("^(.-)%s*%((.-)%)%s*$")
    if base==nil then base,opt=raw:match("^(.-)%s*—%s*(.-)%s*$") end
    if base==nil then base,opt=raw:match("^(.-)%s*–%s*(.-)%s*$") end
    if base==nil then base,opt=raw:match("^(.-)%s+%-%s+(.-)%s*$") end
    if base~=nil and OPTION_BASES[key(base)] then
        local bx=findLoose(list,base)
        if bx then return bx,canonicalOption(opt) end
    end
    return nil,""
end
local function automaticOrigin(origin)
    local z=key(origin)
    return z:find("starting feat",1,true)~=nil or z:find("proeza inicial",1,true)~=nil
end
local function addFeature(root,field,list,attrs,kind,report)
    local raw=attr(attrs,"nomeHabilidade")
    if raw=="" then return end
    local x,opt=featureResolve(list,raw)
    local node=newRecord(ensureList(root,field))
    local desc=attr(attrs,"descricao")
    if x then
        node.baseName=x.name
        node.option=opt or ""
        node.name=x.name..((opt and opt~="") and (" ("..opt..")") or "")
        node.namePt=I18N.name(x)..((opt and opt~="") and (" ("..I18N.option(opt,CAT)..")") or "")
        node.description=x.description or desc
        node.descriptionPt=I18N.field(x,"description")
        node.prerequisites=x.prerequisites or ""
        node.prerequisitesPt=I18N.field(x,"prerequisites")
        node.tree=x.tree or ""; node.treePt=I18N.field(x,"tree")
        node.source=x.page or x.source or sourceText(attrs)
    else
        node.name=raw; node.namePt=raw; node.baseName=raw; node.option=""
        node.description=desc; node.descriptionPt=desc; node.source=sourceText(attrs)
        node.legacyUnresolved=true
        unresolved(report,kind,raw)
    end
    node.legacyOrigin=attr(attrs,"obtencaoHabilidade")
    node.acquiredAtLevel=n(attr(attrs,"nivelHabilidade"),1)
    node.grantLevel=node.acquiredAtLevel
    local classFromOrigin=tostring(node.legacyOrigin or ""):match("[Tt]alent%s+de%s+(.+)%s+%d+$")
        or tostring(node.legacyOrigin or ""):match("[Ss]tarting%s+[Ff]eat%s+de%s+(.+)$")
        or tostring(node.legacyOrigin or ""):match("[Pp]roeza%s+[Ii]nicial%s+de%s+(.+)$")
    if kind=="Proeza" then
        node.automatic=automaticOrigin(node.legacyOrigin)
        if node.automatic then
            node.slotType="automatic"
            node.automaticSource=node.legacyOrigin
            node.grantClass=classFromOrigin or ""
        else
            node.slotType="general"
            node.automaticSource=""
            node.grantClass=classFromOrigin or ""
        end
        report.feats=report.feats+1
    else
        node.slotType="talent"
        node.automatic=false
        node.automaticSource=""
        node.grantClass=classFromOrigin or ""
        node.sourceClass=classFromOrigin or ""
        report.talents=report.talents+1
    end
end
local SKILLS={
 {"Acrobatics","2",false},{"Climb","1",false},{"Deception","6",false},{"Endurance","3",false},
 {"Gather Information","6",false},{"Initiative","2",false},{"Jump","1",false},
 {"Knowledge (Bureaucracy)","4",false},{"Knowledge (Galactic Lore)","4",false},
 {"Knowledge (Life Sciences)","4",false},{"Knowledge (Physical Sciences)","4",false},
 {"Knowledge (Social Sciences)","4",false},{"Knowledge (Tactics)","4",false},
 {"Knowledge (Technology)","4",false},{"Mechanics","4",true},{"Perception","5",false},
 {"Persuasion","6",false},{"Pilot","2",false},{"Ride","2",false},{"Stealth","2",false},
 {"Survival","5",false},{"Swim","1",false},{"Treat Injury","5",false},{"Use Computer","4",false},
 {"Use the Force","6",false}
}
local function ensureSkills(root)
    local list=root.campoDasPericias
    local count=(NDB.isNodeObject(list) and #NDB.getChildNodes(list)) or 0
    if count<25 then
        list=clearList(root,"campoDasPericias")
        for _,d in ipairs(SKILLS) do
            local sk=newRecord(list)
            sk.nomePericia=d[1]; sk.nomePericiaPt=I18N.skills[d[1]] or d[1]
            sk.chavePericia=d[2]; sk.exigeTreino=d[3]
            sk.isClass=false; sk.skillFocus=false; sk.graduacaoPericia=0
        end
        root.swseSkillsVersion="2.1.0"
    else
        for _,sk in ipairs(NDB.getChildNodes(list)) do
            sk.isClass=false; sk.skillFocus=false; sk.graduacaoPericia=0
        end
    end
    return root.campoDasPericias
end
local function findSkillNode(root,name)
    if not NDB.isNodeObject(root.campoDasPericias) then return nil end
    local wanted=key(name)
    for _,sk in ipairs(NDB.getChildNodes(root.campoDasPericias)) do
        if key(sk.nomePericia)==wanted or key(sk.nomePericiaPt)==wanted then return sk end
    end
    return nil
end
local function importSkills(root,xml,report)
    ensureSkills(root)
    for _,a in ipairs(itemAttrs(xml,"campoDasPericias")) do
        local name=attr(a,"nomePericia")
        if name~="" then
            local sk=findSkillNode(root,name)
            if sk then
                local grad=n(attr(a,"graduacaoPericia"))
                local comp=n(attr(a,"competenciaPericia"))
                local legacyFlag=b(attr(a,"isClass"))
                local chosen=(grad>=5) or (legacyFlag and comp<=0 and grad<=0)
                sk.isClass=chosen
                sk.graduacaoPericia=math.max(0,grad-(grad>=5 and 5 or 0))
                sk.legacyTotalPericia=n(attr(a,"totalPericia"))
                sk.legacyGraduacaoPericia=grad
                sk.legacyCompetenciaPericia=comp
                sk.legacyTreinada=legacyFlag
                sk.legacyDescricao=attr(a,"descricao")
                report.skills=report.skills+1
            else
                unresolved(report,"Perícia",name)
            end
        end
    end
end
local function applySkillFeatEffects(root)
    if not NDB.isNodeObject(root.chosenFeats) then return end
    for _,f in ipairs(NDB.getChildNodes(root.chosenFeats)) do
        local base=tostring(f.baseName or "")
        local opt=tostring(f.option or "")
        if opt~="" then
            local sk=findSkillNode(root,opt)
            if sk then
                if base=="Skill Training" then sk.isClass=true end
                if base=="Skill Focus" then sk.skillFocus=true end
            end
        end
    end
end

local function forceDetail(x,legacy)
    if legacy~="" then return legacy end
    if x then return I18N.field(x,"description") end
    return ""
end
local function importForce(root,xml,report)
    local list=clearList(root,"chosenForcePowers")
    for a in tostring(xml or ""):gmatch('<item%s+([^>]-nomeMagia=".-"[^>]*)>') do
        local raw=attr(a,"nomeMagia")
        if raw~="" then
            local x=findLoose(CAT.force_powers,raw)
            local node=newRecord(list)
            if x then
                node.name=x.name; node.namePt=I18N.name(x); node.baseName=x.name
                node.description=x.description or attr(a,"descricao")
                node.descriptionPt=forceDetail(x,attr(a,"descricao"))
                node.source=x.page or attr(a,"pagina") or attr(a,"livro")
            else
                node.name=raw; node.namePt=raw; node.baseName=raw
                node.description=attr(a,"descricao"); node.descriptionPt=node.description
                node.source=attr(a,"pagina") or attr(a,"livro")
                node.legacyUnresolved=true
                unresolved(report,"Poder da Força",raw)
            end
            node.ready=(n(attr(a,"dispMagia"),1)~=0)
            node.legacyPrepared=attr(a,"prepMagia")
            node.legacyExecution=attr(a,"execucao")
            node.legacyRange=attr(a,"alcance")
            node.legacyTarget=attr(a,"alvo")
            report.powers=report.powers+1
        end
    end
end

local ATTACK_TEXT_FIELDS={"nome","arma","armaId","weaponTypeId","weaponSizeId","weaponRangeId","weaponSpecialId","weaponCatalogName","weaponInventoryKey","weaponBaseCost","weaponUpgradeSlotsMax","weaponSize","weaponHand","weaponAvailability","weaponRarity","weaponObjectDR","weaponObjectHPMax","weaponObjectHP","weaponObjectThreshold","weaponAmmoType","weaponAmmoCapacity","tipo","dano","categoria","alcance","municao","obs","rangeBand","attackMode","criticalMultiplier","atributoAtaque","weaponStunDice","weaponEffectText","weaponVariantId","miscAtaque"}
local ATTACK_BOOL_FIELDS={"weaponDouble","weaponStun","weaponStunCapable","weaponStunOnly","weaponStunAttack","weaponNonDamage","weaponRateSingle","weaponRateAuto","weaponAccurate","proficiente","pointBlank","twoHanded","firingIntoMelee","autofireCapable","autofireOnly","braced","rifleOneHanded","weaponIgnoresDR","weaponUsesAmmo"}
local function clearAttacks(root)
    for i=1,20 do
        for _,k in ipairs(ATTACK_TEXT_FIELDS) do root[k..i]=nil end
        for _,k in ipairs(ATTACK_BOOL_FIELDS) do root[k..i]=false end
        root["ataque"..i.."a"]=nil
    end
end
local function freeAttack(root)
    for i=1,20 do if strip(root["nome"..i])=="" then return i end end
end
local function hasFeat(root,full)
    if not NDB.isNodeObject(root.chosenFeats) then return false end
    local wanted=key(full)
    for _,f in ipairs(NDB.getChildNodes(root.chosenFeats)) do
        if key(f.name)==wanted or key(f.baseName)==wanted then return true end
    end
    return false
end
local function proficientFor(root,group)
    local g=key(group)
    if g:find("pistol",1,true) then return hasFeat(root,"Weapon Proficiency (Pistols)") end
    if g:find("rifle",1,true) then return hasFeat(root,"Weapon Proficiency (Rifles)") end
    if g:find("simple",1,true) then return hasFeat(root,"Weapon Proficiency (Simple Weapons)") end
    if g:find("lightsaber",1,true) then return hasFeat(root,"Weapon Proficiency (Lightsabers)") end
    if g:find("heavy",1,true) then return hasFeat(root,"Weapon Proficiency (Heavy Weapons)") end
    if g:find("advanced melee",1,true) then return hasFeat(root,"Weapon Proficiency (Advanced Melee Weapons)") end
    return true
end
local function rangeCode(v)
    local z=key(v)
    if z:find("arremesso",1,true) or z:find("thrown",1,true) then return "thrown" end
    if z:find("corpo a corpo",1,true) or z:find("melee",1,true) then return "melee" end
    return "ranged"
end
local function typeCode(v,range)
    local z=key(v)
    if z:find("melee",1,true) or key(range):find("corpo a corpo",1,true) then return "M" end
    return "R"
end
local function parseCritMult(v)
    return tonumber(tostring(v or ""):match("[xX](%d+)")) or 2
end
local function addCustomAttack(root,a)
    local i=freeAttack(root); if not i then return nil end
    local nm=attr(a,"nome"); if nm=="" then nm=attr(a,"arma") end
    local group=attr(a,"categoria")
    local range=attr(a,"alcance")
    root["nome"..i]=nm
    root["arma"..i]=group~="" and group or "Arma"
    root["armaId"..i]=group
    root["weaponTypeId"..i]=typeCode(attr(a,"tipo"),range)
    root["weaponRangeId"..i]=rangeCode(range)
    root["weaponCatalogName"..i]=""
    root["tipo"..i]=attr(a,"tipo")
    root["dano"..i]=attr(a,"dano")
    root["categoria"..i]=group
    root["alcance"..i]=range
    root["municao"..i]=n(attr(a,"municao"),0)
    local obs=attr(a,"efeitos")
    if obs=="" then obs=attr(a,"especial") end
    if obs=="" then obs=attr(a,"descricao") end
    root["obs"..i]=obs
    root["proficiente"..i]=proficientFor(root,group)
    root["rangeBand"..i]="0"; root["attackMode"..i]="normal"
    root["criticalMultiplier"..i]=parseCritMult(attr(a,"multiplicador"))
    root["pointBlank"..i]=false
    root["atributoAtaque"..i]=(root["weaponRangeId"..i]=="melee") and "1" or "2"
    root["legacyWeapon"]=true
    return i
end
local function makeInventory(root,category,x,name,weight,cost,desc,slot)
    local node=newRecord(ensureList(root,"inventoryItems"))
    node.category=category; node.categoryPt=(category=="Cybernetics" and "Cibernéticos" or category)
    if x then node.name=x.name; node.namePt=I18N.name(x)
    else node.name=name; node.namePt=name; node.legacyUnresolved=true end
    node.qty=1; node.carried=true
    node.unitWeight=n(weight,x and n(x.weight) or 0)
    node.totalWeight=node.unitWeight
    node.unitCost=n(cost,x and n(x.cost or x.price) or 0)
    node.legacyDescription=desc or ""; node.legacySlot=slot or ""
    return node
end
local function findAnyItem(name)
    local x=findLoose(CAT.weapons,name); if x then return x,"Armas" end
    x=findLoose(CAT.armor,name); if x then return x,"Armaduras" end
    x=findLoose(CAT.equipment,name); if x then return x,"Equipamentos" end
    x=findLoose(CAT.ammo,name); if x then return x,"Munição" end
    x=findLoose(CAT.cybernetics,name); if x then return x,"Cybernetics" end
    return nil,nil
end
local function inventoryHas(root,name)
    local wanted=key(name)
    if not NDB.isNodeObject(root.inventoryItems) then return false end
    for _,it in ipairs(NDB.getChildNodes(root.inventoryItems)) do
        if key(it.name)==wanted or key(it.namePt)==wanted then return true end
    end
    return false
end
local function resetArmor(root)
    root.armorInventoryKey=nil
    root.armorName=""; root.armorNameId=""; root.armorRef=0; root.equipFort=0
    root.armorMaxDex=0; root.armorMaxDexKnown=false; root.armorType=""; root.armorWeight=0
    root.armorBaseCost=0; root.armorUpgradeSlotsMax=0; root.armorSpecial=""
    root.armorAvailability=""; root.armorRarity=""; root.armorHelmet=""; root.armorJetPack=""; root.armorExtra=""
    for i=1,4 do root["armorSkill"..i]=""; root["armorSkillBonus"..i]=0 end
    for _,k in ipairs({"For","Des","Con","Int","Sab","Car"}) do root["armorAbility"..k]=0 end
    root.armorObjectDR=0; root.armorHPMax=0; root.armorHP=0; root.armorObjectThreshold=0
end
local function importWeaponsAndEquipment(root,xml,headAttrs,report)
    clearList(root,"inventoryItems")
    clearAttacks(root)
    resetArmor(root)

    for _,a in ipairs(itemAttrs(xml,"campoDasArmas")) do
        local name=attr(a,"nome"); if name=="" then name=attr(a,"arma") end
        if name~="" then
            local x=findLoose(CAT.weapons,name)
            local node=makeInventory(root,"Armas",x,name,attr(a,"peso"),attr(a,"preco"),attr(a,"descricao"),"")
            node.legacyEffects=attr(a,"efeitos"); node.legacySpecial=attr(a,"especial")
            node.legacyDamage=attr(a,"dano"); node.legacyRange=attr(a,"alcance")
            if x then
                local ok,msg=EQUIP.setEquipped(root,node,true)
                if not ok then
                    unresolved(report,"Arma/equipar",name.." — "..tostring(msg or ""))
                    addCustomAttack(root,a)
                end
            else
                unresolved(report,"Arma fora do catálogo",name)
                addCustomAttack(root,a)
            end
            report.weapons=report.weapons+1
        end
    end

    for _,a in ipairs(itemAttrs(xml,"listaDeEquipamentos")) do
        local name=attr(a,"nome")
        if name~="" and not inventoryHas(root,name) then
            local x,cat=findAnyItem(name)
            if cat==nil then cat="Equipamentos" end
            local node=makeInventory(root,cat,x,name,attr(a,"peso"),attr(a,"preco"),attr(a,"descricao"),attr(a,"slot"))
            if not x then unresolved(report,"Equipamento fora do catálogo",name) end
            if x and (cat=="Armaduras") then
                local ok,msg=EQUIP.setEquipped(root,node,true)
                if not ok then unresolved(report,"Armadura/equipar",name.." — "..tostring(msg or "")) end
            end
            report.equipment=report.equipment+1
        end
    end

    local other=attr(headAttrs,"outros")
    if other~="" and #other<=120 and not inventoryHas(root,other) then
        local x,cat=findAnyItem(other)
        if cat==nil then cat="Equipamentos" end
        makeInventory(root,cat,x,other,nil,nil,"Importado do campo Outros da ficha antiga","")
        if not x then unresolved(report,"Outro equipamento fora do catálogo",other) end
        report.equipment=report.equipment+1
    end

    -- Munição separada no RPGmeister antigo: converte quantidades explícitas de reservas.
    -- A carga já inserida na arma não vira item extra do inventário.
    local ammoText=attr(headAttrs,"municoes")
    local ppQty=tonumber(ammoText:match("[Pp]ower%s+[Pp]ack%s*.-(%d+)"))
    if ppQty==nil then ppQty=tonumber(ammoText:match("(%d+)%s+[Pp]ower%s+[Pp]ack")) end
    if ppQty~=nil and ppQty>0 then
        local pack,cat=findAnyItem("Power Pack")
        if cat==nil then cat="Munição" end
        local node=makeInventory(root,cat,pack,"Power Pack",nil,nil,"Reserva importada da ficha antiga","")
        node.qty=math.floor(ppQty)
        node.totalWeight=n(node.unitWeight)*node.qty
        report.equipment=report.equipment+1
        if not pack then unresolved(report,"Munição fora do catálogo","Power Pack") end
    end
end

local function copyAttack(root,src,dst)
    for _,k in ipairs(ATTACK_TEXT_FIELDS) do root[k..dst]=root[k..src] end
    for _,k in ipairs(ATTACK_BOOL_FIELDS) do root[k..dst]=root[k..src] end
    root["ataque"..dst.."a"]=root["ataque"..src.."a"]
end
local function slotMatches(root,i,base)
    local wanted=key(base)
    if wanted=="" then return false end
    if key(root["weaponCatalogName"..i])==wanted then return true end
    if key(root["nome"..i])==wanted then return true end
    local x=findLoose(CAT.weapons,base)
    if x and key(root["weaponCatalogName"..i])==key(x.name) then return true end
    return false
end
local function findAttackSlot(root,base,wantStun,wantPB,used)
    for i=1,20 do
        if not (used and used[i]) and strip(root["nome"..i])~="" and slotMatches(root,i,base) then
            local sameStun=(root["weaponStunAttack"..i]==true)==(wantStun==true)
            local samePB=wantPB==nil or (root["pointBlank"..i]==true)==(wantPB==true)
            if sameStun and samePB then return i end
        end
    end
    return nil
end
local function withinPB(range)
    local nums={}
    for x in tostring(range or ""):gmatch("(%d+)") do nums[#nums+1]=tonumber(x) end
    if #nums==0 then return false end
    local mx=0; for _,v in ipairs(nums) do if v>mx then mx=v end end
    return mx>0 and mx<=20
end
local function appendObs(old,new)
    old=tostring(old or ""); new=tostring(new or "")
    if new=="" then return old end
    if old=="" then return new end
    if key(old):find(key(new),1,true) then return old end
    return old.." | Legado: "..new
end
local function importAttackProfiles(root,headAttrs,report)
    local rawList=clearList(root,"legacyAttackProfiles")
    local used={}
    local function modes(p)
        local title=key(attr(headAttrs,"nome"..p).." "..attr(headAttrs,"tipo"..p))
        local notes=key(attr(headAttrs,"obs"..p))
        local stun=title:find("stun",1,true)~=nil or title:find("atordo",1,true)~=nil
        local pb=title:find("point blank",1,true)~=nil or title:find("pbs",1,true)~=nil
            or notes:find("point blank shot aplicado",1,true)~=nil
        return stun,pb
    end
    local function diceBonus(p)
        local expression=string.lower(attr(headAttrs,"dano"..p)):gsub("stun",""):gsub("atordoamento",""):gsub("%s","")
        local dice,bonus=expression:match("^(%d+d%d+)([+-]%d+)$")
        if not dice then dice=expression:match("^(%d+d%d+)$");bonus=0 end
        return dice,tonumber(bonus)
    end
    for p=1,20 do
        local nm=attr(headAttrs,"nome"..p)
        local base=attr(headAttrs,"arma"..p)
        if nm~="" or base~="" then
            if base=="" then base=nm end
            local typ=attr(headAttrs,"tipo"..p)
            local obs=attr(headAttrs,"obs"..p)
            local stun,pb=modes(p)
            -- Capability notes do not activate a mode. A Stun profile can also
            -- declare PBS numerically: +1 attack AND +1 damage over its normal
            -- profile, with the feat present. Range alone never activates PBS.
            if stun and not pb and hasFeat(root,"Point Blank Shot") then
                local dice,bonus=diceBonus(p)
                for q=1,20 do
                    local otherStun,otherPB=modes(q)
                    local otherBase=attr(headAttrs,"arma"..q)
                    if otherBase=="" then otherBase=attr(headAttrs,"nome"..q) end
                    if key(otherBase)==key(base) and not otherStun and not otherPB then
                        local otherDice,otherBonus=diceBonus(q)
                        local attack,otherAttack=tonumber(attr(headAttrs,"ataque"..p)),tonumber(attr(headAttrs,"ataque"..q))
                        if dice and dice==otherDice and bonus and otherBonus and bonus-otherBonus==1
                            and attack and otherAttack and attack-otherAttack==1 then pb=true;break end
                    end
                end
            end
            local legacy=newRecord(rawList)
            legacy.index=p; legacy.name=nm; legacy.weapon=base
            legacy.attack=attr(headAttrs,"ataque"..p); legacy.damage=attr(headAttrs,"dano"..p)
            legacy.range=attr(headAttrs,"alcance"..p); legacy.ammo=attr(headAttrs,"municao"..p)
            legacy.type=typ; legacy.category=attr(headAttrs,"categoria"..p); legacy.notes=obs
            legacy.critical=attr(headAttrs,"decisivo"..p); legacy.multiplier=attr(headAttrs,"multiplicador"..p)
            legacy.pointBlank=pb;legacy.stun=stun

            local slot=findAttackSlot(root,base,stun,pb,used)
                or findAttackSlot(root,base,stun,nil,used)
            if not slot then
                local template=findAttackSlot(root,base,stun)
                local dst=template and freeAttack(root)
                if dst then copyAttack(root,template,dst);slot=dst end
            end
            if slot then
                used[slot]=true
                if nm~="" then root["nome"..slot]=nm end
                root["pointBlank"..slot]=pb
                if stun then root["weaponStunAttack"..slot]=true; root["weaponStunOnly"..slot]=true end
                local oldRange=attr(headAttrs,"alcance"..p)
                if rangeCode(oldRange)=="thrown" then
                    root["weaponRangeId"..slot]="thrown"
                    root["atributoAtaque"..slot]="2"
                elseif rangeCode(oldRange)=="melee" then
                    root["weaponRangeId"..slot]="melee"
                    root["weaponTypeId"..slot]="M"
                    root["atributoAtaque"..slot]="1"
                end
                local ammo=tonumber(attr(headAttrs,"municao"..p))
                if ammo~=nil then root["municao"..slot]=ammo end
                root["obs"..slot]=appendObs(root["obs"..slot],obs)
                root["legacyProfileName"..slot]=nm
                root["legacyAttackTotal"..slot]=attr(headAttrs,"ataque"..p)
                root["legacyDamageTotal"..slot]=attr(headAttrs,"dano"..p)
                legacy.mappedSlot=slot
            else
                unresolved(report,"Perfil de ataque",nm~="" and nm or base)
            end
            report.attacks=report.attacks+1
        end
    end
end

local function featureFor(root,field,base,group,weapon)
    if not NDB.isNodeObject(root[field]) then return false end
    local bk=key(base); local g=key(group); local w=key(weapon)
    for _,f in ipairs(NDB.getChildNodes(root[field])) do
        local fb=key(f.baseName or f.name); local opt=key(f.option); local full=key(f.name)
        if fb==bk or full==bk or full:find(bk,1,true)==1 then
            if opt=="" then
                if full==bk then return true end
                if (g~="" and full:find(g,1,true)) or (w~="" and full:find(w,1,true)) then return true end
            elseif opt==g or opt==w or (g~="" and g:find(opt,1,true)) or (w~="" and w:find(opt,1,true)) then
                return true
            end
        end
    end
    return false
end
local function syncAttacks(root)
    for i=1,20 do
        if strip(root["nome"..i])~="" then
            local attrMod=(tostring(root["atributoAtaque"..i] or "2")=="1") and n(root.efetModFor,n(root.realModFor)) or n(root.efetModDes,n(root.realModDes))
            local total=n(root.bba)+attrMod+n(root["miscAtaque"..i])+n(root.buffAtaque)+n(root.conditionPenalty)+n(root.combatAttackModifier)+n(root.bonusAttack)+n(root.armorCheckPenalty)
            if root["proficiente"..i]~=true and root.bioCombat~=true then total=total-5 end
            local grp=tostring(root["armaId"..i] or ""); local wn=tostring(root["nome"..i] or "")
            if featureFor(root,"chosenFeats","Weapon Focus",grp,wn) then total=total+1 end
            if featureFor(root,"chosenTalents","Greater Weapon Focus",grp,wn) then total=total+1 end
            if root["pointBlank"..i]==true and hasFeat(root,"Point Blank Shot") then total=total+1 end
            root["ataque"..i.."a"]=total
            root["critico"..i]="20 / x"..tostring(n(root["criticalMultiplier"..i],2))
        end
    end
end
local function recalcInventory(root)
    local all,carried=0,0
    if NDB.isNodeObject(root.inventoryItems) then
        for _,it in ipairs(NDB.getChildNodes(root.inventoryItems)) do
            if it.carried==nil then it.carried=true end
            it.totalWeight=n(it.qty,1)*n(it.unitWeight)
            all=all+n(it.totalWeight)
            if it.carried==true then carried=carried+n(it.totalWeight) end
        end
    end
    root.inventoryWeightAll=all; root.inventoryWeight=carried; root.inventoryCarriedWeight=carried
    root.inventoryRevision=n(root.inventoryRevision)+1
end
local function applySpeciesSkillFlags(root)
    local s=findLoose(CAT.species,root.racaId or root.raca)
    if s==nil or not NDB.isNodeObject(root.campoDasPericias) then return end
    local focus,trained={},{}
    for _,v in ipairs(s.skill_focus or {}) do focus[key(v)]=true end
    for _,v in ipairs(s.trained_skills or {}) do trained[key(v)]=true end
    for _,sk in ipairs(NDB.getChildNodes(root.campoDasPericias)) do
        local k=key(sk.nomePericia)
        sk.speciesBaseFocus=(focus[k]==true)
        sk.speciesBaseTrained=(trained[k]==true)
        sk.speciesFocus=sk.speciesBaseFocus
        sk.speciesTrained=sk.speciesBaseTrained
    end
end

local function importLanguages(root,xml,report)
    local list=clearList(root,"chosenLanguages")
    local base=key(root.idiomasBase or "")
    local seen={}
    for _,a in ipairs(itemAttrs(xml,"campoDosIdiomas")) do
        local name=attr(a,"nomeIdioma")
        if name~="" then
            local k=key(name)
            if not seen[k] and not base:find(k,1,true) then
                local node=newRecord(list)
                node.name=name; node.namePt=I18N.cleanPt(name); node.detailPt="Importado da ficha antiga"
                node.notes=attr(a,"descricao")
                node.legacyAlphabet=attr(a,"alfabetoIdioma")
                node.legacySpoken=b(attr(a,"conversarIdioma")); node.legacyWritten=b(attr(a,"escritaIdioma"))
                report.languages=report.languages+1
                seen[k]=true
            end
        end
    end
end

local function preserveFeatureSection(root,xml,sourceTag,targetField)
    local list=clearList(root,targetField)
    for _,a in ipairs(itemAttrs(xml,sourceTag)) do
        local name=attr(a,"nomeHabilidade")
        if name~="" then
            local node=newRecord(list)
            node.name=name; node.description=attr(a,"descricao")
            node.source=sourceText(a); node.origin=attr(a,"obtencaoHabilidade")
            node.level=n(attr(a,"nivelHabilidade"),1)
        end
    end
end

local function setText(root,headAttrs,dst,src)
    local v=attr(headAttrs,src or dst)
    if v~="" then root[dst]=v end
end
local function importBasics(root,xml,headAttrs,report)
    setText(root,headAttrs,"nome"); setText(root,headAttrs,"idade"); setText(root,headAttrs,"sexo")
    setText(root,headAttrs,"altura"); setText(root,headAttrs,"peso"); setText(root,headAttrs,"avatar")
    setText(root,headAttrs,"aparencia"); setText(root,headAttrs,"personalidade")
    setText(root,headAttrs,"aparenciaOlhos"); setText(root,headAttrs,"pele"); setText(root,headAttrs,"cabelo")
    setText(root,headAttrs,"aparenciaOutros"); setText(root,headAttrs,"regiao")
    for _,f in ipairs({"reino","plano","culto","tendencia","titulo","posto","subtipo","tipo","jogador","campanha","era","afiliacao","destino"}) do setText(root,headAttrs,f) end
    if strip(root.aparenciaOlhos)=="" then setText(root,headAttrs,"aparenciaOlhos","olhos") end
    if strip(root.aparenciaOutros)=="" then setText(root,headAttrs,"aparenciaOutros","outrosDescricao") end

    local attrs={{"For","inicialFor","realFor"},{"Des","inicialDes","realDes"},{"Con","inicialCon","realCon"},
                 {"Int","inicialInt","realInt"},{"Sab","inicialSab","realSab"},{"Car","inicialCar","realCar"}}
    for _,m in ipairs(attrs) do
        local v=tonumber((attr(headAttrs,m[2]):gsub(",",".")))
        if v==nil then v=tonumber((attr(headAttrs,m[3]):gsub(",","."))) end
        if v~=nil then root["base"..m[1]]=v end
    end

    local race=attr(headAttrs,"raca")
    if race~="" and not applySpecies(root,race) then unresolved(report,"Espécie",race) end
    local oldLevel=n(attr(headAttrs,"nep"),1)
    local oldClass=attr(headAttrs,"classe1")
    local classCount=addClasses(root,oldClass,oldLevel,report)

    local xp=tonumber(attr(headAttrs,"xpAtual")); if xp~=nil then root.xpAtual=xp end
    local xpt=tonumber(attr(headAttrs,"xpNivel")); if xpt~=nil then root.xpNivel=xpt end
    local cr=tonumber(attr(headAttrs,"dinheiroRestante")) or tonumber(attr(headAttrs,"creditosSWSE"))
    if cr~=nil then root.creditosSWSE=cr end

    for i=1,9 do
        local note=attr(headAttrs,"anotacoes"..i)
        if note~="" then root["anotacoes"..i]=note end
    end
    local note1=tostring(root.anotacoes1 or "")
    local ds=tonumber(attr(headAttrs,"darkSideScore"))
    if ds==nil then ds=tonumber(note1:match("[Dd]ark [Ss]ide [Ss]core:%s*(%d+)")) end
    if ds~=nil then root.darkSideScore=ds end
    local fp=tonumber(attr(headAttrs,"forcePoints"))
    if fp==nil then fp=tonumber(note1:match("[Ff]orce [Pp]oints:%s*(%d+)")) end
    if fp~=nil then root.forcePoints=fp end
    local dp=tonumber(attr(headAttrs,"destinyPoints"))
    if dp==nil then dp=tonumber(note1:match("[Dd]estiny [Pp]oints:%s*(%d+)")) end
    if dp~=nil then root.destinyPoints=dp end

    local history=attr(headAttrs,"historia")
    local richHistory=richBackgroundText(xml)
    if history~="" then root.legacyHistoria=history end
    if richHistory~="" then root.legacyBackgroundText=richHistory end
    local preferredHistory=(richHistory~="" and richHistory or history)
    if preferredHistory~="" and strip(root.anotacoes3)=="" then
        root.anotacoes3="HISTÓRIA IMPORTADA DA FICHA ANTIGA\n\n"..preferredHistory
    end
    if history~="" and richHistory~="" and history~=richHistory and strip(root.anotacoes8)=="" then
        root.anotacoes8="HISTÓRIA DO CAMPO LEGADO\n\n"..history
    end
    local perman=attr(headAttrs,"permanencias")
    if perman~="" then root.legacyPermanencias=perman; if strip(root.anotacoes4)=="" then root.anotacoes4=perman end end
    local ammo=attr(headAttrs,"municoes")
    if ammo~="" then root.legacyMunicoes=ammo; if strip(root.anotacoes5)=="" then root.anotacoes5=ammo end end
    local other=attr(headAttrs,"outros")
    if other~="" then root.legacyOutros=other; if strip(root.anotacoes6)=="" then root.anotacoes6=other end end
    local money=attr(headAttrs,"dinheiro")
    if money~="" then root.legacyDinheiro=money; if strip(root.anotacoes7)=="" then root.anotacoes7=money end end

    root.legacyImportClassText=oldClass; root.legacyImportRaceText=race; root.legacyImportLevel=oldLevel
    return classCount
end

local function importFeatures(root,xml,report)
    clearList(root,"chosenFeats")
    clearList(root,"chosenTalents")
    for _,a in ipairs(itemAttrs(xml,"campoDosOutros")) do addFeature(root,"chosenFeats",CAT.feats,a,"Proeza",report) end
    for _,a in ipairs(itemAttrs(xml,"campoDosTalentos")) do addFeature(root,"chosenTalents",CAT.talents,a,"Talento",report) end
    root.choiceRevision=n(root.choiceRevision)+1
end

local function finishProgression(root,recalculate)
    if type(recalculate)=="function" then recalculate() end
    local first=nil
    if NDB.isNodeObject(root.classLevels) then first=NDB.getChildNodes(root.classLevels)[1] end
    if first then
        local im=math.floor((n(root.realInt,10)-10)/2)
        root.trainedSkillSlots=math.max(1,n(first.trainedSkillsBase)+im+n(root.bonusTrainedSkills))
        root.startingCreditUnit=n(first.startingCreditUnit)
    end
end

local function reconstructLegacyHP(root,targetHP)
    targetHP=tonumber(targetHP)
    if targetHP==nil or not NDB.isNodeObject(root.classLevels) then return end
    local levels=NDB.getChildNodes(root.classLevels)
    if #levels==0 then return end
    local conMod=0
    if root.isDroid~=true then conMod=math.floor((n(root.realCon,10)-10)/2) end
    local first=levels[1]
    local firstHP
    if tostring(first.className or "")=="Nonheroic" then
        firstHP=math.max(1,n(first.hitDie,4)+conMod)
        first.hpGain=firstHP
    else
        firstHP=(3*n(first.hitDie,0))+conMod
        first.hpGain=0
    end
    local remaining=math.floor(targetHP-firstHP)
    local extra=math.max(0,#levels-1)
    if extra>0 then
        local base=math.floor(remaining/extra)
        local rem=remaining-(base*extra)
        for i=2,#levels do
            local gain=base
            if rem>0 then gain=gain+1; rem=rem-1
            elseif rem<0 then gain=gain-1; rem=rem+1 end
            levels[i].hpGain=gain
            levels[i].legacyHpReconstructed=true
            levels[i].legacyHpTarget=targetHP
        end
    end
    root.legacyHpReconstructed=true
    root.legacyHpTarget=targetHP
end

local function reportText(r)
    local parts={
        "Proezas "..r.feats,
        "Talentos "..r.talents,
        "Perícias lidas "..r.skills,
        "Poderes da Força "..r.powers,
        "Armas "..r.weapons,
        "Equipamentos "..r.equipment,
        "Perfis de ataque "..r.attacks,
        "Idiomas adicionais "..r.languages
    }
    local s=table.concat(parts,", ")
    if #r.unresolved>0 then s=s..". Não resolvidos automaticamente: "..table.concat(r.unresolved,"; ") end
    return s
end

function M.isLegacy(xml)
    local s=tostring(xml or "")
    return (s:find(' inicialFor="',1,true)~=nil and s:find("<campoDosAtaques>",1,true)~=nil)
        or s:find('versionInstalled="VERSÃO INSTALADA:',1,true)~=nil
end

local function importDocument(root,xml,recalculate)
    if root==nil then return false,"Ficha atual indisponível." end
    if not M.isLegacy(xml) then return false,"O arquivo não foi reconhecido como ficha antiga do RPGmeister." end
    local h=head(xml); if h==nil then return false,"Cabeçalho <database> não encontrado." end
    local report=reportNew()

    importBasics(root,xml,h,report)
    importFeatures(root,xml,report)
    importSkills(root,xml,report)
    applySpeciesSkillFlags(root)
    applySkillFeatEffects(root)
    importForce(root,xml,report)
    importLanguages(root,xml,report)

    preserveFeatureSection(root,xml,"campoDasRacas","legacyRacialFeatures")
    preserveFeatureSection(root,xml,"campoDasCaracteristicasClasse","legacyClassFeatures")

    finishProgression(root,recalculate)
    importWeaponsAndEquipment(root,xml,h,report)
    importAttackProfiles(root,h,report)
    recalcInventory(root)
    if type(recalculate)=="function" then recalculate() end
    syncAttacks(root)

    local hp=tonumber(attr(h,"pvTotal"))
    if hp~=nil then
        reconstructLegacyHP(root,hp)
        if type(recalculate)=="function" then recalculate() end
        root.pvTotal=hp
    end
    root.legacyImportSource="XML RPGmeister 3.5 — convertido para Star Wars Saga"
    root.legacySourceXML=tostring(xml)
    root.legacyImportReport=reportText(report)
    root.importRevision=n(root.importRevision)+1
    root.choiceRevision=n(root.choiceRevision)+1
    root.classRevision=n(root.classRevision)+1
    root.forceSuiteRevision=n(root.forceSuiteRevision)+1
    return true,root.legacyImportReport
end

function M.import(root,xml,recalculate)
    if root==nil then return false,"Ficha atual indisponível." end
    if not M.isLegacy(xml) then return false,"O arquivo não foi reconhecido como XML da RPGmeister 3.5." end
    local backup=nil
    if type(NDB.exportXML)=="function" then backup=NDB.exportXML(root) end
    local begun=false
    local ok,success,message=pcall(function()
        if type(NDB.beginUpdate)=="function" then NDB.beginUpdate(root);begun=true end
        return importDocument(root,xml,recalculate)
    end)
    if not ok and backup and type(NDB.importXML)=="function" then
        local restored,err=pcall(NDB.importXML,root,backup)
        if not restored then success=tostring(success).."; restauração: "..tostring(err) end
    end
    if begun then NDB.endUpdate(root) end
    if not ok then return false,"Falha na conversão do XML RPGmeister 3.5: "..tostring(success) end
    return success,message
end

return M
