local M={}
local NDB=require("ndb.lua")
local CAT=require("swse_catalog_pt.lua")
local I18N=require("swse_i18n.lua")
local GEAR=require("swse_gear_detail_410.lua")

local function n(v,d) local x=tonumber(v); if x==nil then return d or 0 end; return x end
local function children(root,field)
    if root==nil or root[field]==nil then return {} end
    return NDB.getChildNodes(root[field])
end
local function find(list,name)
    for _,x in ipairs(list or {}) do if tostring(x.name or "")==tostring(name or "") then return x end end
end
local function hasFeat(root,name)
    local w=string.lower(tostring(name or ""))
    for _,x in ipairs(children(root,"chosenFeats")) do
        local a=string.lower(tostring(x.name or x.baseName or ""))
        local b=string.lower(tostring(x.baseName or x.name or ""))
        if a==w or b==w then return true end
    end
    return false
end
local function proficient(root,x)
    local g=string.lower(tostring(x.group or ""))
    if g=="" then return true end
    if string.find(g,"pistol",1,true) then return hasFeat(root,"Weapon Proficiency (Pistols)") end
    if string.find(g,"rifle",1,true) then return hasFeat(root,"Weapon Proficiency (Rifles)") end
    if string.find(g,"simple",1,true) then return hasFeat(root,"Weapon Proficiency (Simple Weapons)") end
    if string.find(g,"lightsaber",1,true) then return hasFeat(root,"Weapon Proficiency (Lightsabers)") end
    if string.find(g,"heavy",1,true) then return hasFeat(root,"Weapon Proficiency (Heavy Weapons)") end
    if string.find(g,"advanced melee",1,true) then return hasFeat(root,"Weapon Proficiency (Advanced Melee Weapons)") end
    return false
end
local function featureFor(root,listField,base,group,weapon)
    local list=root[listField]
    if list==nil then return false end
    local b=string.lower(tostring(base or ""))
    local g=string.lower(tostring(group or ""))
    local w=string.lower(tostring(weapon or ""))
    for _,f in ipairs(NDB.getChildNodes(list)) do
        local nm=string.lower(tostring(f.baseName or f.name or ""))
        local opt=string.lower(tostring(f.option or ""))
        local full=string.lower(tostring(f.name or ""))
        if nm==b or full==b or string.sub(full,1,#b+2)==b.." (" then
            if opt=="" then
                if full==b then return true end
                if (g~="" and string.find(full,g,1,true)~=nil) or (w~="" and string.find(full,w,1,true)~=nil) then return true end
            elseif opt==g or opt==w or string.find(g,opt,1,true)~=nil or string.find(w,opt,1,true)~=nil then
                return true
            end
        end
    end
    return false
end
local function syncInitialAttack(root,i)
    local attr=0
    if tostring(root["atributoAtaque"..i] or "2")=="1" then attr=n(root.efetModFor,n(root.realModFor,0))
    else attr=n(root.efetModDes,n(root.realModDes,0)) end
    local group=tostring(root["armaId"..i] or "")
    local weapon=tostring(root["nome"..i] or "")
    local total=n(root.bba,0)+attr+n(root["miscAtaque"..i],0)+n(root.buffAtaque,0)
        +n(root.conditionPenalty,0)+n(root.combatAttackModifier,0)+n(root.bonusAttack,0)+n(root.armorCheckPenalty,0)
    if root["proficiente"..i]~=true and root.bioCombat~=true then total=total-5 end
    if featureFor(root,"chosenFeats","Weapon Focus",group,weapon) then total=total+1 end
    if featureFor(root,"chosenTalents","Greater Weapon Focus",group,weapon) then total=total+1 end
    root["ataque"..i.."a"]=total
    root["critico"..i]="20 / x"..tostring(n(root["criticalMultiplier"..i],2))
end
local function diceFromStun(v)
    return string.match(tostring(v or ""), "(%d+[dD]%d+)") or ""
end

local function availabilityPt(v)
    local s=tostring(v or "")
    if s=="C" or string.lower(s)=="common" then return "Comum" end
    if s=="L" or string.lower(s)=="licensed" then return "Licenciado" end
    if s=="R" or string.lower(s)=="restricted" then return "Restrito" end
    if s=="M" or string.lower(s)=="military" then return "Militar" end
    if s=="I" or string.lower(s)=="illegal" then return "Ilegal" end
    if s=="Rare" then return "Raro" end
    return s
end
local function weaponObject(size)
    local code=string.upper(string.sub(tostring(size or "m"),1,1))
    if code=="F" or code=="D" then code="T" end
    if code=="G" or code=="C" then code="H" end
    return GEAR.weapon_objects[code] or GEAR.weapon_objects.M
end
local function freeAttack(root)
    for i=1,20 do if tostring(root["nome"..i] or "")=="" then return i end end
end

-- Store node identity separately from catalog identity: identical items are distinct.
local function inventoryKey(root,item)
    if not NDB.isNodeObject(item) then return nil end
    local parts,node={},item
    while node~=nil and node~=root do
        local name=NDB.getNodeName(node)
        if name==nil then return nil end
        name=string.gsub(string.gsub(name,"%%","%%25"),"/","%%2F")
        table.insert(parts,1,name)
        node=NDB.getParent(node)
    end
    if node~=root or #parts==0 then return nil end
    return table.concat(parts,"/")
end
local function itemAtKey(root,key)
    if key==nil or key=="" then return nil end
    local node=root
    for part in string.gmatch(key,"[^/]+") do
        local decoded=string.gsub(part,"%%(%x%x)",function(h) return string.char(tonumber(h,16)) end)
        node=node[decoded]
        if not NDB.isNodeObject(node) then return nil end
    end
    return node
end
local function siblings(item)
    if NDB.isNodeObject(item) then
        local parent=NDB.getParent(item)
        if parent~=nil then return NDB.getChildNodes(parent) end
    end
    return {item}
end
local function weaponSlots(root,item)
    local key=inventoryKey(root,item)
    local slots={}
    local legacy={}
    for i=1,20 do
        if tostring(root["nome"..i] or "")~="" then
            local owner=tostring(root["weaponInventoryKey"..i] or "")
            if key~=nil and owner==key then
                slots[#slots+1]=i
            elseif owner=="" and tostring(root["weaponCatalogName"..i] or "")==tostring(item.name or "") then
                legacy[#legacy+1]=i
            end
        end
    end
    if #slots>0 then return slots end
    if #legacy==0 then return slots end
    if key==nil then return {legacy[1]} end
    -- Older saves have no owner key. Pair each legacy slot with one unlinked item.
    local rank=0
    for _,candidate in ipairs(siblings(item)) do
        if candidate.category==item.category and candidate.name==item.name then
            local candidateKey=inventoryKey(root,candidate)
            local linked=false
            for i=1,20 do
                if candidateKey~=nil and root["weaponInventoryKey"..i]==candidateKey and tostring(root["nome"..i] or "")~="" then linked=true; break end
            end
            if not linked then
                rank=rank+1
                if candidate==item and legacy[rank]~=nil then return {legacy[rank]} end
            end
        end
    end
    return {}
end
local function weaponSlot(root,item)
    local slots=weaponSlots(root,item)
    return slots[1]
end
local function primaryWeaponSlot(root,item)
    for _,i in ipairs(weaponSlots(root,item)) do
        if root["weaponStunAttack"..i]~=true then return i end
    end
    return weaponSlot(root,item)
end
local function armorOwner(root,item)
    local key=tostring(root.armorInventoryKey or "")
    if key~="" then return itemAtKey(root,key) end
    for _,candidate in ipairs(siblings(item)) do
        if candidate.category=="Armaduras" and tostring(candidate.name or "")==tostring(root.armorNameId or "") then return candidate end
    end
end
local function saveWeaponState(root,item,i)
    item.swseWeaponStateName=tostring(item.name or "")
    item.swseWeaponAmmo=root["municao"..i]
    item.swseWeaponHP=root["weaponObjectHP"..i]
end
local function saveArmorState(root,item)
    if item~=nil then
        item.swseArmorStateName=tostring(item.name or "")
        item.swseArmorHP=root.armorHP
    end
end
local function bounded(value,maximum)
    return math.max(0,math.min(n(maximum,0),n(value,0)))
end

local function clearAttack(root,i)
    for _,k in ipairs({"nome","arma","armaId","weaponTypeId","weaponSizeId","weaponRangeId","weaponSpecialId","weaponCatalogName","weaponInventoryKey","weaponBaseCost","weaponUpgradeSlotsMax","weaponSize","weaponHand","weaponAvailability","weaponRarity","weaponObjectDR","weaponObjectHPMax","weaponObjectHP","weaponObjectThreshold","weaponAmmoType","weaponAmmoCapacity","tipo","dano","categoria","alcance","municao","obs","rangeBand","attackMode","criticalMultiplier","atributoAtaque","weaponStunDice","weaponEffectText","weaponVariantId"}) do root[k..i]=nil end
    for _,k in ipairs({"weaponDouble","weaponStun","weaponStunCapable","weaponStunOnly","weaponStunAttack","weaponNonDamage","weaponRateSingle","weaponRateAuto","weaponAccurate","proficiente","pointBlank","twoHanded","firingIntoMelee","autofireCapable","autofireOnly","braced","rifleOneHanded","weaponIgnoresDR","weaponUsesAmmo"}) do root[k..i]=false end
end

function M.isEquippable(item)
    local c=tostring(item and item.category or "")
    return c=="Armas" or c=="Armaduras"
end

function M.isEquipped(root,item)
    if root==nil or item==nil then return false end
    if item.category=="Armas" then return weaponSlot(root,item)~=nil end
    if item.category=="Armaduras" then
        return tostring(root.armorName or "")~="" and tostring(root.armorNameId or "")==tostring(item.name or "") and armorOwner(root,item)==item
    end
    return false
end

function M.equipWeapon(root,item)
    local x=find(CAT.weapons,item.name)
    if x==nil then return false,"Arma não encontrada no catálogo." end
    if M.isEquipped(root,item) then return true,"Já equipada." end
    local i=freeAttack(root)
    if i==nil then return false,"Não há espaço livre na aba Ataques." end
    root["weaponInventoryKey"..i]=inventoryKey(root,item)
    root["nome"..i]=I18N.name(x)
    root["arma"..i]=I18N.field(x,"group") or "Arma"
    root["armaId"..i]=x.group or ""
    root["weaponTypeId"..i]=x.type or ""
    root["weaponSizeId"..i]=x.size or ""
    root["weaponRangeId"..i]=x.range or ""
    root["weaponSpecialId"..i]=x.special or ""
    root["weaponCatalogName"..i]=x.name or ""
    root["weaponBaseCost"..i]=n(x.cost,0)
    root["weaponUpgradeSlotsMax"..i]=1
    local wd=GEAR.weapons[tostring(x.name or "")] or {}
    root["weaponSize"..i]=tostring(wd.size or x.size or "")
    root["weaponHand"..i]=tostring(wd.hand or "")
    root["weaponDouble"..i]=(tostring(wd.double or "")~="")
    local stunText=tostring(x.stun_dice or wd.stun or x.stun or "")
    local stunDice=tostring(x.stun_dice or diceFromStun(stunText) or "")
    local stunCapable=(stunText~="" or x.stun_only==true)
    local stunOnly=(x.stun_only==true)
    root["weaponStun"..i]=stunCapable
    root["weaponStunCapable"..i]=stunCapable
    root["weaponStunDice"..i]=stunDice
    root["weaponStunOnly"..i]=stunOnly
    root["weaponStunAttack"..i]=stunOnly
    root["weaponNonDamage"..i]=(x.non_damage==true)
    root["weaponEffectText"..i]=I18N.field(x,"special")
    root["weaponRateSingle"..i]=(tostring(wd.rate_single or "")~="")
    root["weaponRateAuto"..i]=(tostring(wd.rate_auto or "")~="")
    root["weaponAccurate"..i]=(tostring(wd.accurate or "")~="")
    root["weaponAvailability"..i]=availabilityPt(wd.availability)
    root["weaponRarity"..i]=availabilityPt(wd.rarity)
    root["weaponAmmoType"..i]=tostring(wd.ammo or x.ammo or "")
    local cap=n(wd.lifetime,n(x.shots,0)); if cap<=0 then cap=n(x.shots,0) end
    root["weaponAmmoCapacity"..i]=math.max(0,math.floor(cap))
    root["weaponUsesAmmo"..i]=(root["weaponAmmoType"..i]~="" and root["weaponAmmoCapacity"..i]>0)
    local wo=weaponObject(wd.size or x.size)
    root["weaponObjectDR"..i]=wo and n(wo.dr,0) or 0
    root["weaponObjectHPMax"..i]=wo and n(wo.hp,0) or 0
    root["weaponObjectHP"..i]=root["weaponObjectHPMax"..i]
    root["weaponObjectThreshold"..i]=wo and n(wo.threshold,0) or 0
    root["tipo"..i]=I18N.field(x,"damage_type")
    local baseDamage=tostring(x.damage_dice or "")
    if baseDamage~="" then root["dano"..i]=baseDamage
    elseif stunOnly and stunDice~="" then root["dano"..i]=stunDice
    else root["dano"..i]="" end
    root["categoria"..i]=I18N.field(x,"type")
    root["alcance"..i]=I18N.field(x,"range")
    root["municao"..i]=root["weaponUsesAmmo"..i] and root["weaponAmmoCapacity"..i] or n(x.shots,0)
    if item.swseWeaponStateName==tostring(item.name or "") then
        if item.swseWeaponAmmo~=nil then root["municao"..i]=math.floor(bounded(item.swseWeaponAmmo,root["weaponAmmoCapacity"..i])) end
        if item.swseWeaponHP~=nil then root["weaponObjectHP"..i]=bounded(item.swseWeaponHP,root["weaponObjectHPMax"..i]) end
    end
    root["obs"..i]=I18N.field(x,"special")
    root["proficiente"..i]=proficient(root,x)
    root["rangeBand"..i]="0"; root["attackMode"..i]="normal"; root["criticalMultiplier"..i]=2
    root["pointBlank"..i]=false; root["twoHanded"..i]=false; root["firingIntoMelee"..i]=false
    root["autofireCapable"..i]=(tostring(wd.rate_auto or "")~=""); root["autofireOnly"..i]=false
    root["braced"..i]=false; root["rifleOneHanded"..i]=false
    local sid=string.lower(tostring(x.special or ""))
    if string.find(sid,"autofire",1,true)~=nil then root["autofireCapable"..i]=true end
    if string.find(sid,"autofire only",1,true)~=nil then root["autofireOnly"..i]=true; root["autofireCapable"..i]=true end
    if string.find(sid,"ignore dr",1,true)~=nil then root["weaponIgnoresDR"..i]=true end
    local grp=string.lower(tostring(x.group or ""))
    root["atributoAtaque"..i]=(string.find(grp,"pistol",1,true) or string.find(grp,"rifle",1,true) or string.find(grp,"heavy",1,true)) and "2" or "1"
    syncInitialAttack(root,i)

    if stunCapable and not stunOnly and root["weaponNonDamage"..i]~=true then
        local j=freeAttack(root)
        if j~=nil then
            local fields={"arma","armaId","weaponTypeId","weaponSizeId","weaponRangeId","weaponSpecialId","weaponCatalogName","weaponInventoryKey","weaponBaseCost","weaponUpgradeSlotsMax","weaponSize","weaponHand","weaponDouble","weaponStun","weaponStunCapable","weaponStunDice","weaponStunOnly","weaponNonDamage","weaponEffectText","weaponRateSingle","weaponRateAuto","weaponAccurate","weaponAvailability","weaponRarity","weaponAmmoType","weaponAmmoCapacity","weaponUsesAmmo","weaponObjectDR","weaponObjectHPMax","weaponObjectHP","weaponObjectThreshold","tipo","categoria","alcance","municao","obs","proficiente","rangeBand","attackMode","criticalMultiplier","pointBlank","twoHanded","firingIntoMelee","autofireCapable","autofireOnly","braced","rifleOneHanded","atributoAtaque"}
            for _,k in ipairs(fields) do root[k..j]=root[k..i] end
            root["nome"..j]=tostring(root["nome"..i] or "").." — Atordoar"
            root["weaponVariantId"..j]="stun"
            root["weaponStunAttack"..j]=true
            root["weaponStunOnly"..j]=true
            root["dano"..j]=(stunDice~="" and stunDice or tostring(root["dano"..i] or ""))
            local obs=tostring(root["obs"..j] or "")
            local note="Atordoamento: metade do dano rolado em PV; compare o dano integral ao Limiar de Dano para o efeito na Trilha de Condição."
            root["obs"..j]=(obs~="" and (obs.." | ") or "")..note
            syncInitialAttack(root,j)
        end
    end

    item.carried=true
    return true
end

function M.unequipWeapon(root,item)
    local slots=weaponSlots(root,item)
    if #slots>0 then
        local primary=primaryWeaponSlot(root,item)
        if primary~=nil then saveWeaponState(root,item,primary) end
        for _,i in ipairs(slots) do clearAttack(root,i) end
        return true
    end
    return false,"A arma não está equipada."
end

function M.equipArmor(root,item)
    local x=find(CAT.armor,item.name)
    if x==nil then return false,"Armadura não encontrada no catálogo." end
    if M.isEquipped(root,item) then
        root.armorInventoryKey=inventoryKey(root,item)
        return true
    end
    saveArmorState(root,armorOwner(root,item))
    root.armorInventoryKey=inventoryKey(root,item)
    root.armorName=I18N.name(x); root.armorNameId=x.name
    root.armorRef=n(x.reflex,0); root.equipFort=n(x.fort,0)
    root.armorMaxDex=n(x.max_dex,0); root.armorMaxDexKnown=(x.max_dex~=nil)
    root.armorType=tostring(x.type or ""); root.armorWeight=n(x.weight,0)
    local ad=GEAR.armor[tostring(x.name or "")] or {}
    root.armorBaseCost=n(ad.price or x.price or x.cost,0)
    root.armorUpgradeSlotsMax=n(ad.slots or x.slots,0)
    root.armorAvailability=availabilityPt(ad.availability); root.armorRarity=availabilityPt(ad.rarity)
    root.armorHelmet=tostring(ad.helmet or ""); root.armorJetPack=tostring(ad.jet_pack or ""); root.armorExtra=tostring(ad.extra or "")
    for i=1,4 do
        root["armorSkill"..i]=(ad.skills and ad.skills[i] and ad.skills[i].name) or ""
        root["armorSkillBonus"..i]=(ad.skills and ad.skills[i] and n(ad.skills[i].bonus,0)) or 0
    end
    local ab=ad.ability or {}
    for _,k in ipairs({"For","Des","Con","Int","Sab","Car"}) do root["armorAbility"..k]=n(ab[k],0) end
    local sizeCode=string.upper(string.sub(tostring(root.sizeCode or "m"),1,1))
    if sizeCode=="F" or sizeCode=="D" then sizeCode="T" end
    if sizeCode=="G" or sizeCode=="C" then sizeCode="H" end
    local ao=GEAR.weapon_objects[sizeCode] or GEAR.weapon_objects.M
    root.armorObjectDR=ao and n(ao.dr,0) or 0; root.armorHPMax=ao and n(ao.hp,0) or 0; root.armorHP=root.armorHPMax
    if item.swseArmorStateName==tostring(item.name or "") and item.swseArmorHP~=nil then root.armorHP=bounded(item.swseArmorHP,root.armorHPMax) end
    root.armorObjectThreshold=ao and n(ao.threshold,0) or 0
    root.armorSpecial=I18N.field(x,"special")
    item.carried=true
    return true
end

function M.unequipArmor(root,item)
    if not M.isEquipped(root,item) then return false,"A armadura não está equipada." end
    saveArmorState(root,item)
    root.armorInventoryKey=nil
    root.armorName=""; root.armorNameId=""; root.armorRef=0; root.equipFort=0
    root.armorMaxDex=0; root.armorMaxDexKnown=false; root.armorType=""; root.armorWeight=0; root.armorBaseCost=0; root.armorUpgradeSlotsMax=0
    root.armorSpecial=""; root.armorAvailability=""; root.armorRarity=""; root.armorHelmet=""; root.armorJetPack=""; root.armorExtra=""
    for i=1,4 do root["armorSkill"..i]=""; root["armorSkillBonus"..i]=0 end
    for _,k in ipairs({"For","Des","Con","Int","Sab","Car"}) do root["armorAbility"..k]=0 end
    root.armorObjectDR=0; root.armorHPMax=0; root.armorHP=0; root.armorObjectThreshold=0
    return true
end

function M.setEquipped(root,item,want)
    if not M.isEquippable(item) then return false,"Este tipo de item não pode ser equipado." end
    if want then
        if tostring(item.category or "")=="Armas" then return M.equipWeapon(root,item) else return M.equipArmor(root,item) end
    else
        if tostring(item.category or "")=="Armas" then return M.unequipWeapon(root,item) else return M.unequipArmor(root,item) end
    end
end

return M
