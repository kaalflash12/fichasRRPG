-- Keep navigation readable. Wrap whole buttons; never reduce their font size.
local M={}
local spec=require('swse_nav_layout_spec.lua')
local function set(c,k,v) if c and c[k]~=v then c[k]=v end end
local function fill(form)
 local frame=form.swseScreenFrame
 if frame then
  set(frame,'align','none');set(frame,'left',0);set(frame,'top',0)
  set(frame,'width',math.max(1,form.width));set(frame,'height',math.max(1,form.height))
 end
end
local function group(form,s)
 local parent=form[s.parent];if not parent then return end
 local fallback=math.max(1,form.width-18)
 local available=math.min(fallback,math.max(1,parent.width-8))
 if not form.isShowing or parent.width<120 then available=fallback;set(parent,'width',available+8) end
 local x,y,count=0,0,0
 for _,b in ipairs(s.buttons) do
  local nav=form[b.name];local label=form[b.label]
  if nav and nav.visible~=false then
   local w=math.min(available,b.width)
   if x>0 and x+w>available+0.01 then x=0;y=y+s.rowHeight end
   set(nav,'align','none');set(nav,'margins',{});set(nav,'left',4+x);set(nav,'top',4+y)
   set(nav,'width',w);set(nav,'height',s.rowHeight-4)
   if label then set(label,'fontSize',s.fontSize);set(label,'wordWrap',false) end
   x=x+w+6;count=count+1
  end
 end
 set(parent,'height',count>0 and y+s.rowHeight+8 or 1)
 for _,name in ipairs(s.ornaments) do set(form[name],'visible',false) end
end
function M.apply(form,entries)
 if not form or form._swseNavSizing then return end
 form._swseNavSizing=true
 local ok,err=pcall(function()
  fill(form)
  if form.fxSignal and form.fxDock then set(form.fxSignal,'visible',form.width>=580) end
  for _,s in ipairs(spec[form.name] or {}) do
   local use=entries==nil
   if entries then
    for _,b in ipairs(s.buttons) do
     for _,m in pairs(entries) do if m[2]==b.name then use=true;break end end
     if use then break end
    end
   end
   if use then group(form,s) end
  end
 end)
 form._swseNavSizing=false
 if not ok then form._swseNavLayoutError=tostring(err) end
 return ok,err
end
function M.request(form)
 if not form or form._swseNavSizing or form._swseNavLayoutTimer then return end
 form._swseNavLayoutTimer=setTimeout(function()
  form._swseNavLayoutTimer=nil
  if form.sheet then M.apply(form) end
 end,40)
end
function M.stop(form)
 if form and form._swseNavLayoutTimer then clearTimeout(form._swseNavLayoutTimer);form._swseNavLayoutTimer=nil end
end
M.spec=spec
return M
