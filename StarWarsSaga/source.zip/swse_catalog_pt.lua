local catalog=require("swse_catalog.lua")
local packs={
    (require("swse_ptbr_characters.lua")),
    (require("swse_ptbr_gear.lua")),
    (require("swse_ptbr_feats.lua")),
    (require("swse_ptbr_talents.lua")),
    (require("swse_ptbr_force.lua"))
}

local function mergeCategory(category,pack)
    local source=catalog[category] or {}
    local translated=pack[category] or {}
    for i,pt in ipairs(translated) do
        local item=source[i]
        if item~=nil then
            for k,v in pairs(pt) do
                item[k.."_pt"]=v
            end
        end
    end
end

for _,pack in ipairs(packs) do
    for category,_ in pairs(pack) do
        mergeCategory(category,pack)
    end
end

-- Correção mecânica da matriz de perícias raciais do SagaForge.
-- Essas entradas tornam a perícia de classe; não concedem +5 de treinamento.
local fixedSpeciesClassSkills={
    ["Astromech Droid Chassis"]={"Mechanics"},
    ["Cathar"]={"Climb","Stealth"},
    ["Jawa"]={"Mechanics"},
    ["Mechanic Droid Chassis"]={"Mechanics"},
    ["Medical Droid Chassis"]={"Treat Injury"},
    ["Mrlssi"]={"Mechanics"},
    ["Nosaurian"]={"Climb"},
    ["Probe Droid Chassis"]={"Perception"},
    ["Protocol Droid Chassis"]={"Persuasion"},
    ["Shard (Droid)"]={"Use Computer"},
    ["Shistavanen"]={"Survival"},
    ["Squib"]={"Persuasion"},
    ["Yarkora"]={"Gather Information"}
}
for _,s in ipairs(catalog.species or {}) do
    local cls=fixedSpeciesClassSkills[tostring(s.name or "")]
    if cls~=nil then
        s.class_skills=cls
        local classSet={}
        for _,v in ipairs(cls) do classSet[tostring(v)]=true end
        local trained={}
        for _,v in ipairs(s.trained_skills or {}) do
            if classSet[tostring(v)]~=true then trained[#trained+1]=v end
        end
        s.trained_skills=trained
    end
end

-- Espécies oficiais que não vieram no extrator SagaForge.
local function ensureSpecies(x)
    for _,s in ipairs(catalog.species or {}) do
        if string.lower(tostring(s.name or ""))==string.lower(tostring(x.name or "")) then return end
    end
    catalog.species[#catalog.species+1]=x
end
ensureSpecies({
    name="Nyriaanan", name_pt="Nyriaanan", display="Nyriaanan", display_pt="Nyriaanan",
    source="GoI", ability_mods={0,0,0,0,2,-2},
    languages={"Nyriaanan"}, languages_pt={"Nyriaanan"},
    size="m", speed=6,
    special={"Bonus Feat","Low-Light Vision"},
    special_pt={"Proeza Bônus","Visão na Penumbra"},
    class_skills={"Survival"}, class_skills_pt={"Sobrevivência"},
    skill_focus={}, trained_skills={}, defense_bonus={ref=0,fort=0,will=0,dr=0},
    bonus_feats={},
    racial_abilities="Low-Light Vision",
    racial_abilities_pt="Visão na Penumbra",
    description="Survival is always a class skill. Gains one bonus feat at 1st level. Ignores concealment from darkness, but not total concealment.",
    description_pt="Sobrevivência é sempre uma perícia de classe. Recebe uma Proeza bônus no 1º nível. Ignora ocultação causada por escuridão, mas não ocultação total."
})

-- Duas entradas da árvore Jedi Consular existem na planilha SagaForge,
-- mas ficaram de fora do catálogo extraído originalmente.
local function ensureTalent(x)
    for _,t in ipairs(catalog.talents or {}) do
        if tostring(t.name or "")==tostring(x.name or "") then return end
    end
    catalog.talents[#catalog.talents+1]=x
end
ensureTalent({
    name="Adept Negotiator", name_pt="Negociador Adepto",
    tree="Jedi Consular", tree_pt="Cônsul Jedi",
    description="Move an enemy down the condition track with a Persuasion check against their Will Defense",
    description_pt="Com um teste de Persuasão contra a Defesa de Vontade do alvo, mova um inimigo um passo para baixo na Trilha de Condição.",
    page="39"
})
ensureTalent({
    name="Aggressive Negotiator", name_pt="Negociador Agressivo",
    tree="Jedi Consular", tree_pt="Cônsul Jedi",
    description="Whenever you damage an opponent with lightsaber attack, take 10 on Persuasion until end of next turn",
    description_pt="Quando causar dano a um oponente com um ataque de sabre de luz, você pode Tomar 10 em Persuasão até o fim do seu próximo turno.",
    page="LE 26"
})
ensureTalent({
    name="Stinging Assault", name_pt="Assalto Cortante",
    tree="Weapon Specialist", tree_pt="Especialista em Armas",
    description="When you damage an opponent using a slashing weapon for which you have the Weapon Specialization talent, your opponent takes a -2 penalty on melee attacks against you until your next turn.",
    description_pt="Quando você causa dano com uma arma cortante para a qual possui Especialização em Arma, o oponente sofre -2 nos ataques corpo a corpo contra você até o seu próximo turno.",
    page="SaV 18"
})

-- Entradas confirmadas em suplementos oficiais que não vieram no extrator original.
local function ensureWeapon(x)
    for _,w in ipairs(catalog.weapons or {}) do
        if string.lower(tostring(w.name or ""))==string.lower(tostring(x.name or "")) then return end
    end
    catalog.weapons[#catalog.weapons+1]=x
end
ensureWeapon({
    name="Short Sword", name_pt="Espada Curta", source=",KotOR,", type="M", group="simple",
    size="s", stun="", damage_type="Slashing or Piercing", damage_type_pt="Cortante ou Perfurante",
    special="Deflect incoming melee attacks", special_pt="Arma simples de desenho antigo; apropriada para combate corpo a corpo e uso com duas armas.",
    damage_dice="1d6", cost=40, weight=1.5, ammo="", shots=0, range=""
})
ensureWeapon({
    name="Frag Grenade", name_pt="Granada de Fragmentação", source=",SECR,", type="R", group="simple",
    size="t", stun="", damage_type="Slashing", damage_type_pt="Cortante",
    special="Area Attack; Thrown Weapon; Burst 2 squares", special_pt="Ataque de área; arma arremessada; explosão em Burst 2 quadrados.",
    damage_dice="4d6", cost=200, weight=0.5, ammo="", shots=0, range="grenades",
    availability="Military", availability_pt="Militar"
})


-- Requisitos corrigidos de classes de prestígio ausentes/incompletos na extração SagaForge.
-- Mantém o catálogo visual; corrige somente os dados mecânicos usados pelo validador.
for _,c in ipairs(catalog.classes or {}) do
    if c.name=="Improviser" then
        c.min_level=7
        c.prereqs={"Minimum Level: 7th","Trained Skills: Mechanics, Use Computer","Feat: Skill Focus (Mechanics)"}
    elseif c.name=="Pathfinder" then
        c.min_level=7
        c.prereqs={"Minimum Level: 7th","Trained Skills: Perception, Survival","Talents: Any two from Awareness, Camouflage or Survivor"}
    elseif c.name=="Martial Arts Master" then
        c.min_level=1
        c.prereqs={
            "Minimum Base Attack Bonus: +7",
            "Feats: Martial Arts I, Martial Arts II, Melee Defense, one Martial Arts Training feat",
            "Talents: Any one from Brawler or Survivor"
        }
    end
end

-- Corrige o Utility Belt padrão do Core Rulebook. A linha extraída pelo SagaForge
-- representa incorretamente apenas o cinto vazio (70 cr / 0,6 kg), não o conjunto padrão.
for _,e in ipairs(catalog.equipment or {}) do
    if string.lower(tostring(e.name or ""))=="utility belt" then
        e.name="Utility Belt (Standard)"
        e.name_pt="Cinto Utilitário (Padrão)"
        e.cost=500
        e.weight=4
        e.singular="standard utility belt"
        e.plural="standard utility belts"
        e.singular_pt="cinto utilitário padrão"
        e.plural_pt="cintos utilitários padrão"
        e.description="Includes 3 Ration Packs, 1 Medpac, Tool Kit, 1 Power Pack, Energy Cell, Glow Rod, Short-Range Comlink, and Liquid Cable Dispenser."
        e.description_pt="Inclui 3 Pacotes de Ração, 1 Medpac, Kit de Ferramentas, 1 Pacote de Energia, Célula de Energia, Bastão Luminoso, Comunicador de Curto Alcance e Dispensador de Cabo Líquido."
        break
    end
end
do
    local hasEmpty=false
    for _,e in ipairs(catalog.equipment or {}) do
        if tostring(e.name or "")=="Utility Belt (Empty)" then hasEmpty=true; break end
    end
    if not hasEmpty then
        catalog.equipment[#catalog.equipment+1]={
            name="Utility Belt (Empty)", name_pt="Cinto Utilitário (Vazio)",
            source=",SECR,", cost=55, weight=0.3, category="f",
            singular="empty utility belt", plural="empty utility belts",
            singular_pt="cinto utilitário vazio", plural_pt="cintos utilitários vazios"
        }
    end
end

-- Remove duas linhas-resíduo do SagaForge que são opções de arma/veículo, não Talentos.
do
    local clean={}
    for _,t in ipairs(catalog.talents or {}) do
        local n=string.lower(tostring(t.name or ""))
        if n~="advanced melee" and n~="airspeeder" then clean[#clean+1]=t end
    end
    catalog.talents=clean
end


-- Normaliza Proezas duplicadas trazidas pelo extrator SagaForge.
-- As variantes por arma/perícia são tratadas pelos seletores de opção da ficha,
-- portanto o catálogo deve conter uma única linha-base por Proeza.
do
    local clean={}
    local byName={}
    for _,f in ipairs(catalog.feats or {}) do
        local key=string.lower(tostring(f.name or ""))
        if key~="" then
            local existing=byName[key]
            if existing==nil then
                byName[key]=f
                clean[#clean+1]=f
            else
                -- Prefere preencher campos ausentes sem criar uma segunda opção visual.
                for k,v in pairs(f) do
                    if (existing[k]==nil or tostring(existing[k])=="") and v~=nil and tostring(v)~="" then existing[k]=v end
                end
            end
        end
    end
    catalog.feats=clean
end

-- Corrige/expande armas cuja planilha usa dados especiais em vez de damage_dice.
local function findWeapon(name)
    for _,w in ipairs(catalog.weapons or {}) do
        if string.lower(tostring(w.name or ""))==string.lower(tostring(name or "")) then return w end
    end
end
local function patchWeapon(name,fields)
    local w=findWeapon(name)
    if w~=nil then for k,v in pairs(fields or {}) do w[k]=v end end
    return w
end
local function ensureWeaponRuntime(x)
    if findWeapon(x.name)==nil then catalog.weapons[#catalog.weapons+1]=x end
end

patchWeapon("Power lance",{damage_dice="2d8"})
patchWeapon("Darter",{damage_dice="1"})
patchWeapon("Mine, antivehicle proton",{damage_dice="8d6",damage_type="Energy",damage_type_pt="Energia",special="4-square burst",special_pt="Explosão em raio de 4 quadrados."})

-- Armas exclusivamente de atordoamento.
for name,dice in pairs({
    ["Shock stick"]="3d6",
    ["Electronet"]="3d8",
    ["Snare pistol"]="1d4",
    ["Stun pistol"]="3d6",
    ["Snare rifle"]="1d6",
    ["Concealed dart launcher"]="3d8",
    ["Deck sweeper"]="3d6"
}) do
    patchWeapon(name,{stun_only=true,stun_dice=dice})
end

-- Armas/dispositivos que não causam dano direto: o botão de dano exibe o efeito em vez de inventar 1d1.
for _,name in ipairs({
    "Grenade, gas","Grenade, smoke","Net","R-9 flash canister","Targeting laser","Amphistaff (spit)","Wrist rocket launcher"
}) do
    local w=findWeapon(name)
    if w~=nil then
        w.non_damage=true
        if name=="Wrist rocket launcher" then
            w.special="Damage and special effect are determined by the loaded wrist rocket."
            w.special_pt="O dano e o efeito são determinados pelo foguete de pulso carregado."
        elseif name=="Amphistaff (spit)" then
            w.special="Poison; no direct hit point damage."
            w.special_pt="Veneno; não causa dano direto de Pontos de Vida."
        end
    end
end

-- O Amphistaff genérico é um contêiner de formas na fonte. Expõe as formas jogáveis separadamente.
do
    local clean={}
    for _,w in ipairs(catalog.weapons or {}) do
        if tostring(w.name or "")~="Amphistaff" then clean[#clean+1]=w end
    end
    catalog.weapons=clean
end
ensureWeaponRuntime({
    name="Amphistaff (quarterstaff form)",name_pt="Amphistaff (forma bastão)",source=",SECR,",type="M",group="Amphistaff",size="l",
    stun="",damage_type="Bludgeoning",damage_type_pt="Concussão",special="Double weapon",special_pt="Arma dupla",
    damage_dice="1d6",cost=0,weight=2,ammo="",shots=0,range=""
})
ensureWeaponRuntime({
    name="Amphistaff (spear form)",name_pt="Amphistaff (forma lança)",source=",SECR,",type="M",group="Amphistaff",size="l",
    stun="",damage_type="Piercing",damage_type_pt="Perfurante",special="Poison; can be thrown",special_pt="Veneno; pode ser arremessada",
    damage_dice="1d8",cost=0,weight=2,ammo="",shots=0,range=""
})
ensureWeaponRuntime({
    name="Amphistaff (whip form)",name_pt="Amphistaff (forma chicote)",source=",SECR,",type="M",group="Amphistaff",size="l",
    stun="",damage_type="Piercing",damage_type_pt="Perfurante",special="Poison; reach 2 squares; Pin or Trip",special_pt="Veneno; alcance de 2 quadrados; pode Imobilizar ou Derrubar",
    damage_dice="1d4",cost=0,weight=2,ammo="",shots=0,range=""
})

return catalog
